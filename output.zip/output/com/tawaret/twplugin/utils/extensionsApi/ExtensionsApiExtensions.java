/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  eu.darkbot.api.extensions.FeatureInfo
 *  eu.darkbot.api.managers.ExtensionsAPI
 */
package com.tawaret.twplugin.utils.extensionsApi;

import eu.darkbot.api.extensions.FeatureInfo;
import eu.darkbot.api.managers.ExtensionsAPI;

public class ExtensionsApiExtensions {
    protected static long \u13e8 = 3814976148093623797L;

    public ExtensionsApiExtensions() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x2CAL ^ 0x449C07FF4A0A9A21L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x61C5 ^ 0xFFFF9E3A)) break;
            l2 = 0x23BC ^ 0x6C568EE2;
        }
    }

    public static <T> boolean IsFeatureEnabled(ExtensionsAPI extensionsAPI, Class<T> tClass) {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x576CL ^ 0xCFC747453F850F22L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == (0x15AE ^ 0x15AF)) break;
            l2 = 0x3494 ^ 0xF8ADF2F3;
        }
        FeatureInfo info = extensionsAPI.getFeatureInfo(tClass);
        if (info == null) {
            return (0x3C13 ^ 0x3C13) != 0;
        }
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = \u13e8 - (0x6A7L ^ 0xD8C389B3A1A0E3C4L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l3 == (0x5F35 ^ 0x5F34)) break;
            l3 = 0x5497 ^ 0xE521783A;
        }
        return info.isEnabled();
    }
}

