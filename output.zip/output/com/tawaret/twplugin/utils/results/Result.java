/*
 * Decompiled with CFR 0.152.
 */
package com.tawaret.twplugin.utils.results;

public class Result {
    private final boolean success;
    private final String error;
    static long \u13e8 = 7803864658052099855L;

    private Result(boolean success, String error) {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x2CACL ^ 0xC60A1B45CA00B1EFL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l2 = 0x5012 ^ 0xF44B4F86;
        }
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = \u13e8 - (0x1A1DL ^ 0x81E88EA47256212L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l3 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l3 = 0x47C6 ^ 0x7335FA3E;
        }
        this.success = success;
        while (true) {
            long l;
            long l4;
            if ((l4 = (l = \u13e8 - (3335272959359598144L >>> "\u0000\u0000".length())) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l4 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l4 = 0x4599 ^ 0xBF95C115;
        }
        this.error = error;
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean getSuccess() {
        long l = \u13e8;
        block4: while (true) {
            switch ((int)l) {
                case -86875499: {
                    l = (-3964082859152807736L >>> "\u0000\u0000".length()) / (0x3AF3L ^ 0x2479A92C095930F3L);
                    continue block4;
                }
                case 1382788879: {
                    return this.success;
                }
            }
            break;
        }
        return this.success;
    }

    public String getError() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x4251L ^ 0xCD870E6417FF4A8BL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l2 = 0x7966 ^ 0xF921A3A0;
        }
        if (this.success) {
            while (true) {
                long l;
                long l3;
                if ((l3 = (l = \u13e8 - (0xEE6L ^ 0x216D4D3FD9A89BCCL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (l3 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                l3 = 0x2648 ^ 0xC19ADA5E;
            }
            while (true) {
                long l;
                long l4;
                if ((l4 = (l = \u13e8 - (0x7CD9L ^ 0x2E94D80051FCA691L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (l4 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                l4 = 0x497A ^ 0xEDF32033;
            }
            throw new IllegalStateException();
        }
        while (true) {
            long l;
            long l5;
            if ((l5 = (l = \u13e8 - (0x1431L ^ 0x49CA93E086D5D7EAL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l5 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l5 = 0x6723 ^ 0xCACD0AA2;
        }
        return this.error;
    }

    public static Result Success() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x6E5DL ^ 0xCDFB5846DBB49698L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l2 = 0x364F ^ 0xECF9F97C;
        }
        boolean bl = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = \u13e8 - (0x1DC7L ^ 0x92A25F414C3B9E62L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l3 == (0xD23 ^ 0xD22)) break;
            l3 = 0xE42 ^ 0x715C47DF;
        }
        return new Result(bl, null);
    }

    public static Result Failure(String error) {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x6BCFL ^ 0x5FA33B14C921CE43L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l2 = 0x445D ^ 0xB086DCFA;
        }
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = \u13e8 - (0x732CL ^ 0xA169E1C63DDCB882L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l3 == (0x73D9 ^ 0x73D8)) break;
            l3 = 0x3316 ^ 0x7036AAE8;
        }
        return new Result((0x39EA ^ 0x39EA) != 0, error);
    }
}

