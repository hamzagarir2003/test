/*
 * Decompiled with CFR 0.152.
 */
package com.tawaret.twplugin.utils.results;

public class ResultItem<T> {
    private final boolean success;
    private final String error;
    private final T item;
    public static long \u13e8 = -8452328088384435908L;

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private ResultItem(boolean success, String error, T item) {
        long l = \u13e8;
        boolean bl = true;
        block5: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x943L ^ 0x673EBB2BE04CE481L);
            }
            switch ((int)l) {
                case -825620164: {
                    break block5;
                }
                case 373193461: {
                    l2 = 0x302L ^ 0x59FFF01C5A8AFEFEL;
                    continue block5;
                }
                case 1147309903: {
                    l2 = 8417296611547520184L >>> "\u0000\u0000".length();
                    continue block5;
                }
            }
            break;
        }
        while (true) {
            long l3;
            long l4;
            if ((l4 = (l3 = \u13e8 - (0x1963L ^ 0x8F6B293EA1D4B7B0L)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) continue;
            if (l4 == (0x6E8F ^ 0xFFFF9170)) break;
            l4 = 0x179E ^ 0x5DD5C35C;
        }
        this.success = success;
        while (true) {
            long l5;
            long l6;
            if ((l6 = (l5 = \u13e8 - (0x69DFL ^ 0x85F0BBD77B639E25L)) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) continue;
            if (l6 == (0x1CF9 ^ 0x1CF8)) break;
            l6 = 0x7965 ^ 0xBA186FBA;
        }
        this.error = error;
        while (true) {
            long l7;
            long l8;
            if ((l8 = (l7 = \u13e8 - (0x347EL ^ 0x3A4FA0066BF3DD04L)) == 0L ? 0 : (l7 < 0L ? -1 : 1)) == false) continue;
            if (l8 == (0x4AEF ^ 0xFFFFB510)) {
                this.item = item;
                return;
            }
            l8 = 0x18AC ^ 0x71C5C8B8;
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public boolean getSuccess() {
        long l = \u13e8;
        boolean bl = true;
        block5: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x2462L ^ 0x4E90077AE39CF002L);
            }
            switch ((int)l) {
                case -825620164: {
                    return this.success;
                }
                case -153543505: {
                    l2 = 0x3DB0L ^ 0x4A8F039981A9A70BL;
                    continue block5;
                }
                case 1561233265: {
                    l2 = 0x5F82L ^ 0xC5740396A547CFD0L;
                    continue block5;
                }
            }
            break;
        }
        return this.success;
    }

    /*
     * Unable to fully structure code
     */
    public String getError() {
        block27: {
            v0 = ResultItem.\u13e8;
            if (true) ** GOTO lbl5
            block23: while (true) {
                v0 = v1 / (24954L ^ 6516280196449261186L);
lbl5:
                // 2 sources

                switch ((int)v0) {
                    case -1482131490: {
                        v1 = 19103L ^ 3415209983264056349L;
                        continue block23;
                    }
                    case -825620164: {
                        break block23;
                    }
                    case 71542130: {
                        v1 = 4162756688616637656L >>> "\u0000\u0000".length();
                        continue block23;
                    }
                    case 130176063: {
                        v1 = 10022L ^ 2623449533248727059L;
                        continue block23;
                    }
                }
                break;
            }
            if (!this.success) break block27;
            v2 = ResultItem.\u13e8;
            if (true) ** GOTO lbl22
            block24: while (true) {
                v2 = v3 / (4937L ^ 8418839421717522087L);
lbl22:
                // 2 sources

                switch ((int)v2) {
                    case -1964909189: {
                        v3 = 5372L ^ -7776324014850111514L;
                        continue block24;
                    }
                    case -825620164: {
                        break block24;
                    }
                    case -352896536: {
                        v3 = 7831L ^ -380492825324568596L;
                        continue block24;
                    }
                    case -252833172: {
                        v3 = 14082L ^ -1034873969394962637L;
                        continue block24;
                    }
                }
                break;
            }
            v4 = ResultItem.\u13e8;
            if (true) ** GOTO lbl38
            block25: while (true) {
                v4 = v5 / (13463L ^ -6951088161412013155L);
lbl38:
                // 2 sources

                switch ((int)v4) {
                    case -1923200548: {
                        v5 = 2080L ^ 7763994549283250635L;
                        continue block25;
                    }
                    case -825620164: {
                        break block25;
                    }
                    case -137721753: {
                        v5 = 12782L ^ 7890588683539272259L;
                        continue block25;
                    }
                    case 477272110: {
                        v5 = 24418L ^ 8956109445181334234L;
                        continue block25;
                    }
                }
                break;
            }
            throw new IllegalStateException();
        }
        v6 = ResultItem.\u13e8;
        if (true) ** GOTO lbl56
        block26: while (true) {
            v6 = v7 / (23063L ^ -8006953467724536038L);
lbl56:
            // 2 sources

            switch ((int)v6) {
                case -2083448022: {
                    v7 = 30908L ^ -3293317003954917838L;
                    continue block26;
                }
                case -959924150: {
                    v7 = 3066L ^ 7722581958264409461L;
                    continue block26;
                }
                case -825620164: {
                    break block26;
                }
            }
            break;
        }
        return this.error;
    }

    /*
     * Enabled aggressive block sorting
     */
    public T getItem() {
        long l = \u13e8;
        block8: while (true) {
            switch ((int)l) {
                case -825620164: {
                    break block8;
                }
                case 845915181: {
                    l = (0x77BBL ^ 0xE1BF2F00E2957C0BL) / (0x3ACFL ^ 0xC8C9FA21E2D4930EL);
                    continue block8;
                }
            }
            break;
        }
        if (!this.success) {
            while (true) {
                long l2;
                long l3;
                if ((l3 = (l2 = \u13e8 - (0x5846L ^ 0xE94CE2D1666A92C3L)) == 0L ? 0 : (l2 < 0L ? -1 : 1)) == false) continue;
                if (l3 == (0x10B5 ^ 0xFFFFEF4A)) break;
                l3 = 0x5648 ^ 0xCC45E74A;
            }
            while (true) {
                long l4;
                long l5;
                if ((l5 = (l4 = \u13e8 - (0x578EL ^ 0xF694693B6734C38CL)) == 0L ? 0 : (l4 < 0L ? -1 : 1)) == false) continue;
                if (l5 == (0x6B8D ^ 0xFFFF9472)) {
                    throw new RuntimeException();
                }
                l5 = 0x2E7E ^ 0xEB13D551;
            }
        }
        long l6 = \u13e8;
        block11: while (true) {
            switch ((int)l6) {
                case -825620164: {
                    return this.item;
                }
                case 896749745: {
                    l6 = (0x2483L ^ 0x6568887CB69A623L) / (0x5438L ^ 0x25F81B2EC6593BFBL);
                    continue block11;
                }
            }
            break;
        }
        return this.item;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public static <T> ResultItem<T> Success(T item) {
        long l = \u13e8;
        boolean bl = true;
        block11: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x10EBL ^ 0xA8706BF1971EEF9BL);
            }
            switch ((int)l) {
                case -825620164: {
                    break block11;
                }
                case -483996554: {
                    l2 = 0x4B05L ^ 0x9E8731F1398BF32EL;
                    continue block11;
                }
                case 1984305875: {
                    l2 = 0x7A99L ^ 0xBEF2ACD08FFC06F0L;
                    continue block11;
                }
            }
            break;
        }
        boolean bl2 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        long l3 = \u13e8;
        boolean bl3 = true;
        block12: while (true) {
            long l4;
            if (!bl3 || (bl3 = false) || !true) {
                l3 = l4 / (0x29B6L ^ 0xFCEDCA011A5E6BE7L);
            }
            switch ((int)l3) {
                case -1002086698: {
                    l4 = 0x1F3DL ^ 0x5CE15141E5D64E31L;
                    continue block12;
                }
                case -825620164: {
                    return new ResultItem<T>(bl2, null, item);
                }
                case 100174434: {
                    l4 = 0xB52L ^ 0x57FEAFD3151A34BDL;
                    continue block12;
                }
                case 1805681480: {
                    l4 = 0x2CBBL ^ 0x8716F0BF5EC05E3EL;
                    continue block12;
                }
            }
            break;
        }
        return new ResultItem<T>(bl2, null, item);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static <T> ResultItem<T> Failure(String error) {
        long l = \u13e8;
        block4: while (true) {
            switch ((int)l) {
                case -825620164: {
                    break block4;
                }
                case 1802819486: {
                    l = (0x30E5L ^ 0xC39FA9102F4FDBECL) / (0x1E20L ^ 0xDAB51233805C4F94L);
                    continue block4;
                }
            }
            break;
        }
        boolean bl = "".length() >>> "\u0000\u0000".length();
        while (true) {
            long l2;
            long l3;
            if ((l3 = (l2 = \u13e8 - (-80439401029593012L >>> "\u0000\u0000".length())) == 0L ? 0 : (l2 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l3 == (0x25EB ^ 0xFFFFDA14)) {
                return new ResultItem<Object>(bl, error, null);
            }
            l3 = 0x4136 ^ 0xC99E9DFA;
        }
    }
}

