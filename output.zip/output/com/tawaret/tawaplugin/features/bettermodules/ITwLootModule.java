/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.core.entities.Npc
 */
package com.tawaret.tawaplugin.features.bettermodules;

import com.github.manolo8.darkbot.core.entities.Npc;
import java.util.function.BooleanSupplier;

public interface ITwLootModule {
    public Npc getAttackTarget();

    public boolean checkDangerousAndCurrentMapPub(BooleanSupplier var1);

    public boolean findTargetPub();

    public void moveToSafePosition();

    public void ignoreTarget();

    public void doAttackKillTargetTick();

    public boolean npcSubnameInPreferredRegion(String var1);
}

