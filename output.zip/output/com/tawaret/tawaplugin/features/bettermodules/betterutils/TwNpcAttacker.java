/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.Main
 *  com.github.manolo8.darkbot.config.NpcExtra
 *  com.github.manolo8.darkbot.config.NpcExtraFlag
 *  com.github.manolo8.darkbot.core.api.Capability
 *  com.github.manolo8.darkbot.core.entities.Entity
 *  com.github.manolo8.darkbot.core.entities.FakeNpc
 *  com.github.manolo8.darkbot.core.entities.Npc
 *  com.github.manolo8.darkbot.core.entities.Ship
 *  com.github.manolo8.darkbot.core.itf.Configurable
 *  com.github.manolo8.darkbot.core.manager.EffectManager$Effect
 *  com.github.manolo8.darkbot.core.manager.HeroManager
 *  com.github.manolo8.darkbot.core.manager.MapManager
 *  com.github.manolo8.darkbot.core.objects.facades.SettingsProxy
 *  com.github.manolo8.darkbot.core.objects.facades.SettingsProxy$KeyBind
 *  com.github.manolo8.darkbot.core.objects.slotbars.CategoryBar
 *  com.github.manolo8.darkbot.core.objects.slotbars.Item
 *  com.github.manolo8.darkbot.core.utils.Drive
 *  com.github.manolo8.darkbot.extensions.features.Feature
 *  com.github.manolo8.darkbot.extensions.features.handlers.LaserSelectorHandler
 *  eu.darkbot.api.extensions.selectors.LaserSelector
 *  eu.darkbot.api.extensions.selectors.PrioritizedSupplier
 *  eu.darkbot.api.extensions.selectors.PrioritizedSupplier$Priority
 *  eu.darkbot.api.game.items.Item
 *  eu.darkbot.api.game.items.SelectableItem
 *  eu.darkbot.api.game.items.SelectableItem$Laser
 *  eu.darkbot.api.game.other.Lockable
 *  eu.darkbot.api.managers.AttackAPI
 *  eu.darkbot.api.managers.HeroAPI
 *  eu.darkbot.api.managers.HeroItemsAPI
 */
package com.tawaret.tawaplugin.features.bettermodules.betterutils;

import com.github.manolo8.darkbot.Main;
import com.github.manolo8.darkbot.config.NpcExtra;
import com.github.manolo8.darkbot.config.NpcExtraFlag;
import com.github.manolo8.darkbot.core.api.Capability;
import com.github.manolo8.darkbot.core.entities.Entity;
import com.github.manolo8.darkbot.core.entities.FakeNpc;
import com.github.manolo8.darkbot.core.entities.Npc;
import com.github.manolo8.darkbot.core.entities.Ship;
import com.github.manolo8.darkbot.core.itf.Configurable;
import com.github.manolo8.darkbot.core.manager.EffectManager;
import com.github.manolo8.darkbot.core.manager.HeroManager;
import com.github.manolo8.darkbot.core.manager.MapManager;
import com.github.manolo8.darkbot.core.objects.facades.SettingsProxy;
import com.github.manolo8.darkbot.core.objects.slotbars.CategoryBar;
import com.github.manolo8.darkbot.core.objects.slotbars.Item;
import com.github.manolo8.darkbot.core.utils.Drive;
import com.github.manolo8.darkbot.extensions.features.Feature;
import com.github.manolo8.darkbot.extensions.features.handlers.LaserSelectorHandler;
import com.tawaret.tawaplugin.features.bettermodules.TwLootModuleConfig;
import com.tawaret.tawaplugin.logging.ILoggable;
import eu.darkbot.api.extensions.selectors.LaserSelector;
import eu.darkbot.api.extensions.selectors.PrioritizedSupplier;
import eu.darkbot.api.game.items.SelectableItem;
import eu.darkbot.api.game.other.Lockable;
import eu.darkbot.api.managers.AttackAPI;
import eu.darkbot.api.managers.HeroAPI;
import eu.darkbot.api.managers.HeroItemsAPI;
import java.lang.invoke.LambdaMetafactory;
import java.util.function.Function;

public class TwNpcAttacker
implements Configurable<TwLootModuleConfig>,
AttackAPI,
ILoggable {
    private static TwNpcAttacker caller;
    protected Main main;
    protected MapManager mapManager;
    protected HeroManager hero;
    protected Drive drive;
    protected final SettingsProxy keybinds;
    protected final CategoryBar bar;
    private final HeroItemsAPI items;
    private final LaserSelectorHandler laserHandler;
    public Npc target;
    protected Long ability;
    protected long clickDelay;
    protected long laserTime;
    protected long isAttacking;
    protected int fixedTimes;
    protected boolean firstAttack;
    protected Character lastShot;
    @Deprecated
    protected boolean sab;
    @Deprecated
    protected boolean rsb;
    @Deprecated
    protected long usedRsb;
    private TwLootModuleConfig config;
    public static long \u13e8 = -5622204941366263229L;

    /*
     * Unable to fully structure code
     */
    public TwNpcAttacker(Main main) {
        while (true) {
            if ((v0 = (cfr_temp_0 = TwNpcAttacker.\u13e8 - (3078L ^ -4436980745050466365L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (17033 ^ -17034)) break;
            v0 = 25548 ^ 2029218422;
        }
        super();
        v1 = TwNpcAttacker.\u13e8;
        if (true) ** GOTO lbl11
        block68: while (true) {
            v1 = v2 / (7435L ^ 6983726044271468535L);
lbl11:
            // 2 sources

            switch ((int)v1) {
                case -1083506109: {
                    break block68;
                }
                case 70023565: {
                    v2 = 15467L ^ -756283564488760056L;
                    continue block68;
                }
                case 1692137952: {
                    v2 = 12938L ^ 3345261390055148917L;
                    continue block68;
                }
            }
            break;
        }
        while (true) {
            if ((v3 = (cfr_temp_1 = TwNpcAttacker.\u13e8 - (19674L ^ -3567689268464103806L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v3 == (28899 ^ -28900)) break;
            v3 = 22589 ^ -1890553493;
        }
        v4 = new TwLootModuleConfig();
        while (true) {
            if ((v5 = (cfr_temp_2 = TwNpcAttacker.\u13e8 - (1338L ^ -3776688081455547463L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v5 == (14315 ^ -14316)) break;
            v5 = 6743 ^ -1076347566;
        }
        this.config = v4;
        v6 = TwNpcAttacker.\u13e8;
        if (true) ** GOTO lbl36
        block71: while (true) {
            v6 = v7 / (10811L ^ -4361664822721677210L);
lbl36:
            // 2 sources

            switch ((int)v6) {
                case -1993715266: {
                    v7 = 29267L ^ 4072167659626180360L;
                    continue block71;
                }
                case -1083506109: {
                    break block71;
                }
                case 831053297: {
                    v7 = 9524L ^ 6538440978120609059L;
                    continue block71;
                }
            }
            break;
        }
        this.main = main;
        while (true) {
            if ((v8 = (cfr_temp_3 = TwNpcAttacker.\u13e8 - (28364L ^ 4233167713271460121L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v8 == (700 ^ -701)) break;
            v8 = 24341 ^ -105086437;
        }
        v9 = main.mapManager;
        while (true) {
            if ((v10 = (cfr_temp_4 = TwNpcAttacker.\u13e8 - (17935L ^ 5948055664503063921L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v10 == (16499 ^ -16500)) break;
            v10 = 7479 ^ 1766127510;
        }
        this.mapManager = v9;
        while (true) {
            if ((v11 = (cfr_temp_5 = TwNpcAttacker.\u13e8 - (18159L ^ 5351578547422801596L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
            if (v11 == (22053 ^ -22054)) break;
            v11 = -1210897572 >>> "\u0000\u0000".length();
        }
        v12 = main.hero;
        v13 = TwNpcAttacker.\u13e8;
        if (true) ** GOTO lbl68
        block75: while (true) {
            v13 = v14 / (32400L ^ 7757574627318042150L);
lbl68:
            // 2 sources

            switch ((int)v13) {
                case -1802324199: {
                    v14 = 20427L ^ -4206898427456867820L;
                    continue block75;
                }
                case -1083506109: {
                    break block75;
                }
                case -544092809: {
                    v14 = 23488L ^ 6975828291133194335L;
                    continue block75;
                }
            }
            break;
        }
        this.hero = v12;
        while (true) {
            if ((v15 = (cfr_temp_6 = TwNpcAttacker.\u13e8 - (8473L ^ -7681892721107327027L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
            if (v15 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v15 = 24709 ^ 597498831;
        }
        while (true) {
            if ((v16 = (cfr_temp_7 = TwNpcAttacker.\u13e8 - (12981L ^ -5448765358690378764L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
            if (v16 == (30711 ^ -30712)) break;
            v16 = 31350 ^ 1976531988;
        }
        v17 = this.hero.drive;
        while (true) {
            if ((v18 = (cfr_temp_8 = TwNpcAttacker.\u13e8 - (3210L ^ 8366877789459420452L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
            if (v18 == (16206 ^ -16207)) break;
            v18 = 18270 ^ -1105758002;
        }
        this.drive = v17;
        v19 = TwNpcAttacker.\u13e8;
        if (true) ** GOTO lbl99
        block79: while (true) {
            v19 = (11531L ^ -5072865208953276309L) / (32240L ^ 1871231167442296127L);
lbl99:
            // 2 sources

            switch ((int)v19) {
                case -1083506109: {
                    break block79;
                }
                case -84607666: {
                    continue block79;
                }
            }
            break;
        }
        v20 = main.facadeManager;
        v21 = TwNpcAttacker.\u13e8;
        if (true) ** GOTO lbl109
        block80: while (true) {
            v21 = v22 / (10891L ^ 8766318852769724170L);
lbl109:
            // 2 sources

            switch ((int)v21) {
                case -1083506109: {
                    break block80;
                }
                case 52372203: {
                    v22 = 8072L ^ 3641393425901049351L;
                    continue block80;
                }
                case 459598364: {
                    v22 = 2256411639526857760L >>> "\u0000\u0000".length();
                    continue block80;
                }
            }
            break;
        }
        v23 = v20.settings;
        v24 = TwNpcAttacker.\u13e8;
        if (true) ** GOTO lbl123
        block81: while (true) {
            v24 = v25 / (13254L ^ -7495751911585997974L);
lbl123:
            // 2 sources

            switch ((int)v24) {
                case -2134053435: {
                    v25 = 12201L ^ -6850751022114994692L;
                    continue block81;
                }
                case -1083506109: {
                    break block81;
                }
                case -41153282: {
                    v25 = 5497L ^ -8376021694850365442L;
                    continue block81;
                }
                case 367900981: {
                    v25 = 17453L ^ -5377095178139189325L;
                    continue block81;
                }
            }
            break;
        }
        this.keybinds = v23;
        v26 = TwNpcAttacker.\u13e8;
        if (true) ** GOTO lbl140
        block82: while (true) {
            v26 = (3315658076653891520L >>> "\u0000\u0000".length()) / (13172L ^ -8275482285361986483L);
lbl140:
            // 2 sources

            switch ((int)v26) {
                case -1083506109: {
                    break block82;
                }
                case 1287798683: {
                    continue block82;
                }
            }
            break;
        }
        v27 = main.facadeManager;
        while (true) {
            if ((v28 = (cfr_temp_9 = TwNpcAttacker.\u13e8 - (28604L ^ -1401073477185195726L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
            if (v28 == (27011 ^ -27012)) break;
            v28 = 1743 ^ -703573907;
        }
        v29 = v27.slotBars;
        v30 = TwNpcAttacker.\u13e8;
        if (true) ** GOTO lbl156
        block84: while (true) {
            v30 = v31 / (-3647353884080201360L >>> "\u0000\u0000".length());
lbl156:
            // 2 sources

            switch ((int)v30) {
                case -1083506109: {
                    break block84;
                }
                case 235419160: {
                    v31 = -1385701198605268028L >>> "\u0000\u0000".length();
                    continue block84;
                }
                case 1530262380: {
                    v31 = 8670L ^ 9171469107412404653L;
                    continue block84;
                }
            }
            break;
        }
        v32 = v29.categoryBar;
        v33 = TwNpcAttacker.\u13e8;
        if (true) ** GOTO lbl170
        block85: while (true) {
            v33 = (6208566361950693068L >>> "\u0000\u0000".length()) / (9174L ^ 6056624893793897762L);
lbl170:
            // 2 sources

            switch ((int)v33) {
                case -1083506109: {
                    break block85;
                }
                case -246499777: {
                    continue block85;
                }
            }
            break;
        }
        this.bar = v32;
        v34 = TwNpcAttacker.\u13e8;
        if (true) ** GOTO lbl180
        block86: while (true) {
            v34 = (19175L ^ -6650668266905097788L) / (13735L ^ -8241989448583413463L);
lbl180:
            // 2 sources

            switch ((int)v34) {
                case -1083506109: {
                    break block86;
                }
                case 347339034: {
                    continue block86;
                }
            }
            break;
        }
        v35 = main.pluginAPI;
        v36 = TwNpcAttacker.\u13e8;
        if (true) ** GOTO lbl190
        block87: while (true) {
            v36 = (11122L ^ -411956840011562613L) / (18752L ^ 8928219513271215012L);
lbl190:
            // 2 sources

            switch ((int)v36) {
                case -1943582095: {
                    continue block87;
                }
                case -1083506109: {
                    break block87;
                }
            }
            break;
        }
        v37 = (HeroItemsAPI)v35.getAPI(HeroItemsAPI.class);
        v38 = TwNpcAttacker.\u13e8;
        if (true) ** GOTO lbl200
        block88: while (true) {
            v38 = v39 / (895301594811280172L >>> "\u0000\u0000".length());
lbl200:
            // 2 sources

            switch ((int)v38) {
                case -1758591774: {
                    v39 = 297L ^ -3855670473686739630L;
                    continue block88;
                }
                case -1083506109: {
                    break block88;
                }
                case -598408972: {
                    v39 = 22389L ^ -6579986324208361645L;
                    continue block88;
                }
                case 612729626: {
                    v39 = 157L ^ -5799341545111651857L;
                    continue block88;
                }
            }
            break;
        }
        this.items = v37;
        v40 = TwNpcAttacker.\u13e8;
        if (true) ** GOTO lbl217
        block89: while (true) {
            v40 = (5589L ^ -3881577581023028799L) / (18028L ^ -1738770528058578583L);
lbl217:
            // 2 sources

            switch ((int)v40) {
                case -1083506109: {
                    break block89;
                }
                case 825936469: {
                    continue block89;
                }
            }
            break;
        }
        v41 = main.pluginAPI;
        while (true) {
            if ((v42 = (cfr_temp_10 = TwNpcAttacker.\u13e8 - (8945L ^ 4108406644156524452L)) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
            if (v42 == (6395 ^ -6396)) break;
            v42 = 26593 ^ -749630800;
        }
        v43 = (LaserSelectorHandler)v41.requireInstance(LaserSelectorHandler.class);
        v44 = TwNpcAttacker.\u13e8;
        if (true) ** GOTO lbl233
        block91: while (true) {
            v44 = v45 / (6221L ^ 7853647645518890585L);
lbl233:
            // 2 sources

            switch ((int)v44) {
                case -1969561114: {
                    v45 = 19607L ^ 344354502330243901L;
                    continue block91;
                }
                case -1202043089: {
                    v45 = 4430L ^ -5152504099343058303L;
                    continue block91;
                }
                case -1083506109: {
                    break block91;
                }
                case 634746262: {
                    v45 = 10887L ^ -5048100201244673208L;
                    continue block91;
                }
            }
            break;
        }
        this.laserHandler = v43;
    }

    /*
     * Unable to fully structure code
     */
    public String status() {
        block51: {
            block50: {
                while (true) {
                    if ((v0 = (cfr_temp_0 = TwNpcAttacker.\u13e8 - (9599L ^ -5911155351291098069L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                    if (v0 == (6225 ^ 6224)) break;
                    v0 = 29997 ^ 1023769595;
                }
                if (this.target == null) break block50;
                v1 = TwNpcAttacker.\u13e8;
                if (true) ** GOTO lbl11
                block36: while (true) {
                    v1 = (11393L ^ -990982098189266052L) / (10578L ^ -5430889310992417381L);
lbl11:
                    // 2 sources

                    switch ((int)v1) {
                        case -1083506109: {
                            break block36;
                        }
                        case -880103070: {
                            continue block36;
                        }
                    }
                    break;
                }
                v2 = TwNpcAttacker.\u13e8;
                if (true) ** GOTO lbl20
                block37: while (true) {
                    v2 = (3371L ^ -9029655140973947178L) / (27628L ^ 8463784664738894266L);
lbl20:
                    // 2 sources

                    switch ((int)v2) {
                        case -1083506109: {
                            break block37;
                        }
                        case 1917567902: {
                            continue block37;
                        }
                    }
                    break;
                }
                v3 = new StringBuilder();
                var2_1 = new byte["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
                var2_1[19561 ^ 19560] = 30582 ^ -30504;
                var2_1["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 420 >>> "\u0000\u0000".length();
                var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 420 >>> "\u0000\u0000".length();
                var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 25130 ^ 25156;
                var2_1[15590 ^ 15599] = 9842 ^ 9730;
                var2_1[18679 ^ 18685] = 396 >>> "\u0000\u0000".length();
                var2_1[32642 ^ 32641] = 432 >>> "\u0000\u0000".length();
                var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 15625 ^ 15719;
                var2_1[25614 ^ 25609] = 5874 ^ 5842;
                var2_1[20622 ^ 20622] = 300 >>> "\u0000\u0000".length();
                var2_1[2098 ^ 2096] = 9804 ^ 9760;
                var2_1[24098 ^ 24100] = 412 >>> "\u0000\u0000".length();
                v4 = new String(var2_1);
                while (true) {
                    if ((v5 = (cfr_temp_1 = TwNpcAttacker.\u13e8 - (-7657771991113612980L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                    if (v5 == (12106 ^ -12107)) break;
                    v5 = 7486 ^ -1588761561;
                }
                v6 = v3.append(v4);
                v7 = TwNpcAttacker.\u13e8;
                if (true) ** GOTO lbl50
                block39: while (true) {
                    v7 = v8 / (19381L ^ -2260175638820908377L);
lbl50:
                    // 2 sources

                    switch ((int)v7) {
                        case -2136229215: {
                            v8 = 8001L ^ -2656559547491995207L;
                            continue block39;
                        }
                        case -1083506109: {
                            break block39;
                        }
                        case 358485172: {
                            v8 = 13446L ^ 8251435955222337205L;
                            continue block39;
                        }
                        case 2133318142: {
                            v8 = 31434L ^ 4649333116382603204L;
                            continue block39;
                        }
                    }
                    break;
                }
                v9 = TwNpcAttacker.\u13e8;
                if (true) ** GOTO lbl66
                block40: while (true) {
                    v9 = v10 / (28460L ^ 6177127617387072863L);
lbl66:
                    // 2 sources

                    switch ((int)v9) {
                        case -1083506109: {
                            break block40;
                        }
                        case 241618897: {
                            v10 = 1224293906621252112L >>> "\u0000\u0000".length();
                            continue block40;
                        }
                        case 1657084757: {
                            v10 = 7724L ^ -3879290685327543631L;
                            continue block40;
                        }
                    }
                    break;
                }
                while (true) {
                    if ((v11 = (cfr_temp_2 = TwNpcAttacker.\u13e8 - (22571L ^ 5058723608536163992L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                    if (v11 == (29494 ^ -29495)) break;
                    v11 = 20665 ^ -878846341;
                }
                if (this.hero.isAttacking((Ship)this.target)) {
                    var2_1 = new byte["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
                    var2_1[2068 ^ 2069] = 360 >>> "\u0000\u0000".length();
                    var2_1[21510 ^ 21511] = 6025 ^ 6106;
                    var2_1[30524 ^ 30524] = 15117 ^ 15149;
                    v12 = new String(var2_1);
                } else {
                    var2_1 = new byte["".length() >>> "\u0000\u0000".length()];
                    v12 = new String(var2_1);
                }
                v13 = TwNpcAttacker.\u13e8;
                if (true) ** GOTO lbl93
                block42: while (true) {
                    v13 = v14 / (13193L ^ -2904990927048042160L);
lbl93:
                    // 2 sources

                    switch ((int)v13) {
                        case -1083506109: {
                            break block42;
                        }
                        case -761248541: {
                            v14 = 2772L ^ -6590752208542189309L;
                            continue block42;
                        }
                        case 700377911: {
                            v14 = 30541L ^ -6477965154473085309L;
                            continue block42;
                        }
                        case 1421238459: {
                            v14 = 17681L ^ -3290350024441383758L;
                            continue block42;
                        }
                    }
                    break;
                }
                v15 = v6.append(v12);
                while (true) {
                    if ((v16 = (cfr_temp_3 = TwNpcAttacker.\u13e8 - (16368L ^ 2693672526958314901L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                    if (v16 == (9201 ^ -9202)) break;
                    v16 = 17039 ^ 657873154;
                }
                if (this.ability != null) {
                    var2_1 = new byte[3588 ^ 3590];
                    var2_1["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 29594 ^ -29609;
                    var2_1["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 9707 ^ 9642;
                    var2_1[30867 ^ 30867] = 4033 ^ 4065;
                    v17 = new String(var2_1);
                } else {
                    var2_1 = new byte["".length() >>> "\u0000\u0000".length()];
                    v17 = new String(var2_1);
                }
                v18 = TwNpcAttacker.\u13e8;
                if (true) ** GOTO lbl124
                block44: while (true) {
                    v18 = v19 / (12846L ^ 8291335293150281297L);
lbl124:
                    // 2 sources

                    switch ((int)v18) {
                        case -1327032628: {
                            v19 = 31097L ^ -557733047870725084L;
                            continue block44;
                        }
                        case -1083506109: {
                            break block44;
                        }
                        case -489271558: {
                            v19 = 24437L ^ -9126793068919146379L;
                            continue block44;
                        }
                        case -89843440: {
                            v19 = 24110L ^ -7722643258076371788L;
                            continue block44;
                        }
                    }
                    break;
                }
                v20 = v15.append(v17);
                v21 = TwNpcAttacker.\u13e8;
                if (true) ** GOTO lbl141
                block45: while (true) {
                    v21 = (8739L ^ -7335017601612952270L) / (5137L ^ -8361350724892328221L);
lbl141:
                    // 2 sources

                    switch ((int)v21) {
                        case -1897307981: {
                            continue block45;
                        }
                        case -1083506109: {
                            break block45;
                        }
                    }
                    break;
                }
                v22 = v20.toString();
                break block51;
            }
            var2_2 = new byte[13024 ^ 13028];
            var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
            var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 432 >>> "\u0000\u0000".length();
            var2_2["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 400 >>> "\u0000\u0000".length();
            var2_2["".length() >>> "\u0000\u0000".length()] = 27965 ^ 28020;
            var2_2[12667 ^ 12664] = 23107 ^ 23078;
            v22 = new String(var2_2);
        }
        return v22;
    }

    public boolean castingAbility() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x4AD3L ^ 0x82073704B3EE4BB7L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l2 = 0x65A3 ^ 0xB7141DB1;
        }
        return (this.ability != null ? 0xAAF ^ 0xAAE : "".length() >>> "\u0000\u0000".length()) != 0;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public boolean hasTarget() {
        int n;
        block19: {
            long l = \u13e8;
            boolean bl = true;
            block10: while (true) {
                long l2;
                if (!bl || (bl = false) || !true) {
                    l = l2 / (-2125767403365385416L >>> "\u0000\u0000".length());
                }
                switch ((int)l) {
                    case -1365944443: {
                        l2 = 0x6180L ^ 0x4A3B95B0545D1793L;
                        continue block10;
                    }
                    case -1083506109: {
                        break block10;
                    }
                    case 317529181: {
                        l2 = 0x4A43L ^ 0x3A351D9BEE1A5100L;
                        continue block10;
                    }
                }
                break;
            }
            if (this.target != null) {
                long l3 = \u13e8;
                boolean bl2 = true;
                block11: while (true) {
                    long l4;
                    if (!bl2 || (bl2 = false) || !true) {
                        l3 = l4 / (0x2F1L ^ 0xBE9E86BA5578DDDDL);
                    }
                    switch ((int)l3) {
                        case -1297360827: {
                            l4 = -6845742268249213096L >>> "\u0000\u0000".length();
                            continue block11;
                        }
                        case -1083506109: {
                            break block11;
                        }
                        case 458753919: {
                            l4 = 0x3411L ^ 0x4B27532E93877E10L;
                            continue block11;
                        }
                    }
                    break;
                }
                while (true) {
                    long l5;
                    long l6;
                    if ((l6 = (l5 = \u13e8 - (-8852324154049049976L >>> "\u0000\u0000".length())) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) {
                        continue;
                    }
                    if (l6 == (0x48CC ^ 0xFFFFB733)) {
                        if (!this.target.removed) {
                            break;
                        }
                        break block19;
                    }
                    l6 = 0x3E8E ^ 0xD41371EF;
                }
                n = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
                return n != 0;
            }
        }
        n = "".length() >>> "\u0000\u0000".length();
        return n != 0;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public boolean isBugged() {
        int n;
        long l = \u13e8;
        boolean bl = true;
        block6: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x3451L ^ 0xD2C9A2B1A3F8AC2BL);
            }
            switch ((int)l) {
                case -2016896229: {
                    l2 = 0x2642L ^ 0x93B2170214F2AA3FL;
                    continue block6;
                }
                case -1083506109: {
                    break block6;
                }
                case 123779498: {
                    l2 = 0x71D9L ^ 0xF582EEEF2628F501L;
                    continue block6;
                }
                case 378000495: {
                    l2 = 0x71CBL ^ 0xE05203E37D678339L;
                    continue block6;
                }
            }
            break;
        }
        if (this.fixedTimes > (0x6A1C ^ 0x6A19)) {
            n = 0x7E6E ^ 0x7E6F;
            return n != 0;
        }
        n = "".length() >>> "\u0000\u0000".length();
        return n != 0;
    }

    /*
     * Unable to fully structure code
     */
    private void instantAttack(Entity entity) {
        while (true) {
            if ((v0 = (cfr_temp_0 = TwNpcAttacker.\u13e8 - (-7753075179201492640L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (10066 ^ -10067)) break;
            v0 = 32559 ^ -1129279414;
        }
        v1 = TwNpcAttacker.\u13e8;
        if (true) ** GOTO lbl10
        block44: while (true) {
            v1 = v2 / (3570L ^ -7472342045808985403L);
lbl10:
            // 2 sources

            switch ((int)v1) {
                case -1083506109: {
                    break block44;
                }
                case -195224979: {
                    v2 = 32062L ^ -3494337513306437941L;
                    continue block44;
                }
                case 1346870340: {
                    v2 = 5586L ^ 2988391557200215469L;
                    continue block44;
                }
            }
            break;
        }
        v3 = TwNpcAttacker.\u13e8;
        if (true) ** GOTO lbl23
        block45: while (true) {
            v3 = (26426L ^ 7356075567935915820L) / (7520L ^ -4831749153814753125L);
lbl23:
            // 2 sources

            switch ((int)v3) {
                case -1083506109: {
                    break block45;
                }
                case 1021272344: {
                    continue block45;
                }
            }
            break;
        }
        while (true) {
            if ((v4 = (cfr_temp_1 = TwNpcAttacker.\u13e8 - (6530L ^ -1920569683241188855L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v4 == (29912 ^ -29913)) break;
            v4 = 2682 ^ 1551500977;
        }
        v5 = this.main.mapManager;
        v6 = TwNpcAttacker.\u13e8;
        if (true) ** GOTO lbl38
        block47: while (true) {
            v6 = (24834L ^ 7806132017520617169L) / (2769L ^ 7720562306978821124L);
lbl38:
            // 2 sources

            switch ((int)v6) {
                case -1968059004: {
                    continue block47;
                }
                case -1083506109: {
                    break block47;
                }
            }
            break;
        }
        v7 = v5.mapAddress;
        v8 = new int[18849 ^ 18848];
        v8["".length() >>> "\u0000\u0000".length()] = 30286 ^ 30262;
        while (true) {
            if ((v9 = (cfr_temp_2 = TwNpcAttacker.\u13e8 - (25993L ^ 2066543817233705711L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v9 == (28121 ^ -28122)) break;
            v9 = 30910 ^ 1234813496;
        }
        v10 = Main.API.readMemoryLong(v7, v8) + (20895L ^ 20919L);
        v11 = TwNpcAttacker.\u13e8;
        if (true) ** GOTO lbl56
        block49: while (true) {
            v11 = v12 / (24299L ^ -2670652873544734991L);
lbl56:
            // 2 sources

            switch ((int)v11) {
                case -1492316905: {
                    v12 = 27085L ^ -6079245648315199436L;
                    continue block49;
                }
                case -1083506109: {
                    break block49;
                }
                case -62234960: {
                    v12 = 31063L ^ 1100204297879971112L;
                    continue block49;
                }
                case 1333703452: {
                    v12 = 20709L ^ -2919769810998515521L;
                    continue block49;
                }
            }
            break;
        }
        v13 = entity.address;
        v14 = TwNpcAttacker.\u13e8;
        if (true) ** GOTO lbl73
        block50: while (true) {
            v14 = (21893L ^ -5990258018228620606L) / (18280L ^ 4941767172333690753L);
lbl73:
            // 2 sources

            switch ((int)v14) {
                case -1083506109: {
                    break block50;
                }
                case -283233365: {
                    continue block50;
                }
            }
            break;
        }
        Main.API.writeMemoryLong(v10, v13);
        v15 = TwNpcAttacker.\u13e8;
        if (true) ** GOTO lbl83
        block51: while (true) {
            v15 = v16 / (584L ^ 2420252431631087523L);
lbl83:
            // 2 sources

            switch ((int)v15) {
                case -2013671350: {
                    v16 = 20177L ^ -6309156590942215720L;
                    continue block51;
                }
                case -1083506109: {
                    break block51;
                }
                case 136928859: {
                    v16 = 897L ^ -4836478691217362754L;
                    continue block51;
                }
                case 1581057945: {
                    v16 = 28027L ^ -855443335393236848L;
                    continue block51;
                }
            }
            break;
        }
        v17 = TwNpcAttacker.\u13e8;
        if (true) ** GOTO lbl99
        block52: while (true) {
            v17 = (3680889062264460464L >>> "\u0000\u0000".length()) / (6393351533011010944L >>> "\u0000\u0000".length());
lbl99:
            // 2 sources

            switch ((int)v17) {
                case -1083506109: {
                    break block52;
                }
                case -280499657: {
                    continue block52;
                }
            }
            break;
        }
        v18 = this.main.facadeManager;
        v19 = TwNpcAttacker.\u13e8;
        if (true) ** GOTO lbl109
        block53: while (true) {
            v19 = v20 / (6756323449977077668L >>> "\u0000\u0000".length());
lbl109:
            // 2 sources

            switch ((int)v19) {
                case -1083506109: {
                    break block53;
                }
                case 168481826: {
                    v20 = 12627L ^ 6442580606402677958L;
                    continue block53;
                }
                case 1601187419: {
                    v20 = 27918L ^ -2568730013463718043L;
                    continue block53;
                }
            }
            break;
        }
        v21 = v18.settings;
        while (true) {
            if ((v22 = (cfr_temp_3 = TwNpcAttacker.\u13e8 - (31186L ^ 2538530915923747719L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v22 == (10492 ^ -10493)) break;
            v22 = 23147 ^ -734640736;
        }
        v23 = TwNpcAttacker.\u13e8;
        if (true) ** GOTO lbl128
        block55: while (true) {
            v23 = v24 / (3099L ^ 1712308335219796152L);
lbl128:
            // 2 sources

            switch ((int)v23) {
                case -2057969513: {
                    v24 = 31024L ^ -6945927636138823364L;
                    continue block55;
                }
                case -1083506109: {
                    break block55;
                }
                case 231005375: {
                    v24 = 149L ^ 2838760000690286485L;
                    continue block55;
                }
            }
            break;
        }
        v21.pressKeybind(SettingsProxy.KeyBind.ATTACK_LASER);
    }

    /*
     * Unable to fully structure code
     */
    public void doKillTargetTick() {
        block111: {
            block114: {
                block113: {
                    block112: {
                        v0 = TwNpcAttacker.\u13e8;
                        if (true) ** GOTO lbl5
                        block74: while (true) {
                            v0 = v1 / (19745L ^ 4036694233997086228L);
lbl5:
                            // 2 sources

                            switch ((int)v0) {
                                case -1083506109: {
                                    break block74;
                                }
                                case 398458552: {
                                    v1 = 28309L ^ 4831111837105639518L;
                                    continue block74;
                                }
                                case 1309036639: {
                                    v1 = 16805L ^ -4846633215305807233L;
                                    continue block74;
                                }
                            }
                            break;
                        }
                        if (this.target == null) break block112;
                        while (true) {
                            if ((v2 = (cfr_temp_0 = TwNpcAttacker.\u13e8 - (12940L ^ -1660130945840332290L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                            if (v2 == (14258 ^ -14259)) break;
                            v2 = 9163 ^ 237160141;
                        }
                        if (!(this.target instanceof FakeNpc)) break block113;
                    }
                    return;
                }
                while (true) {
                    if ((v3 = (cfr_temp_1 = TwNpcAttacker.\u13e8 - (30036L ^ -7520723326110311073L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                    if (v3 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                    v3 = 23188 ^ 405056714;
                }
                v4 = TwNpcAttacker.\u13e8;
                if (true) ** GOTO lbl33
                block77: while (true) {
                    v4 = (16720L ^ -9223040675381186340L) / (3923L ^ 2165888525817227360L);
lbl33:
                    // 2 sources

                    switch ((int)v4) {
                        case -1083506109: {
                            break block77;
                        }
                        case 1247846564: {
                            continue block77;
                        }
                    }
                    break;
                }
                while (true) {
                    if ((v5 = (cfr_temp_2 = TwNpcAttacker.\u13e8 - (7639646386288578912L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                    if (v5 == (6495 ^ -6496)) break;
                    v5 = 28070 ^ -293924854;
                }
                if (this.mapManager.isTarget((Entity)this.target)) break block114;
                v6 = TwNpcAttacker.\u13e8;
                if (true) ** GOTO lbl48
                block79: while (true) {
                    v6 = (10196L ^ 1993450649180235536L) / (2116L ^ -4798095241706732022L);
lbl48:
                    // 2 sources

                    switch ((int)v6) {
                        case -1083506109: {
                            break block79;
                        }
                        case 748952837: {
                            continue block79;
                        }
                    }
                    break;
                }
                this.lockAndSetTarget();
                return;
            }
            v7 = TwNpcAttacker.\u13e8;
            if (true) ** GOTO lbl60
            block80: while (true) {
                v7 = v8 / (32492L ^ 6429304880133915313L);
lbl60:
                // 2 sources

                switch ((int)v7) {
                    case -1083506109: {
                        break block80;
                    }
                    case 216105591: {
                        v8 = 618L ^ -8333167263164266010L;
                        continue block80;
                    }
                    case 1022232757: {
                        v8 = 11301L ^ -4279580363533695368L;
                        continue block80;
                    }
                    case 2129682873: {
                        v8 = 21532L ^ -5519854522785132051L;
                        continue block80;
                    }
                }
                break;
            }
            if (this.ability == null) break block111;
            while (true) {
                if ((v9 = (cfr_temp_3 = TwNpcAttacker.\u13e8 - (12998L ^ 6567095966114722753L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v9 == (23638 ^ -23639)) break;
                v9 = 16320 ^ 1816629321;
            }
            v10 = TwNpcAttacker.\u13e8;
            if (true) ** GOTO lbl82
            block82: while (true) {
                v10 = (27676L ^ -5026104594570612396L) / (8136L ^ 6746590310474126401L);
lbl82:
                // 2 sources

                switch ((int)v10) {
                    case -1083506109: {
                        break block82;
                    }
                    case -261896841: {
                        continue block82;
                    }
                }
                break;
            }
            v11 = this.ability;
            while (true) {
                if ((v12 = (cfr_temp_4 = TwNpcAttacker.\u13e8 - (2799835144580345696L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v12 == (23753 ^ -23754)) break;
                v12 = 22223 ^ 827320966;
            }
            if (v11 >= System.currentTimeMillis()) break block111;
            while (true) {
                if ((v13 = (cfr_temp_5 = TwNpcAttacker.\u13e8 - (14102L ^ -8135773591580831178L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                if (v13 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v13 = 20126 ^ -1592856889;
            }
            v14 = TwNpcAttacker.\u13e8;
            if (true) ** GOTO lbl103
            block85: while (true) {
                v14 = v15 / (27630L ^ 5533314455339308997L);
lbl103:
                // 2 sources

                switch ((int)v14) {
                    case -1442188272: {
                        v15 = 9952L ^ -1159494983952441632L;
                        continue block85;
                    }
                    case -1265640500: {
                        v15 = 30814L ^ -7345573436987253256L;
                        continue block85;
                    }
                    case -1083506109: {
                        break block85;
                    }
                    case 1363966847: {
                        v15 = 4202L ^ 5770366625163781694L;
                        continue block85;
                    }
                }
                break;
            }
            v16 = this.target.health;
            v17 = TwNpcAttacker.\u13e8;
            if (true) ** GOTO lbl120
            block86: while (true) {
                v17 = v18 / (18336L ^ -8714928657233102772L);
lbl120:
                // 2 sources

                switch ((int)v17) {
                    case -1083506109: {
                        break block86;
                    }
                    case 339988589: {
                        v18 = 2301L ^ 4671446367702490757L;
                        continue block86;
                    }
                    case 343784412: {
                        v18 = 9158L ^ 9163389573748662030L;
                        continue block86;
                    }
                    case 1372069559: {
                        v18 = 27052L ^ 5677736828453708674L;
                        continue block86;
                    }
                }
                break;
            }
            v19 = v16.maxHp;
            while (true) {
                if ((v20 = (cfr_temp_6 = TwNpcAttacker.\u13e8 - (20231L ^ 5267020596765689585L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                if (v20 == (2122 ^ -2123)) break;
                v20 = 5778 ^ -1663664099;
            }
            v21 = TwNpcAttacker.\u13e8;
            if (true) ** GOTO lbl142
            block88: while (true) {
                v21 = v22 / (22145L ^ -5339940007995756800L);
lbl142:
                // 2 sources

                switch ((int)v21) {
                    case -1854038095: {
                        v22 = 10093L ^ -6605905075229208157L;
                        continue block88;
                    }
                    case -1083506109: {
                        break block88;
                    }
                    case 342570612: {
                        v22 = 12792L ^ 5896073409394285362L;
                        continue block88;
                    }
                    case 743052815: {
                        v22 = 9123411210142635816L >>> "\u0000\u0000".length();
                        continue block88;
                    }
                }
                break;
            }
            v23 = this.main.config;
            v24 = TwNpcAttacker.\u13e8;
            if (true) ** GOTO lbl159
            block89: while (true) {
                v24 = v25 / (46L ^ 7349990173061677316L);
lbl159:
                // 2 sources

                switch ((int)v24) {
                    case -1121613887: {
                        v25 = 1649L ^ 3601128111253869705L;
                        continue block89;
                    }
                    case -1083506109: {
                        break block89;
                    }
                    case -178662663: {
                        v25 = 22702L ^ -1264724540380667095L;
                        continue block89;
                    }
                    case -88836809: {
                        v25 = 31141L ^ 3046255159482518864L;
                        continue block89;
                    }
                }
                break;
            }
            v26 = v23.LOOT;
            while (true) {
                if ((v27 = (cfr_temp_7 = TwNpcAttacker.\u13e8 - (29567L ^ -8700372063830997788L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                if (v27 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v27 = 12021 ^ -1779814424;
            }
            if (v19 < v26.SHIP_ABILITY_MIN) {
                while (true) {
                    if ((v28 = (cfr_temp_8 = TwNpcAttacker.\u13e8 - (5123L ^ -2347550371221139625L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                    if (v28 == (29399 ^ -29400)) {
                        this.ability = null;
                        break block111;
                    }
                    v28 = 8159 ^ -1717889751;
                }
            }
            v29 = TwNpcAttacker.\u13e8;
            if (true) ** GOTO lbl189
            block92: while (true) {
                v29 = v30 / (1035L ^ -3348687314179899456L);
lbl189:
                // 2 sources

                switch ((int)v29) {
                    case -1656453387: {
                        v30 = 4008L ^ -1158169174681449468L;
                        continue block92;
                    }
                    case -1083506109: {
                        break block92;
                    }
                    case -609659908: {
                        v30 = -5040621088218120560L >>> "\u0000\u0000".length();
                        continue block92;
                    }
                    case -408183779: {
                        v30 = 351L ^ -8495778082064182412L;
                        continue block92;
                    }
                }
                break;
            }
            while (true) {
                if ((v31 = (cfr_temp_9 = TwNpcAttacker.\u13e8 - (14747L ^ 3014273481112320634L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
                if (v31 == (5142 ^ -5143)) break;
                v31 = 30323 ^ -508803237;
            }
            v32 = this.hero.locationInfo;
            while (true) {
                if ((v33 = (cfr_temp_10 = TwNpcAttacker.\u13e8 - (12736579621015244L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
                if (v33 == (6454 ^ -6455)) break;
                v33 = 3923 ^ -416089790;
            }
            while (true) {
                if ((v34 = (cfr_temp_11 = TwNpcAttacker.\u13e8 - (1427L ^ 459475373047765108L)) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
                if (v34 == (8439 ^ -8440)) break;
                v34 = 382426144 >>> "\u0000\u0000".length();
            }
            if (!(v32.distance((Entity)this.target) < 575.0)) break block111;
            while (true) {
                if ((v35 = (cfr_temp_12 = TwNpcAttacker.\u13e8 - (13275L ^ 1327429759092118059L)) == 0L ? 0 : (cfr_temp_12 < 0L ? -1 : 1)) == false) continue;
                if (v35 == (2245 ^ -2246)) break;
                v35 = 25293 ^ -1952299151;
            }
            v36 = TwNpcAttacker.\u13e8;
            if (true) ** GOTO lbl227
            block97: while (true) {
                v36 = (13199L ^ -8425618016387400341L) / (2103L ^ 7631236403331276758L);
lbl227:
                // 2 sources

                switch ((int)v36) {
                    case -1083506109: {
                        break block97;
                    }
                    case -974971700: {
                        continue block97;
                    }
                }
                break;
            }
            v37 = TwNpcAttacker.\u13e8;
            if (true) ** GOTO lbl236
            block98: while (true) {
                v37 = v38 / (25693L ^ 6943057276103030078L);
lbl236:
                // 2 sources

                switch ((int)v37) {
                    case -1083506109: {
                        break block98;
                    }
                    case -188059106: {
                        v38 = 4423069007581293812L >>> "\u0000\u0000".length();
                        continue block98;
                    }
                    case 1882661216: {
                        v38 = 21982L ^ 8372864383036585230L;
                        continue block98;
                    }
                }
                break;
            }
            v39 = this.main.config;
            while (true) {
                if ((v40 = (cfr_temp_13 = TwNpcAttacker.\u13e8 - (-4167677797024762344L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_13 < 0L ? -1 : 1)) == false) continue;
                if (v40 == (19758 ^ -19759)) break;
                v40 = 11703 ^ -950000642;
            }
            v41 = v39.LOOT;
            while (true) {
                if ((v42 = (cfr_temp_14 = TwNpcAttacker.\u13e8 - (19747L ^ -4739462538431402142L)) == 0L ? 0 : (cfr_temp_14 < 0L ? -1 : 1)) == false) continue;
                if (v42 == (22785 ^ -22786)) break;
                v42 = 3386 ^ 2108799348;
            }
            v43 = v41.SHIP_ABILITY;
            v44 = TwNpcAttacker.\u13e8;
            if (true) ** GOTO lbl262
            block101: while (true) {
                v44 = v45 / (24973L ^ 9146564569361933736L);
lbl262:
                // 2 sources

                switch ((int)v44) {
                    case -1083506109: {
                        break block101;
                    }
                    case 989446863: {
                        v45 = -696404246595312892L >>> "\u0000\u0000".length();
                        continue block101;
                    }
                    case 1437156145: {
                        v45 = 25605L ^ -6052851130825333226L;
                        continue block101;
                    }
                    case 1693561110: {
                        v45 = 22900L ^ 369651045215642708L;
                        continue block101;
                    }
                }
                break;
            }
            Main.API.keyboardClick(v43);
            while (true) {
                if ((v46 = (cfr_temp_15 = TwNpcAttacker.\u13e8 - (8540L ^ 5794309774119078404L)) == 0L ? 0 : (cfr_temp_15 < 0L ? -1 : 1)) == false) continue;
                if (v46 == (29187 ^ -29188)) {
                    this.ability = null;
                    break;
                }
                v46 = 2022 ^ -1539729565;
            }
        }
        v47 = TwNpcAttacker.\u13e8;
        if (true) ** GOTO lbl287
        block103: while (true) {
            v47 = v48 / (15292L ^ 5434439351371065231L);
lbl287:
            // 2 sources

            switch ((int)v47) {
                case -1083506109: {
                    break block103;
                }
                case -896556406: {
                    v48 = 16340L ^ -7186592527681194879L;
                    continue block103;
                }
                case -315965489: {
                    v48 = 10984L ^ -3374922674882983059L;
                    continue block103;
                }
                case 1379495909: {
                    v48 = 27745L ^ -5963146134872860755L;
                    continue block103;
                }
            }
            break;
        }
        this.tryAttackOrFix();
    }

    /*
     * Unable to fully structure code
     */
    void lockAndSetTarget() {
        block148: {
            block145: {
                block147: {
                    block146: {
                        while (true) {
                            if ((v0 = (cfr_temp_0 = TwNpcAttacker.\u13e8 - (29221L ^ 1271047436635522972L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                            if (v0 == (13835 ^ -13836)) break;
                            v0 = 6978 ^ -751435697;
                        }
                        while (true) {
                            if ((v1 = (cfr_temp_1 = TwNpcAttacker.\u13e8 - (12455L ^ 3036972166909748278L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                            if (v1 == (30712 ^ -30713)) break;
                            v1 = -2022175820 >>> "\u0000\u0000".length();
                        }
                        v2 = this.hero.getLocalTarget();
                        while (true) {
                            if ((v3 = (cfr_temp_2 = TwNpcAttacker.\u13e8 - (24644L ^ -5817343989538176230L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                            if (v3 == (18731 ^ 18730)) break;
                            v3 = 12552 ^ 2066803529;
                        }
                        if (v2 != this.target) break block146;
                        v4 = TwNpcAttacker.\u13e8;
                        if (true) ** GOTO lbl22
                        block106: while (true) {
                            v4 = (699820086038660368L >>> "\u0000\u0000".length()) / (17480L ^ -4596507386639380162L);
lbl22:
                            // 2 sources

                            switch ((int)v4) {
                                case -1083506109: {
                                    break block106;
                                }
                                case 21312083: {
                                    continue block106;
                                }
                            }
                            break;
                        }
                        if (!this.firstAttack) break block146;
                        v5 = TwNpcAttacker.\u13e8;
                        if (true) ** GOTO lbl32
                        block107: while (true) {
                            v5 = (10924L ^ -7392609756469796103L) / (10178L ^ -2945778851304700253L);
lbl32:
                            // 2 sources

                            switch ((int)v5) {
                                case -1083506109: {
                                    break block107;
                                }
                                case -344330581: {
                                    continue block107;
                                }
                            }
                            break;
                        }
                        v6 = System.currentTimeMillis();
                        v7 = TwNpcAttacker.\u13e8;
                        if (true) ** GOTO lbl42
                        block108: while (true) {
                            v7 = v8 / (-5363074598972466072L >>> "\u0000\u0000".length());
lbl42:
                            // 2 sources

                            switch ((int)v7) {
                                case -1083506109: {
                                    break block108;
                                }
                                case -913584679: {
                                    v8 = 4785L ^ 7656094234882037491L;
                                    continue block108;
                                }
                                case -545089029: {
                                    v8 = 31821L ^ 1344128626084827908L;
                                    continue block108;
                                }
                                case 1538800794: {
                                    v8 = 30174L ^ -6711012442614124818L;
                                    continue block108;
                                }
                            }
                            break;
                        }
                        this.clickDelay = v6;
                    }
                    while (true) {
                        if ((v9 = (cfr_temp_3 = TwNpcAttacker.\u13e8 - (30703L ^ -7446375328748381857L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                        if (v9 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                        v9 = 32393 ^ 391639477;
                    }
                    this.fixedTimes = 7811 ^ 7811;
                    while (true) {
                        if ((v10 = (cfr_temp_4 = TwNpcAttacker.\u13e8 - (22830L ^ 7188979520753367524L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                        if (v10 == (25356 ^ -25357)) break;
                        v10 = 835469756 >>> "\u0000\u0000".length();
                    }
                    this.laserTime = 7905L ^ 7905L;
                    v11 = "".length() >>> "\u0000\u0000".length();
                    v12 = TwNpcAttacker.\u13e8;
                    if (true) ** GOTO lbl73
                    block111: while (true) {
                        v12 = v13 / (3666L ^ -3813369206812046428L);
lbl73:
                        // 2 sources

                        switch ((int)v12) {
                            case -1218000505: {
                                v13 = 7671832752386866876L >>> "\u0000\u0000".length();
                                continue block111;
                            }
                            case -1083506109: {
                                break block111;
                            }
                            case -952163027: {
                                v13 = 12847L ^ 4386674520900492371L;
                                continue block111;
                            }
                            case 1850450285: {
                                v13 = 28681L ^ -939004058991215466L;
                                continue block111;
                            }
                        }
                        break;
                    }
                    this.firstAttack = v11;
                    done = "".length() >>> "\u0000\u0000".length();
                    while (true) {
                        if ((v14 = (cfr_temp_5 = TwNpcAttacker.\u13e8 - (32592L ^ 4780049560255945961L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                        if (v14 == (26704 ^ -26705)) break;
                        v14 = 11559 ^ 1761786792;
                    }
                    v15 = TwNpcAttacker.\u13e8;
                    if (true) ** GOTO lbl96
                    block113: while (true) {
                        v15 = v16 / (10138L ^ -7076430821408097143L);
lbl96:
                        // 2 sources

                        switch ((int)v15) {
                            case -1083506109: {
                                break block113;
                            }
                            case -711894743: {
                                v16 = 11638L ^ -1975496664365344777L;
                                continue block113;
                            }
                            case -122825136: {
                                v16 = 13519L ^ -1277871315743062599L;
                                continue block113;
                            }
                            case 906351841: {
                                v16 = 32215L ^ -3949977913306565291L;
                                continue block113;
                            }
                        }
                        break;
                    }
                    if (!this.config.INSTANT_LOCK) break block147;
                    var3_2 = new byte["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
                    var3_2["".length() >>> "\u0000\u0000".length()] = 6595 ^ 6641;
                    var3_2["".length() >>> "\u0000\u0000".length()] = 292 >>> "\u0000\u0000".length();
                    var3_2[17774 ^ 17772] = 460 >>> "\u0000\u0000".length();
                    var3_2[25762 ^ 25768] = 464 >>> "\u0000\u0000".length();
                    var3_2[20364 ^ 20353] = 428 >>> "\u0000\u0000".length();
                    var3_2[25223 ^ 25230] = 464 >>> "\u0000\u0000".length();
                    var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 13276 ^ 13247;
                    var3_2[6940 ^ 6941] = 440 >>> "\u0000\u0000".length();
                    var3_2[29076 ^ 29079] = 28054 ^ 28130;
                    var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 10248 ^ 10364;
                    var3_2[16340 ^ 16337] = 18004 ^ 17978;
                    var3_2[31035 ^ 31027] = 27127 ^ 27030;
                    var3_2[27852 ^ 27848] = 388 >>> "\u0000\u0000".length();
                    var3_2[5036 ^ 5031] = 388 >>> "\u0000\u0000".length();
                    var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 128 >>> "\u0000\u0000".length();
                    v17 = new String(var3_2);
                    while (true) {
                        if ((v18 = (cfr_temp_6 = TwNpcAttacker.\u13e8 - (5986300218512142900L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                        if (v18 == (25943 ^ -25944)) break;
                        v18 = 10563 ^ -1155273931;
                    }
                    this.log(v17);
                    v19 = TwNpcAttacker.\u13e8;
                    if (true) ** GOTO lbl136
                    block115: while (true) {
                        v19 = (14053L ^ -8240405811678593413L) / (20791L ^ 5241799661413218724L);
lbl136:
                        // 2 sources

                        switch ((int)v19) {
                            case -1083506109: {
                                break block115;
                            }
                            case 1980235826: {
                                continue block115;
                            }
                        }
                        break;
                    }
                    v20 = TwNpcAttacker.\u13e8;
                    if (true) ** GOTO lbl145
                    block116: while (true) {
                        v20 = v21 / (25867L ^ -9046087987949123440L);
lbl145:
                        // 2 sources

                        switch ((int)v20) {
                            case -1433602660: {
                                v21 = 23632L ^ -860122638492530680L;
                                continue block116;
                            }
                            case -1083506109: {
                                break block116;
                            }
                            case -220743606: {
                                v21 = 21842L ^ 7701993479324730895L;
                                continue block116;
                            }
                            case 508122965: {
                                v21 = 20770L ^ -6681047798555727114L;
                                continue block116;
                            }
                        }
                        break;
                    }
                    this.instantAttack((Entity)this.target);
                    while (true) {
                        if ((v22 = (cfr_temp_7 = TwNpcAttacker.\u13e8 - (27823L ^ 5526275267542485049L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                        if (v22 == (21688 ^ -21689)) break;
                        v22 = 8917 ^ -363283884;
                    }
                    v23 = TwNpcAttacker.\u13e8;
                    if (true) ** GOTO lbl167
                    block118: while (true) {
                        v23 = v24 / (18840L ^ -705477454186869600L);
lbl167:
                        // 2 sources

                        switch ((int)v23) {
                            case -1408046372: {
                                v24 = 8018899074021365204L >>> "\u0000\u0000".length();
                                continue block118;
                            }
                            case -1083506109: {
                                break block118;
                            }
                            case -325591759: {
                                v24 = 15903L ^ -6789386791067946770L;
                                continue block118;
                            }
                            case 372578344: {
                                v24 = 13279L ^ -6765205097640902354L;
                                continue block118;
                            }
                        }
                        break;
                    }
                    v25 = TwNpcAttacker.\u13e8;
                    if (true) ** GOTO lbl183
                    block119: while (true) {
                        v25 = (24708L ^ -8583110172326227986L) / (26877L ^ -4484683313481121110L);
lbl183:
                        // 2 sources

                        switch ((int)v25) {
                            case -1083506109: {
                                break block119;
                            }
                            case 2144788116: {
                                continue block119;
                            }
                        }
                        break;
                    }
                    this.hero.setLocalTarget((Lockable)this.target);
                    v26 = TwNpcAttacker.\u13e8;
                    if (true) ** GOTO lbl193
                    block120: while (true) {
                        v26 = v27 / (20956L ^ -3227367067980971419L);
lbl193:
                        // 2 sources

                        switch ((int)v26) {
                            case -1740920491: {
                                v27 = 17350L ^ -1492614884541579309L;
                                continue block120;
                            }
                            case -1083506109: {
                                break block120;
                            }
                            case 1430776833: {
                                v27 = 26753L ^ 4153098187132576252L;
                                continue block120;
                            }
                        }
                        break;
                    }
                    v28 = TwNpcAttacker.\u13e8;
                    if (true) ** GOTO lbl206
                    block121: while (true) {
                        v28 = v29 / (11905L ^ -4751986194837502560L);
lbl206:
                        // 2 sources

                        switch ((int)v28) {
                            case -1083506109: {
                                break block121;
                            }
                            case -760488402: {
                                v29 = 12750L ^ -1408605472200665578L;
                                continue block121;
                            }
                            case 1295580137: {
                                v29 = 15068L ^ -4887476091888423385L;
                                continue block121;
                            }
                        }
                        break;
                    }
                    this.target.trySelect((boolean)(21389 ^ 21389));
                    done = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
                    while (true) {
                        if ((v30 = (cfr_temp_8 = TwNpcAttacker.\u13e8 - (6688L ^ -7604993460801944288L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                        if (v30 == (27842 ^ 27843)) {
                            this.laserTime = 14675L ^ 10971L;
                            break block145;
                        }
                        v30 = 19445 ^ -581972011;
                    }
                }
                while (true) {
                    if ((v31 = (cfr_temp_9 = TwNpcAttacker.\u13e8 - (14452L ^ 8914741395008855981L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
                    if (v31 == (30491 ^ -30492)) break;
                    v31 = 17096 ^ -2020776825;
                }
                v32 = TwNpcAttacker.\u13e8;
                if (true) ** GOTO lbl235
                block124: while (true) {
                    v32 = v33 / (17426L ^ 1038515750642318877L);
lbl235:
                    // 2 sources

                    switch ((int)v32) {
                        case -1083506109: {
                            break block124;
                        }
                        case -659770630: {
                            v33 = 12030L ^ -8506777675024986826L;
                            continue block124;
                        }
                        case 26014964: {
                            v33 = 18399L ^ -1597675852243681577L;
                            continue block124;
                        }
                        case 857815211: {
                            v33 = 831L ^ 3547198963730544288L;
                            continue block124;
                        }
                    }
                    break;
                }
                v34 = this.hero.locationInfo;
                v35 = TwNpcAttacker.\u13e8;
                if (true) ** GOTO lbl252
                block125: while (true) {
                    v35 = v36 / (28935L ^ 4883788484524416847L);
lbl252:
                    // 2 sources

                    switch ((int)v35) {
                        case -1083506109: {
                            break block125;
                        }
                        case -446521626: {
                            v36 = 27116L ^ -8927789054305743357L;
                            continue block125;
                        }
                        case 1239080310: {
                            v36 = -1706111709476084164L >>> "\u0000\u0000".length();
                            continue block125;
                        }
                    }
                    break;
                }
                while (true) {
                    if ((v37 = (cfr_temp_10 = TwNpcAttacker.\u13e8 - (32455L ^ -8928844695740191190L)) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
                    if (v37 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                    v37 = 9029 ^ 1918336228;
                }
                if (!(v34.distance((Entity)this.target) < 800.0)) break block145;
                while (true) {
                    if ((v38 = (cfr_temp_11 = TwNpcAttacker.\u13e8 - (31186L ^ -4832846157988396934L)) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
                    if (v38 == (9904 ^ -9905)) break;
                    v38 = 24034 ^ 582871353;
                }
                v39 = System.currentTimeMillis();
                v40 = TwNpcAttacker.\u13e8;
                if (true) ** GOTO lbl277
                block128: while (true) {
                    v40 = v41 / (25785L ^ 2635000000874574206L);
lbl277:
                    // 2 sources

                    switch ((int)v40) {
                        case -1083506109: {
                            break block128;
                        }
                        case -1006426158: {
                            v41 = 25581L ^ 7322963676969264814L;
                            continue block128;
                        }
                        case -373727184: {
                            v41 = 16440L ^ -6199246019610624454L;
                            continue block128;
                        }
                    }
                    break;
                }
                if (v39 - this.clickDelay <= 2000L >>> "\u0000\u0000".length()) break block145;
                while (true) {
                    if ((v42 = (cfr_temp_12 = TwNpcAttacker.\u13e8 - (879L ^ -4624845440082844346L)) == 0L ? 0 : (cfr_temp_12 < 0L ? -1 : 1)) == false) continue;
                    if (v42 == (6234 ^ -6235)) break;
                    v42 = 14791 ^ 655334999;
                }
                v43 = TwNpcAttacker.\u13e8;
                if (true) ** GOTO lbl296
                block130: while (true) {
                    v43 = v44 / (4179L ^ 4522496270635587547L);
lbl296:
                    // 2 sources

                    switch ((int)v43) {
                        case -1843351904: {
                            v44 = 6835774707868281400L >>> "\u0000\u0000".length();
                            continue block130;
                        }
                        case -1083506109: {
                            break block130;
                        }
                        case 488432418: {
                            v44 = 13310L ^ 1670923506001042375L;
                            continue block130;
                        }
                    }
                    break;
                }
                while (true) {
                    if ((v45 = (cfr_temp_13 = TwNpcAttacker.\u13e8 - (1398L ^ -2772162140356775870L)) == 0L ? 0 : (cfr_temp_13 < 0L ? -1 : 1)) == false) continue;
                    if (v45 == (13350 ^ -13351)) break;
                    v45 = 8220 ^ 1670831298;
                }
                this.hero.setLocalTarget((Lockable)this.target);
                v46 = TwNpcAttacker.\u13e8;
                if (true) ** GOTO lbl315
                block132: while (true) {
                    v46 = v47 / (30791L ^ -5856447008120268694L);
lbl315:
                    // 2 sources

                    switch ((int)v46) {
                        case -2090563162: {
                            v47 = -2482303118649999096L >>> "\u0000\u0000".length();
                            continue block132;
                        }
                        case -1083506109: {
                            break block132;
                        }
                        case -1009465717: {
                            v47 = 11454L ^ 3819875546587687751L;
                            continue block132;
                        }
                        case 785026951: {
                            v47 = 10483L ^ 1969427418434605616L;
                            continue block132;
                        }
                    }
                    break;
                }
                v48 = TwNpcAttacker.\u13e8;
                if (true) ** GOTO lbl331
                block133: while (true) {
                    v48 = v49 / (3344L ^ -2187083921066647063L);
lbl331:
                    // 2 sources

                    switch ((int)v48) {
                        case -1083506109: {
                            break block133;
                        }
                        case -986858004: {
                            v49 = 17204L ^ -5538462787194349225L;
                            continue block133;
                        }
                        case 689413001: {
                            v49 = 24044L ^ 7140758865826473098L;
                            continue block133;
                        }
                        case 1340284857: {
                            v49 = 5041L ^ -4905953131250835614L;
                            continue block133;
                        }
                    }
                    break;
                }
                this.target.trySelect((boolean)(19985 ^ 19985));
                done = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
            }
            if (done == 0) break block148;
            v50 = TwNpcAttacker.\u13e8;
            if (true) ** GOTO lbl352
            block134: while (true) {
                v50 = v51 / (8761L ^ -6621973129999504223L);
lbl352:
                // 2 sources

                switch ((int)v50) {
                    case -2074818458: {
                        v51 = 10356L ^ -2221673680428343038L;
                        continue block134;
                    }
                    case -1834779550: {
                        v51 = 12444L ^ -551246432502502392L;
                        continue block134;
                    }
                    case -1083506109: {
                        break block134;
                    }
                    case 1689060277: {
                        v51 = 18637L ^ 9062315998533387659L;
                        continue block134;
                    }
                }
                break;
            }
            v52 = System.currentTimeMillis();
            while (true) {
                if ((v53 = (cfr_temp_14 = TwNpcAttacker.\u13e8 - (3822L ^ 7145990424219840453L)) == 0L ? 0 : (cfr_temp_14 < 0L ? -1 : 1)) == false) continue;
                if (v53 == (23830 ^ -23831)) break;
                v53 = 17668 ^ -1015102771;
            }
            this.clickDelay = v52;
            while (true) {
                if ((v54 = (cfr_temp_15 = TwNpcAttacker.\u13e8 - (7824L ^ -5848101097188325961L)) == 0L ? 0 : (cfr_temp_15 < 0L ? -1 : 1)) == false) continue;
                if (v54 == (17386 ^ 17387)) break;
                v54 = 15362 ^ -55299608;
            }
            v55 = TwNpcAttacker.\u13e8;
            if (true) ** GOTO lbl380
            block137: while (true) {
                v55 = (22743L ^ -2343076446912983795L) / (25311L ^ -3343654469039688977L);
lbl380:
                // 2 sources

                switch ((int)v55) {
                    case -1083506109: {
                        break block137;
                    }
                    case -135208535: {
                        continue block137;
                    }
                }
                break;
            }
            v56 = this.main.config;
            while (true) {
                if ((v57 = (cfr_temp_16 = TwNpcAttacker.\u13e8 - (18008L ^ -1808066944348555639L)) == 0L ? 0 : (cfr_temp_16 < 0L ? -1 : 1)) == false) continue;
                if (v57 == (31213 ^ -31214)) break;
                v57 = 29582 ^ -480514408;
            }
            v58 = v56.LOOT;
            while (true) {
                if ((v59 = (cfr_temp_17 = TwNpcAttacker.\u13e8 - (9023690322671594032L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_17 < 0L ? -1 : 1)) == false) continue;
                if (v59 == (18895 ^ -18896)) break;
                v59 = "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() ^ -2090584673;
            }
            if (v58.SHIP_ABILITY == null) break block148;
            while (true) {
                if ((v60 = (cfr_temp_18 = TwNpcAttacker.\u13e8 - (29986L ^ -2581693817801323466L)) == 0L ? 0 : (cfr_temp_18 < 0L ? -1 : 1)) == false) continue;
                if (v60 == (1855 ^ -1856)) break;
                v60 = 2501 ^ 1078126881;
            }
            v61 = this.clickDelay + (16000L >>> "\u0000\u0000".length());
            v62 = TwNpcAttacker.\u13e8;
            if (true) ** GOTO lbl408
            block141: while (true) {
                v62 = (27840L ^ -3944901403501256126L) / (3773943005186868832L >>> "\u0000\u0000".length());
lbl408:
                // 2 sources

                switch ((int)v62) {
                    case -1083506109: {
                        break block141;
                    }
                    case -519179154: {
                        continue block141;
                    }
                }
                break;
            }
            v63 = v61;
            while (true) {
                if ((v64 = (cfr_temp_19 = TwNpcAttacker.\u13e8 - (22082L ^ -4341410062895473251L)) == 0L ? 0 : (cfr_temp_19 < 0L ? -1 : 1)) == false) continue;
                if (v64 == (27501 ^ -27502)) {
                    this.ability = v63;
                    break;
                }
                v64 = 8173 ^ -2072458036;
            }
        }
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    protected void tryAttackOrFix() {
        block141: {
            block147: {
                block146: {
                    block145: {
                        block144: {
                            block143: {
                                block142: {
                                    while (true) {
                                        if ((v0 = (cfr_temp_0 = TwNpcAttacker.\u13e8 - (10991L ^ 5058479204276224183L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                                        if (v0 == (9753 ^ -9754)) break;
                                        v0 = 1452 ^ -40144435;
                                    }
                                    v1 = System.currentTimeMillis();
                                    while (true) {
                                        if ((v2 = (cfr_temp_1 = TwNpcAttacker.\u13e8 - (6783L ^ 6996892727820547291L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                                        if (v2 == (16643 ^ -16644)) break;
                                        v2 = 18719 ^ -1796478488;
                                    }
                                    if (v1 < this.laserTime) {
                                        return;
                                    }
                                    v3 = TwNpcAttacker.\u13e8;
                                    if (true) ** GOTO lbl18
                                    block99: while (true) {
                                        v3 = v4 / (27614L ^ 3144354668831818353L);
lbl18:
                                        // 2 sources

                                        switch ((int)v3) {
                                            case -1083506109: {
                                                break block99;
                                            }
                                            case -190710337: {
                                                v4 = 26537L ^ 6320496321401979124L;
                                                continue block99;
                                            }
                                            case 1609638894: {
                                                v4 = 10611L ^ -4820025863598734416L;
                                                continue block99;
                                            }
                                            case 1999028771: {
                                                v4 = 2990987517991833332L >>> "\u0000\u0000".length();
                                                continue block99;
                                            }
                                        }
                                        break;
                                    }
                                    if (this.firstAttack) break block142;
                                    while (true) {
                                        if ((v5 = (cfr_temp_2 = TwNpcAttacker.\u13e8 - (24840L ^ 5059572509929057590L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                                        if (v5 == (15625 ^ -15626)) break;
                                        v5 = 13715 ^ -743699886;
                                    }
                                    v6 = TwNpcAttacker.\u13e8;
                                    if (true) ** GOTO lbl40
                                    block101: while (true) {
                                        v6 = v7 / (26514L ^ 5464206936089179056L);
lbl40:
                                        // 2 sources

                                        switch ((int)v6) {
                                            case -1333369314: {
                                                v7 = 6053982241831562704L >>> "\u0000\u0000".length();
                                                continue block101;
                                            }
                                            case -1083506109: {
                                                break block101;
                                            }
                                            case -20258705: {
                                                v7 = 964472441139250944L >>> "\u0000\u0000".length();
                                                continue block101;
                                            }
                                        }
                                        break;
                                    }
                                    v8 = this.config.RSB_SWITCH_DELAY;
                                    v9 = 20000L >>> "\u0000\u0000".length();
                                    v10 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
                                    v11 = TwNpcAttacker.\u13e8;
                                    if (true) ** GOTO lbl56
                                    block102: while (true) {
                                        v11 = (-989473869580893812L >>> "\u0000\u0000".length()) / (25968L ^ -2403227673662871412L);
lbl56:
                                        // 2 sources

                                        switch ((int)v11) {
                                            case -2103580513: {
                                                continue block102;
                                            }
                                            case -1083506109: {
                                                break block102;
                                            }
                                        }
                                        break;
                                    }
                                    this.sendAttack(v8, v9, v10);
                                    v12 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
                                    v13 = TwNpcAttacker.\u13e8;
                                    if (true) ** GOTO lbl67
                                    block103: while (true) {
                                        v13 = (24829L ^ -5279431005436328816L) / (8157L ^ -8183352383145104666L);
lbl67:
                                        // 2 sources

                                        switch ((int)v13) {
                                            case -1083506109: {
                                                break block103;
                                            }
                                            case 407590583: {
                                                continue block103;
                                            }
                                        }
                                        break;
                                    }
                                    this.firstAttack = v12;
                                    break block141;
                                }
                                while (true) {
                                    if ((v14 = (cfr_temp_3 = TwNpcAttacker.\u13e8 - (7128885914739893960L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                                    if (v14 == (4876 ^ -4877)) break;
                                    v14 = 27478 ^ 821907381;
                                }
                                v15 = this.getPreviousAttackKey();
                                v16 = TwNpcAttacker.\u13e8;
                                if (true) ** GOTO lbl85
                                block105: while (true) {
                                    v16 = (23449L ^ 7777557744149057480L) / (24000L ^ 5714688758043091226L);
lbl85:
                                    // 2 sources

                                    switch ((int)v16) {
                                        case -1083506109: {
                                            break block105;
                                        }
                                        case -850945735: {
                                            continue block105;
                                        }
                                    }
                                    break;
                                }
                                if (v15 == this.getAttackKey()) break block143;
                                while (true) {
                                    if ((v17 = (cfr_temp_4 = TwNpcAttacker.\u13e8 - (18967L ^ -7827087282417852321L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                                    if (v17 == (14269 ^ 14268)) break;
                                    v17 = 366 ^ 2075259491;
                                }
                                v18 = TwNpcAttacker.\u13e8;
                                if (true) ** GOTO lbl100
                                block107: while (true) {
                                    v18 = v19 / (31562L ^ -4805864777388578595L);
lbl100:
                                    // 2 sources

                                    switch ((int)v18) {
                                        case -1733216551: {
                                            v19 = 22824L ^ -401377040219233391L;
                                            continue block107;
                                        }
                                        case -1083506109: {
                                            break block107;
                                        }
                                        case -217391171: {
                                            v19 = 1374182392432130412L >>> "\u0000\u0000".length();
                                            continue block107;
                                        }
                                        case 703978577: {
                                            v19 = 19873L ^ -8546453867728445968L;
                                            continue block107;
                                        }
                                    }
                                    break;
                                }
                                v20 = this.config.RSB_SWITCH_DELAY;
                                v21 = 20000L >>> "\u0000\u0000".length();
                                while (true) {
                                    if ((v22 = (cfr_temp_5 = TwNpcAttacker.\u13e8 - (21509L ^ 7178798084065841199L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                                    if (v22 == (6888 ^ -6889)) {
                                        this.sendAttack(v20, v21, (boolean)(24840 ^ 24841));
                                        break block141;
                                    }
                                    v22 = 30945 ^ -1402276468;
                                }
                            }
                            while (true) {
                                if ((v23 = (cfr_temp_6 = TwNpcAttacker.\u13e8 - (-7209776522270565756L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                                if (v23 == (21382 ^ -21383)) break;
                                v23 = 24169 ^ -1782154736;
                            }
                            v24 = TwNpcAttacker.\u13e8;
                            if (true) ** GOTO lbl131
                            block110: while (true) {
                                v24 = (18249L ^ 7952011053531295076L) / (1615770633555790720L >>> "\u0000\u0000".length());
lbl131:
                                // 2 sources

                                switch ((int)v24) {
                                    case -1161003452: {
                                        continue block110;
                                    }
                                    case -1083506109: {
                                        break block110;
                                    }
                                }
                                break;
                            }
                            v25 = TwNpcAttacker.\u13e8;
                            if (true) ** GOTO lbl140
                            block111: while (true) {
                                v25 = (26598L ^ -6006742126477917579L) / (4951L ^ 7085099561205379418L);
lbl140:
                                // 2 sources

                                switch ((int)v25) {
                                    case -1083506109: {
                                        break block111;
                                    }
                                    case 1459019784: {
                                        continue block111;
                                    }
                                }
                                break;
                            }
                            if (!this.hero.isAttacking((Ship)this.target)) break block144;
                            v26 = TwNpcAttacker.\u13e8;
                            if (true) ** GOTO lbl150
                            block112: while (true) {
                                v26 = v27 / (12914L ^ 8492460716877851452L);
lbl150:
                                // 2 sources

                                switch ((int)v26) {
                                    case -1783702247: {
                                        v27 = 8930L ^ 4131057505055970874L;
                                        continue block112;
                                    }
                                    case -1083506109: {
                                        break block112;
                                    }
                                    case -190848447: {
                                        v27 = 31169L ^ -8759991084794094376L;
                                        continue block112;
                                    }
                                    case 1842156106: {
                                        v27 = 30849L ^ -7787509453637825084L;
                                        continue block112;
                                    }
                                }
                                break;
                            }
                            v28 = TwNpcAttacker.\u13e8;
                            if (true) ** GOTO lbl166
                            block113: while (true) {
                                v28 = (27206L ^ -1390114823261610012L) / (1304L ^ -2416874638437439038L);
lbl166:
                                // 2 sources

                                switch ((int)v28) {
                                    case -1083506109: {
                                        break block113;
                                    }
                                    case 1030038086: {
                                        continue block113;
                                    }
                                }
                                break;
                            }
                            v29 = TwNpcAttacker.\u13e8;
                            if (true) ** GOTO lbl175
                            block114: while (true) {
                                v29 = (13277L ^ 2894303295451774795L) / (16048L ^ -7196923528393876538L);
lbl175:
                                // 2 sources

                                switch ((int)v29) {
                                    case -1708263809: {
                                        continue block114;
                                    }
                                    case -1083506109: {
                                        break block114;
                                    }
                                }
                                break;
                            }
                            if (this.hero.isAiming((Ship)this.target)) break block145;
                        }
                        v30 = 20000L >>> "\u0000\u0000".length();
                        while (true) {
                            if ((v31 = (cfr_temp_7 = TwNpcAttacker.\u13e8 - (6671L ^ -6830072373473726585L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                            if (v31 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                                this.sendAttack(16467L ^ 17807L, v30, (boolean)(25906 ^ 25906));
                                break block141;
                            }
                            v31 = 30053 ^ -54601769;
                        }
                    }
                    while (true) {
                        if ((v32 = (cfr_temp_8 = TwNpcAttacker.\u13e8 - (1634L ^ -4560356767117714893L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                        if (v32 == (29785 ^ -29786)) break;
                        v32 = -1693797896 >>> "\u0000\u0000".length();
                    }
                    while (true) {
                        if ((v33 = (cfr_temp_9 = TwNpcAttacker.\u13e8 - (7387L ^ 5975744703230463872L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
                        if (v33 == (27528 ^ -27529)) break;
                        v33 = 10004 ^ -1568893462;
                    }
                    v34 = this.target.health;
                    v35 = 6000 >>> "\u0000\u0000".length();
                    v36 = TwNpcAttacker.\u13e8;
                    if (true) ** GOTO lbl207
                    block118: while (true) {
                        v36 = v37 / (5411419458152882800L >>> "\u0000\u0000".length());
lbl207:
                        // 2 sources

                        switch ((int)v36) {
                            case -1684479450: {
                                v37 = 556L ^ 1145413722137512477L;
                                continue block118;
                            }
                            case -1083506109: {
                                break block118;
                            }
                            case 1277316544: {
                                v37 = 30376L ^ 4769738561674179145L;
                                continue block118;
                            }
                            case 2064647635: {
                                v37 = 1758L ^ 7379587393260810976L;
                                continue block118;
                            }
                        }
                        break;
                    }
                    if (v34.hpDecreasedIn(v35)) break block146;
                    v38 = TwNpcAttacker.\u13e8;
                    if (true) ** GOTO lbl224
                    block119: while (true) {
                        v38 = v39 / (1869L ^ -1719380112720447477L);
lbl224:
                        // 2 sources

                        switch ((int)v38) {
                            case -1950076216: {
                                v39 = 20993L ^ 6338555859260876094L;
                                continue block119;
                            }
                            case -1083506109: {
                                break block119;
                            }
                            case -854550861: {
                                v39 = 26972L ^ 891739192432580220L;
                                continue block119;
                            }
                            case 1631394879: {
                                v39 = 27799L ^ 7142625841104860023L;
                                continue block119;
                            }
                        }
                        break;
                    }
                    v40 = TwNpcAttacker.\u13e8;
                    if (true) ** GOTO lbl240
                    block120: while (true) {
                        v40 = (27606L ^ -4194746930565968196L) / (9637L ^ -566139231920568453L);
lbl240:
                        // 2 sources

                        switch ((int)v40) {
                            case -1849881314: {
                                continue block120;
                            }
                            case -1083506109: {
                                break block120;
                            }
                        }
                        break;
                    }
                    while (true) {
                        if ((v41 = (cfr_temp_10 = TwNpcAttacker.\u13e8 - (-4735914670283854772L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
                        if (v41 == (19344 ^ -19345)) break;
                        v41 = -1688397636 >>> "\u0000\u0000".length();
                    }
                    if (this.target.hasEffect(EffectManager.Effect.NPC_ISH)) break block146;
                    v42 = TwNpcAttacker.\u13e8;
                    if (true) ** GOTO lbl255
                    block122: while (true) {
                        v42 = v43 / (29975L ^ 2231739374838786063L);
lbl255:
                        // 2 sources

                        switch ((int)v42) {
                            case -1083506109: {
                                break block122;
                            }
                            case 1602113938: {
                                v43 = 16009L ^ 5708805671240438319L;
                                continue block122;
                            }
                            case 1922730317: {
                                v43 = 12656L ^ -9131675469113414647L;
                                continue block122;
                            }
                            case 2119133589: {
                                v43 = 32035L ^ -1432800030259477237L;
                                continue block122;
                            }
                        }
                        break;
                    }
                    while (true) {
                        if ((v44 = (cfr_temp_11 = TwNpcAttacker.\u13e8 - (17700L ^ -4082437579572404792L)) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
                        if (v44 == (20785 ^ -20786)) break;
                        v44 = 18781 ^ 1608031040;
                    }
                    v45 = this.hero.locationInfo;
                    while (true) {
                        if ((v46 = (cfr_temp_12 = TwNpcAttacker.\u13e8 - (15338L ^ 7835599279693384101L)) == 0L ? 0 : (cfr_temp_12 < 0L ? -1 : 1)) == false) continue;
                        if (v46 == (7484 ^ -7485)) break;
                        v46 = 16847 ^ -435393408;
                    }
                    v47 = TwNpcAttacker.\u13e8;
                    if (true) ** GOTO lbl282
                    block125: while (true) {
                        v47 = (3560L ^ -3690331448825862975L) / (19726L ^ 4885155944728900409L);
lbl282:
                        // 2 sources

                        switch ((int)v47) {
                            case -1083506109: {
                                break block125;
                            }
                            case 1085243821: {
                                continue block125;
                            }
                        }
                        break;
                    }
                    if (!(v45.distance((Entity)this.target) > 700.0)) break block147;
                }
                while (true) {
                    if ((v48 = (cfr_temp_13 = TwNpcAttacker.\u13e8 - (81L ^ -435420627653735344L)) == 0L ? 0 : (cfr_temp_13 < 0L ? -1 : 1)) == false) continue;
                    if (v48 == (8258 ^ -8259)) break;
                    v48 = 12132 ^ 809719902;
                }
                v49 = TwNpcAttacker.\u13e8;
                if (true) ** GOTO lbl298
                block127: while (true) {
                    v49 = (11959L ^ 4240801837395194045L) / (16032L ^ -3740694041737708201L);
lbl298:
                    // 2 sources

                    switch ((int)v49) {
                        case -1083506109: {
                            break block127;
                        }
                        case 1071183164: {
                            continue block127;
                        }
                    }
                    break;
                }
                v50 = System.currentTimeMillis() + (8000L >>> "\u0000\u0000".length());
                while (true) {
                    if ((v51 = (cfr_temp_14 = TwNpcAttacker.\u13e8 - (29755L ^ -906102412002797781L)) == 0L ? 0 : (cfr_temp_14 < 0L ? -1 : 1)) == false) continue;
                    if (v51 == (567 ^ -568)) break;
                    v51 = 30760 ^ -636340;
                }
                v52 = Math.max(this.isAttacking, v50);
                v53 = TwNpcAttacker.\u13e8;
                if (true) ** GOTO lbl314
                block129: while (true) {
                    v53 = v54 / (18251L ^ 1305389698683500889L);
lbl314:
                    // 2 sources

                    switch ((int)v53) {
                        case -1083506109: {
                            break block129;
                        }
                        case -84141282: {
                            v54 = 26588L ^ -8670742079853912186L;
                            continue block129;
                        }
                        case 1499525550: {
                            v54 = 10136L ^ -4862883020929831244L;
                            continue block129;
                        }
                        case 1527745563: {
                            v54 = 31588L ^ -2974876343797346767L;
                            continue block129;
                        }
                    }
                    break;
                }
                this.isAttacking = v52;
                break block141;
            }
            while (true) {
                if ((v55 = (cfr_temp_15 = TwNpcAttacker.\u13e8 - (12756L ^ 7066527624946735188L)) == 0L ? 0 : (cfr_temp_15 < 0L ? -1 : 1)) == false) continue;
                if (v55 == (25221 ^ -25222)) break;
                v55 = 2469 ^ 882397703;
            }
            v56 = System.currentTimeMillis();
            v57 = TwNpcAttacker.\u13e8;
            if (true) ** GOTO lbl339
            block131: while (true) {
                v57 = (21980L ^ -6964779958429159179L) / (8429L ^ -479400014308400466L);
lbl339:
                // 2 sources

                switch ((int)v57) {
                    case -1083506109: {
                        break block131;
                    }
                    case 851478059: {
                        continue block131;
                    }
                }
                break;
            }
            if (v56 <= this.isAttacking) break block141;
            while (true) {
                if ((v58 = (cfr_temp_16 = TwNpcAttacker.\u13e8 - (20831L ^ -5899337318855764287L)) == 0L ? 0 : (cfr_temp_16 < 0L ? -1 : 1)) == false) continue;
                if (v58 == (25409 ^ 25408)) break;
                v58 = 20178 ^ 1497013386;
            }
            v59 = TwNpcAttacker.\u13e8;
            if (true) ** GOTO lbl354
            block133: while (true) {
                v59 = v60 / (9679L ^ -6524805608721396282L);
lbl354:
                // 2 sources

                switch ((int)v59) {
                    case -1434943392: {
                        v60 = 5286L ^ 5262204241341108139L;
                        continue block133;
                    }
                    case -1083506109: {
                        break block133;
                    }
                    case 1515207429: {
                        v60 = 28611L ^ 6579556962747096031L;
                        continue block133;
                    }
                    case 1765295920: {
                        v60 = 4874L ^ -3896230446918615707L;
                        continue block133;
                    }
                }
                break;
            }
            v61 = (long)(this.fixedTimes += 2524 ^ 2525) * (12000L >>> "\u0000\u0000".length());
            v62 = "".length() >>> "\u0000\u0000".length();
            while (true) {
                if ((v63 = (cfr_temp_17 = TwNpcAttacker.\u13e8 - (1586175889822570956L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_17 < 0L ? -1 : 1)) == false) continue;
                if (v63 == (10869 ^ -10870)) {
                    this.sendAttack(27976L ^ 26772L, v61, v62);
                    break;
                }
                v63 = 16022 ^ -602960413;
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private void sendAttack(long minWait, long bugTime, boolean normal) {
        block51: {
            block53: {
                block52: {
                    while (true) {
                        if ((v0 = (cfr_temp_0 = TwNpcAttacker.\u13e8 - (4707273531461307156L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                        if (v0 == (8257 ^ -8258)) break;
                        v0 = 7254 ^ -120117837;
                    }
                    v1 = System.currentTimeMillis() + minWait;
                    while (true) {
                        if ((v2 = (cfr_temp_1 = TwNpcAttacker.\u13e8 - (546645468769567024L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                        if (v2 == (20117 ^ -20118)) break;
                        v2 = 22726 ^ 1161708616;
                    }
                    this.laserTime = v1;
                    while (true) {
                        if ((v3 = (cfr_temp_2 = TwNpcAttacker.\u13e8 - (80L ^ -8967437247101766090L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                        if (v3 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                        v3 = 6426 ^ -652678286;
                    }
                    while (true) {
                        if ((v4 = (cfr_temp_3 = TwNpcAttacker.\u13e8 - (-5924957509784244340L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                        if (v4 == (7577 ^ -7578)) break;
                        v4 = 27019 ^ -878525682;
                    }
                    while (true) {
                        if ((v5 = (cfr_temp_4 = TwNpcAttacker.\u13e8 - (2902L ^ -877170235312337930L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                        if (v5 == (16053 ^ -16054)) break;
                        v5 = -424259460 >>> "\u0000\u0000".length();
                    }
                    v6 = Math.max(this.isAttacking, this.laserTime + bugTime);
                    while (true) {
                        if ((v7 = (cfr_temp_5 = TwNpcAttacker.\u13e8 - (19141L ^ 5391443385014783918L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                        if (v7 == (23636 ^ -23637)) break;
                        v7 = 2411 ^ -281764477;
                    }
                    this.isAttacking = v6;
                    if (!normal) break block52;
                    while (true) {
                        if ((v8 = (cfr_temp_6 = TwNpcAttacker.\u13e8 - (29827L ^ -3733116032019750449L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                        if (v8 == (14880 ^ -14881)) break;
                        v8 = 17782 ^ 1118776969;
                    }
                    v9 = TwNpcAttacker.\u13e8;
                    if (true) ** GOTO lbl45
                    block38: while (true) {
                        v9 = v10 / (730762508684999240L >>> "\u0000\u0000".length());
lbl45:
                        // 2 sources

                        switch ((int)v9) {
                            case -1083506109: {
                                break block38;
                            }
                            case 484944748: {
                                v10 = 7915L ^ 6021843036688855916L;
                                continue block38;
                            }
                            case 1531001558: {
                                v10 = 27799L ^ 5440632243041655101L;
                                continue block38;
                            }
                        }
                        break;
                    }
                    v11 = this.getAttackKey();
                    v12 = TwNpcAttacker.\u13e8;
                    if (true) ** GOTO lbl59
                    block39: while (true) {
                        v12 = v13 / (24383L ^ -3264837147090932994L);
lbl59:
                        // 2 sources

                        switch ((int)v12) {
                            case -1651498686: {
                                v13 = 4566L ^ -351836470780336150L;
                                continue block39;
                            }
                            case -1083506109: {
                                break block39;
                            }
                            case 18793027: {
                                v13 = 19547L ^ -3844135642577216931L;
                                continue block39;
                            }
                            case 269154663: {
                                v13 = 6005L ^ -7418018183018141001L;
                                continue block39;
                            }
                        }
                        break;
                    }
                    this.lastShot = v11;
                    v14 = TwNpcAttacker.\u13e8;
                    if (true) ** GOTO lbl76
                    block40: while (true) {
                        v14 = v15 / (29316L ^ -8634292373110900869L);
lbl76:
                        // 2 sources

                        switch ((int)v14) {
                            case -1891452777: {
                                v15 = 4891L ^ -8069226867232950858L;
                                continue block40;
                            }
                            case -1242880218: {
                                v15 = -8559964207107976512L >>> "\u0000\u0000".length();
                                continue block40;
                            }
                            case -1083506109: {
                                break block40;
                            }
                            case 876206036: {
                                v15 = 5011L ^ 9008524459348788272L;
                                continue block40;
                            }
                        }
                        break;
                    }
                    Main.API.keyboardClick(v11);
                    break block51;
                }
                while (true) {
                    if ((v16 = (cfr_temp_7 = TwNpcAttacker.\u13e8 - (25116L ^ 5377115536138732403L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                    if (v16 == (32024 ^ -32025)) break;
                    v16 = 26458 ^ -1960028061;
                }
                v17 = TwNpcAttacker.\u13e8;
                if (true) ** GOTO lbl100
                block42: while (true) {
                    v17 = (26738L ^ 7174998167977951267L) / (8914170995949881348L >>> "\u0000\u0000".length());
lbl100:
                    // 2 sources

                    switch ((int)v17) {
                        case -1083506109: {
                            break block42;
                        }
                        case 31019139: {
                            continue block42;
                        }
                    }
                    break;
                }
                while (true) {
                    if ((v18 = (cfr_temp_8 = TwNpcAttacker.\u13e8 - (7113L ^ 7217019720434308584L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                    if (v18 == (21587 ^ -21588)) break;
                    v18 = 4847 ^ -1022406016;
                }
                if (!Main.API.hasCapability(Capability.ALL_KEYBINDS_SUPPORT)) break block53;
                while (true) {
                    if ((v19 = (cfr_temp_9 = TwNpcAttacker.\u13e8 - (15749L ^ -3007317927459218967L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
                    if (v19 == (7939 ^ -7940)) break;
                    v19 = 7038 ^ -1097242383;
                }
                v20 = TwNpcAttacker.\u13e8;
                if (true) ** GOTO lbl120
                block45: while (true) {
                    v20 = (30823L ^ 4260658651652126360L) / (8507L ^ 7357427470342991317L);
lbl120:
                    // 2 sources

                    switch ((int)v20) {
                        case -1083506109: {
                            break block45;
                        }
                        case 608944519: {
                            continue block45;
                        }
                    }
                    break;
                }
                while (true) {
                    if ((v21 = (cfr_temp_10 = TwNpcAttacker.\u13e8 - (1390L ^ 8329361430602782011L)) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
                    if (v21 == (10850 ^ -10851)) {
                        this.keybinds.pressKeybind(SettingsProxy.KeyBind.ATTACK_LASER);
                        break block51;
                    }
                    v21 = 3783 ^ 1184919566;
                }
            }
            v22 = TwNpcAttacker.\u13e8;
            if (true) ** GOTO lbl137
            block47: while (true) {
                v22 = v23 / (19270L ^ -6888850188329997802L);
lbl137:
                // 2 sources

                switch ((int)v22) {
                    case -1643524518: {
                        v23 = 11552L ^ -1258189170923191147L;
                        continue block47;
                    }
                    case -1083506109: {
                        break block47;
                    }
                    case -872012459: {
                        v23 = 22340L ^ -7013422923979449772L;
                        continue block47;
                    }
                    case -480562446: {
                        v23 = 2265L ^ -5000262610381645061L;
                        continue block47;
                    }
                }
                break;
            }
            while (true) {
                if ((v24 = (cfr_temp_11 = TwNpcAttacker.\u13e8 - (4742L ^ -6274833948273431898L)) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
                if (v24 == (29725 ^ 29724)) {
                    this.target.trySelect((boolean)(27866 ^ 27867));
                    break;
                }
                v24 = 27347 ^ 1138136339;
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    public double modifyRadius(double radius) {
        block108: {
            block109: {
                block107: {
                    block106: {
                        block105: {
                            v0 = TwNpcAttacker.\u13e8;
                            if (true) ** GOTO lbl5
                            block71: while (true) {
                                v0 = v1 / (-4997533031761410500L >>> "\u0000\u0000".length());
lbl5:
                                // 2 sources

                                switch ((int)v0) {
                                    case -1083506109: {
                                        break block71;
                                    }
                                    case 338908321: {
                                        v1 = 1597L ^ -3356820445874824697L;
                                        continue block71;
                                    }
                                    case 469619773: {
                                        v1 = 17155L ^ 7680801208664625633L;
                                        continue block71;
                                    }
                                }
                                break;
                            }
                            while (true) {
                                if ((v2 = (cfr_temp_0 = TwNpcAttacker.\u13e8 - (32159L ^ -5304776232946071879L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                                if (v2 == (9806 ^ -9807)) break;
                                v2 = 4331 ^ 602628858;
                            }
                            v3 = this.target.health;
                            while (true) {
                                if ((v4 = (cfr_temp_1 = TwNpcAttacker.\u13e8 - (18319L ^ -2560401445981855460L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                                if (v4 == (23066 ^ -23067)) break;
                                v4 = 19813 ^ -158072650;
                            }
                            if (!(v3.hpPercent() < 0.25)) break block105;
                            while (true) {
                                if ((v5 = (cfr_temp_2 = TwNpcAttacker.\u13e8 - (31870L ^ -7372941431088193055L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                                if (v5 == (1910 ^ 1911)) break;
                                v5 = 1502 ^ -1212610318;
                            }
                            while (true) {
                                if ((v6 = (cfr_temp_3 = TwNpcAttacker.\u13e8 - (19837L ^ 9087961177284238707L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                                if (v6 == (5088 ^ -5089)) break;
                                v6 = 10144 ^ 1204338546;
                            }
                            v7 = this.target.npcInfo;
                            v8 = TwNpcAttacker.\u13e8;
                            if (true) ** GOTO lbl41
                            block76: while (true) {
                                v8 = (10119L ^ -7598662411862826119L) / (20145L ^ 4675854521349962246L);
lbl41:
                                // 2 sources

                                switch ((int)v8) {
                                    case -1083506109: {
                                        break block76;
                                    }
                                    case 1905971835: {
                                        continue block76;
                                    }
                                }
                                break;
                            }
                            v9 = v7.extra;
                            while (true) {
                                if ((v10 = (cfr_temp_4 = TwNpcAttacker.\u13e8 - (11019L ^ -4632484227291529342L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                                if (v10 == (22171 ^ -22172)) break;
                                v10 = 15997 ^ 942084223;
                            }
                            v11 = TwNpcAttacker.\u13e8;
                            if (true) ** GOTO lbl56
                            block78: while (true) {
                                v11 = v12 / (2019L ^ 6988119230359415421L);
lbl56:
                                // 2 sources

                                switch ((int)v11) {
                                    case -1083506109: {
                                        break block78;
                                    }
                                    case -375037570: {
                                        v12 = 27385L ^ 7572560045794625259L;
                                        continue block78;
                                    }
                                    case 325230031: {
                                        v12 = 8220L ^ -7815497436130869329L;
                                        continue block78;
                                    }
                                    case 1580583082: {
                                        v12 = 16068L ^ -6249048716111445731L;
                                        continue block78;
                                    }
                                }
                                break;
                            }
                            if (v9.has((NpcExtraFlag)NpcExtra.AGGRESSIVE_FOLLOW)) {
                                radius *= 0.75;
                            }
                        }
                        v13 = TwNpcAttacker.\u13e8;
                        if (true) ** GOTO lbl75
                        block79: while (true) {
                            v13 = v14 / (25211L ^ -7685053533782676926L);
lbl75:
                            // 2 sources

                            switch ((int)v13) {
                                case -1600833681: {
                                    v14 = 11779L ^ -4411499249990733492L;
                                    continue block79;
                                }
                                case -1083506109: {
                                    break block79;
                                }
                                case 638371771: {
                                    v14 = 6366L ^ -4567104237162812924L;
                                    continue block79;
                                }
                            }
                            break;
                        }
                        v15 = TwNpcAttacker.\u13e8;
                        if (true) ** GOTO lbl88
                        block80: while (true) {
                            v15 = v16 / (10155L ^ 8059093860132773347L);
lbl88:
                            // 2 sources

                            switch ((int)v15) {
                                case -1083506109: {
                                    break block80;
                                }
                                case 936380388: {
                                    v16 = 2150L ^ 1166960426363348623L;
                                    continue block80;
                                }
                                case 1401960481: {
                                    v16 = 29289L ^ -2343398500692436313L;
                                    continue block80;
                                }
                            }
                            break;
                        }
                        v17 = TwNpcAttacker.\u13e8;
                        if (true) ** GOTO lbl101
                        block81: while (true) {
                            v17 = (4844140833099266432L >>> "\u0000\u0000".length()) / (19776L ^ -5156599823954239416L);
lbl101:
                            // 2 sources

                            switch ((int)v17) {
                                case -1083506109: {
                                    break block81;
                                }
                                case 945973105: {
                                    continue block81;
                                }
                            }
                            break;
                        }
                        if (this.target != this.hero.getLocalTarget()) break block106;
                        while (true) {
                            if ((v18 = (cfr_temp_5 = TwNpcAttacker.\u13e8 - (4297L ^ 4233440086999770115L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                            if (v18 == (4516 ^ -4517)) break;
                            v18 = 2431 ^ 832773977;
                        }
                        while (true) {
                            if ((v19 = (cfr_temp_6 = TwNpcAttacker.\u13e8 - (-5633353490679878968L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                            if (v19 == (19111 ^ -19112)) break;
                            v19 = 28995 ^ 2051143626;
                        }
                        while (true) {
                            if ((v20 = (cfr_temp_7 = TwNpcAttacker.\u13e8 - (14728L ^ -8170750336899201270L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                            if (v20 == (5053 ^ 5052)) break;
                            v20 = 9220 ^ -633220360;
                        }
                        if (!this.hero.isAttacking((Ship)this.target)) break block106;
                        while (true) {
                            if ((v21 = (cfr_temp_8 = TwNpcAttacker.\u13e8 - (26990L ^ -394193537129279302L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                            if (v21 == (25171 ^ -25172)) break;
                            v21 = 26203 ^ -2023463319;
                        }
                        if (!this.castingAbility()) break block107;
                    }
                    v22 = TwNpcAttacker.\u13e8;
                    if (true) ** GOTO lbl134
                    block86: while (true) {
                        v22 = v23 / (9634L ^ -8266799205485519300L);
lbl134:
                        // 2 sources

                        switch ((int)v22) {
                            case -1717865406: {
                                v23 = 15400L ^ -4500012691996353908L;
                                continue block86;
                            }
                            case -1083506109: {
                                break block86;
                            }
                            case -263766181: {
                                v23 = 15565L ^ -2509784017928305268L;
                                continue block86;
                            }
                        }
                        break;
                    }
                    radius = Math.min(550.0, radius);
                    break block108;
                }
                v24 = TwNpcAttacker.\u13e8;
                if (true) ** GOTO lbl150
                block87: while (true) {
                    v24 = v25 / (3607L ^ 783178611242354654L);
lbl150:
                    // 2 sources

                    switch ((int)v24) {
                        case -1083506109: {
                            break block87;
                        }
                        case -597991362: {
                            v25 = 2459L ^ 148057423237852491L;
                            continue block87;
                        }
                        case 1630948943: {
                            v25 = 5316L ^ 2774646124093088045L;
                            continue block87;
                        }
                    }
                    break;
                }
                while (true) {
                    if ((v26 = (cfr_temp_9 = TwNpcAttacker.\u13e8 - (21555L ^ 8932770482918378096L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
                    if (v26 == (6794 ^ -6795)) break;
                    v26 = 2740 ^ -576957642;
                }
                v27 = this.target.locationInfo;
                v28 = TwNpcAttacker.\u13e8;
                if (true) ** GOTO lbl169
                block89: while (true) {
                    v28 = (5440408541772588040L >>> "\u0000\u0000".length()) / (7547L ^ -1812577255662620447L);
lbl169:
                    // 2 sources

                    switch ((int)v28) {
                        case -1909079298: {
                            continue block89;
                        }
                        case -1083506109: {
                            break block89;
                        }
                    }
                    break;
                }
                if (!v27.isMoving()) break block109;
                v29 = TwNpcAttacker.\u13e8;
                if (true) ** GOTO lbl179
                block90: while (true) {
                    v29 = (32655L ^ -8768029156134413454L) / (13123L ^ -6417145759668413855L);
lbl179:
                    // 2 sources

                    switch ((int)v29) {
                        case -1555220745: {
                            continue block90;
                        }
                        case -1083506109: {
                            break block90;
                        }
                    }
                    break;
                }
                v30 = TwNpcAttacker.\u13e8;
                if (true) ** GOTO lbl188
                block91: while (true) {
                    v30 = v31 / (23209L ^ 1295773172072892857L);
lbl188:
                    // 2 sources

                    switch ((int)v30) {
                        case -1083506109: {
                            break block91;
                        }
                        case 417872447: {
                            v31 = 5670L ^ -1348978906632658227L;
                            continue block91;
                        }
                        case 1164363212: {
                            v31 = 21049L ^ -5913483057553054534L;
                            continue block91;
                        }
                        case 1762266233: {
                            v31 = 23106L ^ -2181641390399826251L;
                            continue block91;
                        }
                    }
                    break;
                }
                v32 = this.target.health;
                while (true) {
                    if ((v33 = (cfr_temp_10 = TwNpcAttacker.\u13e8 - (5750L ^ -8222305397514687949L)) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
                    if (v33 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                    v33 = 5618 ^ 935364135;
                }
                if (!(v32.hpPercent() < 0.25)) break block108;
            }
            while (true) {
                if ((v34 = (cfr_temp_11 = TwNpcAttacker.\u13e8 - (8260698813709373120L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
                if (v34 == (4906 ^ -4907)) break;
                v34 = 16928 ^ -769187478;
            }
            radius = Math.min(600.0, radius);
        }
        while (true) {
            if ((v35 = (cfr_temp_12 = TwNpcAttacker.\u13e8 - (32584L ^ 6193913974297434579L)) == 0L ? 0 : (cfr_temp_12 < 0L ? -1 : 1)) == false) continue;
            if (v35 == (17716 ^ -17717)) break;
            v35 = 30555 ^ -117867099;
        }
        var4_2 = new byte["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
        var4_2[13584 ^ 13589] = 288 >>> "\u0000\u0000".length();
        var4_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 11364 ^ 11280;
        var4_2["".length() >>> "\u0000\u0000".length()] = 24153 ^ 24120;
        var4_2[10128 ^ 10113] = 464 >>> "\u0000\u0000".length();
        var4_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 5464 ^ 5418;
        var4_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 416 >>> "\u0000\u0000".length();
        var4_2[9316 ^ 9322] = 380 >>> "\u0000\u0000".length();
        var4_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 28811 ^ 28923;
        var4_2[2468 ^ 2471] = 432 >>> "\u0000\u0000".length();
        var4_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 26161 ^ 26196;
        var4_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 380 >>> "\u0000\u0000".length();
        var4_2[6753 ^ 6759] = 10639 ^ 10742;
        var4_2[4972 ^ 4964] = 488 >>> "\u0000\u0000".length();
        var4_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 18057 ^ 18148;
        var4_2[30941 ^ 30943] = 420 >>> "\u0000\u0000".length();
        var4_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 6249 ^ 6144;
        var4_2[32226 ^ 32238] = 484 >>> "\u0000\u0000".length();
        var4_2["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 17197 ^ 17231;
        var4_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 436 >>> "\u0000\u0000".length();
        v36 = new String(var4_2);
        v37 = TwNpcAttacker.\u13e8;
        if (true) ** GOTO lbl245
        block95: while (true) {
            v37 = (23615L ^ 7729551654142113363L) / (22501L ^ 8132439456718723752L);
lbl245:
            // 2 sources

            switch ((int)v37) {
                case -2052544693: {
                    continue block95;
                }
                case -1083506109: {
                    break block95;
                }
            }
            break;
        }
        v38 = this.bar.findItemById(v36);
        v39 = TwNpcAttacker.\u13e8;
        if (true) ** GOTO lbl255
        block96: while (true) {
            v39 = (31843L ^ -3125304709503689278L) / (10370L ^ 5975541841476265734L);
lbl255:
            // 2 sources

            switch ((int)v39) {
                case -2096415236: {
                    continue block96;
                }
                case -1083506109: {
                    break block96;
                }
            }
            break;
        }
        v40 = (Function<Item, Double>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, lambda$modifyRadius$0(com.github.manolo8.darkbot.core.objects.slotbars.Item ), (Lcom/github/manolo8/darkbot/core/objects/slotbars/Item;)Ljava/lang/Double;)();
        while (true) {
            if ((v41 = (cfr_temp_13 = TwNpcAttacker.\u13e8 - (16690L ^ 7781601954970545680L)) == 0L ? 0 : (cfr_temp_13 < 0L ? -1 : 1)) == false) continue;
            if (v41 == (17749 ^ -17750)) break;
            v41 = 1677941784 >>> "\u0000\u0000".length();
        }
        v42 = v38.map(v40);
        while (true) {
            if ((v43 = (cfr_temp_14 = TwNpcAttacker.\u13e8 - (10121L ^ -1908340391768414205L)) == 0L ? 0 : (cfr_temp_14 < 0L ? -1 : 1)) == false) continue;
            if (v43 == (3899 ^ -3900)) break;
            v43 = 24646 ^ -1335382460;
        }
        v44 = 0.0;
        v45 = TwNpcAttacker.\u13e8;
        if (true) ** GOTO lbl277
        block99: while (true) {
            v45 = (20389L ^ 4870002076745735529L) / (24363L ^ 1842996185993354117L);
lbl277:
            // 2 sources

            switch ((int)v45) {
                case -1083506109: {
                    break block99;
                }
                case -693232049: {
                    continue block99;
                }
            }
            break;
        }
        v46 = TwNpcAttacker.\u13e8;
        if (true) ** GOTO lbl286
        block100: while (true) {
            v46 = v47 / (16381L ^ 8790630741239855670L);
lbl286:
            // 2 sources

            switch ((int)v46) {
                case -1424206486: {
                    v47 = 2106L ^ -2085504059873501047L;
                    continue block100;
                }
                case -1083506109: {
                    break block100;
                }
                case 2058687617: {
                    v47 = 3129L ^ 458400538175224213L;
                    continue block100;
                }
                case 2125300030: {
                    v47 = -6224656326358758524L >>> "\u0000\u0000".length();
                    continue block100;
                }
            }
            break;
        }
        return radius + v42.orElse(v44) * 5.0;
    }

    /*
     * Unable to fully structure code
     */
    private Character getAttackKey() {
        block98: {
            block97: {
                block96: {
                    block94: {
                        block95: {
                            v0 = TwNpcAttacker.\u13e8;
                            if (true) ** GOTO lbl5
                            block68: while (true) {
                                v0 = v1 / (13916L ^ -7735745775560971568L);
lbl5:
                                // 2 sources

                                switch ((int)v0) {
                                    case -1735159372: {
                                        v1 = 21538L ^ -8779403338282104256L;
                                        continue block68;
                                    }
                                    case -1083506109: {
                                        break block68;
                                    }
                                    case 1064592073: {
                                        v1 = 15030L ^ -2859989748716327076L;
                                        continue block68;
                                    }
                                }
                                break;
                            }
                            TwNpcAttacker.caller = this;
                            v2 = TwNpcAttacker.\u13e8;
                            if (true) ** GOTO lbl19
                            block69: while (true) {
                                v2 = v3 / (2269097994304817844L >>> "\u0000\u0000".length());
lbl19:
                                // 2 sources

                                switch ((int)v2) {
                                    case -1083506109: {
                                        break block69;
                                    }
                                    case -278565884: {
                                        v3 = 15572L ^ 5974496124470283020L;
                                        continue block69;
                                    }
                                    case 1546100298: {
                                        v3 = 24711L ^ -5485764222388280969L;
                                        continue block69;
                                    }
                                }
                                break;
                            }
                            v4 = TwNpcAttacker.\u13e8;
                            if (true) ** GOTO lbl32
                            block70: while (true) {
                                v4 = v5 / (29847L ^ 2881216750558312149L);
lbl32:
                                // 2 sources

                                switch ((int)v4) {
                                    case -1596215342: {
                                        v5 = 22115L ^ -297529335208228843L;
                                        continue block70;
                                    }
                                    case -1083506109: {
                                        break block70;
                                    }
                                    case -547206358: {
                                        v5 = 6319L ^ 4975650626485678612L;
                                        continue block70;
                                    }
                                    case 1590349332: {
                                        v5 = 10430L ^ -3871437751552042321L;
                                        continue block70;
                                    }
                                }
                                break;
                            }
                            laser = (SelectableItem.Laser)this.laserHandler.getBest();
                            while (true) {
                                if ((v6 = (cfr_temp_0 = TwNpcAttacker.\u13e8 - (26011L ^ 2776416925724915376L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                                if (v6 == (6595 ^ -6596)) break;
                                v6 = 31112 ^ 492729134;
                            }
                            TwNpcAttacker.caller = null;
                            if (laser == null) break block94;
                            skipShot = "".length() >>> "\u0000\u0000".length();
                            v7 = TwNpcAttacker.\u13e8;
                            if (true) ** GOTO lbl57
                            block72: while (true) {
                                v7 = (21182L ^ -6851541061872993769L) / (27430L ^ -1007234564911967186L);
lbl57:
                                // 2 sources

                                switch ((int)v7) {
                                    case -1083506109: {
                                        break block72;
                                    }
                                    case 948871316: {
                                        continue block72;
                                    }
                                }
                                break;
                            }
                            if (this.config == null) break block95;
                            v8 = TwNpcAttacker.\u13e8;
                            if (true) ** GOTO lbl67
                            block73: while (true) {
                                v8 = (9960L ^ 8426910390750683740L) / (19620L ^ -6579113277625818444L);
lbl67:
                                // 2 sources

                                switch ((int)v8) {
                                    case -1083506109: {
                                        break block73;
                                    }
                                    case 783224208: {
                                        continue block73;
                                    }
                                }
                                break;
                            }
                            isRsb = laser.hasCooldown();
                            v9 = TwNpcAttacker.\u13e8;
                            if (true) ** GOTO lbl77
                            block74: while (true) {
                                v9 = (12474L ^ 9014446951087981749L) / (15485L ^ 690918527008874457L);
lbl77:
                                // 2 sources

                                switch ((int)v9) {
                                    case -1083506109: {
                                        break block74;
                                    }
                                    case 902271624: {
                                        continue block74;
                                    }
                                }
                                break;
                            }
                            v10 = willBeFirstAttack = this.firstAttack == false ? 5781 ^ 5780 : "".length() >>> "\u0000\u0000".length();
                            if (!isRsb || willBeFirstAttack == 0) ** GOTO lbl-1000
                            v11 = TwNpcAttacker.\u13e8;
                            if (true) ** GOTO lbl88
                            block75: while (true) {
                                v11 = v12 / (18753L ^ 4346835020886170981L);
lbl88:
                                // 2 sources

                                switch ((int)v11) {
                                    case -1083506109: {
                                        break block75;
                                    }
                                    case 130515660: {
                                        v12 = 6440L ^ 1904095863373470329L;
                                        continue block75;
                                    }
                                    case 969717890: {
                                        v12 = 8339L ^ -3510546930107437899L;
                                        continue block75;
                                    }
                                }
                                break;
                            }
                            v13 = TwNpcAttacker.\u13e8;
                            if (true) ** GOTO lbl101
                            block76: while (true) {
                                v13 = v14 / (-3965345619197466796L >>> "\u0000\u0000".length());
lbl101:
                                // 2 sources

                                switch ((int)v13) {
                                    case -1083506109: {
                                        break block76;
                                    }
                                    case 451307231: {
                                        v14 = 29731L ^ -2855903625281910153L;
                                        continue block76;
                                    }
                                    case 1246684392: {
                                        v14 = 32215L ^ 7444559318294863471L;
                                        continue block76;
                                    }
                                    case 1368569313: {
                                        v14 = 30351L ^ -742844174381275135L;
                                        continue block76;
                                    }
                                }
                                break;
                            }
                            if (!this.config.USE_RSB_FOR_FIRST_ATTACK) {
                                v15 = 1456 ^ 1457;
                            } else lbl-1000:
                            // 2 sources

                            {
                                v15 = skipShot = 2449 ^ 2449;
                            }
                        }
                        if (skipShot == 0) {
                            while (true) {
                                if ((v16 = (cfr_temp_1 = TwNpcAttacker.\u13e8 - (7629283431347318200L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                                if (v16 == (1155 ^ -1156)) break;
                                v16 = 5164 ^ 854267241;
                            }
                            while (true) {
                                if ((v17 = (cfr_temp_2 = TwNpcAttacker.\u13e8 - (27246L ^ -127264505060324152L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                                if (v17 == (6928 ^ -6929)) break;
                                v17 = 6680 ^ 1212409998;
                            }
                            key = this.items.getKeyBind((SelectableItem)laser);
                            if (key != null) {
                                return key;
                            }
                        }
                    }
                    while (true) {
                        if ((v18 = (cfr_temp_3 = TwNpcAttacker.\u13e8 - (20686L ^ -4972003276544847712L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                        if (v18 == (26551 ^ -26552)) break;
                        v18 = 13414 ^ -1663013972;
                    }
                    if (this.target == null) break block96;
                    while (true) {
                        if ((v19 = (cfr_temp_4 = TwNpcAttacker.\u13e8 - (20641L ^ 4045683451681619762L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                        if (v19 == (13185 ^ -13186)) break;
                        v19 = 22182 ^ -81145497;
                    }
                    v20 = TwNpcAttacker.\u13e8;
                    if (true) ** GOTO lbl148
                    block81: while (true) {
                        v20 = v21 / (30507L ^ -1428871719342110442L);
lbl148:
                        // 2 sources

                        switch ((int)v20) {
                            case -2068451669: {
                                v21 = 31365L ^ 6293958893173656774L;
                                continue block81;
                            }
                            case -1083506109: {
                                break block81;
                            }
                            case 721655149: {
                                v21 = 626L ^ -6556027532272195183L;
                                continue block81;
                            }
                        }
                        break;
                    }
                    v22 = this.target.npcInfo;
                    while (true) {
                        if ((v23 = (cfr_temp_5 = TwNpcAttacker.\u13e8 - (8441222759821696012L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                        if (v23 == (2665 ^ -2666)) break;
                        v23 = 25775 ^ -192500824;
                    }
                    if (v22.attackKey != null) break block97;
                }
                v24 = TwNpcAttacker.\u13e8;
                if (true) ** GOTO lbl169
                block83: while (true) {
                    v24 = v25 / (7442L ^ 5127943372413006756L);
lbl169:
                    // 2 sources

                    switch ((int)v24) {
                        case -1588723066: {
                            v25 = 30002L ^ -4829145526026792756L;
                            continue block83;
                        }
                        case -1083506109: {
                            break block83;
                        }
                        case -835077665: {
                            v25 = 31287L ^ -5648165403761225960L;
                            continue block83;
                        }
                    }
                    break;
                }
                v26 = TwNpcAttacker.\u13e8;
                if (true) ** GOTO lbl182
                block84: while (true) {
                    v26 = (30814L ^ 5938634422895509149L) / (20684L ^ -5808502757646557235L);
lbl182:
                    // 2 sources

                    switch ((int)v26) {
                        case -1083506109: {
                            break block84;
                        }
                        case 259050911: {
                            continue block84;
                        }
                    }
                    break;
                }
                v27 = this.main.config;
                v28 = TwNpcAttacker.\u13e8;
                if (true) ** GOTO lbl192
                block85: while (true) {
                    v28 = (9923L ^ -2007479683118497167L) / (27789L ^ 3924481005546736649L);
lbl192:
                    // 2 sources

                    switch ((int)v28) {
                        case -2054227050: {
                            continue block85;
                        }
                        case -1083506109: {
                            break block85;
                        }
                    }
                    break;
                }
                v29 = v27.LOOT;
                v30 = TwNpcAttacker.\u13e8;
                if (true) ** GOTO lbl202
                block86: while (true) {
                    v30 = v31 / (31297L ^ 386166659358340289L);
lbl202:
                    // 2 sources

                    switch ((int)v30) {
                        case -1642056880: {
                            v31 = 3522L ^ 4915887471296310737L;
                            continue block86;
                        }
                        case -1083506109: {
                            break block86;
                        }
                        case -703954798: {
                            v31 = 15714L ^ -4128938696274003195L;
                            continue block86;
                        }
                        case -241078945: {
                            v31 = 29598L ^ 8941307533140456486L;
                            continue block86;
                        }
                    }
                    break;
                }
                v32 = v29.AMMO_KEY;
                break block98;
            }
            while (true) {
                if ((v33 = (cfr_temp_6 = TwNpcAttacker.\u13e8 - (-9127462534938383980L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                if (v33 == (7624 ^ -7625)) break;
                v33 = 15329 ^ 1245194676;
            }
            while (true) {
                if ((v34 = (cfr_temp_7 = TwNpcAttacker.\u13e8 - (12770L ^ 8500317613333454688L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                if (v34 == (24000 ^ -24001)) break;
                v34 = 10924 ^ 1004112122;
            }
            v35 = this.target.npcInfo;
            v36 = TwNpcAttacker.\u13e8;
            if (true) ** GOTO lbl232
            block89: while (true) {
                v36 = v37 / (-8927335707930654092L >>> "\u0000\u0000".length());
lbl232:
                // 2 sources

                switch ((int)v36) {
                    case -2078363509: {
                        v37 = 952L ^ 9204504516987850713L;
                        continue block89;
                    }
                    case -1083506109: {
                        break block89;
                    }
                    case 1328475342: {
                        v37 = 5950L ^ -4436493763519012189L;
                        continue block89;
                    }
                }
                break;
            }
            v32 = v35.attackKey;
        }
        return v32;
    }

    private Character getPreviousAttackKey() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0xD51L ^ 0xD601CFF1ABA8EE52L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == (0x20D9 ^ 0xFFFFDF26)) break;
            l2 = 0x30A0 ^ 0xA47BF154;
        }
        return this.lastShot;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public Lockable getTarget() {
        long l = \u13e8;
        boolean bl = true;
        block5: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x6903L ^ 0x921E0292FDA5A772L);
            }
            switch ((int)l) {
                case -1083506109: {
                    return this.target;
                }
                case -550199043: {
                    l2 = 0x6373L ^ 0xF20785D7BA8F5963L;
                    continue block5;
                }
                case 42598987: {
                    l2 = 0xB1L ^ 0x855A7B7A38A48248L;
                    continue block5;
                }
            }
            break;
        }
        return this.target;
    }

    /*
     * Unable to fully structure code
     */
    public void setTarget(Lockable target) {
        block9: {
            if (target == null || target instanceof Npc) break block9;
            while (true) {
                if ((v0 = (cfr_temp_0 = TwNpcAttacker.\u13e8 - (31394L ^ -8175392972921205453L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v0 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v0 = 29713 ^ -2024637557;
            }
            var3_2 = new byte[15800 ^ 15758];
            var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 21371 ^ -21267;
            var3_2[8845 ^ 8846] = 21059 ^ 21050;
            var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 407 ^ 504;
            var3_2[14842 ^ 14810] = 25204 ^ 25110;
            var3_2[8846 ^ 8869] = 7128 ^ 7092;
            var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 448 >>> "\u0000\u0000".length();
            var3_2[26162 ^ 26163] = 440 >>> "\u0000\u0000".length();
            var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 16665 ^ 16745;
            var3_2[4297 ^ 4301] = 128 >>> "\u0000\u0000".length();
            var3_2[200 >>> "\u0000\u0000".length()] = 21840 ^ 21796;
            var3_2[24916 ^ 24918] = 432 >>> "\u0000\u0000".length();
            var3_2[32635 ^ 32625] = 464 >>> "\u0000\u0000".length();
            var3_2[19656 ^ 19692] = 6721 ^ 6697;
            var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 17481 ^ 17513;
            var3_2[1876 ^ 1910] = 9359 ^ 9391;
            var3_2[204 >>> "\u0000\u0000".length()] = 420 >>> "\u0000\u0000".length();
            var3_2[160 >>> "\u0000\u0000".length()] = 17471 ^ 17494;
            var3_2[25028 ^ 25065] = 29819 ^ 29718;
            var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 464 >>> "\u0000\u0000".length();
            var3_2[21584 ^ 21597] = 396 >>> "\u0000\u0000".length();
            var3_2[17491 ^ 17529] = 17456 ^ 17472;
            var3_2[212 >>> "\u0000\u0000".length()] = 6337 ^ 6319;
            var3_2[2914 ^ 2894] = 32327 ^ 32290;
            var3_2[2067 ^ 2101] = 25106 ^ 25185;
            var3_2[21147 ^ 21182] = 420 >>> "\u0000\u0000".length();
            var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 21682 ^ 21702;
            var3_2[196 >>> "\u0000\u0000".length()] = 388 >>> "\u0000\u0000".length();
            var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 2327 ^ 2359;
            var3_2[6035 ^ 6077] = 29778 ^ 29751;
            var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 428 >>> "\u0000\u0000".length();
            var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 460 >>> "\u0000\u0000".length();
            var3_2[3536 ^ 3548] = 26377 ^ 26472;
            var3_2[18294 ^ 18291] = 8367 ^ 8417;
            var3_2[208 >>> "\u0000\u0000".length()] = 444 >>> "\u0000\u0000".length();
            var3_2[5308 ^ 5288] = 27672 ^ 27755;
            var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 606 ^ 570;
            var3_2[17989 ^ 17996] = 9749 ^ 9844;
            var3_2[4651 ^ 4664] = 420 >>> "\u0000\u0000".length();
            var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 22047 ^ 22138;
            var3_2[188 >>> "\u0000\u0000".length()] = 440 >>> "\u0000\u0000".length();
            var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 412 >>> "\u0000\u0000".length();
            var3_2[27786 ^ 27834] = 26165 ^ 26177;
            var3_2[11626 ^ 11628] = 2636 ^ 2588;
            var3_2[140 >>> "\u0000\u0000".length()] = 15630 ^ 15738;
            var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 440 >>> "\u0000\u0000".length();
            var3_2[15004 ^ 14990] = 7765 ^ 7797;
            var3_2[28764 ^ 28747] = 468 >>> "\u0000\u0000".length();
            var3_2[5007 ^ 5007] = 316 >>> "\u0000\u0000".length();
            var3_2[31685 ^ 31682] = 25891 ^ 25952;
            var3_2[29438 ^ 29401] = 128 >>> "\u0000\u0000".length();
            var3_2[6937 ^ 6968] = 5321 ^ 5296;
            var3_2[934 ^ 947] = 128 >>> "\u0000\u0000".length();
            var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 23789 ^ 23711;
            var3_2[31619 ^ 31658] = 11415 ^ 11514;
            var3_2[1055 ^ 1040] = 420 >>> "\u0000\u0000".length();
            v1 = new String(var3_2);
            v2 = TwNpcAttacker.\u13e8;
            if (true) ** GOTO lbl68
            block7: while (true) {
                v2 = v3 / (4605L ^ 2748424028585926772L);
lbl68:
                // 2 sources

                switch ((int)v2) {
                    case -1894955404: {
                        v3 = 21799L ^ 7634229349862170570L;
                        continue block7;
                    }
                    case -1083506109: {
                        break block7;
                    }
                    case 264391586: {
                        v3 = 29500L ^ -3633259881819443576L;
                        continue block7;
                    }
                    case 1385222429: {
                        v3 = 8785L ^ 7220198381858604478L;
                        continue block7;
                    }
                }
                break;
            }
            throw new IllegalArgumentException(v1);
        }
        v4 = (Npc)target;
        while (true) {
            if ((v5 = (cfr_temp_1 = TwNpcAttacker.\u13e8 - (26350L ^ -6982883657938056286L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v5 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v5 = 19687 ^ 718324152;
        }
        this.target = v4;
    }

    /*
     * Unable to fully structure code
     */
    public boolean isLocked() {
        while (true) {
            if ((v0 = (cfr_temp_0 = TwNpcAttacker.\u13e8 - (11514L ^ -778641575955325986L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v0 == (30559 ^ -30560)) break;
            v0 = 14327 ^ 747799223;
        }
        v1 = TwNpcAttacker.\u13e8;
        if (true) ** GOTO lbl11
        block11: while (true) {
            v1 = v2 / (32670L ^ 427082913766043778L);
lbl11:
            // 2 sources

            switch ((int)v1) {
                case -1083506109: {
                    break block11;
                }
                case -49926466: {
                    v2 = 7957L ^ -1222315766798979883L;
                    continue block11;
                }
                case 350881716: {
                    v2 = 105L ^ -4782702200635343970L;
                    continue block11;
                }
            }
            break;
        }
        v3 = TwNpcAttacker.\u13e8;
        if (true) ** GOTO lbl24
        block12: while (true) {
            v3 = v4 / (3728L ^ 47846133401966037L);
lbl24:
            // 2 sources

            switch ((int)v3) {
                case -1712648547: {
                    v4 = 4541L ^ 4711282098734599609L;
                    continue block12;
                }
                case -1083506109: {
                    break block12;
                }
                case 40521768: {
                    v4 = 8711L ^ -956305631434047940L;
                    continue block12;
                }
            }
            break;
        }
        return this.mapManager.isTarget((Entity)this.target);
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public void tryLockTarget() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x16EAL ^ 0x585659F1A607BEC0L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == (0x695 ^ 0xFFFFF96A)) break;
            l2 = 0x63B8 ^ 0xE4AA95D3;
        }
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = \u13e8 - (0x55BFL ^ 0xB5B64066A1CE769BL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l3 == (0x3500 ^ 0xFFFFCAFF)) break;
            l3 = 0x1B4E ^ 0x6BC01FAF;
        }
        while (true) {
            long l;
            long l4;
            if ((l4 = (l = \u13e8 - (0x1757L ^ 0xDD4007D63E8B75D9L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l4 == (0x71A4 ^ 0xFFFF8E5B)) {
                if (this.mapManager.isTarget((Entity)this.target)) return;
                break;
            }
            l4 = 0x5822 ^ 0x84053ADD;
        }
        long l = \u13e8;
        boolean bl = true;
        block9: while (true) {
            long l5;
            if (!bl || (bl = false) || !true) {
                l = l5 / (0x459FL ^ 0xB76A0D7364EB19ADL);
            }
            switch ((int)l) {
                case -1083506109: {
                    break block9;
                }
                case 943593953: {
                    l5 = 0x54EFL ^ 0x72ED336845EDA0E8L;
                    continue block9;
                }
                case 1290165812: {
                    l5 = 0x60F4L ^ 0x47BE8BF31F4283A7L;
                    continue block9;
                }
                case 1340206367: {
                    l5 = 9006707523075395596L >>> "\u0000\u0000".length();
                    continue block9;
                }
            }
            break;
        }
        this.lockAndSetTarget();
    }

    /*
     * Unable to fully structure code
     */
    public boolean isAttacking() {
        while (true) {
            if ((v0 = (cfr_temp_0 = TwNpcAttacker.\u13e8 - (20896L ^ 2939052217395106642L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v0 == (3375 ^ -3376)) break;
            v0 = 21040 ^ -903158494;
        }
        v1 = TwNpcAttacker.\u13e8;
        if (true) ** GOTO lbl11
        block6: while (true) {
            v1 = v2 / (11507L ^ -1276042158314457333L);
lbl11:
            // 2 sources

            switch ((int)v1) {
                case -1565584629: {
                    v2 = 32322L ^ 5087517390812031923L;
                    continue block6;
                }
                case -1083506109: {
                    break block6;
                }
                case 1787069097: {
                    v2 = -4554919798273590460L >>> "\u0000\u0000".length();
                    continue block6;
                }
            }
            break;
        }
        while (true) {
            if ((v3 = (cfr_temp_1 = TwNpcAttacker.\u13e8 - (1375369232694965220L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v3 == (32764 ^ -32765)) break;
            v3 = 25239 ^ 973852780;
        }
        return this.hero.isAttacking((Ship)this.target);
    }

    public void tryLockAndAttack() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (1689381842020356336L >>> "\u0000\u0000".length())) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x452D ^ 0xFFFFBAD2)) break;
            l2 = 0x6D5C ^ 0xE1A7BFD7;
        }
        this.doKillTargetTick();
    }

    /*
     * Unable to fully structure code
     */
    public void stopAttack() {
        block71: {
            block72: {
                v0 = TwNpcAttacker.\u13e8;
                if (true) ** GOTO lbl5
                block53: while (true) {
                    v0 = (16416L ^ -8112358648212093526L) / (16722L ^ -2217235927864810489L);
lbl5:
                    // 2 sources

                    switch ((int)v0) {
                        case -1964426081: {
                            continue block53;
                        }
                        case -1083506109: {
                            break block53;
                        }
                    }
                    break;
                }
                v1 = System.currentTimeMillis();
                while (true) {
                    if ((v2 = (cfr_temp_0 = TwNpcAttacker.\u13e8 - (130L ^ -6511119029338216073L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                    if (v2 == (29395 ^ 29394)) break;
                    v2 = 1815873376 >>> "\u0000\u0000".length();
                }
                if (v1 < this.laserTime) {
                    return;
                }
                v3 = TwNpcAttacker.\u13e8;
                if (true) ** GOTO lbl22
                block55: while (true) {
                    v3 = v4 / (-6707914578454758376L >>> "\u0000\u0000".length());
lbl22:
                    // 2 sources

                    switch ((int)v3) {
                        case -1083506109: {
                            break block55;
                        }
                        case -177204070: {
                            v4 = 8099L ^ 1994189022668094224L;
                            continue block55;
                        }
                        case 1111993180: {
                            v4 = 4694135917459288472L >>> "\u0000\u0000".length();
                            continue block55;
                        }
                    }
                    break;
                }
                if (!this.isAttacking()) break block71;
                v5 = TwNpcAttacker.\u13e8;
                if (true) ** GOTO lbl36
                block56: while (true) {
                    v5 = (28423L ^ 4514453253253413888L) / (887L ^ -9007382035004957970L);
lbl36:
                    // 2 sources

                    switch ((int)v5) {
                        case -1083506109: {
                            break block56;
                        }
                        case 1863978757: {
                            continue block56;
                        }
                    }
                    break;
                }
                v6 = System.currentTimeMillis() + (10004L ^ 8904L);
                while (true) {
                    if ((v7 = (cfr_temp_1 = TwNpcAttacker.\u13e8 - (11845L ^ -3039140156522414990L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                    if (v7 == (4867 ^ -4868)) break;
                    v7 = 1694338360 >>> "\u0000\u0000".length();
                }
                this.laserTime = v6;
                while (true) {
                    if ((v8 = (cfr_temp_2 = TwNpcAttacker.\u13e8 - (31486L ^ -4028058802334820547L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                    if (v8 == (31333 ^ -31334)) break;
                    v8 = 10120 ^ -1349737809;
                }
                v9 = TwNpcAttacker.\u13e8;
                if (true) ** GOTO lbl57
                block59: while (true) {
                    v9 = (19589L ^ -3863366829414528336L) / (29977L ^ 7982827441105627790L);
lbl57:
                    // 2 sources

                    switch ((int)v9) {
                        case -1083506109: {
                            break block59;
                        }
                        case -466942890: {
                            continue block59;
                        }
                    }
                    break;
                }
                v10 = TwNpcAttacker.\u13e8;
                if (true) ** GOTO lbl66
                block60: while (true) {
                    v10 = (-909622816799361620L >>> "\u0000\u0000".length()) / (915L ^ 6951580225592402774L);
lbl66:
                    // 2 sources

                    switch ((int)v10) {
                        case -1083506109: {
                            break block60;
                        }
                        case -976459913: {
                            continue block60;
                        }
                    }
                    break;
                }
                if (!Main.API.hasCapability(Capability.ALL_KEYBINDS_SUPPORT)) break block72;
                v11 = TwNpcAttacker.\u13e8;
                if (true) ** GOTO lbl76
                block61: while (true) {
                    v11 = v12 / (10868L ^ 8265599072741335145L);
lbl76:
                    // 2 sources

                    switch ((int)v11) {
                        case -1325773810: {
                            v12 = 6482L ^ -2677553352087880460L;
                            continue block61;
                        }
                        case -1083506109: {
                            break block61;
                        }
                        case 939525570: {
                            v12 = 3882851710333637336L >>> "\u0000\u0000".length();
                            continue block61;
                        }
                        case 1513533318: {
                            v12 = 9304L ^ -2629519095551472556L;
                            continue block61;
                        }
                    }
                    break;
                }
                v13 = TwNpcAttacker.\u13e8;
                if (true) ** GOTO lbl92
                block62: while (true) {
                    v13 = v14 / (22122L ^ -967851221544870926L);
lbl92:
                    // 2 sources

                    switch ((int)v13) {
                        case -1083506109: {
                            break block62;
                        }
                        case -73404317: {
                            v14 = 17085L ^ -4279969586051085723L;
                            continue block62;
                        }
                        case 492967025: {
                            v14 = 21637L ^ -1166789344371911348L;
                            continue block62;
                        }
                    }
                    break;
                }
                v15 = TwNpcAttacker.\u13e8;
                if (true) ** GOTO lbl105
                block63: while (true) {
                    v15 = v16 / (13650L ^ -9000151694915213534L);
lbl105:
                    // 2 sources

                    switch ((int)v15) {
                        case -1083506109: {
                            break block63;
                        }
                        case -629742925: {
                            v16 = 30434L ^ -7815101184768437399L;
                            continue block63;
                        }
                        case 1634965391: {
                            v16 = 11632L ^ 6214044618133206991L;
                            continue block63;
                        }
                    }
                    break;
                }
                v17 = TwNpcAttacker.\u13e8;
                if (true) ** GOTO lbl118
                block64: while (true) {
                    v17 = v18 / (18331L ^ -7001554719756601184L);
lbl118:
                    // 2 sources

                    switch ((int)v17) {
                        case -1153995598: {
                            v18 = -8187437245139596532L >>> "\u0000\u0000".length();
                            continue block64;
                        }
                        case -1083506109: {
                            break block64;
                        }
                        case 944724875: {
                            v18 = 16327L ^ -5311666953888938617L;
                            continue block64;
                        }
                        case 1928099023: {
                            v18 = -8208910169885566552L >>> "\u0000\u0000".length();
                            continue block64;
                        }
                    }
                    break;
                }
                v19 = this.keybinds.getCharCode(SettingsProxy.KeyBind.ATTACK_LASER);
                while (true) {
                    if ((v20 = (cfr_temp_3 = TwNpcAttacker.\u13e8 - (25477L ^ 7397443517570272553L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                    if (v20 == (8741 ^ -8742)) {
                        Main.API.keyboardClick(v19);
                        break block71;
                    }
                    v20 = -366166768 >>> "\u0000\u0000".length();
                }
            }
            while (true) {
                if ((v21 = (cfr_temp_4 = TwNpcAttacker.\u13e8 - (25554L ^ -5020685343436891884L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v21 == (14247 ^ -14248)) break;
                v21 = 21956 ^ 1722860095;
            }
            v22 = TwNpcAttacker.\u13e8;
            if (true) ** GOTO lbl148
            block67: while (true) {
                v22 = v23 / (28433L ^ 6941925600415400724L);
lbl148:
                // 2 sources

                switch ((int)v22) {
                    case -1571658548: {
                        v23 = 18218L ^ -2887261775724048831L;
                        continue block67;
                    }
                    case -1083506109: {
                        break block67;
                    }
                    case -183023804: {
                        v23 = 16059L ^ 6612080600662481145L;
                        continue block67;
                    }
                }
                break;
            }
            v24 = this.getPreviousAttackKey();
            v25 = TwNpcAttacker.\u13e8;
            if (true) ** GOTO lbl162
            block68: while (true) {
                v25 = v26 / (13826L ^ 7281913204297514157L);
lbl162:
                // 2 sources

                switch ((int)v25) {
                    case -1696015957: {
                        v26 = 17172L ^ 7327371007078147762L;
                        continue block68;
                    }
                    case -1083506109: {
                        break block68;
                    }
                    case 984085963: {
                        v26 = 16327L ^ 4348883818525890057L;
                        continue block68;
                    }
                }
                break;
            }
            Main.API.keyboardClick(v24);
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public String getStatus() {
        long l = \u13e8;
        boolean bl = true;
        block5: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x2B5CL ^ 0x56CDDADC70085DFCL);
            }
            switch ((int)l) {
                case -1083506109: {
                    return this.status();
                }
                case -1016960869: {
                    l2 = 0x6EF2L ^ 0xFC0930B5F288758EL;
                    continue block5;
                }
                case 1505492477: {
                    l2 = 0x3DF4L ^ 0x436408211BAAA3C3L;
                    continue block5;
                }
            }
            break;
        }
        return this.status();
    }

    public boolean isCastingAbility() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x7305L ^ 0x30532E6DBE5DF65DL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == (0x4B31 ^ 0xFFFFB4CE)) break;
            l2 = 0x5320 ^ 0xA11805B6;
        }
        return this.castingAbility();
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public static AttackAPI getCallerOr(AttackAPI api) {
        AttackAPI attackAPI;
        long l = \u13e8;
        boolean bl = true;
        block11: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (1906364576453902016L >>> "\u0000\u0000".length());
            }
            switch ((int)l) {
                case -1083506109: {
                    break block11;
                }
                case -522481809: {
                    l2 = -3116837552555543872L >>> "\u0000\u0000".length();
                    continue block11;
                }
                case 3365889: {
                    l2 = -8704395112959930224L >>> "\u0000\u0000".length();
                    continue block11;
                }
                case 646216509: {
                    l2 = 0x46DAL ^ 0xB5F074CAFF4E3085L;
                    continue block11;
                }
            }
            break;
        }
        if (caller == null) {
            attackAPI = api;
            return attackAPI;
        }
        long l3 = \u13e8;
        boolean bl2 = true;
        block12: while (true) {
            long l4;
            if (!bl2 || (bl2 = false) || !true) {
                l3 = l4 / (0x9A7L ^ 0x14496016773A0B66L);
            }
            switch ((int)l3) {
                case -1083506109: {
                    break block12;
                }
                case 186077081: {
                    l4 = 0x36DFL ^ 0x780C72EA43269F2EL;
                    continue block12;
                }
                case 1170617555: {
                    l4 = 0x50DEL ^ 0x470BE501AAF309AFL;
                    continue block12;
                }
            }
            break;
        }
        attackAPI = caller;
        return attackAPI;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public void setConfig(TwLootModuleConfig config) {
        long l = \u13e8;
        boolean bl = true;
        block6: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x5B7EL ^ 0xEF13E04EF99E2065L);
            }
            switch ((int)l) {
                case -1475555462: {
                    l2 = 0x1606L ^ 0xC0F245D5782275CAL;
                    continue block6;
                }
                case -1391310232: {
                    l2 = 0x7E9CL ^ 0xFA29C907F23E96B3L;
                    continue block6;
                }
                case -1083506109: {
                    break block6;
                }
                case 1204491197: {
                    l2 = 0x6600L ^ 0x787101FAF6D46C1CL;
                    continue block6;
                }
            }
            break;
        }
        this.config = config;
    }

    /*
     * Enabled aggressive block sorting
     */
    private static /* synthetic */ Double lambda$modifyRadius$0(Item i) {
        long l = \u13e8;
        block4: while (true) {
            switch ((int)l) {
                case -1083506109: {
                    break block4;
                }
                case -351538737: {
                    l = (0x2423L ^ 0xC4E99CB186A0B7CFL) / (0x350FL ^ 0x5A307BAA84D200FFL);
                    continue block4;
                }
            }
            break;
        }
        double d = i.quantity;
        while (true) {
            long l2;
            long l3;
            if ((l3 = (l2 = \u13e8 - (0x68B1L ^ 0x828E25448F6EBBC3L)) == 0L ? 0 : (l2 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l3 == (0x704C ^ 0x704D)) {
                return d;
            }
            l3 = 0x62EA ^ 0xA9D2809A;
        }
    }

    @Feature(name="SAB supplier", description="Supplies SAB ammo if enabled & should enable")
    public static class SabSupplier
    implements LaserSelector,
    PrioritizedSupplier<SelectableItem.Laser> {
        private final Main main;
        private final HeroAPI hero;
        private final AttackAPI attacker;
        private final HeroItemsAPI items;
        static long \u13e8 = 4346627110484274424L;

        public SabSupplier(Main main, HeroAPI hero, AttackAPI attacker, HeroItemsAPI items) {
            while (true) {
                long l;
                long l2;
                if ((l2 = (l = \u13e8 - (0x43C9L ^ 0xDED7EA9DF50D44ADL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
                if (l2 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                l2 = 0x3F90 ^ 0x420BC5F0;
            }
            while (true) {
                long l;
                long l3;
                if ((l3 = (l = \u13e8 - (4968169735154850652L >>> "\u0000\u0000".length())) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
                if (l3 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                l3 = 0x634 ^ 0x192370FF;
            }
            this.main = main;
            while (true) {
                long l;
                long l4;
                if ((l4 = (l = \u13e8 - (4906579431780115004L >>> "\u0000\u0000".length())) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
                if (l4 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                l4 = 0x601B ^ 0xC5D10A86;
            }
            this.hero = hero;
            while (true) {
                long l;
                long l5;
                if ((l5 = (l = \u13e8 - (0x3873L ^ 0xA0FEE9DE5347652BL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
                if (l5 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                l5 = -1366650540 >>> "\u0000\u0000".length();
            }
            this.attacker = attacker;
            while (true) {
                long l;
                long l6;
                if ((l6 = (l = \u13e8 - (0x5983L ^ 0xE4717873F534FA77L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
                if (l6 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                l6 = 0x37D3 ^ 0x5C9C116A;
            }
            this.items = items;
        }

        public PrioritizedSupplier<SelectableItem.Laser> getLaserSupplier() {
            return this;
        }

        /*
         * Unable to fully structure code
         */
        public SelectableItem.Laser get() {
            while (true) {
                if ((v0 = (cfr_temp_0 = SabSupplier.\u13e8 - (11218L ^ 6731319210603533334L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v0 == (17907 ^ -17908)) break;
                v0 = 19859 ^ -191386377;
            }
            if (!this.shouldSab()) {
                return null;
            }
            v1 = SabSupplier.\u13e8;
            if (true) ** GOTO lbl12
            block21: while (true) {
                v1 = v2 / (15936L ^ -8759935254910903076L);
lbl12:
                // 2 sources

                switch ((int)v1) {
                    case -612406024: {
                        break block21;
                    }
                    case -524786273: {
                        v2 = 10504L ^ -8154413893417613557L;
                        continue block21;
                    }
                    case -248597324: {
                        v2 = 4151465019616427512L >>> "\u0000\u0000".length();
                        continue block21;
                    }
                }
                break;
            }
            v3 = SabSupplier.\u13e8;
            if (true) ** GOTO lbl25
            block22: while (true) {
                v3 = v4 / (-8821241808599135152L >>> "\u0000\u0000".length());
lbl25:
                // 2 sources

                switch ((int)v3) {
                    case -1423835047: {
                        v4 = 8088L ^ 6898917193079583940L;
                        continue block22;
                    }
                    case -612406024: {
                        break block22;
                    }
                    case 1090475126: {
                        v4 = 30164L ^ 1369960764998649454L;
                        continue block22;
                    }
                    case 1620080634: {
                        v4 = 5287L ^ -3890223285915704343L;
                        continue block22;
                    }
                }
                break;
            }
            while (true) {
                if ((v5 = (cfr_temp_1 = SabSupplier.\u13e8 - (16839L ^ -4742740975903439400L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v5 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v5 = 24094 ^ 2085950017;
            }
            v6 = this.main.config;
            v7 = SabSupplier.\u13e8;
            if (true) ** GOTO lbl47
            block24: while (true) {
                v7 = (17631L ^ 732595423197796076L) / (16705L ^ -5749440774207414545L);
lbl47:
                // 2 sources

                switch ((int)v7) {
                    case -1363051495: {
                        continue block24;
                    }
                    case -612406024: {
                        break block24;
                    }
                }
                break;
            }
            v8 = v6.LOOT;
            while (true) {
                if ((v9 = (cfr_temp_2 = SabSupplier.\u13e8 - (11452L ^ 929646699027184124L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v9 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v9 = 27539 ^ 1829743416;
            }
            v10 = v8.SAB;
            while (true) {
                if ((v11 = (cfr_temp_3 = SabSupplier.\u13e8 - (29543L ^ -873865809080074178L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v11 == (6655 ^ 6654)) break;
                v11 = 19847 ^ 704873361;
            }
            v12 = v10.KEY;
            v13 = SabSupplier.\u13e8;
            if (true) ** GOTO lbl69
            block27: while (true) {
                v13 = v14 / (27492L ^ 7222226931615011353L);
lbl69:
                // 2 sources

                switch ((int)v13) {
                    case -619455292: {
                        v14 = 4706L ^ -7964070350164161902L;
                        continue block27;
                    }
                    case -612406024: {
                        break block27;
                    }
                    case -285149948: {
                        v14 = 28946L ^ 6243875991514791742L;
                        continue block27;
                    }
                }
                break;
            }
            sab = this.items.getItem(v12);
            if (sab != null) {
                while (true) {
                    if ((v15 = (cfr_temp_4 = SabSupplier.\u13e8 - (24380L ^ 1163038433139436940L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                    if (v15 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                    v15 = -985302676 >>> "\u0000\u0000".length();
                }
                v16 = (SelectableItem.Laser)sab.getAs(SelectableItem.Laser.class);
            } else {
                v16 = null;
            }
            return v16;
        }

        /*
         * Unable to fully structure code
         */
        private boolean shouldSab() {
            block107: {
                block106: {
                    while (true) {
                        if ((v0 = (cfr_temp_0 = SabSupplier.\u13e8 - (17179L ^ -8923732272265081829L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                        if (v0 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                        v0 = 5447 ^ 1837407086;
                    }
                    while (true) {
                        if ((v1 = (cfr_temp_1 = SabSupplier.\u13e8 - (5049L ^ -4296719258080560761L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                        if (v1 == (29381 ^ 29380)) break;
                        v1 = 32367 ^ -1670422231;
                    }
                    v2 = this.main.config;
                    while (true) {
                        if ((v3 = (cfr_temp_2 = SabSupplier.\u13e8 - (12503L ^ -1098792798223886304L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                        if (v3 == (14426 ^ 14427)) break;
                        v3 = 11499 ^ -1857491428;
                    }
                    v4 = v2.LOOT;
                    v5 = SabSupplier.\u13e8;
                    if (true) ** GOTO lbl22
                    block76: while (true) {
                        v5 = v6 / (11391L ^ -156184796991248736L);
lbl22:
                        // 2 sources

                        switch ((int)v5) {
                            case -693513030: {
                                v6 = 30150L ^ 4785202183307441947L;
                                continue block76;
                            }
                            case -612406024: {
                                break block76;
                            }
                            case 1082114279: {
                                v6 = 11444L ^ 5985312584307026353L;
                                continue block76;
                            }
                        }
                        break;
                    }
                    v7 = v4.SAB;
                    v8 = SabSupplier.\u13e8;
                    if (true) ** GOTO lbl36
                    block77: while (true) {
                        v8 = v9 / (9826L ^ -8371011934394443302L);
lbl36:
                        // 2 sources

                        switch ((int)v8) {
                            case -612406024: {
                                break block77;
                            }
                            case -367311387: {
                                v9 = 25301L ^ -8869857808692542397L;
                                continue block77;
                            }
                            case 119443932: {
                                v9 = 12661L ^ -7728374819359561137L;
                                continue block77;
                            }
                            case 678929379: {
                                v9 = 25902L ^ -2107961362752434753L;
                                continue block77;
                            }
                        }
                        break;
                    }
                    if (!v7.ENABLED) break block106;
                    while (true) {
                        if ((v10 = (cfr_temp_3 = SabSupplier.\u13e8 - (4153L ^ -5526598316570914898L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                        if (v10 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                        v10 = 12106 ^ 1402764999;
                    }
                    v11 = SabSupplier.\u13e8;
                    if (true) ** GOTO lbl58
                    block79: while (true) {
                        v11 = v12 / (4492L ^ -7526341543252757861L);
lbl58:
                        // 2 sources

                        switch ((int)v11) {
                            case -2102441191: {
                                v12 = 20998L ^ -1086494906564513504L;
                                continue block79;
                            }
                            case -612406024: {
                                break block79;
                            }
                            case 444580903: {
                                v12 = -945910228399105048L >>> "\u0000\u0000".length();
                                continue block79;
                            }
                        }
                        break;
                    }
                    v13 = TwNpcAttacker.getCallerOr(this.attacker);
                    while (true) {
                        if ((v14 = (cfr_temp_4 = SabSupplier.\u13e8 - (8435L ^ 8495702963518309676L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                        if (v14 == (14265 ^ -14266)) break;
                        v14 = -1133700292 >>> "\u0000\u0000".length();
                    }
                    v15 = SabSupplier.\u13e8;
                    if (true) ** GOTO lbl77
                    block81: while (true) {
                        v15 = (8488L ^ 2612760837394430476L) / (4488L ^ 4783799546781967028L);
lbl77:
                        // 2 sources

                        switch ((int)v15) {
                            case -1051763118: {
                                continue block81;
                            }
                            case -612406024: {
                                break block81;
                            }
                        }
                        break;
                    }
                    if (!v13.hasExtraFlag((Enum)NpcExtra.NO_SAB)) break block107;
                }
                return "".length() >>> "\u0000\u0000".length();
            }
            while (true) {
                if ((v16 = (cfr_temp_5 = SabSupplier.\u13e8 - (27348L ^ -6999718970879065887L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                if (v16 == (9869 ^ 9868)) break;
                v16 = 17808 ^ -631216716;
            }
            while (true) {
                if ((v17 = (cfr_temp_6 = SabSupplier.\u13e8 - (19084L ^ 4646729387761780352L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                if (v17 == (29929 ^ -29930)) break;
                v17 = 8104 ^ 2107190056;
            }
            v18 = this.main.config;
            v19 = SabSupplier.\u13e8;
            if (true) ** GOTO lbl101
            block84: while (true) {
                v19 = v20 / (11602L ^ -3957192209605761861L);
lbl101:
                // 2 sources

                switch ((int)v19) {
                    case -1592217691: {
                        v20 = 16167L ^ 2360368633427945588L;
                        continue block84;
                    }
                    case -612406024: {
                        break block84;
                    }
                    case 46156422: {
                        v20 = 14550L ^ -2868392933554489088L;
                        continue block84;
                    }
                }
                break;
            }
            v21 = v18.LOOT;
            v22 = SabSupplier.\u13e8;
            if (true) ** GOTO lbl115
            block85: while (true) {
                v22 = v23 / (10591L ^ -8071876757779706054L);
lbl115:
                // 2 sources

                switch ((int)v22) {
                    case -2108152167: {
                        v23 = 6060643532199722868L >>> "\u0000\u0000".length();
                        continue block85;
                    }
                    case -612406024: {
                        break block85;
                    }
                    case 1737756095: {
                        v23 = 8081174288051238432L >>> "\u0000\u0000".length();
                        continue block85;
                    }
                }
                break;
            }
            SAB = v21.SAB;
            while (true) {
                if ((v24 = (cfr_temp_7 = SabSupplier.\u13e8 - (17207L ^ 4617303408301346936L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                if (v24 == (18552 ^ -18553)) break;
                v24 = 17769 ^ 1512747025;
            }
            v25 = SabSupplier.\u13e8;
            if (true) ** GOTO lbl134
            block87: while (true) {
                v25 = (12253L ^ -4493022168019193646L) / (23295L ^ 7971910765626979192L);
lbl134:
                // 2 sources

                switch ((int)v25) {
                    case -612406024: {
                        break block87;
                    }
                    case 807680615: {
                        continue block87;
                    }
                }
                break;
            }
            v26 = this.hero.getHealth();
            v27 = SabSupplier.\u13e8;
            if (true) ** GOTO lbl144
            block88: while (true) {
                v27 = v28 / (28247L ^ -635179124475127262L);
lbl144:
                // 2 sources

                switch ((int)v27) {
                    case -1098248230: {
                        v28 = 18418L ^ -7365528655683078862L;
                        continue block88;
                    }
                    case -1001995662: {
                        v28 = 19027L ^ -2284994277345679701L;
                        continue block88;
                    }
                    case -612406024: {
                        break block88;
                    }
                    case -540840777: {
                        v28 = 26383L ^ -9221398306699087462L;
                        continue block88;
                    }
                }
                break;
            }
            v29 = v26.shieldPercent();
            while (true) {
                if ((v30 = (cfr_temp_8 = SabSupplier.\u13e8 - (7029L ^ -1767248551170295993L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                if (v30 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v30 = 6863 ^ 863715905;
            }
            if (!(v29 <= SAB.PERCENT)) ** GOTO lbl-1000
            while (true) {
                if ((v31 = (cfr_temp_9 = SabSupplier.\u13e8 - (1917L ^ -1896379695389711437L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
                if (v31 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v31 = 1272 ^ -1026633111;
            }
            while (true) {
                if ((v32 = (cfr_temp_10 = SabSupplier.\u13e8 - (3573054532457748892L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
                if (v32 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v32 = 12138 ^ 1265128002;
            }
            v33 = TwNpcAttacker.getCallerOr(this.attacker);
            v34 = SabSupplier.\u13e8;
            if (true) ** GOTO lbl178
            block92: while (true) {
                v34 = v35 / (954L ^ -6958534931546151273L);
lbl178:
                // 2 sources

                switch ((int)v34) {
                    case -612406024: {
                        break block92;
                    }
                    case 1166962436: {
                        v35 = 18564L ^ 1816980935279762015L;
                        continue block92;
                    }
                    case 1569613919: {
                        v35 = 19973L ^ -2022145145743123317L;
                        continue block92;
                    }
                    case 1815859120: {
                        v35 = 27601L ^ 152888850072970501L;
                        continue block92;
                    }
                }
                break;
            }
            v36 = v33.getTarget();
            while (true) {
                if ((v37 = (cfr_temp_11 = SabSupplier.\u13e8 - (20061L ^ 6486583981285006456L)) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
                if (v37 == (8604 ^ -8605)) break;
                v37 = 4382 ^ -1646335559;
            }
            v38 = v36.getHealth();
            v39 = SabSupplier.\u13e8;
            if (true) ** GOTO lbl201
            block94: while (true) {
                v39 = v40 / (-7092458699239626488L >>> "\u0000\u0000".length());
lbl201:
                // 2 sources

                switch ((int)v39) {
                    case -1792877439: {
                        v40 = 25383L ^ -6707757012934827086L;
                        continue block94;
                    }
                    case -612406024: {
                        break block94;
                    }
                    case -428925717: {
                        v40 = 15931L ^ 4743144987490567392L;
                        continue block94;
                    }
                    case 958591961: {
                        v40 = 8101L ^ -7098825894387399052L;
                        continue block94;
                    }
                }
                break;
            }
            v41 = v38.getShield();
            v42 = SabSupplier.\u13e8;
            if (true) ** GOTO lbl218
            block95: while (true) {
                v42 = v43 / (21949L ^ 6449431409997419689L);
lbl218:
                // 2 sources

                switch ((int)v42) {
                    case -1218522987: {
                        v43 = 3849418648083817908L >>> "\u0000\u0000".length();
                        continue block95;
                    }
                    case -612406024: {
                        break block95;
                    }
                    case 394866074: {
                        v43 = 26996L ^ 3226757229535481131L;
                        continue block95;
                    }
                    case 1866591214: {
                        v43 = 31840L ^ 8093761680042124673L;
                        continue block95;
                    }
                }
                break;
            }
            if (v41 <= SAB.NPC_AMOUNT) ** GOTO lbl-1000
            while (true) {
                if ((v44 = (cfr_temp_12 = SabSupplier.\u13e8 - (5048L ^ -7831280913150715857L)) == 0L ? 0 : (cfr_temp_12 < 0L ? -1 : 1)) == false) continue;
                if (v44 == (12497 ^ 12496)) break;
                v44 = 21562 ^ 912996274;
            }
            if (SAB.CONDITION == null) ** GOTO lbl-1000
            v45 = SabSupplier.\u13e8;
            if (true) ** GOTO lbl241
            block97: while (true) {
                v45 = (20418L ^ 7659150638701284107L) / (472L ^ -4775549785152378486L);
lbl241:
                // 2 sources

                switch ((int)v45) {
                    case -861999618: {
                        continue block97;
                    }
                    case -612406024: {
                        break block97;
                    }
                }
                break;
            }
            v46 = SAB.CONDITION;
            while (true) {
                if ((v47 = (cfr_temp_13 = SabSupplier.\u13e8 - (21083L ^ -6516234659666503863L)) == 0L ? 0 : (cfr_temp_13 < 0L ? -1 : 1)) == false) continue;
                if (v47 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v47 = 24228 ^ 1783605299;
            }
            v48 = SabSupplier.\u13e8;
            if (true) ** GOTO lbl256
            block99: while (true) {
                v48 = v49 / (16906L ^ -3138454361274995207L);
lbl256:
                // 2 sources

                switch ((int)v48) {
                    case -1291092949: {
                        v49 = 27466L ^ 4725920244235770169L;
                        continue block99;
                    }
                    case -612406024: {
                        break block99;
                    }
                    case 1252644968: {
                        v49 = 26685L ^ 1187804525759524504L;
                        continue block99;
                    }
                    case 1723288655: {
                        v49 = 13524L ^ -2444664666255357294L;
                        continue block99;
                    }
                }
                break;
            }
            v50 = v46.get(this.main);
            v51 = SabSupplier.\u13e8;
            if (true) ** GOTO lbl273
            block100: while (true) {
                v51 = v52 / (23595L ^ -1522756200903837979L);
lbl273:
                // 2 sources

                switch ((int)v51) {
                    case -612406024: {
                        break block100;
                    }
                    case 2450791: {
                        v52 = 12711L ^ 3439655981875188669L;
                        continue block100;
                    }
                    case 1545684814: {
                        v52 = 21891L ^ 6524182717089405050L;
                        continue block100;
                    }
                }
                break;
            }
            if (v50.toBoolean()) lbl-1000:
            // 2 sources

            {
                v53 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
            } else lbl-1000:
            // 3 sources

            {
                v53 = "".length() >>> "\u0000\u0000".length();
            }
            return (boolean)v53;
        }

        public PrioritizedSupplier.Priority getPriority() {
            while (true) {
                long l;
                long l2;
                if ((l2 = (l = \u13e8 - (0x4315L ^ 0x40B1C26D406B1AC7L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (l2 == (0x660C ^ 0xFFFF99F3)) break;
                l2 = 0x59D8 ^ 0x8C2EC605;
            }
            return PrioritizedSupplier.Priority.LOW;
        }
    }

    @Feature(name="RSB supplier", description="Supplies RSB ammo if enabled & it's time")
    public static class RsbSupplier
    implements LaserSelector,
    PrioritizedSupplier<SelectableItem.Laser> {
        private final Main main;
        private final AttackAPI attacker;
        private final HeroItemsAPI items;
        private long usedRsb;
        private eu.darkbot.api.game.items.Item rsbItem;
        static long \u13e8 = -908410350950474653L;

        /*
         * Handled impossible loop by adding 'first' condition
         * Enabled aggressive block sorting
         */
        public RsbSupplier(Main main, AttackAPI attacker, HeroItemsAPI items) {
            long l = \u13e8;
            boolean bl = true;
            block14: while (true) {
                long l2;
                if (!bl || (bl = false) || !true) {
                    l = l2 / (0x4908L ^ 0x5247BF459A77CBB4L);
                }
                switch ((int)l) {
                    case -1123040710: {
                        l2 = 0x625BL ^ 0x9B8129FF2980E7BBL;
                        continue block14;
                    }
                    case 386254638: {
                        l2 = 5715723369998127752L >>> "\u0000\u0000".length();
                        continue block14;
                    }
                    case 1229921379: {
                        break block14;
                    }
                    case 2033215162: {
                        l2 = 0x9C3L ^ 0x5567F0B6F51BD355L;
                        continue block14;
                    }
                }
                break;
            }
            long l3 = \u13e8;
            block15: while (true) {
                switch ((int)l3) {
                    case 20464437: {
                        l3 = (0x1ABL ^ 0xE62B185A2FE67158L) / (0x2DB8L ^ 0x6E43711C45346FL);
                        continue block15;
                    }
                    case 1229921379: {
                        break block15;
                    }
                }
                break;
            }
            this.usedRsb = 0x2102L ^ 0x2102L;
            long l4 = \u13e8;
            block16: while (true) {
                switch ((int)l4) {
                    case 826734964: {
                        l4 = (0x62A4L ^ 0xBFA4EC5848FB60ADL) / (0x17E4L ^ 0x428EB4364B1DDE86L);
                        continue block16;
                    }
                    case 1229921379: {
                        break block16;
                    }
                }
                break;
            }
            this.main = main;
            while (true) {
                long l5;
                long l6;
                if ((l6 = (l5 = \u13e8 - (8027975697380026536L >>> "\u0000\u0000".length())) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) continue;
                if (l6 == (0x531 ^ 0xFFFFFACE)) break;
                l6 = 0x5CFA ^ 0x6F7ED922;
            }
            this.attacker = attacker;
            while (true) {
                long l7;
                long l8;
                if ((l8 = (l7 = \u13e8 - (0x4F33L ^ 0xF99ED31D60078B2EL)) == 0L ? 0 : (l7 < 0L ? -1 : 1)) == false) continue;
                if (l8 == (0x4510 ^ 0xFFFFBAEF)) {
                    this.items = items;
                    return;
                }
                l8 = 1827733148 >>> "\u0000\u0000".length();
            }
        }

        public PrioritizedSupplier<SelectableItem.Laser> getLaserSupplier() {
            return this;
        }

        /*
         * Handled impossible loop by adding 'first' condition
         * Enabled aggressive block sorting
         */
        public SelectableItem.Laser get() {
            while (true) {
                long l;
                long l2;
                if ((l2 = (l = \u13e8 - (0x5904L ^ 0xF8371E9F1E956ECFL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (l2 == (0x5B43 ^ 0xFFFFA4BC)) {
                    if (!this.shouldRsb()) {
                        return null;
                    }
                    break;
                }
                l2 = 0x512F ^ 0x445206D2;
            }
            while (true) {
                long l;
                long l3;
                if ((l3 = (l = \u13e8 - (0x6228L ^ 0xA93117320FC53F53L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (l3 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                    if (this.rsbItem != null) break;
                    return null;
                }
                l3 = 1069242484 >>> "\u0000\u0000".length();
            }
            long l = \u13e8;
            boolean bl = true;
            block12: while (true) {
                long l4;
                if (!bl || (bl = false) || !true) {
                    l = l4 / (0x409FL ^ 0xF243D58ED1DC2A28L);
                }
                switch ((int)l) {
                    case -346923492: {
                        l4 = 0x3BFCL ^ 0x85C0DBE544E47BD2L;
                        continue block12;
                    }
                    case 1005671575: {
                        l4 = 0x3EC3L ^ 0x923F53FDE2FA6CECL;
                        continue block12;
                    }
                    case 1229921379: {
                        break block12;
                    }
                    case 1484150984: {
                        l4 = 0x3F8BL ^ 0xC0A23A875950E43EL;
                        continue block12;
                    }
                }
                break;
            }
            long l5 = \u13e8;
            block13: while (true) {
                switch ((int)l5) {
                    case 876948592: {
                        l5 = (0x5F6L ^ 0x4E1BD6880F6252F5L) / (0x5C34L ^ 0x84ECF6CF04FDDC7BL);
                        continue block13;
                    }
                    case 1229921379: {
                        break block13;
                    }
                }
                break;
            }
            SelectableItem.Laser laser = (SelectableItem.Laser)this.rsbItem.getAs(SelectableItem.Laser.class);
            return laser;
        }

        /*
         * Unable to fully structure code
         */
        private boolean shouldRsb() {
            block115: {
                block114: {
                    block113: {
                        v0 = RsbSupplier.\u13e8;
                        if (true) ** GOTO lbl5
                        block70: while (true) {
                            v0 = v1 / (12485L ^ 8607255752818072570L);
lbl5:
                            // 2 sources

                            switch ((int)v0) {
                                case -725084036: {
                                    v1 = 19700L ^ -9038858091028578940L;
                                    continue block70;
                                }
                                case -18419448: {
                                    v1 = 283047841385346404L >>> "\u0000\u0000".length();
                                    continue block70;
                                }
                                case 1010362966: {
                                    v1 = -5956456486955213668L >>> "\u0000\u0000".length();
                                    continue block70;
                                }
                                case 1229921379: {
                                    break block70;
                                }
                            }
                            break;
                        }
                        while (true) {
                            if ((v2 = (cfr_temp_0 = RsbSupplier.\u13e8 - (22092L ^ -7596356644823769029L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                            if (v2 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                            v2 = 30279 ^ 857334369;
                        }
                        v3 = this.main.config;
                        v4 = RsbSupplier.\u13e8;
                        if (true) ** GOTO lbl27
                        block72: while (true) {
                            v4 = (5693L ^ 6197828329515998825L) / (1700L ^ -5405059281711072364L);
lbl27:
                            // 2 sources

                            switch ((int)v4) {
                                case 1229921379: {
                                    break block72;
                                }
                                case 1350401547: {
                                    continue block72;
                                }
                            }
                            break;
                        }
                        v5 = v3.LOOT;
                        v6 = RsbSupplier.\u13e8;
                        if (true) ** GOTO lbl37
                        block73: while (true) {
                            v6 = v7 / (11519L ^ 3599472564285334781L);
lbl37:
                            // 2 sources

                            switch ((int)v6) {
                                case -320274343: {
                                    v7 = 8267L ^ 1174479603552252022L;
                                    continue block73;
                                }
                                case 1229921379: {
                                    break block73;
                                }
                                case 1856887851: {
                                    v7 = -3628646111409382708L >>> "\u0000\u0000".length();
                                    continue block73;
                                }
                                case 1991531996: {
                                    v7 = 30218L ^ 6329442396553957081L;
                                    continue block73;
                                }
                            }
                            break;
                        }
                        v8 = v5.RSB;
                        while (true) {
                            if ((v9 = (cfr_temp_1 = RsbSupplier.\u13e8 - (-2214802046164581260L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                            if (v9 == (22511 ^ -22512)) break;
                            v9 = 3518 ^ 1095117936;
                        }
                        if (!v8.ENABLED) break block113;
                        while (true) {
                            if ((v10 = (cfr_temp_2 = RsbSupplier.\u13e8 - (16501L ^ 4456393320546035190L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                            if (v10 == (10933 ^ -10934)) break;
                            v10 = 25675 ^ -86454986;
                        }
                        v11 = RsbSupplier.\u13e8;
                        if (true) ** GOTO lbl65
                        block76: while (true) {
                            v11 = (6662L ^ -8012126467333494084L) / (8291L ^ 5069378237243460371L);
lbl65:
                            // 2 sources

                            switch ((int)v11) {
                                case 223267866: {
                                    continue block76;
                                }
                                case 1229921379: {
                                    break block76;
                                }
                            }
                            break;
                        }
                        v12 = this.main.config;
                        while (true) {
                            if ((v13 = (cfr_temp_3 = RsbSupplier.\u13e8 - (6215L ^ -789300025876620553L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                            if (v13 == (5957 ^ -5958)) break;
                            v13 = 30136 ^ -1929923199;
                        }
                        v14 = v12.LOOT;
                        v15 = RsbSupplier.\u13e8;
                        if (true) ** GOTO lbl81
                        block78: while (true) {
                            v15 = v16 / (23173L ^ 5773026734060363415L);
lbl81:
                            // 2 sources

                            switch ((int)v15) {
                                case 2929006: {
                                    v16 = 26726L ^ -5360645156843953909L;
                                    continue block78;
                                }
                                case 1229921379: {
                                    break block78;
                                }
                                case 1852904909: {
                                    v16 = 1758L ^ 8027146720774082215L;
                                    continue block78;
                                }
                            }
                            break;
                        }
                        v17 = v14.RSB;
                        v18 = RsbSupplier.\u13e8;
                        if (true) ** GOTO lbl95
                        block79: while (true) {
                            v18 = v19 / (23634L ^ 3276431145961655234L);
lbl95:
                            // 2 sources

                            switch ((int)v18) {
                                case -407082859: {
                                    v19 = 27140L ^ -5997443964380445569L;
                                    continue block79;
                                }
                                case 1229568594: {
                                    v19 = 20009L ^ -4424255233816379767L;
                                    continue block79;
                                }
                                case 1229921379: {
                                    break block79;
                                }
                            }
                            break;
                        }
                        if (v17.KEY == null) break block113;
                        v20 = RsbSupplier.\u13e8;
                        if (true) ** GOTO lbl109
                        block80: while (true) {
                            v20 = v21 / (5196L ^ 8868651938923836527L);
lbl109:
                            // 2 sources

                            switch ((int)v20) {
                                case -550455604: {
                                    v21 = 3164L ^ -2748803458024477055L;
                                    continue block80;
                                }
                                case -329555135: {
                                    v21 = 13568L ^ -5517469101137149816L;
                                    continue block80;
                                }
                                case 1229921379: {
                                    break block80;
                                }
                            }
                            break;
                        }
                        while (true) {
                            if ((v22 = (cfr_temp_4 = RsbSupplier.\u13e8 - (10992L ^ -5903321909290374943L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                            if (v22 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                            v22 = 15677 ^ -1023815069;
                        }
                        v23 = TwNpcAttacker.getCallerOr(this.attacker);
                        v24 = RsbSupplier.\u13e8;
                        if (true) ** GOTO lbl128
                        block82: while (true) {
                            v24 = v25 / (19271L ^ 7000030214359131124L);
lbl128:
                            // 2 sources

                            switch ((int)v24) {
                                case -1250987225: {
                                    v25 = 3257341644349861408L >>> "\u0000\u0000".length();
                                    continue block82;
                                }
                                case -836133673: {
                                    v25 = 21262L ^ 58963735289041952L;
                                    continue block82;
                                }
                                case 1039833808: {
                                    v25 = 25068L ^ 4048793326244301780L;
                                    continue block82;
                                }
                                case 1229921379: {
                                    break block82;
                                }
                            }
                            break;
                        }
                        while (true) {
                            if ((v26 = (cfr_temp_5 = RsbSupplier.\u13e8 - (15547L ^ -2327965744168401761L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                            if (v26 == (4354 ^ 4355)) break;
                            v26 = 13972 ^ -1326464953;
                        }
                        if (v23.hasExtraFlag((Enum)NpcExtra.USE_RSB)) break block114;
                    }
                    return "".length() >>> "\u0000\u0000".length();
                }
                while (true) {
                    if ((v27 = (cfr_temp_6 = RsbSupplier.\u13e8 - (31355L ^ 5801029722538428328L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                    if (v27 == ("\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() ^ -33)) break;
                    v27 = 22871 ^ 243071164;
                }
                v28 = RsbSupplier.\u13e8;
                if (true) ** GOTO lbl158
                block85: while (true) {
                    v28 = (-4594405013014689660L >>> "\u0000\u0000".length()) / (621L ^ 6421083577481569797L);
lbl158:
                    // 2 sources

                    switch ((int)v28) {
                        case 1138155418: {
                            continue block85;
                        }
                        case 1229921379: {
                            break block85;
                        }
                    }
                    break;
                }
                while (true) {
                    if ((v29 = (cfr_temp_7 = RsbSupplier.\u13e8 - (26550L ^ 8230023799325726444L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                    if (v29 == (5018 ^ -5019)) break;
                    v29 = 693338032 >>> "\u0000\u0000".length();
                }
                v30 = this.main.config;
                while (true) {
                    if ((v31 = (cfr_temp_8 = RsbSupplier.\u13e8 - (28877L ^ -4861546691999997707L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                    if (v31 == (8811 ^ 8810)) break;
                    v31 = 19015 ^ -1499129606;
                }
                v32 = v30.LOOT;
                while (true) {
                    if ((v33 = (cfr_temp_9 = RsbSupplier.\u13e8 - (22621L ^ 7584428746445991834L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
                    if (v33 == (24124 ^ -24125)) break;
                    v33 = 1490038664 >>> "\u0000\u0000".length();
                }
                v34 = v32.RSB;
                while (true) {
                    if ((v35 = (cfr_temp_10 = RsbSupplier.\u13e8 - (280587995139574820L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
                    if (v35 == (187 ^ -188)) break;
                    v35 = 26858 ^ -2010072990;
                }
                v36 = v34.KEY;
                while (true) {
                    if ((v37 = (cfr_temp_11 = RsbSupplier.\u13e8 - (22933L ^ -6040496019938397620L)) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
                    if (v37 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                    v37 = 24110 ^ -1987831550;
                }
                v38 = this.items.getItem(v36);
                v39 = RsbSupplier.\u13e8;
                if (true) ** GOTO lbl197
                block91: while (true) {
                    v39 = v40 / (17079L ^ 6623125378591399271L);
lbl197:
                    // 2 sources

                    switch ((int)v39) {
                        case -1548946852: {
                            v40 = -3843846413038044296L >>> "\u0000\u0000".length();
                            continue block91;
                        }
                        case -1145301485: {
                            v40 = 2552L ^ 4921360941324610815L;
                            continue block91;
                        }
                        case -777222002: {
                            v40 = 3944L ^ 6693603191445887716L;
                            continue block91;
                        }
                        case 1229921379: {
                            break block91;
                        }
                    }
                    break;
                }
                this.rsbItem = v38;
                v41 = RsbSupplier.\u13e8;
                if (true) ** GOTO lbl214
                block92: while (true) {
                    v41 = v42 / (8937L ^ -1826460937115560968L);
lbl214:
                    // 2 sources

                    switch ((int)v41) {
                        case -1239394079: {
                            v42 = 32462L ^ 6580342543787532967L;
                            continue block92;
                        }
                        case -233781378: {
                            v42 = 23232L ^ 8877454063615295245L;
                            continue block92;
                        }
                        case 1229921379: {
                            break block92;
                        }
                    }
                    break;
                }
                if (this.rsbItem == null) ** GOTO lbl-1000
                while (true) {
                    if ((v43 = (cfr_temp_12 = RsbSupplier.\u13e8 - (24L ^ -8197635656927528456L)) == 0L ? 0 : (cfr_temp_12 < 0L ? -1 : 1)) == false) continue;
                    if (v43 == (5835 ^ 5834)) break;
                    v43 = 15298 ^ -738233267;
                }
                while (true) {
                    if ((v44 = (cfr_temp_13 = RsbSupplier.\u13e8 - (22262L ^ -204489815898613090L)) == 0L ? 0 : (cfr_temp_13 < 0L ? -1 : 1)) == false) continue;
                    if (v44 == (5358 ^ -5359)) break;
                    v44 = 25331 ^ -560025179;
                }
                if (!this.rsbItem.isUsable()) ** GOTO lbl-1000
                while (true) {
                    if ((v45 = (cfr_temp_14 = RsbSupplier.\u13e8 - (25947L ^ 6359890355192159371L)) == 0L ? 0 : (cfr_temp_14 < 0L ? -1 : 1)) == false) continue;
                    if (v45 == (23439 ^ -23440)) break;
                    v45 = 14479 ^ 1596771154;
                }
                v46 = RsbSupplier.\u13e8;
                if (true) ** GOTO lbl244
                block96: while (true) {
                    v46 = (16396L ^ 5642198385635882978L) / (21921L ^ -8520075738523136960L);
lbl244:
                    // 2 sources

                    switch ((int)v46) {
                        case -769883204: {
                            continue block96;
                        }
                        case 1229921379: {
                            break block96;
                        }
                    }
                    break;
                }
                if (this.rsbItem.isReady()) {
                    v47 = 13553 ^ 13552;
                } else lbl-1000:
                // 3 sources

                {
                    v47 = isReady = "".length() >>> "\u0000\u0000".length();
                }
                if (isReady == 0) break block115;
                v48 = RsbSupplier.\u13e8;
                if (true) ** GOTO lbl258
                block97: while (true) {
                    v48 = (4217L ^ -2315972443894046647L) / (31597L ^ 3624985096332406961L);
lbl258:
                    // 2 sources

                    switch ((int)v48) {
                        case -1938868295: {
                            continue block97;
                        }
                        case 1229921379: {
                            break block97;
                        }
                    }
                    break;
                }
                while (true) {
                    if ((v49 = (cfr_temp_15 = RsbSupplier.\u13e8 - (9093L ^ -4665116291056265878L)) == 0L ? 0 : (cfr_temp_15 < 0L ? -1 : 1)) == false) continue;
                    if (v49 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                    v49 = 1901282680 >>> "\u0000\u0000".length();
                }
                if (this.usedRsb < System.currentTimeMillis() - (18444L ^ 19428L)) {
                    while (true) {
                        if ((v50 = (cfr_temp_16 = RsbSupplier.\u13e8 - (7263L ^ 4212257207580618486L)) == 0L ? 0 : (cfr_temp_16 < 0L ? -1 : 1)) == false) continue;
                        if (v50 == (12296 ^ -12297)) break;
                        v50 = 18488 ^ 1898108264;
                    }
                    v51 = System.currentTimeMillis();
                    while (true) {
                        if ((v52 = (cfr_temp_17 = RsbSupplier.\u13e8 - (24109L ^ -8950829163969905867L)) == 0L ? 0 : (cfr_temp_17 < 0L ? -1 : 1)) == false) continue;
                        if (v52 == (24654 ^ 24655)) {
                            this.usedRsb = v51;
                            break;
                        }
                        v52 = 7846 ^ 588631046;
                    }
                }
            }
            while (true) {
                if ((v53 = (cfr_temp_18 = RsbSupplier.\u13e8 - (31274L ^ 6009211322311853039L)) == 0L ? 0 : (cfr_temp_18 < 0L ? -1 : 1)) == false) continue;
                if (v53 == (29960 ^ -29961)) break;
                v53 = -477621244 >>> "\u0000\u0000".length();
            }
            if (this.rsbItem == null) ** GOTO lbl-1000
            v54 = RsbSupplier.\u13e8;
            if (true) ** GOTO lbl293
            block102: while (true) {
                v54 = v55 / (7580L ^ -6306402328679397492L);
lbl293:
                // 2 sources

                switch ((int)v54) {
                    case 700841057: {
                        v55 = 9876L ^ 5042981889253356319L;
                        continue block102;
                    }
                    case 1229921379: {
                        break block102;
                    }
                    case 1605149213: {
                        v55 = 8165L ^ -9111569343068459548L;
                        continue block102;
                    }
                    case 2020386919: {
                        v55 = 19033L ^ 8866249229504957229L;
                        continue block102;
                    }
                }
                break;
            }
            while (true) {
                if ((v56 = (cfr_temp_19 = RsbSupplier.\u13e8 - (4020L ^ -126033984305040871L)) == 0L ? 0 : (cfr_temp_19 < 0L ? -1 : 1)) == false) continue;
                if (v56 == (28889 ^ -28890)) break;
                v56 = 5972 ^ -775672448;
            }
            if (this.usedRsb > System.currentTimeMillis() - (25885L ^ 25903L)) {
                v57 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
            } else lbl-1000:
            // 2 sources

            {
                v57 = "".length() >>> "\u0000\u0000".length();
            }
            return (boolean)v57;
        }

        /*
         * Handled impossible loop by adding 'first' condition
         * Enabled aggressive block sorting
         */
        public PrioritizedSupplier.Priority getPriority() {
            long l = \u13e8;
            boolean bl = true;
            block6: while (true) {
                long l2;
                if (!bl || (bl = false) || !true) {
                    l = l2 / (0x4D68L ^ 0x4AAE0F6A325012D0L);
                }
                switch ((int)l) {
                    case -2092970613: {
                        l2 = 0x4E4FL ^ 0xC819284D205AFA1FL;
                        continue block6;
                    }
                    case 1229921379: {
                        return PrioritizedSupplier.Priority.MODERATE;
                    }
                    case 1276031194: {
                        l2 = 0x5798L ^ 0x58C358421C6D5316L;
                        continue block6;
                    }
                    case 1745752677: {
                        l2 = -7986066260281818748L >>> "\u0000\u0000".length();
                        continue block6;
                    }
                }
                break;
            }
            return PrioritizedSupplier.Priority.MODERATE;
        }
    }
}

