/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.Main
 *  com.github.manolo8.darkbot.config.Config
 *  com.github.manolo8.darkbot.config.NpcExtra
 *  com.github.manolo8.darkbot.config.NpcExtraFlag
 *  com.github.manolo8.darkbot.config.NpcInfo
 *  com.github.manolo8.darkbot.config.ZoneInfo
 *  com.github.manolo8.darkbot.core.entities.Entity
 *  com.github.manolo8.darkbot.core.entities.Npc
 *  com.github.manolo8.darkbot.core.entities.Ship
 *  com.github.manolo8.darkbot.core.itf.Configurable
 *  com.github.manolo8.darkbot.core.itf.Module
 *  com.github.manolo8.darkbot.core.manager.EffectManager$Effect
 *  com.github.manolo8.darkbot.core.manager.HeroManager
 *  com.github.manolo8.darkbot.core.manager.MapManager
 *  com.github.manolo8.darkbot.core.objects.Health
 *  com.github.manolo8.darkbot.core.objects.LocationInfo
 *  com.github.manolo8.darkbot.core.objects.PlayerInfo
 *  com.github.manolo8.darkbot.core.utils.Drive
 *  com.github.manolo8.darkbot.core.utils.Location
 *  com.github.manolo8.darkbot.extensions.features.Feature
 *  com.github.manolo8.darkbot.modules.utils.SafetyFinder
 *  com.github.manolo8.darkbot.modules.utils.SafetyFinder$Escaping
 */
package com.tawaret.tawaplugin.features.bettermodules;

import com.github.manolo8.darkbot.Main;
import com.github.manolo8.darkbot.config.Config;
import com.github.manolo8.darkbot.config.NpcExtra;
import com.github.manolo8.darkbot.config.NpcExtraFlag;
import com.github.manolo8.darkbot.config.NpcInfo;
import com.github.manolo8.darkbot.config.ZoneInfo;
import com.github.manolo8.darkbot.core.entities.Entity;
import com.github.manolo8.darkbot.core.entities.Npc;
import com.github.manolo8.darkbot.core.entities.Ship;
import com.github.manolo8.darkbot.core.itf.Configurable;
import com.github.manolo8.darkbot.core.itf.Module;
import com.github.manolo8.darkbot.core.manager.EffectManager;
import com.github.manolo8.darkbot.core.manager.HeroManager;
import com.github.manolo8.darkbot.core.manager.MapManager;
import com.github.manolo8.darkbot.core.objects.Health;
import com.github.manolo8.darkbot.core.objects.LocationInfo;
import com.github.manolo8.darkbot.core.objects.PlayerInfo;
import com.github.manolo8.darkbot.core.utils.Drive;
import com.github.manolo8.darkbot.core.utils.Location;
import com.github.manolo8.darkbot.extensions.features.Feature;
import com.github.manolo8.darkbot.modules.utils.SafetyFinder;
import com.tawaret.tawaplugin.debugging.IDebuggable;
import com.tawaret.tawaplugin.features.bettermodules.ITwLootModule;
import com.tawaret.tawaplugin.features.bettermodules.TwLootModuleConfig;
import com.tawaret.tawaplugin.features.bettermodules.betterutils.TwNpcAttacker;
import com.tawaret.tawaplugin.features.maptravellers.ITwMapTraveller;
import com.tawaret.tawaplugin.features.maptravellers.TwMapTraveller;
import java.lang.invoke.LambdaMetafactory;
import java.util.Comparator;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.ToDoubleFunction;
import java.util.function.ToIntFunction;
import java.util.stream.Stream;

@Feature(name="Tw Npc Killer", description="Better version of the Npc Killer", enabledByDefault=false)
public class TwLootModule
implements Module,
ITwLootModule,
Configurable<TwLootModuleConfig>,
IDebuggable {
    private Main main;
    private List<Ship> ships;
    private List<Npc> npcs;
    private HeroManager hero;
    private Drive drive;
    private Config config;
    private TwLootModuleConfig twLootModuleConfig;
    protected TwNpcAttacker attack;
    protected SafetyFinder safety;
    protected long refreshing;
    private final ITwMapTraveller mapTraveler;
    protected boolean backwards;
    private static long \u13e8 = -2925848774113927610L;

    /*
     * Unable to fully structure code
     */
    public TwLootModule() {
        while (true) {
            if ((v0 = (cfr_temp_0 = TwLootModule.\u13e8 - (7450003059197905948L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (22632 ^ -22633)) break;
            v0 = 6049 ^ 1989013678;
        }
        super();
        v1 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl11
        block32: while (true) {
            v1 = v2 / (1237L ^ -8257470897562408781L);
lbl11:
            // 2 sources

            switch ((int)v1) {
                case -1911268152: {
                    v2 = 23693L ^ 6300852541423552913L;
                    continue block32;
                }
                case -1335009722: {
                    break block32;
                }
                case 235983029: {
                    v2 = 20118L ^ -1641448828049951487L;
                    continue block32;
                }
                case 568325051: {
                    v2 = 8836L ^ -6515459578933085721L;
                    continue block32;
                }
            }
            break;
        }
        v3 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl27
        block33: while (true) {
            v3 = (17447L ^ -2627291831976468804L) / (31558L ^ 1264324656420727599L);
lbl27:
            // 2 sources

            switch ((int)v3) {
                case -1538937614: {
                    continue block33;
                }
                case -1335009722: {
                    break block33;
                }
            }
            break;
        }
        v4 = new TwLootModuleConfig();
        v5 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl37
        block34: while (true) {
            v5 = v6 / (10285L ^ -7711412511020609240L);
lbl37:
            // 2 sources

            switch ((int)v5) {
                case -2018844267: {
                    v6 = -4610593335805992632L >>> "\u0000\u0000".length();
                    continue block34;
                }
                case -1335009722: {
                    break block34;
                }
                case 341098184: {
                    v6 = 15454L ^ 5968696253352761987L;
                    continue block34;
                }
            }
            break;
        }
        this.twLootModuleConfig = v4;
        while (true) {
            if ((v7 = (cfr_temp_1 = TwLootModule.\u13e8 - (3827549246559441604L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v7 == (26602 ^ -26603)) break;
            v7 = 22618 ^ 1338344204;
        }
        this.backwards = 4180 ^ 4180;
        v8 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl57
        block36: while (true) {
            v8 = v9 / (21660L ^ -7870626518854088045L);
lbl57:
            // 2 sources

            switch ((int)v8) {
                case -1335009722: {
                    break block36;
                }
                case 1365265730: {
                    v9 = 14029L ^ -5877770639746209125L;
                    continue block36;
                }
                case 2047265402: {
                    v9 = 14678L ^ 9052445836237160124L;
                    continue block36;
                }
            }
            break;
        }
        v10 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl70
        block37: while (true) {
            v10 = v11 / (26522L ^ 7417271653924557733L);
lbl70:
            // 2 sources

            switch ((int)v10) {
                case -1335009722: {
                    break block37;
                }
                case -937148097: {
                    v11 = 440L ^ 5550922584052132680L;
                    continue block37;
                }
                case 1901209402: {
                    v11 = 18081L ^ -7006931786906724300L;
                    continue block37;
                }
            }
            break;
        }
        v12 = new TwMapTraveller();
        v13 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl84
        block38: while (true) {
            v13 = v14 / (28797L ^ 3566019257260406290L);
lbl84:
            // 2 sources

            switch ((int)v13) {
                case -1629574299: {
                    v14 = 26530L ^ 5647853710848566193L;
                    continue block38;
                }
                case -1406072945: {
                    v14 = 28972L ^ -8658634879331237619L;
                    continue block38;
                }
                case -1335009722: {
                    break block38;
                }
                case 1824085664: {
                    v14 = 4186L ^ -4673132844931702005L;
                    continue block38;
                }
            }
            break;
        }
        this.mapTraveler = v12;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public int getNumNpcsInRange(String subname) {
        block40: {
            block39: {
                while (true) {
                    long l;
                    long l2;
                    if ((l2 = (l = \u13e8 - (0x7C4BL ^ 0xE0474D4A2BB6D323L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
                    if (l2 == (0x57BE ^ 0xFFFFA841)) {
                        if (this.npcs == null) {
                            return 0x48B7 ^ 0x48B7;
                        }
                        break;
                    }
                    l2 = 1459938220 >>> "\u0000\u0000".length();
                }
                if (subname == null) break block39;
                long l = \u13e8;
                boolean bl = true;
                block25: while (true) {
                    long l3;
                    if (!bl || (bl = false) || !true) {
                        l = l3 / (0xCC2L ^ 0xA9E9A40A1D9EC1A1L);
                    }
                    switch ((int)l) {
                        case -1958568729: {
                            l3 = -6338102429522044520L >>> "\u0000\u0000".length();
                            continue block25;
                        }
                        case -1335009722: {
                            break block25;
                        }
                        case 962794030: {
                            l3 = 0x3782L ^ 0xA5C82219ABCE7C99L;
                            continue block25;
                        }
                        case 1551977553: {
                            l3 = 0x36C5L ^ 0xDC48748EF7875F42L;
                            continue block25;
                        }
                    }
                    break;
                }
                if (subname.length() != 0) break block40;
            }
            long l = \u13e8;
            block26: while (true) {
                switch ((int)l) {
                    case -2089663678: {
                        l = (0x6B9L ^ 0x2B4FB6542E89991FL) / (0x4581L ^ 0x5487F4D3A9F02313L);
                        continue block26;
                    }
                    case -1335009722: {
                        break block26;
                    }
                }
                break;
            }
            long l4 = \u13e8;
            boolean bl = true;
            block27: while (true) {
                long l5;
                if (!bl || (bl = false) || !true) {
                    l4 = l5 / (0x3E3BL ^ 0x5601CDACE7732186L);
                }
                switch ((int)l4) {
                    case -1335009722: {
                        return this.npcs.size();
                    }
                    case -756855232: {
                        l5 = 0x1EC1L ^ 0x91321D7513981437L;
                        continue block27;
                    }
                    case 1778740678: {
                        l5 = 0x23CL ^ 0x70F2BFFD4B997EDBL;
                        continue block27;
                    }
                    case 1857656084: {
                        l5 = 0x1EBDL ^ 0x39925473DC33D7DEL;
                        continue block27;
                    }
                }
                break;
            }
            return this.npcs.size();
        }
        while (true) {
            long l;
            long l6;
            if ((l6 = (l = \u13e8 - (-6613070180370298624L >>> "\u0000\u0000".length())) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l6 == (0x28A1 ^ 0xFFFFD75E)) break;
            l6 = 0x477E ^ 0xD556D6F8;
        }
        while (true) {
            long l;
            long l7;
            if ((l7 = (l = \u13e8 - (6707935829156991572L >>> "\u0000\u0000".length())) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l7 == (0x5D75 ^ 0xFFFFA28A)) break;
            l7 = 0x635B ^ 0xCD088DA4;
        }
        Stream stream = this.npcs.stream();
        while (true) {
            long l;
            long l8;
            if ((l8 = (l = \u13e8 - (0x7365L ^ 0xAAED61349F015F91L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l8 == (0x6F9C ^ 0x6F9D)) break;
            l8 = 0x6FB1 ^ 0xF9BECE60;
        }
        Predicate<Npc> predicate = npc -> {
            long l = \u13e8;
            boolean bl = true;
            block14: while (true) {
                long l2;
                if (!bl || (bl = false) || !true) {
                    l = l2 / (0x6557L ^ 0xC6EE718E6934C677L);
                }
                switch ((int)l) {
                    case -2075482274: {
                        l2 = 0x5CA5L ^ 0x7EE89FE79E9AABDCL;
                        continue block14;
                    }
                    case -1395822885: {
                        l2 = 0x4856L ^ 0xE4CC4325410D53B3L;
                        continue block14;
                    }
                    case -1335009722: {
                        break block14;
                    }
                    case 886049409: {
                        l2 = 0x7DB0L ^ 0x1293A8E5B58B7AF7L;
                        continue block14;
                    }
                }
                break;
            }
            PlayerInfo playerInfo = npc.playerInfo;
            long l3 = \u13e8;
            block15: while (true) {
                switch ((int)l3) {
                    case -1641361770: {
                        l3 = (0x3CFCL ^ 0x44E20DD913D01579L) / (0x7D2FL ^ 0x9475146C2781F0A6L);
                        continue block15;
                    }
                    case -1335009722: {
                        break block15;
                    }
                }
                break;
            }
            String string = playerInfo.getUsername();
            while (true) {
                long l4;
                long l5;
                if ((l5 = (l4 = \u13e8 - (0x143BL ^ 0x8E54C5162F6E8943L)) == 0L ? 0 : (l4 < 0L ? -1 : 1)) == false) continue;
                if (l5 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                l5 = 0x1DFB ^ 0x4D2A511D;
            }
            String string2 = string.toLowerCase();
            long l6 = \u13e8;
            block17: while (true) {
                switch ((int)l6) {
                    case -1335009722: {
                        break block17;
                    }
                    case 1917346088: {
                        l6 = (0x2932L ^ 0x2437B79E9E98BA97L) / (0x3DF2L ^ 0xFA830905D661958DL);
                        continue block17;
                    }
                }
                break;
            }
            String string3 = subname.toLowerCase();
            while (true) {
                long l7;
                long l8;
                if ((l8 = (l7 = \u13e8 - (0xF1BL ^ 0x30749CD38CF67596L)) == 0L ? 0 : (l7 < 0L ? -1 : 1)) == false) continue;
                if (l8 == (0x191B ^ 0xFFFFE6E4)) {
                    return string2.contains(string3);
                }
                l8 = 0x4430 ^ 0x770B2F6A;
            }
        };
        long l = \u13e8;
        block31: while (true) {
            switch ((int)l) {
                case -1335009722: {
                    break block31;
                }
                case 175849819: {
                    l = (0x3184L ^ 0x3EF57E5D31E0CA42L) / (0x5E74L ^ 0x5377187FA443B992L);
                    continue block31;
                }
            }
            break;
        }
        Stream<Npc> stream2 = stream.filter(predicate);
        long l9 = \u13e8;
        block32: while (true) {
            switch ((int)l9) {
                case -1335009722: {
                    return (int)stream2.count();
                }
                case -559840746: {
                    l9 = (0x1C8EL ^ 0x7BE574B9AA7B01FBL) / (0x6D90L ^ 0x8720CA823080D72AL);
                    continue block32;
                }
            }
            break;
        }
        return (int)stream2.count();
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public int getNumNpcsInRange() {
        byte[] byArray = new byte["".length() >>> "\u0000\u0000".length()];
        String string = new String(byArray);
        long l = \u13e8;
        boolean bl = true;
        block5: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (6029543382934292072L >>> "\u0000\u0000".length());
            }
            switch ((int)l) {
                case -1335009722: {
                    return this.getNumNpcsInRange(string);
                }
                case 640821393: {
                    l2 = 0x1F61L ^ 0xE3EC023E5A7D51BL;
                    continue block5;
                }
                case 1827008995: {
                    l2 = 0x78A6L ^ 0xBF70CB414686F87EL;
                    continue block5;
                }
            }
            break;
        }
        return this.getNumNpcsInRange(string);
    }

    /*
     * Unable to fully structure code
     */
    public int getNumShipsInRange() {
        while (true) {
            if ((v0 = (cfr_temp_0 = TwLootModule.\u13e8 - (7395L ^ 8744665618667545155L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (1804 ^ -1805)) break;
            v0 = 24208 ^ 75640360;
        }
        if (this.ships == null) {
            return "".length() >>> "\u0000\u0000".length();
        }
        ret = 24145 ^ 24145;
        v1 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl13
        block31: while (true) {
            v1 = (22802L ^ -4615371153496413297L) / (24158L ^ -1016248681569824060L);
lbl13:
            // 2 sources

            switch ((int)v1) {
                case -1335009722: {
                    break block31;
                }
                case 629712558: {
                    continue block31;
                }
            }
            break;
        }
        v2 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl22
        block32: while (true) {
            v2 = v3 / (5614L ^ -6537927208713606715L);
lbl22:
            // 2 sources

            switch ((int)v2) {
                case -2134807439: {
                    v3 = 11660L ^ 1356275093835030500L;
                    continue block32;
                }
                case -1950182243: {
                    v3 = 32284L ^ -6870035562596774216L;
                    continue block32;
                }
                case -1335009722: {
                    break block32;
                }
            }
            break;
        }
        var2_2 = this.ships.iterator();
        while (true) {
            if ((v4 = (cfr_temp_1 = TwLootModule.\u13e8 - (24459L ^ 6084496940307427875L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v4 != (897 ^ -898)) {
                v4 = 9177 ^ -2068615063;
                continue;
            }
            if (!var2_2.hasNext()) break;
            while (true) {
                if ((v5 = (cfr_temp_2 = TwLootModule.\u13e8 - (20239L ^ 4638407700210605528L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v5 == (16009 ^ -16010)) break;
                v5 = 5967 ^ 1167892105;
            }
            ship = var2_2.next();
            v6 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl48
            block35: while (true) {
                v6 = v7 / (13413L ^ 8479007943043528619L);
lbl48:
                // 2 sources

                switch ((int)v6) {
                    case -1335009722: {
                        break block35;
                    }
                    case -483014795: {
                        v7 = 16385L ^ -5915570669612083788L;
                        continue block35;
                    }
                    case 902400220: {
                        v7 = 27157L ^ -9129047358874379893L;
                        continue block35;
                    }
                    case 1496073923: {
                        v7 = 19919L ^ 4079569245031693705L;
                        continue block35;
                    }
                }
                break;
            }
            v8 = ship.address;
            v9 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl65
            block36: while (true) {
                v9 = v10 / (26776L ^ 8044995797770112849L);
lbl65:
                // 2 sources

                switch ((int)v9) {
                    case -1335009722: {
                        break block36;
                    }
                    case 1234187585: {
                        v10 = 32434L ^ 4815851982710480020L;
                        continue block36;
                    }
                    case 1667795981: {
                        v10 = -7434744334807750976L >>> "\u0000\u0000".length();
                        continue block36;
                    }
                    case 1920125444: {
                        v10 = 9159319286508931844L >>> "\u0000\u0000".length();
                        continue block36;
                    }
                }
                break;
            }
            v11 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl81
            block37: while (true) {
                v11 = v12 / (8066L ^ -2280994734452624983L);
lbl81:
                // 2 sources

                switch ((int)v11) {
                    case -1335009722: {
                        break block37;
                    }
                    case -305763155: {
                        v12 = 24007L ^ -695720734642806722L;
                        continue block37;
                    }
                    case -210710008: {
                        v12 = 17749L ^ -7722518352042612997L;
                        continue block37;
                    }
                }
                break;
            }
            if (v8 == this.hero.address) continue;
            while (true) {
                if ((v13 = (cfr_temp_3 = TwLootModule.\u13e8 - (21980L ^ 3380511503998968275L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v13 == (9920 ^ -9921)) break;
                v13 = 8642 ^ -2139941993;
            }
            v14 = ship.address;
            v15 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl101
            block39: while (true) {
                v15 = (3394L ^ -1884849940768963038L) / (24478L ^ -5886317420450677123L);
lbl101:
                // 2 sources

                switch ((int)v15) {
                    case -1335009722: {
                        break block39;
                    }
                    case 1399679566: {
                        continue block39;
                    }
                }
                break;
            }
            while (true) {
                if ((v16 = (cfr_temp_4 = TwLootModule.\u13e8 - (22974L ^ -4853197941252007003L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v16 == (19226 ^ 19227)) break;
                v16 = 201 ^ -1634647081;
            }
            v17 = this.hero.pet;
            while (true) {
                if ((v18 = (cfr_temp_5 = TwLootModule.\u13e8 - (15370L ^ 4742300947846733074L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                if (v18 == (24338 ^ -24339)) break;
                v18 = 11085 ^ -530607428;
            }
            if (v14 == v17.address) continue;
            ++ret;
        }
        return ret;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public int getNumNpcsInPreferredRegion() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x72AL ^ 0xE52F107ADA68DE3L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x10FE ^ 0xFFFFEF01)) break;
            l2 = 0x79C9 ^ 0xEBF30CF8;
        }
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = \u13e8 - (0x6206L ^ 0x7BF55AEA182827DAL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l3 == (0x7561 ^ 0xFFFF8A9E)) break;
            l3 = 0x6328 ^ 0x69ECA0A2;
        }
        Stream stream = this.npcs.stream();
        while (true) {
            long l;
            long l4;
            if ((l4 = (l = \u13e8 - (0x29C4L ^ 0xCD26C98EF9078729L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l4 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l4 = 0x66C9 ^ 0xF8CEBF8A;
        }
        Predicate<Npc> predicate = npc -> {
            long l = \u13e8;
            boolean bl = true;
            block15: while (true) {
                long l2;
                if (!bl || (bl = false) || !true) {
                    l = l2 / (0x5BDCL ^ 0x55E812A51AEA85D0L);
                }
                switch ((int)l) {
                    case -1335009722: {
                        break block15;
                    }
                    case -1144263462: {
                        l2 = 0x63E8L ^ 0x737211B7EC017326L;
                        continue block15;
                    }
                    case 778580370: {
                        l2 = 0x29E3L ^ 0xB227B5A6B3DFEB6BL;
                        continue block15;
                    }
                    case 910996217: {
                        l2 = 0x4283L ^ 0xD3F8F75CBDC73E9DL;
                        continue block15;
                    }
                }
                break;
            }
            long l3 = \u13e8;
            boolean bl2 = true;
            block16: while (true) {
                long l4;
                if (!bl2 || (bl2 = false) || !true) {
                    l3 = l4 / (0x5EACL ^ 0x738B72040C133C1FL);
                }
                switch ((int)l3) {
                    case -1335009722: {
                        break block16;
                    }
                    case 0xD4DCDD4: {
                        l4 = 0x6A69L ^ 0xBDB155EB3DE3AE78L;
                        continue block16;
                    }
                    case 390875939: {
                        l4 = 0x2BF0L ^ 0xBCD65DA48CEF9E35L;
                        continue block16;
                    }
                }
                break;
            }
            MapManager mapManager = this.main.mapManager;
            while (true) {
                long l5;
                long l6;
                if ((l6 = (l5 = \u13e8 - (0x7678L ^ 0x62119F384C22892CL)) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) continue;
                if (l6 == (0x2350 ^ 0xFFFFDCAF)) break;
                l6 = 0x559A ^ 0x1D2C4778;
            }
            ZoneInfo zoneInfo = mapManager.preferred;
            while (true) {
                long l7;
                long l8;
                if ((l8 = (l7 = \u13e8 - (0x2A6BL ^ 0xC1584E9B5697E0C6L)) == 0L ? 0 : (l7 < 0L ? -1 : 1)) == false) continue;
                if (l8 == (0x2E76 ^ 0x2E77)) break;
                l8 = 0x649D ^ 0xE8ED3B52;
            }
            LocationInfo locationInfo = npc.locationInfo;
            long l9 = \u13e8;
            block19: while (true) {
                switch ((int)l9) {
                    case -1339364696: {
                        l9 = (0x53D4L ^ 0x7CA8B056C96E176BL) / (7991382406931083552L >>> "\u0000\u0000".length());
                        continue block19;
                    }
                    case -1335009722: {
                        break block19;
                    }
                }
                break;
            }
            Location location = locationInfo.now;
            while (true) {
                long l10;
                long l11;
                if ((l11 = (l10 = \u13e8 - (0x2282L ^ 0xF21064624F3FEFF7L)) == 0L ? 0 : (l10 < 0L ? -1 : 1)) == false) continue;
                if (l11 == (0x6E7 ^ 0xFFFFF918)) {
                    return zoneInfo.contains(location);
                }
                l11 = 0x60C2 ^ 0xDDAAE99A;
            }
        };
        long l = \u13e8;
        block12: while (true) {
            switch ((int)l) {
                case -1889880580: {
                    l = (0x6266L ^ 0xC90D5E42BD1E8A1FL) / (0x3261L ^ 0x6106E4CA09EB2468L);
                    continue block12;
                }
                case -1335009722: {
                    break block12;
                }
            }
            break;
        }
        Stream<Npc> stream2 = stream.filter(predicate);
        long l5 = \u13e8;
        boolean bl = true;
        block13: while (true) {
            long l6;
            if (!bl || (bl = false) || !true) {
                l5 = l6 / (0x720DL ^ 0xF37CD79F8AC3AAABL);
            }
            switch ((int)l5) {
                case -1335009722: {
                    return (int)stream2.count();
                }
                case -302795970: {
                    l6 = 0x7073L ^ 0xB1D71D2EE078409FL;
                    continue block13;
                }
                case 1928014087: {
                    l6 = -5208142860732893348L >>> "\u0000\u0000".length();
                    continue block13;
                }
            }
            break;
        }
        return (int)stream2.count();
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public boolean npcSubnameInSight(String npcSubname) {
        long l = \u13e8;
        block18: while (true) {
            switch ((int)l) {
                case -1335009722: {
                    break block18;
                }
                case 2055300343: {
                    l = (0x3621L ^ 0x4CBD5F182B5FE33EL) / (0x7B24L ^ 0xAB9FA740141A7C82L);
                    continue block18;
                }
            }
            break;
        }
        long l2 = \u13e8;
        block19: while (true) {
            switch ((int)l2) {
                case -1335009722: {
                    break block19;
                }
                case 1798948740: {
                    l2 = (0x398L ^ 0x7A8AB29874FF62DAL) / (0x7700L ^ 0xDD4C317493DC2339L);
                    continue block19;
                }
            }
            break;
        }
        Stream stream = this.npcs.stream();
        long l3 = \u13e8;
        block20: while (true) {
            switch ((int)l3) {
                case -1335009722: {
                    break block20;
                }
                case -524936267: {
                    l3 = (0x3329L ^ 0x550ED90984C91839L) / (3528407555216431444L >>> "\u0000\u0000".length());
                    continue block20;
                }
            }
            break;
        }
        Predicate<Npc> predicate = npc -> {
            long l = \u13e8;
            block13: while (true) {
                switch ((int)l) {
                    case -1335009722: {
                        break block13;
                    }
                    case 1453715266: {
                        l = (0x2DDBL ^ 0xE8E6957D85AF42ACL) / (0x5CB4L ^ 0xE9B2A61B9EB2E99AL);
                        continue block13;
                    }
                }
                break;
            }
            PlayerInfo playerInfo = npc.playerInfo;
            while (true) {
                long l2;
                long l3;
                if ((l3 = (l2 = \u13e8 - (-6494143566861969256L >>> "\u0000\u0000".length())) == 0L ? 0 : (l2 < 0L ? -1 : 1)) == false) continue;
                if (l3 == (0x684F ^ 0xFFFF97B0)) break;
                l3 = -964141736 >>> "\u0000\u0000".length();
            }
            String string = playerInfo.username;
            while (true) {
                long l4;
                long l5;
                if ((l5 = (l4 = \u13e8 - (0x5F50L ^ 0xE6ABC4617AA09ADEL)) == 0L ? 0 : (l4 < 0L ? -1 : 1)) == false) continue;
                if (l5 == (0x462A ^ 0xFFFFB9D5)) break;
                l5 = 0x4B44 ^ 0x53419467;
            }
            String string2 = string.toLowerCase();
            long l6 = \u13e8;
            block16: while (true) {
                switch ((int)l6) {
                    case -1335009722: {
                        break block16;
                    }
                    case -701508623: {
                        l6 = (0x1652L ^ 0xF0746CB564D7DE4BL) / (0x6586L ^ 0x5816BB5E2514EB5L);
                        continue block16;
                    }
                }
                break;
            }
            String string3 = npcSubname.toLowerCase();
            long l7 = \u13e8;
            boolean bl = true;
            block17: while (true) {
                long l8;
                if (!bl || (bl = false) || !true) {
                    l7 = l8 / (0x31D9L ^ 0x3649EBF38FB3EDF3L);
                }
                switch ((int)l7) {
                    case -2041786566: {
                        l8 = 0x5707L ^ 0x785BD9D9B98997L;
                        continue block17;
                    }
                    case -1335009722: {
                        return string2.contains(string3);
                    }
                    case 189237955: {
                        l8 = 0x77E2L ^ 0x199AD20DC4DF7D46L;
                        continue block17;
                    }
                }
                break;
            }
            return string2.contains(string3);
        };
        long l4 = \u13e8;
        boolean bl = true;
        block21: while (true) {
            long l5;
            if (!bl || (bl = false) || !true) {
                l4 = l5 / (0x19D3L ^ 0x4F81702C07AE25DEL);
            }
            switch ((int)l4) {
                case -2093399234: {
                    l5 = 0x7143L ^ 0xDDF20E4B18C15F71L;
                    continue block21;
                }
                case -1335009722: {
                    return stream.anyMatch(predicate);
                }
                case -755916439: {
                    l5 = 0x53F0L ^ 0xC69DA01B5EA72296L;
                    continue block21;
                }
                case 836259685: {
                    l5 = 0x1A25L ^ 0x82E6AF87266CB99L;
                    continue block21;
                }
            }
            break;
        }
        return stream.anyMatch(predicate);
    }

    /*
     * Unable to fully structure code
     */
    public void install(Main main) {
        while (true) {
            if ((v0 = (cfr_temp_0 = TwLootModule.\u13e8 - (2250L ^ -6640789216300857591L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (11409 ^ 11408)) break;
            v0 = 31197 ^ -1642116751;
        }
        this.main = main;
        while (true) {
            if ((v1 = (cfr_temp_1 = TwLootModule.\u13e8 - (20821L ^ 4836897561357138153L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v1 == (18777 ^ -18778)) break;
            v1 = 22290 ^ -1497074851;
        }
        v2 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl16
        block52: while (true) {
            v2 = v3 / (1534L ^ 1732945195767381909L);
lbl16:
            // 2 sources

            switch ((int)v2) {
                case -1488786423: {
                    v3 = 727L ^ -8473079870692110785L;
                    continue block52;
                }
                case -1335009722: {
                    break block52;
                }
                case 398309251: {
                    v3 = 13971L ^ -4057736321063560195L;
                    continue block52;
                }
                case 1256847901: {
                    v3 = 12236L ^ -7102254722924806272L;
                    continue block52;
                }
            }
            break;
        }
        v4 = new TwNpcAttacker(main);
        while (true) {
            if ((v5 = (cfr_temp_2 = TwLootModule.\u13e8 - (8571L ^ -602771511582755365L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v5 == (5900 ^ -5901)) break;
            v5 = 3938 ^ 1570289688;
        }
        this.attack = v4;
        while (true) {
            if ((v6 = (cfr_temp_3 = TwLootModule.\u13e8 - (8460L ^ -6396518061708897390L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v6 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v6 = 31845 ^ -1159384287;
        }
        while (true) {
            if ((v7 = (cfr_temp_4 = TwLootModule.\u13e8 - (6479L ^ -740234384019933964L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v7 == (2326 ^ -2327)) break;
            v7 = 23806 ^ 1941734316;
        }
        v8 = new SafetyFinder(main);
        v9 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl50
        block56: while (true) {
            v9 = v10 / (16312L ^ -8500632039486057607L);
lbl50:
            // 2 sources

            switch ((int)v9) {
                case -2041805126: {
                    v10 = 28148L ^ -1021826723588976893L;
                    continue block56;
                }
                case -1335009722: {
                    break block56;
                }
                case -821831458: {
                    v10 = 24642L ^ -1224870450890219851L;
                    continue block56;
                }
                case -155911324: {
                    v10 = 14881L ^ -4226910008495468187L;
                    continue block56;
                }
            }
            break;
        }
        this.safety = v8;
        v11 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl67
        block57: while (true) {
            v11 = v12 / (31490L ^ 6496129275111826740L);
lbl67:
            // 2 sources

            switch ((int)v11) {
                case -1335009722: {
                    break block57;
                }
                case -1233411528: {
                    v12 = 9805L ^ -380751036479353809L;
                    continue block57;
                }
                case -998732115: {
                    v12 = 16429L ^ -5611356454316835348L;
                    continue block57;
                }
            }
            break;
        }
        v13 = main.hero;
        while (true) {
            if ((v14 = (cfr_temp_5 = TwLootModule.\u13e8 - (24262L ^ -5066696414555114445L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
            if (v14 == (9624 ^ 9625)) break;
            v14 = 29611 ^ 648288032;
        }
        this.hero = v13;
        v15 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl87
        block59: while (true) {
            v15 = (11851L ^ 5710006835686017269L) / (2940L ^ 464626435722447603L);
lbl87:
            // 2 sources

            switch ((int)v15) {
                case -1335009722: {
                    break block59;
                }
                case -912011812: {
                    continue block59;
                }
            }
            break;
        }
        v16 = main.hero;
        v17 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl97
        block60: while (true) {
            v17 = (25808L ^ -7554887248255005502L) / (30015L ^ -166577374734060676L);
lbl97:
            // 2 sources

            switch ((int)v17) {
                case -1335009722: {
                    break block60;
                }
                case -1213934656: {
                    continue block60;
                }
            }
            break;
        }
        v18 = v16.drive;
        while (true) {
            if ((v19 = (cfr_temp_6 = TwLootModule.\u13e8 - (28132L ^ 5244653966748718928L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
            if (v19 == (2670 ^ -2671)) break;
            v19 = 3251 ^ -1018267743;
        }
        this.drive = v18;
        while (true) {
            if ((v20 = (cfr_temp_7 = TwLootModule.\u13e8 - (15539L ^ 7226813892787436282L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
            if (v20 == (8173 ^ -8174)) break;
            v20 = 13539 ^ -1073779068;
        }
        v21 = main.mapManager;
        v22 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl119
        block63: while (true) {
            v22 = v23 / (30121L ^ 7180895286787740341L);
lbl119:
            // 2 sources

            switch ((int)v22) {
                case -1669875984: {
                    v23 = 24146L ^ 5692467229256731305L;
                    continue block63;
                }
                case -1573951817: {
                    v23 = 20548L ^ -824354136045087830L;
                    continue block63;
                }
                case -1335009722: {
                    break block63;
                }
                case -1018485245: {
                    v23 = 8980L ^ 954790952033258736L;
                    continue block63;
                }
            }
            break;
        }
        v24 = v21.entities;
        v25 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl136
        block64: while (true) {
            v25 = (32480L ^ -6004789089790294222L) / (24709L ^ -1894820320045163671L);
lbl136:
            // 2 sources

            switch ((int)v25) {
                case -1957888778: {
                    continue block64;
                }
                case -1335009722: {
                    break block64;
                }
            }
            break;
        }
        v26 = v24.ships;
        while (true) {
            if ((v27 = (cfr_temp_8 = TwLootModule.\u13e8 - (19909L ^ 5356630566648366587L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
            if (v27 == ("\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() ^ -33)) break;
            v27 = 24671 ^ 1806032076;
        }
        this.ships = v26;
        while (true) {
            if ((v28 = (cfr_temp_9 = TwLootModule.\u13e8 - (28324L ^ 5972415422620482016L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
            if (v28 == (24323 ^ -24324)) break;
            v28 = 27671 ^ -979000412;
        }
        v29 = main.mapManager;
        while (true) {
            if ((v30 = (cfr_temp_10 = TwLootModule.\u13e8 - (32709L ^ -5355493687709970925L)) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
            if (v30 == (4243 ^ 4242)) break;
            v30 = 27902 ^ 74961839;
        }
        v31 = v29.entities;
        while (true) {
            if ((v32 = (cfr_temp_11 = TwLootModule.\u13e8 - (772L ^ 7901701328531370638L)) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
            if (v32 == (6063 ^ -6064)) break;
            v32 = 1934 ^ -431914846;
        }
        v33 = v31.npcs;
        v34 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl170
        block69: while (true) {
            v34 = (22849L ^ -8449287381198984811L) / (18515L ^ -5957835823133957056L);
lbl170:
            // 2 sources

            switch ((int)v34) {
                case -2019324485: {
                    continue block69;
                }
                case -1335009722: {
                    break block69;
                }
            }
            break;
        }
        this.npcs = v33;
        v35 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl180
        block70: while (true) {
            v35 = v36 / (18230L ^ -994686055232605523L);
lbl180:
            // 2 sources

            switch ((int)v35) {
                case -1398316935: {
                    v36 = 14217L ^ 7047927334973188708L;
                    continue block70;
                }
                case -1335009722: {
                    break block70;
                }
                case 2110390006: {
                    v36 = 22780L ^ 2495339111500567674L;
                    continue block70;
                }
            }
            break;
        }
        v37 = main.config;
        while (true) {
            if ((v38 = (cfr_temp_12 = TwLootModule.\u13e8 - (26184L ^ 6520083340609216495L)) == 0L ? 0 : (cfr_temp_12 < 0L ? -1 : 1)) == false) continue;
            if (v38 == (18507 ^ -18508)) break;
            v38 = 30778 ^ -1976050628;
        }
        this.config = v37;
        while (true) {
            if ((v39 = (cfr_temp_13 = TwLootModule.\u13e8 - (31368L ^ -4268209072371744725L)) == 0L ? 0 : (cfr_temp_13 < 0L ? -1 : 1)) == false) continue;
            if (v39 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v39 = 12909 ^ -632986481;
        }
        v40 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl205
        block73: while (true) {
            v40 = v41 / (8404L ^ 7809747794117182126L);
lbl205:
            // 2 sources

            switch ((int)v40) {
                case -2025989790: {
                    v41 = 7628L ^ 5931533751905863255L;
                    continue block73;
                }
                case -1335009722: {
                    break block73;
                }
                case -218838038: {
                    v41 = 14940L ^ -8102796292387755588L;
                    continue block73;
                }
                case 2124572496: {
                    v41 = 15848L ^ -483668555884400702L;
                    continue block73;
                }
            }
            break;
        }
        this.mapTraveler.install(main);
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public void uninstall() {
        long l = \u13e8;
        boolean bl = true;
        block6: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x3400L ^ 0x6BC7B942155951CAL);
            }
            switch ((int)l) {
                case -1335009722: {
                    break block6;
                }
                case 564457819: {
                    l2 = 0x79BFL ^ 0xC383021993F66150L;
                    continue block6;
                }
                case 1174905475: {
                    l2 = 0x11E0L ^ 0x556F6F20CDEE9D69L;
                    continue block6;
                }
                case 1193161822: {
                    l2 = 0x3F44L ^ 0xBE4C9C6B2F22C721L;
                    continue block6;
                }
            }
            break;
        }
        while (true) {
            long l3;
            long l4;
            if ((l4 = (l3 = \u13e8 - (0x450CL ^ 0xB2FB8FA497483041L)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) continue;
            if (l4 == (0x2ACF ^ 0x2ACE)) break;
            l4 = 0x1C09 ^ 0xC5976E8F;
        }
        this.safety.uninstall();
        while (true) {
            long l5;
            long l6;
            if ((l6 = (l5 = \u13e8 - (0x2E7AL ^ 0x72A95C3C147EB8CAL)) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) continue;
            if (l6 == (0x972 ^ 0xFFFFF68D)) break;
            l6 = 0x1C0A ^ 0x5ADDE65F;
        }
        while (true) {
            long l7;
            long l8;
            if ((l8 = (l7 = \u13e8 - (0x6A1CL ^ 0xC421B584F7074735L)) == 0L ? 0 : (l7 < 0L ? -1 : 1)) == false) continue;
            if (l8 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                this.mapTraveler.uninstall();
                return;
            }
            l8 = 0x4529 ^ 0xCD91073A;
        }
    }

    /*
     * Unable to fully structure code
     */
    public String status() {
        block33: {
            block34: {
                while (true) {
                    if ((v0 = (cfr_temp_0 = TwLootModule.\u13e8 - (7237L ^ -8647865495932107967L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                        continue;
                    }
                    if (v0 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                    v0 = 27004 ^ 2121304781;
                }
                v1 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl11
                block16: while (true) {
                    v1 = v2 / (29991L ^ 6769308376010887135L);
lbl11:
                    // 2 sources

                    switch ((int)v1) {
                        case -1335009722: {
                            break block16;
                        }
                        case -417297730: {
                            v2 = 24521L ^ 8311310211216716688L;
                            continue block16;
                        }
                        case 987589491: {
                            v2 = 23756L ^ 2007843594300404315L;
                            continue block16;
                        }
                    }
                    break;
                }
                v3 = this.safety.state();
                v4 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl25
                block17: while (true) {
                    v4 = v5 / (13282L ^ 5607944176306937389L);
lbl25:
                    // 2 sources

                    switch ((int)v4) {
                        case -1702037382: {
                            v5 = -8050915817446429144L >>> "\u0000\u0000".length();
                            continue block17;
                        }
                        case -1335009722: {
                            break block17;
                        }
                        case -340119452: {
                            v5 = 30355L ^ 7790838456437450263L;
                            continue block17;
                        }
                    }
                    break;
                }
                if (v3 == SafetyFinder.Escaping.NONE) break block34;
                v6 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl39
                block18: while (true) {
                    v6 = v7 / (30510L ^ -8909388955831745502L);
lbl39:
                    // 2 sources

                    switch ((int)v6) {
                        case -1335009722: {
                            break block18;
                        }
                        case -1198729238: {
                            v7 = 14915L ^ -4522106666408547069L;
                            continue block18;
                        }
                        case 1438718384: {
                            v7 = 23758L ^ -5105575967169366137L;
                            continue block18;
                        }
                    }
                    break;
                }
                while (true) {
                    if ((v8 = (cfr_temp_1 = TwLootModule.\u13e8 - (19541L ^ 9148380529498451004L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) {
                        continue;
                    }
                    if (v8 == (9040 ^ -9041)) {
                        v9 = this.safety.status();
                        break block33;
                    }
                    v8 = 10053 ^ 1890143175;
                }
            }
            while (true) {
                if ((v10 = (cfr_temp_2 = TwLootModule.\u13e8 - (19634L ^ -8288066780997593781L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (v10 == (18216 ^ 18217)) break;
                v10 = 5108 ^ -666225785;
            }
            while (true) {
                if ((v11 = (cfr_temp_3 = TwLootModule.\u13e8 - (30637L ^ 3449850231590203741L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (v11 == (4063 ^ -4064)) break;
                v11 = 5839 ^ 1116910196;
            }
            if (this.attack.hasTarget()) {
                while (true) {
                    if ((v12 = (cfr_temp_4 = TwLootModule.\u13e8 - (7419117149054811776L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) {
                        continue;
                    }
                    if (v12 == (15668 ^ -15669)) break;
                    v12 = 6942 ^ -771697560;
                }
                while (true) {
                    if ((v13 = (cfr_temp_5 = TwLootModule.\u13e8 - (26992L ^ -2961491439567786828L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) {
                        continue;
                    }
                    if (v13 == (26303 ^ 26302)) {
                        v9 = this.attack.status();
                        break block33;
                    }
                    v13 = 16460 ^ -832397747;
                }
            }
            var2_1 = new byte[20835 ^ 20836];
            var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 7259 ^ -7182;
            var2_1[18764 ^ 18766] = 25476 ^ 25573;
            var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 20713 ^ 20615;
            var2_1[25366 ^ 25366] = 31150 ^ 31228;
            var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 436 >>> "\u0000\u0000".length();
            var2_1[21682 ^ 21686] = 420 >>> "\u0000\u0000".length();
            var2_1[27747 ^ 27746] = 444 >>> "\u0000\u0000".length();
            var2_1[5281 ^ 5287] = 412 >>> "\u0000\u0000".length();
            v9 = new String(var2_1);
        }
        return v9;
    }

    /*
     * Unable to fully structure code
     */
    public boolean canRefresh() {
        block36: {
            while (true) {
                if ((v0 = (cfr_temp_0 = TwLootModule.\u13e8 - (11808L ^ -7789817370478297020L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (v0 == (1135 ^ 1134)) break;
                v0 = 25746 ^ -126719855;
            }
            while (true) {
                if ((v1 = (cfr_temp_1 = TwLootModule.\u13e8 - (8909L ^ 8100727267990600984L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (v1 == (26595 ^ -26596)) break;
                v1 = 10860 ^ 1370581263;
            }
            if (this.attack.hasTarget()) break block36;
            v2 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl18
            block22: while (true) {
                v2 = v3 / (12272L ^ 6668179715743616135L);
lbl18:
                // 2 sources

                switch ((int)v2) {
                    case -1335009722: {
                        break block22;
                    }
                    case 944820411: {
                        v3 = 21949L ^ -1973441419807855702L;
                        continue block22;
                    }
                    case 1829667229: {
                        v3 = 18239L ^ -685410519649223123L;
                        continue block22;
                    }
                    case 2022991591: {
                        v3 = 435L ^ 394946561246717854L;
                        continue block22;
                    }
                }
                break;
            }
            v4 = System.currentTimeMillis() + (40000L >>> "\u0000\u0000".length());
            v5 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl35
            block23: while (true) {
                v5 = v6 / (13036L ^ 5537084944937537787L);
lbl35:
                // 2 sources

                switch ((int)v5) {
                    case -1335009722: {
                        break block23;
                    }
                    case -38576741: {
                        v6 = 23037L ^ -3769312307259844123L;
                        continue block23;
                    }
                    case 2080942426: {
                        v6 = 5030L ^ 3473040525189604189L;
                        continue block23;
                    }
                }
                break;
            }
            this.refreshing = v4;
        }
        while (true) {
            if ((v7 = (cfr_temp_2 = TwLootModule.\u13e8 - (31581L ^ -1281225727176111851L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v7 == (24415 ^ -24416)) break;
            v7 = 32519 ^ 2124697726;
        }
        v8 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl56
        block25: while (true) {
            v8 = (3530173923336405504L >>> "\u0000\u0000".length()) / (14101L ^ 7058052426917556577L);
lbl56:
            // 2 sources

            switch ((int)v8) {
                case -1624490965: {
                    continue block25;
                }
                case -1335009722: {
                    break block25;
                }
            }
            break;
        }
        if (this.attack.hasTarget()) ** GOTO lbl-1000
        while (true) {
            if ((v9 = (cfr_temp_3 = TwLootModule.\u13e8 - (12903L ^ 5973359340329233051L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v9 == (23142 ^ -23143)) break;
            v9 = 24898 ^ 1218489188;
        }
        v10 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl72
        block27: while (true) {
            v10 = v11 / (5052L ^ -4821219088550681844L);
lbl72:
            // 2 sources

            switch ((int)v10) {
                case -1335009722: {
                    break block27;
                }
                case -977057393: {
                    v11 = 27448L ^ -4719987486594408417L;
                    continue block27;
                }
                case 1912296450: {
                    v11 = 5149L ^ -2073399430001708748L;
                    continue block27;
                }
            }
            break;
        }
        v12 = this.safety.state();
        while (true) {
            if ((v13 = (cfr_temp_4 = TwLootModule.\u13e8 - (4808577669320493780L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v13 == (29432 ^ -29433)) break;
            v13 = 1469 ^ -1026237492;
        }
        if (v12 == SafetyFinder.Escaping.WAITING) {
            v14 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        } else lbl-1000:
        // 2 sources

        {
            v14 = "".length() >>> "\u0000\u0000".length();
        }
        return (boolean)v14;
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    public void tick() {
        block61: {
            block62: {
                while (true) {
                    if ((v0 = (cfr_temp_0 = TwLootModule.\u13e8 - (31769L ^ 7289422906210327326L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                    if (v0 == (29570 ^ -29571)) break;
                    v0 = 12549 ^ 1274080579;
                }
                if (!this.checkDangerousAndCurrentMap()) break block61;
                v1 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl11
                block43: while (true) {
                    v1 = (15145L ^ -376316439979474439L) / (13260L ^ -7122510431149447520L);
lbl11:
                    // 2 sources

                    switch ((int)v1) {
                        case -1390365542: {
                            continue block43;
                        }
                        case -1335009722: {
                            break block43;
                        }
                    }
                    break;
                }
                v2 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl20
                block44: while (true) {
                    v2 = (32374L ^ -3634896085728299764L) / (13557L ^ 8928605173498491729L);
lbl20:
                    // 2 sources

                    switch ((int)v2) {
                        case -1702708850: {
                            continue block44;
                        }
                        case -1335009722: {
                            break block44;
                        }
                    }
                    break;
                }
                v3 = this.main.guiManager;
                v4 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl30
                block45: while (true) {
                    v4 = v5 / (2728679723925761412L >>> "\u0000\u0000".length());
lbl30:
                    // 2 sources

                    switch ((int)v4) {
                        case -1335009722: {
                            break block45;
                        }
                        case -1249960801: {
                            v5 = 6007L ^ 4907325800678318747L;
                            continue block45;
                        }
                        case -52528286: {
                            v5 = 4457L ^ 6938937900174469779L;
                            continue block45;
                        }
                        case 181543467: {
                            v5 = 8666L ^ -8766525360412052493L;
                            continue block45;
                        }
                    }
                    break;
                }
                v6 = v3.pet;
                v7 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
                v8 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl48
                block46: while (true) {
                    v8 = v9 / (-8712796638056440908L >>> "\u0000\u0000".length());
lbl48:
                    // 2 sources

                    switch ((int)v8) {
                        case -1335009722: {
                            break block46;
                        }
                        case 343082699: {
                            v9 = 2520L ^ -4307447151948203911L;
                            continue block46;
                        }
                        case 1865404682: {
                            v9 = 3957848890872408052L >>> "\u0000\u0000".length();
                            continue block46;
                        }
                    }
                    break;
                }
                v6.setEnabled(v7);
                while (true) {
                    if ((v10 = (cfr_temp_1 = TwLootModule.\u13e8 - (22127L ^ -3716303725545860822L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                    if (v10 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                    v10 = 7157 ^ -22676537;
                }
                if (!this.findTarget()) break block62;
                v11 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl68
                block48: while (true) {
                    v11 = v12 / (15486L ^ 8419832441826441429L);
lbl68:
                    // 2 sources

                    switch ((int)v11) {
                        case -1335009722: {
                            break block48;
                        }
                        case 49696805: {
                            v12 = 8053L ^ 5736703696229878646L;
                            continue block48;
                        }
                        case 496016868: {
                            v12 = 29918L ^ -5580551523617368698L;
                            continue block48;
                        }
                    }
                    break;
                }
                this.moveToAnSafePosition();
                v13 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl82
                block49: while (true) {
                    v13 = (20513L ^ -4720097932382276461L) / (12162L ^ 6727109391312307286L);
lbl82:
                    // 2 sources

                    switch ((int)v13) {
                        case -1335009722: {
                            break block49;
                        }
                        case 1803439956: {
                            continue block49;
                        }
                    }
                    break;
                }
                this.ignoreInvalidTarget();
                v14 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl92
                block50: while (true) {
                    v14 = (28444L ^ -6147278096329274881L) / (4578076007580170872L >>> "\u0000\u0000".length());
lbl92:
                    // 2 sources

                    switch ((int)v14) {
                        case -1435721724: {
                            continue block50;
                        }
                        case -1335009722: {
                            break block50;
                        }
                    }
                    break;
                }
                while (true) {
                    if ((v15 = (cfr_temp_2 = TwLootModule.\u13e8 - (29687L ^ 3014241425571864208L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                    if (v15 == (19119 ^ -19120)) {
                        this.attack.doKillTargetTick();
                        break block61;
                    }
                    v15 = 11111 ^ -1813578647;
                }
            }
            v16 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl109
            block52: while (true) {
                v16 = (26209L ^ -5491766371068752777L) / (20094L ^ -5757765489636965117L);
lbl109:
                // 2 sources

                switch ((int)v16) {
                    case -1335009722: {
                        break block52;
                    }
                    case 1168748773: {
                        continue block52;
                    }
                }
                break;
            }
            while (true) {
                if ((v17 = (cfr_temp_3 = TwLootModule.\u13e8 - (16087L ^ -5342651197188706030L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v17 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v17 = 1754 ^ -2094960435;
            }
            this.hero.roamMode();
            v18 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl124
            block54: while (true) {
                v18 = v19 / (16369L ^ 4779143356868822351L);
lbl124:
                // 2 sources

                switch ((int)v18) {
                    case -1335009722: {
                        break block54;
                    }
                    case -581893826: {
                        v19 = 14550L ^ 1518257017786016565L;
                        continue block54;
                    }
                    case 1074448121: {
                        v19 = 6148L ^ 1889197974855868254L;
                        continue block54;
                    }
                    case 1250093073: {
                        v19 = 15076L ^ 8986352151786882208L;
                        continue block54;
                    }
                }
                break;
            }
            while (true) {
                if ((v20 = (cfr_temp_4 = TwLootModule.\u13e8 - (5802L ^ 6824980431429463988L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v20 == (23203 ^ -23204)) break;
                v20 = 14607 ^ -1292564956;
            }
            if (!this.drive.isMoving()) {
                while (true) {
                    if ((v21 = (cfr_temp_5 = TwLootModule.\u13e8 - (7466L ^ -4807154446604374614L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                    if (v21 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                    v21 = 3023 ^ -1947577440;
                }
                while (true) {
                    if ((v22 = (cfr_temp_6 = TwLootModule.\u13e8 - (14608L ^ -5651756364321117887L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                    if (v22 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                        this.drive.moveRandom();
                        break;
                    }
                    v22 = 8740 ^ -1435635875;
                }
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    public boolean tryTickMapModule() {
        while (true) {
            if ((v0 = (cfr_temp_0 = TwLootModule.\u13e8 - (1550L ^ -3721110891087391254L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v0 = 24099 ^ 1529372288;
        }
        v1 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl10
        block17: while (true) {
            v1 = v2 / (16534L ^ 8546481203538941491L);
lbl10:
            // 2 sources

            switch ((int)v1) {
                case -1335009722: {
                    break block17;
                }
                case -1043208238: {
                    v2 = 20935L ^ 8814733183340438673L;
                    continue block17;
                }
                case -943030793: {
                    v2 = 5682L ^ 7310974324101858588L;
                    continue block17;
                }
                case 906321335: {
                    v2 = 18714L ^ 2869449848704027515L;
                    continue block17;
                }
            }
            break;
        }
        while (true) {
            if ((v3 = (cfr_temp_1 = TwLootModule.\u13e8 - (-7671805059938421372L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v3 == (6190 ^ -6191)) break;
            v3 = 27141 ^ -1294353861;
        }
        v4 = this.twLootModuleConfig.MAP_TRAVELLER_CONFIG;
        while (true) {
            if ((v5 = (cfr_temp_2 = TwLootModule.\u13e8 - (5263237159087506136L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v5 == (1516 ^ -1517)) break;
            v5 = 3191 ^ -737729917;
        }
        this.mapTraveler.tick(v4);
        v6 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl38
        block20: while (true) {
            v6 = v7 / (22642L ^ -7067947530551405161L);
lbl38:
            // 2 sources

            switch ((int)v6) {
                case -1335009722: {
                    break block20;
                }
                case -543513716: {
                    v7 = 5456139207973071128L >>> "\u0000\u0000".length();
                    continue block20;
                }
                case 1798179808: {
                    v7 = 29758L ^ 121793859014130447L;
                    continue block20;
                }
                case 2047421916: {
                    v7 = 18259L ^ -8869068550463722138L;
                    continue block20;
                }
            }
            break;
        }
        v8 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl54
        block21: while (true) {
            v8 = (30831L ^ -8931754837683821389L) / (31749L ^ 9140846642015134229L);
lbl54:
            // 2 sources

            switch ((int)v8) {
                case -1335009722: {
                    break block21;
                }
                case -830567677: {
                    continue block21;
                }
            }
            break;
        }
        return (boolean)(this.mapTraveler.isDone() == false ? 8208 ^ 8209 : 12797 ^ 12797);
    }

    /*
     * Unable to fully structure code
     */
    protected boolean checkDangerousAndCurrentMap() {
        while (true) {
            if ((v0 = (cfr_temp_0 = TwLootModule.\u13e8 - (6887L ^ -4166017926784822939L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v0 = 18233 ^ 2144663013;
        }
        v1 = (BooleanSupplier)LambdaMetafactory.metafactory(null, null, null, ()Z, lambda$checkDangerousAndCurrentMap$3(), ()Z)();
        v2 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl11
        block7: while (true) {
            v2 = v3 / (4890L ^ -4704867968994029050L);
lbl11:
            // 2 sources

            switch ((int)v2) {
                case -1844945285: {
                    v3 = -8555505459404723128L >>> "\u0000\u0000".length();
                    continue block7;
                }
                case -1683036268: {
                    v3 = 22560L ^ -4766260509867203216L;
                    continue block7;
                }
                case -1335009722: {
                    break block7;
                }
                case 2071597903: {
                    v3 = 4174777209512732788L >>> "\u0000\u0000".length();
                    continue block7;
                }
            }
            break;
        }
        return this.checkDangerousAndCurrentMap(v1);
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    protected boolean checkDangerousAndCurrentMap(BooleanSupplier withinRefreshPeriod) {
        v0 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl5
        block25: while (true) {
            v0 = v1 / (10486L ^ -6209048367152929142L);
lbl5:
            // 2 sources

            switch ((int)v0) {
                case -2093123571: {
                    v1 = 14850L ^ 7443081596975889248L;
                    continue block25;
                }
                case -1335009722: {
                    break block25;
                }
                case -1307975973: {
                    v1 = 21743L ^ 7960174198382208144L;
                    continue block25;
                }
                case -1183851340: {
                    v1 = 19327L ^ -6534420595221182444L;
                    continue block25;
                }
            }
            break;
        }
        while (true) {
            if ((v2 = (cfr_temp_0 = TwLootModule.\u13e8 - (22532L ^ -1600723924094152318L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v2 == (24073 ^ -24074)) break;
            v2 = 13221 ^ -1487321655;
        }
        v3 = System.currentTimeMillis();
        v4 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl27
        block27: while (true) {
            v4 = v5 / (13366L ^ -3301773864118960621L);
lbl27:
            // 2 sources

            switch ((int)v4) {
                case -1335009722: {
                    break block27;
                }
                case -785376725: {
                    v5 = 16760L ^ -2829302764854295687L;
                    continue block27;
                }
                case -428161003: {
                    v5 = 21279L ^ -7785816177568337074L;
                    continue block27;
                }
                case 1352759566: {
                    v5 = 1082735183764384280L >>> "\u0000\u0000".length();
                    continue block27;
                }
            }
            break;
        }
        if (v3 > this.refreshing) ** GOTO lbl-1000
        v6 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl44
        block28: while (true) {
            v6 = v7 / (12027L ^ -3184793945168302936L);
lbl44:
            // 2 sources

            switch ((int)v6) {
                case -1335009722: {
                    break block28;
                }
                case 1062640412: {
                    v7 = 18713L ^ -1862077730784291130L;
                    continue block28;
                }
                case 1942772107: {
                    v7 = 20928L ^ -6073975706695486954L;
                    continue block28;
                }
            }
            break;
        }
        if (withinRefreshPeriod.getAsBoolean()) {
            v8 = 26088 ^ 26089;
        } else lbl-1000:
        // 2 sources

        {
            v8 = 17070 ^ 17070;
        }
        while (true) {
            if ((v9 = (cfr_temp_1 = TwLootModule.\u13e8 - (3393L ^ -8905516206236641465L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v9 == (1797 ^ 1796)) break;
            v9 = 19958 ^ 2064955428;
        }
        this.safety.setRefreshing(v8);
        while (true) {
            if ((v10 = (cfr_temp_2 = TwLootModule.\u13e8 - (25245L ^ -3427128215054125083L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v10 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v10 = 1801410200 >>> "\u0000\u0000".length();
        }
        v11 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl72
        block31: while (true) {
            v11 = (27465L ^ 9114198085310075775L) / (30144L ^ -5139278099856154721L);
lbl72:
            // 2 sources

            switch ((int)v11) {
                case -1335009722: {
                    break block31;
                }
                case -326011528: {
                    continue block31;
                }
            }
            break;
        }
        if (!this.safety.tick()) ** GOTO lbl-1000
        v12 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl82
        block32: while (true) {
            v12 = (3557L ^ -9037127727816464704L) / (-1976631016277838256L >>> "\u0000\u0000".length());
lbl82:
            // 2 sources

            switch ((int)v12) {
                case -1335009722: {
                    break block32;
                }
                case 840880415: {
                    continue block32;
                }
            }
            break;
        }
        if (this.checkMap()) {
            v13 = 1406 ^ 1407;
        } else lbl-1000:
        // 2 sources

        {
            v13 = 21210 ^ 21210;
        }
        return (boolean)v13;
    }

    /*
     * Unable to fully structure code
     */
    protected boolean checkMap() {
        block71: {
            v0 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl5
            block54: while (true) {
                v0 = (32666L ^ 9221154950394502440L) / (19047L ^ -7002360871434301113L);
lbl5:
                // 2 sources

                switch ((int)v0) {
                    case -1335009722: {
                        break block54;
                    }
                    case -199571538: {
                        continue block54;
                    }
                }
                break;
            }
            v1 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl14
            block55: while (true) {
                v1 = (3456L ^ -8186771785361258958L) / (1584L ^ -4096865869385367503L);
lbl14:
                // 2 sources

                switch ((int)v1) {
                    case -1335009722: {
                        break block55;
                    }
                    case 1317621056: {
                        continue block55;
                    }
                }
                break;
            }
            v2 = this.config.GENERAL;
            v3 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl24
            block56: while (true) {
                v3 = (8966L ^ 7315123702603624673L) / (6029L ^ 5859857468142573705L);
lbl24:
                // 2 sources

                switch ((int)v3) {
                    case -1335009722: {
                        break block56;
                    }
                    case -691090882: {
                        continue block56;
                    }
                }
                break;
            }
            v4 = v2.WORKING_MAP;
            while (true) {
                if ((v5 = (cfr_temp_0 = TwLootModule.\u13e8 - (-6868977680927575040L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v5 == (29664 ^ -29665)) break;
                v5 = 1106 ^ 1575229631;
            }
            while (true) {
                if ((v6 = (cfr_temp_1 = TwLootModule.\u13e8 - (14735L ^ -1597101139864754788L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v6 == (7117 ^ -7118)) break;
                v6 = 15363 ^ 1570426106;
            }
            v7 = this.hero.map;
            v8 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl45
            block59: while (true) {
                v8 = v9 / (15670L ^ 5916092393377354932L);
lbl45:
                // 2 sources

                switch ((int)v8) {
                    case -1335009722: {
                        break block59;
                    }
                    case -147269753: {
                        v9 = -8179637138465321144L >>> "\u0000\u0000".length();
                        continue block59;
                    }
                    case 1639511260: {
                        v9 = 14351L ^ 5144734986340615255L;
                        continue block59;
                    }
                    case 1997529446: {
                        v9 = -4915159161566017464L >>> "\u0000\u0000".length();
                        continue block59;
                    }
                }
                break;
            }
            v10 = heroOnWorkingMap = v4 == v7.id ? "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length() : "".length() >>> "\u0000\u0000".length();
            if (heroOnWorkingMap != 0) break block71;
            while (true) {
                if ((v11 = (cfr_temp_2 = TwLootModule.\u13e8 - (19417L ^ 6039671679839146982L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v11 == (10415 ^ -10416)) break;
                v11 = 19235 ^ 1800639291;
            }
            v12 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl68
            block61: while (true) {
                v12 = (6989L ^ 1526736647069974138L) / (9157361103844146156L >>> "\u0000\u0000".length());
lbl68:
                // 2 sources

                switch ((int)v12) {
                    case -1335009722: {
                        break block61;
                    }
                    case 946203906: {
                        continue block61;
                    }
                }
                break;
            }
            v13 = this.main.mapManager;
            v14 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl78
            block62: while (true) {
                v14 = (32364L ^ 7718853088354079423L) / (19757L ^ -3218477235250810025L);
lbl78:
                // 2 sources

                switch ((int)v14) {
                    case -1335009722: {
                        break block62;
                    }
                    case 270387151: {
                        continue block62;
                    }
                }
                break;
            }
            v15 = v13.entities;
            v16 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl88
            block63: while (true) {
                v16 = v17 / (17768L ^ 8563506803489780721L);
lbl88:
                // 2 sources

                switch ((int)v16) {
                    case -1792639043: {
                        v17 = 21807L ^ -5416054527595390675L;
                        continue block63;
                    }
                    case -1335009722: {
                        break block63;
                    }
                    case -388205512: {
                        v17 = 29519L ^ -3415175961774162922L;
                        continue block63;
                    }
                    case 1585175877: {
                        v17 = 13930L ^ -6345231981272914142L;
                        continue block63;
                    }
                }
                break;
            }
            v18 = v15.portals;
            v19 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl105
            block64: while (true) {
                v19 = (7595L ^ 8674036172683233240L) / (1315L ^ -6180591702596843453L);
lbl105:
                // 2 sources

                switch ((int)v19) {
                    case -1335009722: {
                        break block64;
                    }
                    case 853481602: {
                        continue block64;
                    }
                }
                break;
            }
            if (v18.isEmpty()) break block71;
            v20 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl115
            block65: while (true) {
                v20 = v21 / (8411L ^ 5565367577645098398L);
lbl115:
                // 2 sources

                switch ((int)v20) {
                    case -1335009722: {
                        break block65;
                    }
                    case 246417561: {
                        v21 = 21628L ^ -6338507149232308006L;
                        continue block65;
                    }
                    case 1029114201: {
                        v21 = 10949L ^ -8935101908054142884L;
                        continue block65;
                    }
                }
                break;
            }
            while (true) {
                if ((v22 = (cfr_temp_3 = TwLootModule.\u13e8 - (14891L ^ -8194933905854963323L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v22 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v22 = 22590 ^ 1955684966;
            }
            v23 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl133
            block67: while (true) {
                v23 = (6442L ^ -2109892709944065306L) / (28656L ^ -1266128800912559352L);
lbl133:
                // 2 sources

                switch ((int)v23) {
                    case -1335009722: {
                        break block67;
                    }
                    case 1517461550: {
                        continue block67;
                    }
                }
                break;
            }
            v24 = this.main.config;
            v25 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl143
            block68: while (true) {
                v25 = (4237L ^ -3937080152875143663L) / (-3786884978076714980L >>> "\u0000\u0000".length());
lbl143:
                // 2 sources

                switch ((int)v25) {
                    case -1335009722: {
                        break block68;
                    }
                    case -989703117: {
                        continue block68;
                    }
                }
                break;
            }
            v26 = v24.GENERAL;
            while (true) {
                if ((v27 = (cfr_temp_4 = TwLootModule.\u13e8 - (29420L ^ 6998513246248869957L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v27 == (4691 ^ -4692)) break;
                v27 = 28593 ^ -440261093;
            }
            v28 = v26.WORKING_MAP;
            v29 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl159
            block70: while (true) {
                v29 = v30 / (12053L ^ 8649457205296857253L);
lbl159:
                // 2 sources

                switch ((int)v29) {
                    case -1335009722: {
                        break block70;
                    }
                    case -110022189: {
                        v30 = 18899L ^ 2498273089637192514L;
                        continue block70;
                    }
                    case 1936803364: {
                        v30 = 14829L ^ 5058814934033991747L;
                        continue block70;
                    }
                }
                break;
            }
            this.mapTraveler.setTargetMap(v28);
            return (boolean)(20556 ^ 20556);
        }
        return (boolean)(2602 ^ 2603);
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    protected boolean findTarget() {
        boolean bl;
        long l = \u13e8;
        block13: while (true) {
            switch ((int)l) {
                case -1335009722: {
                    break block13;
                }
                case -720594887: {
                    l = (-5769339364490827152L >>> "\u0000\u0000".length()) / (0x69CDL ^ 0x6E8223B073AF73BAL);
                    continue block13;
                }
            }
            break;
        }
        long l2 = \u13e8;
        block14: while (true) {
            switch ((int)l2) {
                case -1335009722: {
                    break block14;
                }
                case 445891678: {
                    l2 = (0x6019L ^ 0x8DDD9FE58FB0B39FL) / (0x2AF4L ^ 0xE86F9839568B22BBL);
                    continue block14;
                }
            }
            break;
        }
        long l3 = \u13e8;
        boolean bl2 = true;
        block15: while (true) {
            long l4;
            if (!bl2 || (bl2 = false) || !true) {
                l3 = l4 / (0x5CF8L ^ 0x8CFB70E8E3FE75C4L);
            }
            switch ((int)l3) {
                case -1335009722: {
                    break block15;
                }
                case 260526434: {
                    l4 = 8083353520959723880L >>> "\u0000\u0000".length();
                    continue block15;
                }
                case 2072640421: {
                    l4 = 0x1FCEL ^ 0x6F46262D3E673E8EL;
                    continue block15;
                }
            }
            break;
        }
        LocationInfo locationInfo = this.hero.locationInfo;
        while (true) {
            long l5;
            long l6;
            if ((l6 = (l5 = \u13e8 - (0x3108L ^ 0xF383C5B43A5B5258L)) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) continue;
            if (l6 == (0x2B64 ^ 0xFFFFD49B)) break;
            l6 = 469990860 >>> "\u0000\u0000".length();
        }
        Location location = locationInfo.now;
        while (true) {
            long l7;
            long l8;
            if ((l8 = (l7 = \u13e8 - (0x6177L ^ 0x27452DD8DE0CAADFL)) == 0L ? 0 : (l7 < 0L ? -1 : 1)) == false) continue;
            if (l8 == (0x15FE ^ 0xFFFFEA01)) break;
            l8 = 0x26B ^ 0xF4599BCC;
        }
        Npc npc = this.closestNpc(location);
        while (true) {
            long l9;
            long l10;
            if ((l10 = (l9 = \u13e8 - (0x5927L ^ 0xD1A1B0E393A48DADL)) == 0L ? 0 : (l9 < 0L ? -1 : 1)) == false) continue;
            if (l10 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                this.attack.target = npc;
                if (npc != null) break;
                bl = 0xE31 ^ 0xE31;
                return bl;
            }
            l10 = 0x6A9C ^ 0x2D936443;
        }
        bl = 0x7E7A ^ 0x7E7B;
        return bl;
    }

    /*
     * Unable to fully structure code
     */
    protected void ignoreInvalidTarget() {
        block287: {
            block291: {
                block289: {
                    block290: {
                        block288: {
                            block286: {
                                while (true) {
                                    if ((v0 = (cfr_temp_0 = TwLootModule.\u13e8 - (19113L ^ -1807471700158913527L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                                    if (v0 == (14952 ^ -14953)) break;
                                    v0 = 15513 ^ -1755733022;
                                }
                                v1 = TwLootModule.\u13e8;
                                if (true) ** GOTO lbl10
                                block202: while (true) {
                                    v1 = v2 / (32344L ^ -6339225008588151910L);
lbl10:
                                    // 2 sources

                                    switch ((int)v1) {
                                        case -1335009722: {
                                            break block202;
                                        }
                                        case -5682426: {
                                            v2 = 32444L ^ 6382920641845346056L;
                                            continue block202;
                                        }
                                        case 191100811: {
                                            v2 = 6665L ^ -2811811337442457459L;
                                            continue block202;
                                        }
                                        case 674570747: {
                                            v2 = 12621L ^ -9150941972669653140L;
                                            continue block202;
                                        }
                                    }
                                    break;
                                }
                                while (true) {
                                    if ((v3 = (cfr_temp_1 = TwLootModule.\u13e8 - (31785L ^ -2498103010695462806L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                                    if (v3 == (14583 ^ -14584)) break;
                                    v3 = 3577 ^ -1147931594;
                                }
                                v4 = this.attack.target;
                                v5 = TwLootModule.\u13e8;
                                if (true) ** GOTO lbl32
                                block204: while (true) {
                                    v5 = v6 / (22513L ^ -670379687726299365L);
lbl32:
                                    // 2 sources

                                    switch ((int)v5) {
                                        case -1335009722: {
                                            break block204;
                                        }
                                        case -1082488497: {
                                            v6 = 10213L ^ 5543462687307361955L;
                                            continue block204;
                                        }
                                        case 672304862: {
                                            v6 = 32143L ^ -5507434761565246161L;
                                            continue block204;
                                        }
                                    }
                                    break;
                                }
                                v7 = v4.locationInfo;
                                v8 = TwLootModule.\u13e8;
                                if (true) ** GOTO lbl46
                                block205: while (true) {
                                    v8 = v9 / (30125L ^ -1508533612777396038L);
lbl46:
                                    // 2 sources

                                    switch ((int)v8) {
                                        case -1335009722: {
                                            break block205;
                                        }
                                        case 1340144045: {
                                            v9 = 4906L ^ -3070645689127547877L;
                                            continue block205;
                                        }
                                        case 1497765008: {
                                            v9 = 23554L ^ -2473229553664143194L;
                                            continue block205;
                                        }
                                    }
                                    break;
                                }
                                v10 = v7.now;
                                v11 = TwLootModule.\u13e8;
                                if (true) ** GOTO lbl60
                                block206: while (true) {
                                    v11 = (15029L ^ 520922168559475510L) / (4852L ^ -7761710529049124114L);
lbl60:
                                    // 2 sources

                                    switch ((int)v11) {
                                        case -1335009722: {
                                            break block206;
                                        }
                                        case 548713140: {
                                            continue block206;
                                        }
                                    }
                                    break;
                                }
                                closestDist = this.drive.closestDistance(v10);
                                while (true) {
                                    if ((v12 = (cfr_temp_2 = TwLootModule.\u13e8 - (12500L ^ 5695977469579844459L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                                    if (v12 == (22728 ^ -22729)) break;
                                    v12 = 1166 ^ 1427342583;
                                }
                                v13 = TwLootModule.\u13e8;
                                if (true) ** GOTO lbl75
                                block208: while (true) {
                                    v13 = v14 / (8657L ^ -2393837005380772759L);
lbl75:
                                    // 2 sources

                                    switch ((int)v13) {
                                        case -1974347401: {
                                            v14 = -3102311355348631748L >>> "\u0000\u0000".length();
                                            continue block208;
                                        }
                                        case -1335009722: {
                                            break block208;
                                        }
                                        case -1092538394: {
                                            v14 = 25507L ^ -6694221803434405399L;
                                            continue block208;
                                        }
                                    }
                                    break;
                                }
                                v15 = this.main.mapManager;
                                while (true) {
                                    if ((v16 = (cfr_temp_3 = TwLootModule.\u13e8 - (17122L ^ -8865327710030319282L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                                    if (v16 == (25166 ^ 25167)) break;
                                    v16 = 18144 ^ -617096943;
                                }
                                v17 = TwLootModule.\u13e8;
                                if (true) ** GOTO lbl94
                                block210: while (true) {
                                    v17 = v18 / (882L ^ 8234056584897190859L);
lbl94:
                                    // 2 sources

                                    switch ((int)v17) {
                                        case -1669528884: {
                                            v18 = 29462L ^ -4318703936936536251L;
                                            continue block210;
                                        }
                                        case -1335009722: {
                                            break block210;
                                        }
                                        case -285257796: {
                                            v18 = 11165L ^ -299936747298950629L;
                                            continue block210;
                                        }
                                        case 1957789148: {
                                            v18 = -8194067768586503208L >>> "\u0000\u0000".length();
                                            continue block210;
                                        }
                                    }
                                    break;
                                }
                                v19 = this.attack.target;
                                while (true) {
                                    if ((v20 = (cfr_temp_4 = TwLootModule.\u13e8 - (32247L ^ -2399936493545571660L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                                    if (v20 == (4560 ^ -4561)) break;
                                    v20 = 13691 ^ 2130268282;
                                }
                                if (v15.isTarget((Entity)v19)) break block286;
                                if (!(closestDist > 600.0)) break block287;
                                v21 = TwLootModule.\u13e8;
                                if (true) ** GOTO lbl118
                                block212: while (true) {
                                    v21 = (-8217116685830948996L >>> "\u0000\u0000".length()) / (17821L ^ -1474198335882592545L);
lbl118:
                                    // 2 sources

                                    switch ((int)v21) {
                                        case -1335009722: {
                                            break block212;
                                        }
                                        case -921051022: {
                                            continue block212;
                                        }
                                    }
                                    break;
                                }
                                v22 = TwLootModule.\u13e8;
                                if (true) ** GOTO lbl127
                                block213: while (true) {
                                    v22 = v23 / (4840L ^ 3323047262877523229L);
lbl127:
                                    // 2 sources

                                    switch ((int)v22) {
                                        case -1335009722: {
                                            break block213;
                                        }
                                        case 801524089: {
                                            v23 = 24669L ^ -7547812156866737786L;
                                            continue block213;
                                        }
                                        case 1394542165: {
                                            v23 = 3717L ^ 9062740257951439999L;
                                            continue block213;
                                        }
                                    }
                                    break;
                                }
                                v24 = this.attack.target;
                                v25 = TwLootModule.\u13e8;
                                if (true) ** GOTO lbl141
                                block214: while (true) {
                                    v25 = (11616L ^ 1912780312242175382L) / (28389L ^ -8360012819618994269L);
lbl141:
                                    // 2 sources

                                    switch ((int)v25) {
                                        case -1335009722: {
                                            break block214;
                                        }
                                        case 508596595: {
                                            continue block214;
                                        }
                                    }
                                    break;
                                }
                                v24.setTimerTo(847L ^ 167L);
                                v26 = TwLootModule.\u13e8;
                                if (true) ** GOTO lbl151
                                block215: while (true) {
                                    v26 = (-860032016642610816L >>> "\u0000\u0000".length()) / (1125L ^ 1877076756202466873L);
lbl151:
                                    // 2 sources

                                    switch ((int)v26) {
                                        case -2041584388: {
                                            continue block215;
                                        }
                                        case -1335009722: {
                                            break block215;
                                        }
                                    }
                                    break;
                                }
                                v27 = TwLootModule.\u13e8;
                                if (true) ** GOTO lbl160
                                block216: while (true) {
                                    v27 = (-8185246447876415876L >>> "\u0000\u0000".length()) / (27524L ^ -3342897418178518639L);
lbl160:
                                    // 2 sources

                                    switch ((int)v27) {
                                        case -1335009722: {
                                            break block216;
                                        }
                                        case 2067290021: {
                                            continue block216;
                                        }
                                    }
                                    break;
                                }
                                while (true) {
                                    if ((v28 = (cfr_temp_5 = TwLootModule.\u13e8 - (32008L ^ 8746100431282208842L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                                    if (v28 == (25220 ^ -25221)) break;
                                    v28 = 28142 ^ -1068780795;
                                }
                                this.attack.target = null;
                                v29 = TwLootModule.\u13e8;
                                if (true) ** GOTO lbl175
                                block218: while (true) {
                                    v29 = v30 / (11524L ^ 5254855840712766131L);
lbl175:
                                    // 2 sources

                                    switch ((int)v29) {
                                        case -1807990149: {
                                            v30 = 12023L ^ -2244044261894234491L;
                                            continue block218;
                                        }
                                        case -1672221114: {
                                            v30 = 24399L ^ 6935393806145085185L;
                                            continue block218;
                                        }
                                        case -1335009722: {
                                            break block218;
                                        }
                                    }
                                    break;
                                }
                                this.hero.setTarget(null);
                                break block287;
                            }
                            while (true) {
                                if ((v31 = (cfr_temp_6 = TwLootModule.\u13e8 - (15356L ^ -7484300034914175175L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                                if (v31 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                                v31 = 32682 ^ -866057719;
                            }
                            v32 = TwLootModule.\u13e8;
                            if (true) ** GOTO lbl196
                            block220: while (true) {
                                v32 = v33 / (26528L ^ 7016711652734050257L);
lbl196:
                                // 2 sources

                                switch ((int)v32) {
                                    case -1335009722: {
                                        break block220;
                                    }
                                    case -743023193: {
                                        v33 = 32216L ^ 6482271929200945171L;
                                        continue block220;
                                    }
                                    case 816461186: {
                                        v33 = 23141L ^ 186777278062605578L;
                                        continue block220;
                                    }
                                }
                                break;
                            }
                            v34 = this.attack.target;
                            while (true) {
                                if ((v35 = (cfr_temp_7 = TwLootModule.\u13e8 - (13733L ^ 7691690643072871706L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                                if (v35 == (7529 ^ -7530)) break;
                                v35 = 6281 ^ 1029762529;
                            }
                            v36 = v34.npcInfo;
                            while (true) {
                                if ((v37 = (cfr_temp_8 = TwLootModule.\u13e8 - (32415L ^ -5811482691048140303L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                                if (v37 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                                v37 = 15521 ^ -828014795;
                            }
                            v38 = v36.extra;
                            v39 = TwLootModule.\u13e8;
                            if (true) ** GOTO lbl222
                            block223: while (true) {
                                v39 = (14084L ^ -7296065707435841673L) / (15544L ^ 5320844740134102376L);
lbl222:
                                // 2 sources

                                switch ((int)v39) {
                                    case -1335009722: {
                                        break block223;
                                    }
                                    case -360929980: {
                                        continue block223;
                                    }
                                }
                                break;
                            }
                            while (true) {
                                if ((v40 = (cfr_temp_9 = TwLootModule.\u13e8 - (7318L ^ -5075850618161121345L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
                                if (v40 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                                v40 = 2114322872 >>> "\u0000\u0000".length();
                            }
                            if (v38.has((NpcExtraFlag)NpcExtra.IGNORE_OWNERSHIP)) break block288;
                            v41 = TwLootModule.\u13e8;
                            if (true) ** GOTO lbl237
                            block225: while (true) {
                                v41 = v42 / (24095L ^ 5009687275977348586L);
lbl237:
                                // 2 sources

                                switch ((int)v41) {
                                    case -1335009722: {
                                        break block225;
                                    }
                                    case 307584280: {
                                        v42 = 20046L ^ -2787035062191629812L;
                                        continue block225;
                                    }
                                    case 2114018109: {
                                        v42 = 14051L ^ -7054079464709196125L;
                                        continue block225;
                                    }
                                }
                                break;
                            }
                            v43 = TwLootModule.\u13e8;
                            if (true) ** GOTO lbl250
                            block226: while (true) {
                                v43 = (-4152318599051457344L >>> "\u0000\u0000".length()) / (3124L ^ -6423124701922210697L);
lbl250:
                                // 2 sources

                                switch ((int)v43) {
                                    case -1335009722: {
                                        break block226;
                                    }
                                    case 759693508: {
                                        continue block226;
                                    }
                                }
                                break;
                            }
                            v44 = this.main.mapManager;
                            while (true) {
                                if ((v45 = (cfr_temp_10 = TwLootModule.\u13e8 - (13428L ^ -1033417031689594437L)) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
                                if (v45 == (16317 ^ -16318)) break;
                                v45 = 1306500348 >>> "\u0000\u0000".length();
                            }
                            if (!v44.isCurrentTargetOwned()) break block289;
                        }
                        while (true) {
                            if ((v46 = (cfr_temp_11 = TwLootModule.\u13e8 - (2066L ^ -3373931094941464248L)) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
                            if (v46 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                            v46 = 4046 ^ 1960407148;
                        }
                        v47 = TwLootModule.\u13e8;
                        if (true) ** GOTO lbl272
                        block229: while (true) {
                            v47 = v48 / (22587L ^ -4440451218106622139L);
lbl272:
                            // 2 sources

                            switch ((int)v47) {
                                case -1335009722: {
                                    break block229;
                                }
                                case -46307484: {
                                    v48 = 30977L ^ -1676954970826221391L;
                                    continue block229;
                                }
                                case 1167324153: {
                                    v48 = -7933301050156584776L >>> "\u0000\u0000".length();
                                    continue block229;
                                }
                            }
                            break;
                        }
                        if (this.attack.isBugged()) break block289;
                        v49 = TwLootModule.\u13e8;
                        if (true) ** GOTO lbl286
                        block230: while (true) {
                            v49 = v50 / (24028L ^ 5150570486646552939L);
lbl286:
                            // 2 sources

                            switch ((int)v49) {
                                case -1989209900: {
                                    v50 = 3757L ^ -3731062312130322246L;
                                    continue block230;
                                }
                                case -1335009722: {
                                    break block230;
                                }
                                case -698423712: {
                                    v50 = 22203L ^ -5438159021805240354L;
                                    continue block230;
                                }
                                case 686780945: {
                                    v50 = 4733481480253732256L >>> "\u0000\u0000".length();
                                    continue block230;
                                }
                            }
                            break;
                        }
                        while (true) {
                            if ((v51 = (cfr_temp_12 = TwLootModule.\u13e8 - (17353L ^ 5986578227116404886L)) == 0L ? 0 : (cfr_temp_12 < 0L ? -1 : 1)) == false) continue;
                            if (v51 == (27668 ^ -27669)) break;
                            v51 = 13558 ^ 384550314;
                        }
                        v52 = this.hero.locationInfo;
                        while (true) {
                            if ((v53 = (cfr_temp_13 = TwLootModule.\u13e8 - (23032L ^ 4159703914800429480L)) == 0L ? 0 : (cfr_temp_13 < 0L ? -1 : 1)) == false) continue;
                            if (v53 == (1323 ^ -1324)) break;
                            v53 = 4180 ^ -46517434;
                        }
                        while (true) {
                            if ((v54 = (cfr_temp_14 = TwLootModule.\u13e8 - (14880L ^ -991574858374588607L)) == 0L ? 0 : (cfr_temp_14 < 0L ? -1 : 1)) == false) continue;
                            if (v54 == (17200 ^ -17201)) break;
                            v54 = 20847 ^ -99693464;
                        }
                        v55 = this.attack.target;
                        v56 = TwLootModule.\u13e8;
                        if (true) ** GOTO lbl319
                        block234: while (true) {
                            v56 = v57 / (29916L ^ -1142815061409166835L);
lbl319:
                            // 2 sources

                            switch ((int)v56) {
                                case -1335009722: {
                                    break block234;
                                }
                                case -223114096: {
                                    v57 = 9516L ^ -8520957618247415931L;
                                    continue block234;
                                }
                                case 193723623: {
                                    v57 = 16599L ^ -5224040464816478349L;
                                    continue block234;
                                }
                            }
                            break;
                        }
                        v58 = v52.distance((Entity)v55);
                        while (true) {
                            if ((v59 = (cfr_temp_15 = TwLootModule.\u13e8 - (32612L ^ -6603299909284400268L)) == 0L ? 0 : (cfr_temp_15 < 0L ? -1 : 1)) == false) continue;
                            if (v59 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                            v59 = 789765708 >>> "\u0000\u0000".length();
                        }
                        v60 = TwLootModule.\u13e8;
                        if (true) ** GOTO lbl338
                        block236: while (true) {
                            v60 = (22331L ^ 7632387983392620765L) / (3655453301261155860L >>> "\u0000\u0000".length());
lbl338:
                            // 2 sources

                            switch ((int)v60) {
                                case -1599645078: {
                                    continue block236;
                                }
                                case -1335009722: {
                                    break block236;
                                }
                            }
                            break;
                        }
                        v61 = this.config.LOOT;
                        while (true) {
                            if ((v62 = (cfr_temp_16 = TwLootModule.\u13e8 - (14383L ^ 6907665283601078091L)) == 0L ? 0 : (cfr_temp_16 < 0L ? -1 : 1)) == false) continue;
                            if (v62 == (13082 ^ -13083)) break;
                            v62 = 2044 ^ -1848805549;
                        }
                        if (v58 > (double)v61.NPC_DISTANCE_IGNORE) break block289;
                        if (!(closestDist > 650.0)) break block290;
                        while (true) {
                            if ((v63 = (cfr_temp_17 = TwLootModule.\u13e8 - (4675378204278998344L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_17 < 0L ? -1 : 1)) == false) continue;
                            if (v63 == (6090 ^ -6091)) break;
                            v63 = 4270 ^ 1689592046;
                        }
                        while (true) {
                            if ((v64 = (cfr_temp_18 = TwLootModule.\u13e8 - (21425L ^ -1129150900442540088L)) == 0L ? 0 : (cfr_temp_18 < 0L ? -1 : 1)) == false) continue;
                            if (v64 == (18022 ^ -18023)) break;
                            v64 = 17298 ^ -986713122;
                        }
                        v65 = this.attack.target;
                        v66 = TwLootModule.\u13e8;
                        if (true) ** GOTO lbl366
                        block240: while (true) {
                            v66 = v67 / (11228L ^ -6631457882630229206L);
lbl366:
                            // 2 sources

                            switch ((int)v66) {
                                case -1335009722: {
                                    break block240;
                                }
                                case -157992988: {
                                    v67 = 14622L ^ -4134725648420367542L;
                                    continue block240;
                                }
                                case 2106273971: {
                                    v67 = 25842L ^ 7308571858136651250L;
                                    continue block240;
                                }
                            }
                            break;
                        }
                        v68 = v65.health;
                        v69 = TwLootModule.\u13e8;
                        if (true) ** GOTO lbl380
                        block241: while (true) {
                            v69 = v70 / (689L ^ -4514894421430554992L);
lbl380:
                            // 2 sources

                            switch ((int)v69) {
                                case -1535560026: {
                                    v70 = 10260L ^ -5951738717386007301L;
                                    continue block241;
                                }
                                case -1335009722: {
                                    break block241;
                                }
                                case -1143075301: {
                                    v70 = 19836L ^ 6022042841988924777L;
                                    continue block241;
                                }
                                case 1018611950: {
                                    v70 = 18381L ^ 4415221901249860607L;
                                    continue block241;
                                }
                            }
                            break;
                        }
                        if (v68.hpPercent() > 0.9) break block289;
                    }
                    if (!(closestDist > 500.0)) break block291;
                    v71 = TwLootModule.\u13e8;
                    if (true) ** GOTO lbl399
                    block242: while (true) {
                        v71 = v72 / (7848647525989882596L >>> "\u0000\u0000".length());
lbl399:
                        // 2 sources

                        switch ((int)v71) {
                            case -1877680263: {
                                v72 = 8413L ^ -2583741252635391282L;
                                continue block242;
                            }
                            case -1335009722: {
                                break block242;
                            }
                            case 928530554: {
                                v72 = 16957L ^ 2549726148364568316L;
                                continue block242;
                            }
                            case 1239853990: {
                                v72 = 23238L ^ -7620472105281851592L;
                                continue block242;
                            }
                        }
                        break;
                    }
                    v73 = TwLootModule.\u13e8;
                    if (true) ** GOTO lbl415
                    block243: while (true) {
                        v73 = v74 / (10258L ^ -6707298400841610765L);
lbl415:
                        // 2 sources

                        switch ((int)v73) {
                            case -1601075657: {
                                v74 = 1050L ^ -4794309577637924017L;
                                continue block243;
                            }
                            case -1335009722: {
                                break block243;
                            }
                            case 932585822: {
                                v74 = 22018L ^ -8097070088605883382L;
                                continue block243;
                            }
                        }
                        break;
                    }
                    v75 = this.attack.target;
                    v76 = TwLootModule.\u13e8;
                    if (true) ** GOTO lbl429
                    block244: while (true) {
                        v76 = v77 / (10741L ^ -2567182775792571053L);
lbl429:
                        // 2 sources

                        switch ((int)v76) {
                            case -1587376280: {
                                v77 = 13631L ^ -2182304990828671066L;
                                continue block244;
                            }
                            case -1335009722: {
                                break block244;
                            }
                            case -577148538: {
                                v77 = 2446L ^ -2543443712821729319L;
                                continue block244;
                            }
                        }
                        break;
                    }
                    v78 = v75.locationInfo;
                    v79 = TwLootModule.\u13e8;
                    if (true) ** GOTO lbl443
                    block245: while (true) {
                        v79 = v80 / (3701L ^ 3840765414718089154L);
lbl443:
                        // 2 sources

                        switch ((int)v79) {
                            case -2029378090: {
                                v80 = 23495L ^ 7155880400101773933L;
                                continue block245;
                            }
                            case -1335009722: {
                                break block245;
                            }
                            case -1262346473: {
                                v80 = 1416L ^ -6911005892957691661L;
                                continue block245;
                            }
                            case 897740956: {
                                v80 = 21297L ^ 1098866827793825232L;
                                continue block245;
                            }
                        }
                        break;
                    }
                    if (v78.isMoving()) break block291;
                    v81 = TwLootModule.\u13e8;
                    if (true) ** GOTO lbl460
                    block246: while (true) {
                        v81 = (-2468900459886277440L >>> "\u0000\u0000".length()) / (15930L ^ 3465583743780819039L);
lbl460:
                        // 2 sources

                        switch ((int)v81) {
                            case -1335009722: {
                                break block246;
                            }
                            case 1697863149: {
                                continue block246;
                            }
                        }
                        break;
                    }
                    while (true) {
                        if ((v82 = (cfr_temp_19 = TwLootModule.\u13e8 - (27676L ^ -2778949942958562120L)) == 0L ? 0 : (cfr_temp_19 < 0L ? -1 : 1)) == false) continue;
                        if (v82 == (8895 ^ -8896)) break;
                        v82 = 21547 ^ 937784812;
                    }
                    v83 = this.attack.target;
                    v84 = TwLootModule.\u13e8;
                    if (true) ** GOTO lbl475
                    block248: while (true) {
                        v84 = v85 / (10375L ^ -6017785050863084908L);
lbl475:
                        // 2 sources

                        switch ((int)v84) {
                            case -1375871435: {
                                v85 = 24115L ^ 8788150724292795308L;
                                continue block248;
                            }
                            case -1335009722: {
                                break block248;
                            }
                            case 192163832: {
                                v85 = 22858L ^ 9183253491867665149L;
                                continue block248;
                            }
                        }
                        break;
                    }
                    v86 = v83.health;
                    v87 = 4000 >>> "\u0000\u0000".length();
                    v88 = TwLootModule.\u13e8;
                    if (true) ** GOTO lbl490
                    block249: while (true) {
                        v88 = v89 / (15679L ^ 6372368103927437488L);
lbl490:
                        // 2 sources

                        switch ((int)v88) {
                            case -1702108176: {
                                v89 = 20220L ^ 5888353887483740835L;
                                continue block249;
                            }
                            case -1335009722: {
                                break block249;
                            }
                            case -1227167892: {
                                v89 = 3437L ^ 6428130546695555645L;
                                continue block249;
                            }
                        }
                        break;
                    }
                    if (v86.shIncreasedIn(v87)) break block289;
                    while (true) {
                        if ((v90 = (cfr_temp_20 = TwLootModule.\u13e8 - (-2965321061393787236L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_20 < 0L ? -1 : 1)) == false) continue;
                        if (v90 == (29845 ^ -29846)) break;
                        v90 = 6209 ^ 1226044426;
                    }
                    while (true) {
                        if ((v91 = (cfr_temp_21 = TwLootModule.\u13e8 - (19231L ^ -3301978053570401963L)) == 0L ? 0 : (cfr_temp_21 < 0L ? -1 : 1)) == false) continue;
                        if (v91 == (29185 ^ 29184)) break;
                        v91 = 26325 ^ -11379260;
                    }
                    v92 = this.attack.target;
                    v93 = TwLootModule.\u13e8;
                    if (true) ** GOTO lbl515
                    block252: while (true) {
                        v93 = (7709L ^ -7245409478822730707L) / (20279L ^ 8764449623586893313L);
lbl515:
                        // 2 sources

                        switch ((int)v93) {
                            case -1923246884: {
                                continue block252;
                            }
                            case -1335009722: {
                                break block252;
                            }
                        }
                        break;
                    }
                    v94 = v92.health;
                    while (true) {
                        if ((v95 = (cfr_temp_22 = TwLootModule.\u13e8 - (23577L ^ -8056225642901998055L)) == 0L ? 0 : (cfr_temp_22 < 0L ? -1 : 1)) == false) continue;
                        if (v95 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                        v95 = 5014 ^ -2082440003;
                    }
                    if (!(v94.shieldPercent() > 0.99)) break block291;
                }
                while (true) {
                    if ((v96 = (cfr_temp_23 = TwLootModule.\u13e8 - (26854L ^ 349097093276468969L)) == 0L ? 0 : (cfr_temp_23 < 0L ? -1 : 1)) == false) continue;
                    if (v96 == (13224 ^ -13225)) break;
                    v96 = -149865364 >>> "\u0000\u0000".length();
                }
                v97 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl537
                block255: while (true) {
                    v97 = (8159591100629645920L >>> "\u0000\u0000".length()) / (17700L ^ -4109910430345344839L);
lbl537:
                    // 2 sources

                    switch ((int)v97) {
                        case -1335009722: {
                            break block255;
                        }
                        case -1329501079: {
                            continue block255;
                        }
                    }
                    break;
                }
                v98 = this.attack.target;
                v99 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl547
                block256: while (true) {
                    v99 = (20843L ^ -1491085877927251109L) / (28102L ^ -5335685189758561591L);
lbl547:
                    // 2 sources

                    switch ((int)v99) {
                        case -1335009722: {
                            break block256;
                        }
                        case -333158351: {
                            continue block256;
                        }
                    }
                    break;
                }
                v98.setTimerTo(24205L ^ 19717L);
                while (true) {
                    if ((v100 = (cfr_temp_24 = TwLootModule.\u13e8 - (2420L ^ -7719278221298184720L)) == 0L ? 0 : (cfr_temp_24 < 0L ? -1 : 1)) == false) continue;
                    if (v100 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                    v100 = 8585 ^ -61180174;
                }
                while (true) {
                    if ((v101 = (cfr_temp_25 = TwLootModule.\u13e8 - (13160L ^ 3496943611146170677L)) == 0L ? 0 : (cfr_temp_25 < 0L ? -1 : 1)) == false) continue;
                    if (v101 == (12544 ^ -12545)) break;
                    v101 = -1401263768 >>> "\u0000\u0000".length();
                }
                while (true) {
                    if ((v102 = (cfr_temp_26 = TwLootModule.\u13e8 - (-8105415182823721848L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_26 < 0L ? -1 : 1)) == false) continue;
                    if (v102 == (24423 ^ -24424)) break;
                    v102 = -1187371472 >>> "\u0000\u0000".length();
                }
                this.attack.target = null;
                v103 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl573
                block260: while (true) {
                    v103 = v104 / (1093L ^ -9029811320079409508L);
lbl573:
                    // 2 sources

                    switch ((int)v103) {
                        case -1335009722: {
                            break block260;
                        }
                        case 31917925: {
                            v104 = 6027L ^ -5855444379252216490L;
                            continue block260;
                        }
                        case 1970520024: {
                            v104 = 18687L ^ -3556961539662906626L;
                            continue block260;
                        }
                    }
                    break;
                }
                this.hero.setTarget(null);
                break block287;
            }
            while (true) {
                if ((v105 = (cfr_temp_27 = TwLootModule.\u13e8 - (14299L ^ -4492936634047835196L)) == 0L ? 0 : (cfr_temp_27 < 0L ? -1 : 1)) == false) continue;
                if (v105 == (13869 ^ 13868)) break;
                v105 = 26075 ^ 2098060046;
            }
            while (true) {
                if ((v106 = (cfr_temp_28 = TwLootModule.\u13e8 - (13265L ^ -6083989060628808745L)) == 0L ? 0 : (cfr_temp_28 < 0L ? -1 : 1)) == false) continue;
                if (v106 == (17535 ^ 17534)) break;
                v106 = 16145 ^ 1602548685;
            }
            v107 = this.attack.target;
            v108 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl600
            block263: while (true) {
                v108 = v109 / (16299L ^ -8713550299105026405L);
lbl600:
                // 2 sources

                switch ((int)v108) {
                    case -1847257661: {
                        v109 = 7943L ^ 3239909207070762278L;
                        continue block263;
                    }
                    case -1335009722: {
                        break block263;
                    }
                    case -1176173719: {
                        v109 = 2933832554742026092L >>> "\u0000\u0000".length();
                        continue block263;
                    }
                }
                break;
            }
            v110 = v107.playerInfo;
            while (true) {
                if ((v111 = (cfr_temp_29 = TwLootModule.\u13e8 - (2708L ^ -8915680872291117833L)) == 0L ? 0 : (cfr_temp_29 < 0L ? -1 : 1)) == false) continue;
                if (v111 == (1069 ^ 1068)) break;
                v111 = 134959172 >>> "\u0000\u0000".length();
            }
            v112 = v110.username;
            var4_2 = new byte[5031 ^ 5025];
            var4_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 21977 ^ -21911;
            var4_2[17739 ^ 17736] = 6781 ^ 6674;
            var4_2[9343 ^ 9342] = 1213 ^ 1235;
            var4_2[438 ^ 435] = 13071 ^ 13162;
            var4_2[6985 ^ 6987] = 472 >>> "\u0000\u0000".length();
            var4_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 18182 ^ 18285;
            var4_2["".length() >>> "\u0000\u0000".length()] = 292 >>> "\u0000\u0000".length();
            v113 = new String(var4_2);
            v114 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl629
            block265: while (true) {
                v114 = (13595L ^ -2848940768549836630L) / (6408L ^ 8092186920805870275L);
lbl629:
                // 2 sources

                switch ((int)v114) {
                    case -1335009722: {
                        break block265;
                    }
                    case -685105243: {
                        continue block265;
                    }
                }
                break;
            }
            if (!v112.contains(v113)) break block287;
            v115 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl639
            block266: while (true) {
                v115 = v116 / (19755L ^ -6362831863969096560L);
lbl639:
                // 2 sources

                switch ((int)v115) {
                    case -1335009722: {
                        break block266;
                    }
                    case 623512558: {
                        v116 = 3800L ^ -6462705111401796301L;
                        continue block266;
                    }
                    case 2060142097: {
                        v116 = 28032L ^ -3758509234686387138L;
                        continue block266;
                    }
                }
                break;
            }
            v117 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl652
            block267: while (true) {
                v117 = v118 / (27525L ^ -516336806821624645L);
lbl652:
                // 2 sources

                switch ((int)v117) {
                    case -1335009722: {
                        break block267;
                    }
                    case 182105200: {
                        v118 = 31661L ^ -5423334538147400845L;
                        continue block267;
                    }
                    case 243547944: {
                        v118 = 8470L ^ 836385330087202503L;
                        continue block267;
                    }
                    case 544811612: {
                        v118 = 6541L ^ 1878144170565075219L;
                        continue block267;
                    }
                }
                break;
            }
            v119 = this.attack.target;
            while (true) {
                if ((v120 = (cfr_temp_30 = TwLootModule.\u13e8 - (20272L ^ -1979534875762353374L)) == 0L ? 0 : (cfr_temp_30 < 0L ? -1 : 1)) == false) continue;
                if (v120 == (26189 ^ -26190)) break;
                v120 = 27978 ^ 470772732;
            }
            v121 = v119.npcInfo;
            while (true) {
                if ((v122 = (cfr_temp_31 = TwLootModule.\u13e8 - (14831L ^ 4711542531132949016L)) == 0L ? 0 : (cfr_temp_31 < 0L ? -1 : 1)) == false) continue;
                if (v122 == (14726 ^ -14727)) break;
                v122 = 14395 ^ 584062514;
            }
            v123 = v121.extra;
            while (true) {
                if ((v124 = (cfr_temp_32 = TwLootModule.\u13e8 - (17977L ^ 7408886525441911206L)) == 0L ? 0 : (cfr_temp_32 < 0L ? -1 : 1)) == false) continue;
                if (v124 == (8242 ^ -8243)) break;
                v124 = 21575 ^ 1797817287;
            }
            while (true) {
                if ((v125 = (cfr_temp_33 = TwLootModule.\u13e8 - (27510L ^ -6030452619392275888L)) == 0L ? 0 : (cfr_temp_33 < 0L ? -1 : 1)) == false) continue;
                if (v125 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v125 = 23941 ^ 1008075269;
            }
            if (!v123.has((NpcExtraFlag)NpcExtra.PASSIVE)) break block287;
            v126 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl692
            block272: while (true) {
                v126 = v127 / (9590L ^ -4579469166993359467L);
lbl692:
                // 2 sources

                switch ((int)v126) {
                    case -1770574135: {
                        v127 = 17406L ^ 853209207991163385L;
                        continue block272;
                    }
                    case -1335009722: {
                        break block272;
                    }
                    case -513032686: {
                        v127 = -2425743866337742056L >>> "\u0000\u0000".length();
                        continue block272;
                    }
                }
                break;
            }
            while (true) {
                if ((v128 = (cfr_temp_34 = TwLootModule.\u13e8 - (2567364193710666544L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_34 < 0L ? -1 : 1)) == false) continue;
                if (v128 == (25200 ^ -25201)) break;
                v128 = 2540 ^ 876472962;
            }
            v129 = this.attack.target;
            while (true) {
                if ((v130 = (cfr_temp_35 = TwLootModule.\u13e8 - (2252L ^ 2708471033942945870L)) == 0L ? 0 : (cfr_temp_35 < 0L ? -1 : 1)) == false) continue;
                if (v130 == (12889 ^ -12890)) break;
                v130 = -1316406632 >>> "\u0000\u0000".length();
            }
            while (true) {
                if ((v131 = (cfr_temp_36 = TwLootModule.\u13e8 - (17165L ^ 5802498121449756517L)) == 0L ? 0 : (cfr_temp_36 < 0L ? -1 : 1)) == false) continue;
                if (v131 == (10444 ^ -10445)) break;
                v131 = 26020 ^ -97827722;
            }
            if (v129 != this.hero.target) break block287;
            v132 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl722
            block276: while (true) {
                v132 = (22631L ^ 1824630358672067158L) / (30079L ^ 1616606172805637643L);
lbl722:
                // 2 sources

                switch ((int)v132) {
                    case -1335009722: {
                        break block276;
                    }
                    case 896891397: {
                        continue block276;
                    }
                }
                break;
            }
            while (true) {
                if ((v133 = (cfr_temp_37 = TwLootModule.\u13e8 - (23152L ^ 7897047908784208750L)) == 0L ? 0 : (cfr_temp_37 < 0L ? -1 : 1)) == false) continue;
                if (v133 == (2299 ^ -2300)) break;
                v133 = 29943 ^ -258815577;
            }
            if (this.attack.castingAbility()) break block287;
            while (true) {
                if ((v134 = (cfr_temp_38 = TwLootModule.\u13e8 - (27995L ^ 8848738476319150422L)) == 0L ? 0 : (cfr_temp_38 < 0L ? -1 : 1)) == false) continue;
                if (v134 == (393 ^ -394)) break;
                v134 = 10253 ^ -1865215835;
            }
            v135 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl742
            block279: while (true) {
                v135 = (-1233106208523210612L >>> "\u0000\u0000".length()) / (25900L ^ 1146557711280965237L);
lbl742:
                // 2 sources

                switch ((int)v135) {
                    case -1335009722: {
                        break block279;
                    }
                    case 67182536: {
                        continue block279;
                    }
                }
                break;
            }
            v136 = this.attack.target;
            while (true) {
                if ((v137 = (cfr_temp_39 = TwLootModule.\u13e8 - (4123L ^ -3946847936646710389L)) == 0L ? 0 : (cfr_temp_39 < 0L ? -1 : 1)) == false) continue;
                if (v137 == (21746 ^ 21747)) break;
                v137 = 825 ^ -1577234653;
            }
            v136.setTimerTo(28100L ^ 608772L);
            v138 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl758
            block281: while (true) {
                v138 = v139 / (18065L ^ -152934724893552208L);
lbl758:
                // 2 sources

                switch ((int)v138) {
                    case -1335009722: {
                        break block281;
                    }
                    case 883131297: {
                        v139 = 23495L ^ -9148823039290890123L;
                        continue block281;
                    }
                    case 1241413558: {
                        v139 = -638865155264231816L >>> "\u0000\u0000".length();
                        continue block281;
                    }
                }
                break;
            }
            v140 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl771
            block282: while (true) {
                v140 = (25924L ^ -5273537764625498797L) / (4520L ^ 2615321047520012089L);
lbl771:
                // 2 sources

                switch ((int)v140) {
                    case -1533603011: {
                        continue block282;
                    }
                    case -1335009722: {
                        break block282;
                    }
                }
                break;
            }
            while (true) {
                if ((v141 = (cfr_temp_40 = TwLootModule.\u13e8 - (6530L ^ -4817168036585637515L)) == 0L ? 0 : (cfr_temp_40 < 0L ? -1 : 1)) == false) continue;
                if (v141 == (31440 ^ 31441)) break;
                v141 = 7408 ^ -1884344454;
            }
            this.attack.target = null;
            while (true) {
                if ((v142 = (cfr_temp_41 = TwLootModule.\u13e8 - (2495179428694319852L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_41 < 0L ? -1 : 1)) == false) continue;
                if (v142 == (12035 ^ -12036)) {
                    this.hero.setTarget(null);
                    break;
                }
                v142 = 7391 ^ 1875921749;
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    protected void moveToAnSafePosition() {
        block161: {
            block160: {
                block158: {
                    block159: {
                        while (true) {
                            if ((v0 = (cfr_temp_0 = TwLootModule.\u13e8 - (23263L ^ 1506156296536917245L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                            if (v0 == (7476 ^ -7477)) break;
                            v0 = -1572889320 >>> "\u0000\u0000".length();
                        }
                        while (true) {
                            if ((v1 = (cfr_temp_1 = TwLootModule.\u13e8 - (23307L ^ -615283161402870207L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                            if (v1 == (8745 ^ -8746)) break;
                            v1 = 14835 ^ -135703790;
                        }
                        target = this.attack.target;
                        v2 = TwLootModule.\u13e8;
                        if (true) ** GOTO lbl16
                        block108: while (true) {
                            v2 = v3 / (12024L ^ 6878435147651672955L);
lbl16:
                            // 2 sources

                            switch ((int)v2) {
                                case -1335009722: {
                                    break block108;
                                }
                                case -1172850655: {
                                    v3 = -6419163399502785124L >>> "\u0000\u0000".length();
                                    continue block108;
                                }
                                case -417559519: {
                                    v3 = 7708L ^ -8712839030880864097L;
                                    continue block108;
                                }
                                case -186255410: {
                                    v3 = 9731L ^ -7108125626227835158L;
                                    continue block108;
                                }
                            }
                            break;
                        }
                        while (true) {
                            if ((v4 = (cfr_temp_2 = TwLootModule.\u13e8 - (5077L ^ -1034862493444838112L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                            if (v4 == (29076 ^ -29077)) break;
                            v4 = 18401 ^ -1172074647;
                        }
                        direction = this.drive.movingTo();
                        while (true) {
                            if ((v5 = (cfr_temp_3 = TwLootModule.\u13e8 - (7317L ^ 6702445193267339290L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                            if (v5 == (26046 ^ -26047)) break;
                            v5 = -1688805900 >>> "\u0000\u0000".length();
                        }
                        v6 = TwLootModule.\u13e8;
                        if (true) ** GOTO lbl43
                        block111: while (true) {
                            v6 = v7 / (17756L ^ -7247984090294964653L);
lbl43:
                            // 2 sources

                            switch ((int)v6) {
                                case -1335009722: {
                                    break block111;
                                }
                                case -945902711: {
                                    v7 = 19279L ^ 2757523845460212924L;
                                    continue block111;
                                }
                                case -195311817: {
                                    v7 = 10994L ^ -2772633961160846494L;
                                    continue block111;
                                }
                            }
                            break;
                        }
                        v8 = this.hero.locationInfo;
                        while (true) {
                            if ((v9 = (cfr_temp_4 = TwLootModule.\u13e8 - (6952L ^ -8468967318742004621L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                            if (v9 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                            v9 = 18341 ^ 1960251485;
                        }
                        heroLoc = v8.now;
                        while (true) {
                            if ((v10 = (cfr_temp_5 = TwLootModule.\u13e8 - (25289L ^ -5946169354207693715L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                            if (v10 == (16968 ^ 16969)) break;
                            v10 = 30572 ^ -2030180942;
                        }
                        v11 = target.locationInfo;
                        while (true) {
                            if ((v12 = (cfr_temp_6 = TwLootModule.\u13e8 - (16502L ^ -2849789999849986556L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                            if (v12 == (23458 ^ -23459)) break;
                            v12 = -505287556 >>> "\u0000\u0000".length();
                        }
                        targetLoc = v11.destinationInTime(23786L ^ 23930L);
                        while (true) {
                            if ((v13 = (cfr_temp_7 = TwLootModule.\u13e8 - (9587L ^ -8972528815732856672L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                            if (v13 == (2900 ^ 2901)) break;
                            v13 = 7709 ^ 1105051049;
                        }
                        v14 = target.locationInfo;
                        while (true) {
                            if ((v15 = (cfr_temp_8 = TwLootModule.\u13e8 - (21205L ^ 5829768546736362117L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                            if (v15 == (1428 ^ -1429)) break;
                            v15 = 30083 ^ -516904134;
                        }
                        v16 = v14.now;
                        while (true) {
                            if ((v17 = (cfr_temp_9 = TwLootModule.\u13e8 - (18136L ^ 5687881580401814081L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
                            if (v17 == (5765 ^ -5766)) break;
                            v17 = 11114 ^ 1633942317;
                        }
                        distance = heroLoc.distance(v16);
                        while (true) {
                            if ((v18 = (cfr_temp_10 = TwLootModule.\u13e8 - (20548L ^ 3322967400673689730L)) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
                            if (v18 == (11730 ^ -11731)) break;
                            v18 = 6382 ^ -1711660558;
                        }
                        angle = targetLoc.angle(heroLoc);
                        v19 = TwLootModule.\u13e8;
                        if (true) ** GOTO lbl99
                        block119: while (true) {
                            v19 = (32727L ^ -1352800740561107438L) / (6631L ^ 4458293623768602992L);
lbl99:
                            // 2 sources

                            switch ((int)v19) {
                                case -1335009722: {
                                    break block119;
                                }
                                case 718014202: {
                                    continue block119;
                                }
                            }
                            break;
                        }
                        v20 = target.npcInfo;
                        while (true) {
                            if ((v21 = (cfr_temp_11 = TwLootModule.\u13e8 - (21122L ^ 7854908898291359544L)) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
                            if (v21 == (11436 ^ -11437)) break;
                            v21 = 17378 ^ 543566876;
                        }
                        radius = v20.radius;
                        while (true) {
                            if ((v22 = (cfr_temp_12 = TwLootModule.\u13e8 - (4343L ^ 8839055209764450624L)) == 0L ? 0 : (cfr_temp_12 < 0L ? -1 : 1)) == false) continue;
                            if (v22 == (27265 ^ -27266)) break;
                            v22 = 15078 ^ -439877223;
                        }
                        v23 = target.npcInfo;
                        v24 = TwLootModule.\u13e8;
                        if (true) ** GOTO lbl121
                        block122: while (true) {
                            v24 = v25 / (-7171721330156408780L >>> "\u0000\u0000".length());
lbl121:
                            // 2 sources

                            switch ((int)v24) {
                                case -2113665791: {
                                    v25 = -1360274362027099892L >>> "\u0000\u0000".length();
                                    continue block122;
                                }
                                case -1335009722: {
                                    break block122;
                                }
                                case 1599234937: {
                                    v25 = 31752L ^ 1907569552529702373L;
                                    continue block122;
                                }
                                case 1724846999: {
                                    v25 = 19853L ^ 9004218539052171054L;
                                    continue block122;
                                }
                            }
                            break;
                        }
                        v26 = v23.extra;
                        while (true) {
                            if ((v27 = (cfr_temp_13 = TwLootModule.\u13e8 - (4688L ^ -4146512692826573923L)) == 0L ? 0 : (cfr_temp_13 < 0L ? -1 : 1)) == false) continue;
                            if (v27 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                            v27 = 23257 ^ 1796095227;
                        }
                        while (true) {
                            if ((v28 = (cfr_temp_14 = TwLootModule.\u13e8 - (6118L ^ -4942219321459457882L)) == 0L ? 0 : (cfr_temp_14 < 0L ? -1 : 1)) == false) continue;
                            if (v28 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                            v28 = 10493 ^ -1975268202;
                        }
                        noCircle = v26.has((NpcExtraFlag)NpcExtra.NO_CIRCLE);
                        while (true) {
                            if ((v29 = (cfr_temp_15 = TwLootModule.\u13e8 - (1565008989679620988L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_15 < 0L ? -1 : 1)) == false) continue;
                            if (v29 == (26661 ^ -26662)) break;
                            v29 = 17565 ^ 2031653411;
                        }
                        v30 = TwLootModule.\u13e8;
                        if (true) ** GOTO lbl154
                        block126: while (true) {
                            v30 = v31 / (21772L ^ 4674243267628308412L);
lbl154:
                            // 2 sources

                            switch ((int)v30) {
                                case -1335009722: {
                                    break block126;
                                }
                                case 93116136: {
                                    v31 = 23694L ^ 8878199432140314944L;
                                    continue block126;
                                }
                                case 1012904329: {
                                    v31 = 5573L ^ 3816386235720262094L;
                                    continue block126;
                                }
                                case 1654718347: {
                                    v31 = 8503L ^ 1452754321235489077L;
                                    continue block126;
                                }
                            }
                            break;
                        }
                        radius = this.attack.modifyRadius(radius);
                        if (radius > 750.0) {
                            noCircle = "".length() >>> "\u0000\u0000".length();
                        }
                        if (noCircle == 0) break block158;
                        v32 = TwLootModule.\u13e8;
                        if (true) ** GOTO lbl174
                        block127: while (true) {
                            v32 = (12541L ^ 8708165538222524690L) / (9812L ^ 530128405723770340L);
lbl174:
                            // 2 sources

                            switch ((int)v32) {
                                case -1335009722: {
                                    break block127;
                                }
                                case 1619506613: {
                                    continue block127;
                                }
                            }
                            break;
                        }
                        dist = targetLoc.distance(direction);
                        v33 = TwLootModule.\u13e8;
                        if (true) ** GOTO lbl184
                        block128: while (true) {
                            v33 = v34 / (6489L ^ -3670127456515313840L);
lbl184:
                            // 2 sources

                            switch ((int)v33) {
                                case -1335009722: {
                                    break block128;
                                }
                                case -1303948255: {
                                    v34 = 22963L ^ 8633750965559405052L;
                                    continue block128;
                                }
                                case 835017881: {
                                    v34 = 23300L ^ -3319617738569722712L;
                                    continue block128;
                                }
                            }
                            break;
                        }
                        v35 = Math.min(radius - 200.0, radius * 0.5);
                        while (true) {
                            if ((v36 = (cfr_temp_16 = TwLootModule.\u13e8 - (7667L ^ 6238504826161899382L)) == 0L ? 0 : (cfr_temp_16 < 0L ? -1 : 1)) == false) continue;
                            if (v36 == (30661 ^ -30662)) break;
                            v36 = 16581 ^ -1357825361;
                        }
                        minRad = Math.max(0.0, v35);
                        if (!(dist <= radius) || !(dist >= minRad)) break block159;
                        v37 = TwLootModule.\u13e8;
                        if (true) ** GOTO lbl205
                        block130: while (true) {
                            v37 = (23080L ^ 5897387419945070297L) / (18623L ^ 8234437086275126144L);
lbl205:
                            // 2 sources

                            switch ((int)v37) {
                                case -1335009722: {
                                    break block130;
                                }
                                case -253903680: {
                                    continue block130;
                                }
                            }
                            break;
                        }
                        this.setConfig(direction);
                        return;
                    }
                    v38 = TwLootModule.\u13e8;
                    if (true) ** GOTO lbl217
                    block131: while (true) {
                        v38 = (13144L ^ 8632601081026450481L) / (1303L ^ 7821346019985248490L);
lbl217:
                        // 2 sources

                        switch ((int)v38) {
                            case -1335009722: {
                                break block131;
                            }
                            case 2034042807: {
                                continue block131;
                            }
                        }
                        break;
                    }
                    distance = minRad + Math.random() * (radius - minRad - 10.0);
                    v39 = TwLootModule.\u13e8;
                    if (true) ** GOTO lbl227
                    block132: while (true) {
                        v39 = v40 / (2604650248140867512L >>> "\u0000\u0000".length());
lbl227:
                        // 2 sources

                        switch ((int)v39) {
                            case -1820233159: {
                                v40 = 12207L ^ -1511867100349920766L;
                                continue block132;
                            }
                            case -1335009722: {
                                break block132;
                            }
                            case -900037201: {
                                v40 = 11218L ^ -2426847410572849872L;
                                continue block132;
                            }
                            case 1056896823: {
                                v40 = 6445L ^ 5757885426876976757L;
                                continue block132;
                            }
                        }
                        break;
                    }
                    angleDiff = Math.random() * 0.1 - 0.05;
                    break block160;
                }
                while (true) {
                    if ((v41 = (cfr_temp_17 = TwLootModule.\u13e8 - (19152L ^ 8054236052068676267L)) == 0L ? 0 : (cfr_temp_17 < 0L ? -1 : 1)) == false) continue;
                    if (v41 == (19380 ^ -19381)) break;
                    v41 = 17064 ^ 1653811042;
                }
                v42 = target.npcInfo;
                while (true) {
                    if ((v43 = (cfr_temp_18 = TwLootModule.\u13e8 - (5235L ^ -2634663293543682596L)) == 0L ? 0 : (cfr_temp_18 < 0L ? -1 : 1)) == false) continue;
                    if (v43 == (24881 ^ -24882)) break;
                    v43 = 31111 ^ -1517773187;
                }
                maxRadFix = v42.radius / 2.0;
                v44 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl258
                block135: while (true) {
                    v44 = v45 / (31843L ^ 5763048354890357570L);
lbl258:
                    // 2 sources

                    switch ((int)v44) {
                        case -1335009722: {
                            break block135;
                        }
                        case -492311511: {
                            v45 = 8716L ^ -1237054130042931110L;
                            continue block135;
                        }
                        case 1758371052: {
                            v45 = 4017L ^ 7041829376118102218L;
                            continue block135;
                        }
                    }
                    break;
                }
                v46 = Math.min(radius - distance, maxRadFix);
                v47 = -maxRadFix;
                while (true) {
                    if ((v48 = (cfr_temp_19 = TwLootModule.\u13e8 - (14256L ^ -5323538059081290701L)) == 0L ? 0 : (cfr_temp_19 < 0L ? -1 : 1)) == false) continue;
                    if (v48 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                    v48 = 31363 ^ 1482335644;
                }
                radiusFix = (int)Math.max(v46, v47);
                distance = radius += radiusFix;
                while (true) {
                    if ((v49 = (cfr_temp_20 = TwLootModule.\u13e8 - (15974L ^ 5774416852828289108L)) == 0L ? 0 : (cfr_temp_20 < 0L ? -1 : 1)) == false) continue;
                    if (v49 == (12123 ^ -12124)) break;
                    v49 = 30574 ^ -1547153990;
                }
                v50 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl285
                block138: while (true) {
                    v50 = (11116L ^ -2085317600765073054L) / (27827L ^ 8767067324856041073L);
lbl285:
                    // 2 sources

                    switch ((int)v50) {
                        case -1814511326: {
                            continue block138;
                        }
                        case -1335009722: {
                            break block138;
                        }
                    }
                    break;
                }
                v51 = this.hero.shipInfo;
                while (true) {
                    if ((v52 = (cfr_temp_21 = TwLootModule.\u13e8 - (29961L ^ 1154223934021580566L)) == 0L ? 0 : (cfr_temp_21 < 0L ? -1 : 1)) == false) continue;
                    if (v52 == (6194 ^ -6195)) break;
                    v52 = 25684 ^ 1127203110;
                }
                v53 = (double)v51.speed * 0.625;
                v54 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl301
                block140: while (true) {
                    v54 = v55 / (22164L ^ -5976900468881437135L);
lbl301:
                    // 2 sources

                    switch ((int)v54) {
                        case -1335009722: {
                            break block140;
                        }
                        case -1051102284: {
                            v55 = 5810L ^ 5523082853946404700L;
                            continue block140;
                        }
                        case -971919187: {
                            v55 = -4359011335345708132L >>> "\u0000\u0000".length();
                            continue block140;
                        }
                        case 1384689782: {
                            v55 = 19735L ^ 5066530342743406735L;
                            continue block140;
                        }
                    }
                    break;
                }
                v56 = target.locationInfo;
                v57 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl318
                block141: while (true) {
                    v57 = (21568L ^ -9154469058364646049L) / (32367L ^ 2940331772238374377L);
lbl318:
                    // 2 sources

                    switch ((int)v57) {
                        case -1335009722: {
                            break block141;
                        }
                        case -498149073: {
                            continue block141;
                        }
                    }
                    break;
                }
                v58 = v56.speed;
                v59 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl328
                block142: while (true) {
                    v59 = (-8062311411486453488L >>> "\u0000\u0000".length()) / (-1962628940078469116L >>> "\u0000\u0000".length());
lbl328:
                    // 2 sources

                    switch ((int)v59) {
                        case -1335009722: {
                            break block142;
                        }
                        case -43344395: {
                            continue block142;
                        }
                    }
                    break;
                }
                v60 = v53 + Double.min(200.0, v58) * 0.625;
                v61 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl338
                block143: while (true) {
                    v61 = (20891L ^ -6199775014962554394L) / (14674L ^ 6833782781789414933L);
lbl338:
                    // 2 sources

                    switch ((int)v61) {
                        case -1335009722: {
                            break block143;
                        }
                        case 858387099: {
                            continue block143;
                        }
                    }
                    break;
                }
                v62 = Location.of((Location)targetLoc, (double)angle, (double)radius);
                while (true) {
                    if ((v63 = (cfr_temp_22 = TwLootModule.\u13e8 - (2784L ^ -888268323370528388L)) == 0L ? 0 : (cfr_temp_22 < 0L ? -1 : 1)) == false) continue;
                    if (v63 == (3206 ^ -3207)) break;
                    v63 = 14140 ^ -40116450;
                }
                v64 = v60 - heroLoc.distance(v62);
                v65 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl354
                block145: while (true) {
                    v65 = v66 / (-9122301624080292908L >>> "\u0000\u0000".length());
lbl354:
                    // 2 sources

                    switch ((int)v65) {
                        case -1335009722: {
                            break block145;
                        }
                        case -312177283: {
                            v66 = 21149L ^ -7233841151064591740L;
                            continue block145;
                        }
                        case 253333895: {
                            v66 = 7758L ^ -9195407427752848765L;
                            continue block145;
                        }
                    }
                    break;
                }
                angleDiff = Math.max(v64, 0.0) / radius;
            }
            while (true) {
                if ((v67 = (cfr_temp_23 = TwLootModule.\u13e8 - (24570L ^ -1285962911219931412L)) == 0L ? 0 : (cfr_temp_23 < 0L ? -1 : 1)) == false) continue;
                if (v67 == (22803 ^ -22804)) break;
                v67 = 5336 ^ 446012299;
            }
            direction = this.getBestDir(targetLoc, angle, angleDiff, distance);
            block147: while (true) {
                if ((v68 = (cfr_temp_24 = TwLootModule.\u13e8 - (24210L ^ -2092709653112738643L)) == 0L ? 0 : (cfr_temp_24 < 0L ? -1 : 1)) == false) continue;
                if (v68 != (31930 ^ -31931)) {
                    v68 = 259010704 >>> "\u0000\u0000".length();
                    continue;
                }
                v69 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl380
                block148: while (true) {
                    v69 = v70 / (30136L ^ -7839850878401731134L);
lbl380:
                    // 2 sources

                    switch ((int)v69) {
                        case -1335009722: {
                            break block148;
                        }
                        case -1009943272: {
                            v70 = 18043L ^ 5464819032189076103L;
                            continue block148;
                        }
                        case 1119838304: {
                            v70 = 7888L ^ -6471835624456432791L;
                            continue block148;
                        }
                    }
                    break;
                }
                if (this.drive.canMove(direction) || !(distance < 10000.0)) break;
                v71 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl394
                block149: while (true) {
                    v71 = v72 / (20746L ^ 3807226971664462704L);
lbl394:
                    // 2 sources

                    switch ((int)v71) {
                        case -1335009722: {
                            break block149;
                        }
                        case 674112517: {
                            v72 = 16047L ^ 1149333902523641918L;
                            continue block149;
                        }
                        case 1658089322: {
                            v72 = 7650172105410412852L >>> "\u0000\u0000".length();
                            continue block149;
                        }
                    }
                    break;
                }
                angle += this.backwards != false ? -0.3 : 0.3;
                distance += 2.0;
                while (true) {
                    if ((v73 = (cfr_temp_25 = TwLootModule.\u13e8 - (-6359517832252714672L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_25 < 0L ? -1 : 1)) == false) continue;
                    if (v73 == (7074 ^ -7075)) {
                        direction.toAngle(targetLoc, angle, distance);
                        continue block147;
                    }
                    v73 = 15114 ^ 1871851751;
                }
                break;
            }
            if (!(distance >= 10000.0)) break block161;
            v74 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl417
            block151: while (true) {
                v74 = (3293L ^ -2438736648834089861L) / (31998L ^ -3213262187668075991L);
lbl417:
                // 2 sources

                switch ((int)v74) {
                    case -1335009722: {
                        break block151;
                    }
                    case -451400306: {
                        continue block151;
                    }
                }
                break;
            }
            direction.toAngle(targetLoc, angle, 500.0);
        }
        while (true) {
            if ((v75 = (cfr_temp_26 = TwLootModule.\u13e8 - (21380L ^ 4658943142488580391L)) == 0L ? 0 : (cfr_temp_26 < 0L ? -1 : 1)) == false) continue;
            if (v75 == (27727 ^ -27728)) break;
            v75 = 10819 ^ -1334574747;
        }
        this.setConfig(direction);
        v76 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl435
        block153: while (true) {
            v76 = (15991L ^ 5813304341520579128L) / (5997937153504240288L >>> "\u0000\u0000".length());
lbl435:
            // 2 sources

            switch ((int)v76) {
                case -1775789715: {
                    continue block153;
                }
                case -1335009722: {
                    break block153;
                }
            }
            break;
        }
        v77 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl444
        block154: while (true) {
            v77 = v78 / (20114L ^ -3985191266341336046L);
lbl444:
            // 2 sources

            switch ((int)v77) {
                case -2008064352: {
                    v78 = 4308L ^ 354065359023238938L;
                    continue block154;
                }
                case -1335009722: {
                    break block154;
                }
                case 11265775: {
                    v78 = 12090L ^ 8894465616755484740L;
                    continue block154;
                }
                case 1235189843: {
                    v78 = 18557L ^ -8037436611416181669L;
                    continue block154;
                }
            }
            break;
        }
        this.drive.move(direction);
    }

    /*
     * Unable to fully structure code
     */
    protected Location getBestDir(Location targetLoc, double angle, double angleDiff, double distance) {
        block52: {
            iteration = 2955 ^ 2954;
            forwardScore = 0.0;
            backScore = 0.0;
            do {
                v0 = angle + angleDiff * (double)iteration;
                while (true) {
                    if ((v1 = (cfr_temp_0 = TwLootModule.\u13e8 - (18129L ^ 2044224894212787928L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                    if (v1 == (18447 ^ -18448)) break;
                    v1 = 7794 ^ -461264760;
                }
                v2 = Location.of((Location)targetLoc, (double)v0, (double)distance);
                v3 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl16
                block39: while (true) {
                    v3 = v4 / (6160L ^ 4570503604847915818L);
lbl16:
                    // 2 sources

                    switch ((int)v3) {
                        case -1520652013: {
                            v4 = 11061L ^ -1239900044327686333L;
                            continue block39;
                        }
                        case -1335009722: {
                            break block39;
                        }
                        case 1834618206: {
                            v4 = 1530L ^ 234273144232976838L;
                            continue block39;
                        }
                    }
                    break;
                }
                forwardScore += this.score(v2);
                v5 = angle - angleDiff * (double)iteration;
                while (true) {
                    if ((v6 = (cfr_temp_1 = TwLootModule.\u13e8 - (20400L ^ 7152599860701102396L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                    if (v6 == (2166 ^ -2167)) break;
                    v6 = 15381 ^ -1315494325;
                }
                v7 = Location.of((Location)targetLoc, (double)v5, (double)distance);
                while (true) {
                    if ((v8 = (cfr_temp_2 = TwLootModule.\u13e8 - (19850L ^ -9079266650372879092L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                    if (v8 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                    v8 = 689111888 >>> "\u0000\u0000".length();
                }
                if ((forwardScore < 0.0 ? "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length() : "".length() >>> "\u0000\u0000".length()) != ((backScore += this.score(v7)) < 0.0 ? "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length() : "".length() >>> "\u0000\u0000".length())) break;
                v9 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl43
                block42: while (true) {
                    v9 = v10 / (14122L ^ -1304866977843708695L);
lbl43:
                    // 2 sources

                    switch ((int)v9) {
                        case -1335009722: {
                            break block42;
                        }
                        case -983178693: {
                            v10 = 18928L ^ -8755446215262507431L;
                            continue block42;
                        }
                        case -423165060: {
                            v10 = 28766L ^ -6204192365798729845L;
                            continue block42;
                        }
                    }
                    break;
                }
                if (Math.abs(forwardScore - backScore) > 300.0) break;
                v11 = iteration++;
                v12 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl58
                block43: while (true) {
                    v12 = v13 / (460429777611114300L >>> "\u0000\u0000".length());
lbl58:
                    // 2 sources

                    switch ((int)v12) {
                        case -1335009722: {
                            break block43;
                        }
                        case 320087563: {
                            v13 = 19752L ^ -6160081158903702937L;
                            continue block43;
                        }
                        case 709383230: {
                            v13 = 17660L ^ 2897178004483373146L;
                            continue block43;
                        }
                    }
                    break;
                }
                while (true) {
                    if ((v14 = (cfr_temp_3 = TwLootModule.\u13e8 - (10649L ^ -1339573597197561470L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                    if (v14 == (6192 ^ -6193)) break;
                    v14 = 23950 ^ -1152895262;
                }
                v15 = this.config.LOOT;
                v16 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl77
                block45: while (true) {
                    v16 = v17 / (282L ^ -678469109983234343L);
lbl77:
                    // 2 sources

                    switch ((int)v16) {
                        case -1335009722: {
                            break block45;
                        }
                        case -1292266249: {
                            v17 = 118151560074688192L >>> "\u0000\u0000".length();
                            continue block45;
                        }
                        case -728614549: {
                            v17 = 18406L ^ -5769463948744364766L;
                            continue block45;
                        }
                    }
                    break;
                }
            } while (v11 < v15.MAX_CIRCLE_ITERATIONS);
            v18 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl91
            block46: while (true) {
                v18 = v19 / (31362L ^ -2309509624261336135L);
lbl91:
                // 2 sources

                switch ((int)v18) {
                    case -1335009722: {
                        break block46;
                    }
                    case -1059766801: {
                        v19 = 17385L ^ 283317570349618352L;
                        continue block46;
                    }
                    case -617625022: {
                        v19 = 648316338534855792L >>> "\u0000\u0000".length();
                        continue block46;
                    }
                }
                break;
            }
            while (true) {
                if ((v20 = (cfr_temp_4 = TwLootModule.\u13e8 - (31728L ^ -5643883666087311070L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v20 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v20 = 2313 ^ -1215447454;
            }
            v21 = this.config.LOOT;
            while (true) {
                if ((v22 = (cfr_temp_5 = TwLootModule.\u13e8 - (9198L ^ 5832101398089360811L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                if (v22 == (27658 ^ -27659)) break;
                v22 = 17167 ^ -274311052;
            }
            if (iteration > v21.MAX_CIRCLE_ITERATIONS) break block52;
            v23 = backScore > forwardScore ? 8252 ^ 8253 : 25820 ^ 25820;
            v24 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl117
            block49: while (true) {
                v24 = v25 / (2831L ^ -2730773692260545369L);
lbl117:
                // 2 sources

                switch ((int)v24) {
                    case -1898529382: {
                        v25 = 21807L ^ -8167661558003743302L;
                        continue block49;
                    }
                    case -1335009722: {
                        break block49;
                    }
                    case 363735539: {
                        v25 = -8185381473588379032L >>> "\u0000\u0000".length();
                        continue block49;
                    }
                    case 1213676368: {
                        v25 = 4816L ^ -1554819546563477258L;
                        continue block49;
                    }
                }
                break;
            }
            this.backwards = v23;
        }
        v26 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl135
        block50: while (true) {
            v26 = v27 / (-7037835876953794132L >>> "\u0000\u0000".length());
lbl135:
            // 2 sources

            switch ((int)v26) {
                case -2105290337: {
                    v27 = 8692L ^ 6951597041844654587L;
                    continue block50;
                }
                case -1944646923: {
                    v27 = 11379L ^ 451351315216585690L;
                    continue block50;
                }
                case -1880251078: {
                    v27 = 14963L ^ -2913709845306593980L;
                    continue block50;
                }
                case -1335009722: {
                    break block50;
                }
            }
            break;
        }
        v28 = angle + angleDiff * (double)(this.backwards != false ? 24468 ^ -24469 : "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length());
        while (true) {
            if ((v29 = (cfr_temp_6 = TwLootModule.\u13e8 - (988L ^ -2379825628380527850L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
            if (v29 == (14067 ^ -14068)) break;
            v29 = 8328 ^ -772505214;
        }
        return Location.of((Location)targetLoc, (double)v28, (double)distance);
    }

    /*
     * Unable to fully structure code
     */
    protected double score(Location loc) {
        while (true) {
            if ((v0 = (cfr_temp_0 = TwLootModule.\u13e8 - (15560L ^ -4622302536468365245L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v0 = 18819 ^ 106217034;
        }
        while (true) {
            if ((v1 = (cfr_temp_1 = TwLootModule.\u13e8 - (13290L ^ -6609700659283479355L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v1 == (23515 ^ 23514)) break;
            v1 = 23261 ^ 2050759623;
        }
        v2 = this.drive.canMove(loc) != false ? "".length() >>> "\u0000\u0000".length() : 957 ^ -91;
        v3 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl16
        block18: while (true) {
            v3 = v4 / (24350L ^ 8377174841493757510L);
lbl16:
            // 2 sources

            switch ((int)v3) {
                case -2098171484: {
                    v4 = -449082940494722880L >>> "\u0000\u0000".length();
                    continue block18;
                }
                case -1356930287: {
                    v4 = 19442L ^ -1680009998550432921L;
                    continue block18;
                }
                case -1335009722: {
                    break block18;
                }
                case -753451912: {
                    v4 = 1216L ^ 8349310490289701342L;
                    continue block18;
                }
            }
            break;
        }
        while (true) {
            if ((v5 = (cfr_temp_2 = TwLootModule.\u13e8 - (2347L ^ -7933669760229273429L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v5 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v5 = 15960 ^ -1051062357;
        }
        v6 = this.npcs.stream();
        v7 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl38
        block20: while (true) {
            v7 = v8 / (10666L ^ -3990976742445015479L);
lbl38:
            // 2 sources

            switch ((int)v7) {
                case -1335009722: {
                    break block20;
                }
                case -72421609: {
                    v8 = 24841L ^ -1919301987914419997L;
                    continue block20;
                }
                case 1840339778: {
                    v8 = 26495L ^ 6950150649203201091L;
                    continue block20;
                }
            }
            break;
        }
        v9 = (Predicate<Npc>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Z, lambda$score$4(com.github.manolo8.darkbot.core.entities.Npc ), (Lcom/github/manolo8/darkbot/core/entities/Npc;)Z)((TwLootModule)this);
        while (true) {
            if ((v10 = (cfr_temp_3 = TwLootModule.\u13e8 - (27408L ^ -4644144692367556689L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v10 == (20625 ^ 20624)) break;
            v10 = 28896 ^ 1096960689;
        }
        v11 = v6.filter(v9);
        while (true) {
            if ((v12 = (cfr_temp_4 = TwLootModule.\u13e8 - (7828L ^ 8086773842047263582L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v12 == (23511 ^ -23512)) break;
            v12 = 12063 ^ -881324625;
        }
        v13 = (ToDoubleFunction<Npc>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)D, lambda$score$5(com.github.manolo8.darkbot.core.utils.Location com.github.manolo8.darkbot.core.entities.Npc ), (Lcom/github/manolo8/darkbot/core/entities/Npc;)D)((Location)loc);
        v14 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl64
        block23: while (true) {
            v14 = v15 / (6559L ^ 1604524293351450020L);
lbl64:
            // 2 sources

            switch ((int)v14) {
                case -1335009722: {
                    break block23;
                }
                case 480162795: {
                    v15 = 27692L ^ -1215733693231418666L;
                    continue block23;
                }
                case 1267243912: {
                    v15 = 9398L ^ -7081267495168170893L;
                    continue block23;
                }
            }
            break;
        }
        v16 = v11.mapToDouble(v13);
        while (true) {
            if ((v17 = (cfr_temp_5 = TwLootModule.\u13e8 - (30914L ^ 7323528862000459123L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
            if (v17 == (24292 ^ -24293)) break;
            v17 = 1464031720 >>> "\u0000\u0000".length();
        }
        return v2 - v16.sum();
    }

    /*
     * Unable to fully structure code
     */
    protected void setConfig(Location direction) {
        block140: {
            block142: {
                block141: {
                    while (true) {
                        if ((v0 = (cfr_temp_0 = TwLootModule.\u13e8 - (336L ^ -362238320706349042L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                        if (v0 == (4811 ^ -4812)) break;
                        v0 = 20736 ^ 1774407774;
                    }
                    v1 = TwLootModule.\u13e8;
                    if (true) ** GOTO lbl10
                    block101: while (true) {
                        v1 = v2 / (24883L ^ -8939816706039318908L);
lbl10:
                        // 2 sources

                        switch ((int)v1) {
                            case -1335009722: {
                                break block101;
                            }
                            case -1297476259: {
                                v2 = 30767L ^ 8615229054887516223L;
                                continue block101;
                            }
                            case -999806160: {
                                v2 = 19754L ^ 4809826640436862311L;
                                continue block101;
                            }
                            case -385570639: {
                                v2 = 25704L ^ 3232728097726907319L;
                                continue block101;
                            }
                        }
                        break;
                    }
                    if (this.attack.hasTarget()) break block141;
                    v3 = TwLootModule.\u13e8;
                    if (true) ** GOTO lbl27
                    block102: while (true) {
                        v3 = v4 / (-4026860811516582820L >>> "\u0000\u0000".length());
lbl27:
                        // 2 sources

                        switch ((int)v3) {
                            case -1335009722: {
                                break block102;
                            }
                            case -700841114: {
                                v4 = 15679L ^ -4484894586693017015L;
                                continue block102;
                            }
                            case 512974443: {
                                v4 = 12845L ^ 5947689359680130849L;
                                continue block102;
                            }
                            case 2087369403: {
                                v4 = 7706L ^ 8453770662040381992L;
                                continue block102;
                            }
                        }
                        break;
                    }
                    while (true) {
                        if ((v5 = (cfr_temp_1 = TwLootModule.\u13e8 - (10913L ^ -9222629502138826179L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                        if (v5 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                            this.hero.roamMode();
                            break block140;
                        }
                        v5 = 3310 ^ -1121658729;
                    }
                }
                v6 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl51
                block104: while (true) {
                    v6 = v7 / (417133218525714288L >>> "\u0000\u0000".length());
lbl51:
                    // 2 sources

                    switch ((int)v6) {
                        case -1481197424: {
                            v7 = -6554854004138109196L >>> "\u0000\u0000".length();
                            continue block104;
                        }
                        case -1335009722: {
                            break block104;
                        }
                        case 285963108: {
                            v7 = 12942L ^ 7698121573431645887L;
                            continue block104;
                        }
                        case 1920576978: {
                            v7 = 9824L ^ -3672103731104634219L;
                            continue block104;
                        }
                    }
                    break;
                }
                v8 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl67
                block105: while (true) {
                    v8 = v9 / (20696L ^ 6890283048215077475L);
lbl67:
                    // 2 sources

                    switch ((int)v8) {
                        case -1335009722: {
                            break block105;
                        }
                        case -939238769: {
                            v9 = 5158L ^ 1892076750183124523L;
                            continue block105;
                        }
                        case -253456030: {
                            v9 = 10217L ^ 4704569382007643981L;
                            continue block105;
                        }
                        case 1590815777: {
                            v9 = 26474L ^ -8165432464215628718L;
                            continue block105;
                        }
                    }
                    break;
                }
                v10 = this.config.LOOT;
                v11 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl84
                block106: while (true) {
                    v11 = v12 / (8529L ^ -5010617081335710664L);
lbl84:
                    // 2 sources

                    switch ((int)v11) {
                        case -2102773391: {
                            v12 = 5645633851051921028L >>> "\u0000\u0000".length();
                            continue block106;
                        }
                        case -2027072023: {
                            v12 = 13331L ^ -8661558059356234783L;
                            continue block106;
                        }
                        case -1335009722: {
                            break block106;
                        }
                        case 761637104: {
                            v12 = 12608L ^ 1445014207927603056L;
                            continue block106;
                        }
                    }
                    break;
                }
                if (!v10.RUN_CONFIG_IN_CIRCLE) break block142;
                while (true) {
                    if ((v13 = (cfr_temp_2 = TwLootModule.\u13e8 - (7167L ^ -1519459233360185665L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                    if (v13 == (24620 ^ -24621)) break;
                    v13 = 29357 ^ -1600989813;
                }
                v14 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl106
                block108: while (true) {
                    v14 = (23368L ^ 412629668658221222L) / (25613L ^ -8328391294206095052L);
lbl106:
                    // 2 sources

                    switch ((int)v14) {
                        case -1335009722: {
                            break block108;
                        }
                        case 1695155649: {
                            continue block108;
                        }
                    }
                    break;
                }
                v15 = this.attack.target;
                while (true) {
                    if ((v16 = (cfr_temp_3 = TwLootModule.\u13e8 - (14512L ^ 1886867979689881958L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                    if (v16 == (7483 ^ -7484)) break;
                    v16 = 23932 ^ 1829901116;
                }
                v17 = v15.health;
                v18 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl122
                block110: while (true) {
                    v18 = (-3758670390215041936L >>> "\u0000\u0000".length()) / (16178L ^ 7197661505210132607L);
lbl122:
                    // 2 sources

                    switch ((int)v18) {
                        case -1335009722: {
                            break block110;
                        }
                        case -1251930716: {
                            continue block110;
                        }
                    }
                    break;
                }
                if (!(v17.hpPercent() < 0.25)) break block142;
                while (true) {
                    if ((v19 = (cfr_temp_4 = TwLootModule.\u13e8 - (30044L ^ -4352216125681455685L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                    if (v19 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                    v19 = 3650 ^ -897859589;
                }
                v20 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl137
                block112: while (true) {
                    v20 = v21 / (7555L ^ -9134321717186495269L);
lbl137:
                    // 2 sources

                    switch ((int)v20) {
                        case -1335009722: {
                            break block112;
                        }
                        case -381655358: {
                            v21 = 27266L ^ 8409228743807937319L;
                            continue block112;
                        }
                        case 1537498523: {
                            v21 = 30651L ^ 1604398113738898013L;
                            continue block112;
                        }
                    }
                    break;
                }
                v22 = this.hero.locationInfo;
                while (true) {
                    if ((v23 = (cfr_temp_5 = TwLootModule.\u13e8 - (4135L ^ -6574950399374605423L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                    if (v23 == (17862 ^ 17863)) break;
                    v23 = 722 ^ 1526310847;
                }
                v24 = v22.now;
                v25 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl157
                block114: while (true) {
                    v25 = v26 / (-1373286468741938224L >>> "\u0000\u0000".length());
lbl157:
                    // 2 sources

                    switch ((int)v25) {
                        case -1335009722: {
                            break block114;
                        }
                        case 345965865: {
                            v26 = 22321L ^ 138542147212202819L;
                            continue block114;
                        }
                        case 614246433: {
                            v26 = 9217L ^ -4534360334552841349L;
                            continue block114;
                        }
                    }
                    break;
                }
                v27 = v24.distance(direction);
                v28 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl171
                block115: while (true) {
                    v28 = v29 / (-2954010786041556560L >>> "\u0000\u0000".length());
lbl171:
                    // 2 sources

                    switch ((int)v28) {
                        case -2006484539: {
                            v29 = 22496L ^ -6990261169074286761L;
                            continue block115;
                        }
                        case -1456853351: {
                            v29 = -9109165163748377424L >>> "\u0000\u0000".length();
                            continue block115;
                        }
                        case -1351079795: {
                            v29 = 17660L ^ 8709937468477397509L;
                            continue block115;
                        }
                        case -1335009722: {
                            break block115;
                        }
                    }
                    break;
                }
                v30 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl187
                block116: while (true) {
                    v30 = (7100L ^ 526089884803404717L) / (15116L ^ 6912513575225808782L);
lbl187:
                    // 2 sources

                    switch ((int)v30) {
                        case -1335009722: {
                            break block116;
                        }
                        case -1333036396: {
                            continue block116;
                        }
                    }
                    break;
                }
                v31 = this.attack.target;
                v32 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl197
                block117: while (true) {
                    v32 = v33 / (-5182094491895075232L >>> "\u0000\u0000".length());
lbl197:
                    // 2 sources

                    switch ((int)v32) {
                        case -1335009722: {
                            break block117;
                        }
                        case -206248655: {
                            v33 = 22178L ^ -1913232181473985406L;
                            continue block117;
                        }
                        case 322246005: {
                            v33 = 20464L ^ -9101949292439034010L;
                            continue block117;
                        }
                        case 1653546349: {
                            v33 = 24504L ^ 4877674507783382636L;
                            continue block117;
                        }
                    }
                    break;
                }
                v34 = v31.npcInfo;
                v35 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl214
                block118: while (true) {
                    v35 = (9943L ^ -906686192131234985L) / (9927L ^ 1885055954780120672L);
lbl214:
                    // 2 sources

                    switch ((int)v35) {
                        case -1335009722: {
                            break block118;
                        }
                        case 11438580: {
                            continue block118;
                        }
                    }
                    break;
                }
                if (!(v27 > v34.radius * 2.0)) break block142;
                v36 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl224
                block119: while (true) {
                    v36 = v37 / (6200L ^ 85666234873522783L);
lbl224:
                    // 2 sources

                    switch ((int)v36) {
                        case -1410263947: {
                            v37 = 3289738788706197388L >>> "\u0000\u0000".length();
                            continue block119;
                        }
                        case -1335009722: {
                            break block119;
                        }
                        case -938657164: {
                            v37 = 6018L ^ -1074029657801681159L;
                            continue block119;
                        }
                    }
                    break;
                }
                while (true) {
                    if ((v38 = (cfr_temp_6 = TwLootModule.\u13e8 - (28885L ^ -7830911621867968469L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                    if (v38 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                        this.hero.runMode();
                        break block140;
                    }
                    v38 = 15107 ^ -144860386;
                }
            }
            v39 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl245
            block121: while (true) {
                v39 = (7791L ^ -4599748254336857040L) / (22220L ^ 6413809811918125894L);
lbl245:
                // 2 sources

                switch ((int)v39) {
                    case -1335009722: {
                        break block121;
                    }
                    case 1951903852: {
                        continue block121;
                    }
                }
                break;
            }
            while (true) {
                if ((v40 = (cfr_temp_7 = TwLootModule.\u13e8 - (20607L ^ -4755567404493007546L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                if (v40 == (3997 ^ 3996)) break;
                v40 = -2055003984 >>> "\u0000\u0000".length();
            }
            v41 = this.hero.locationInfo;
            v42 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl260
            block123: while (true) {
                v42 = (11757L ^ -6986092585193576063L) / (3184L ^ -1302935903701221534L);
lbl260:
                // 2 sources

                switch ((int)v42) {
                    case -1335009722: {
                        break block123;
                    }
                    case 622522182: {
                        continue block123;
                    }
                }
                break;
            }
            v43 = v41.now;
            while (true) {
                if ((v44 = (cfr_temp_8 = TwLootModule.\u13e8 - (10668L ^ -9104476508207180461L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                if (v44 == (24365 ^ 24364)) break;
                v44 = 24685 ^ -207468992;
            }
            v45 = v43.distance(direction);
            v46 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl276
            block125: while (true) {
                v46 = v47 / (13919L ^ 4919242024633045867L);
lbl276:
                // 2 sources

                switch ((int)v46) {
                    case -1335009722: {
                        break block125;
                    }
                    case 169279586: {
                        v47 = 19578L ^ 7339189624332975023L;
                        continue block125;
                    }
                    case 601064723: {
                        v47 = 11560L ^ -2822944553603798800L;
                        continue block125;
                    }
                }
                break;
            }
            while (true) {
                if ((v48 = (cfr_temp_9 = TwLootModule.\u13e8 - (782144606898653384L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
                if (v48 == (19123 ^ -19124)) break;
                v48 = 1827156924 >>> "\u0000\u0000".length();
            }
            v49 = this.attack.target;
            v50 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl295
            block127: while (true) {
                v50 = v51 / (17732L ^ 6746495786327924128L);
lbl295:
                // 2 sources

                switch ((int)v50) {
                    case -1335009722: {
                        break block127;
                    }
                    case -1033974005: {
                        v51 = 3874L ^ -5425315694259557685L;
                        continue block127;
                    }
                    case 940756934: {
                        v51 = 18013L ^ 3606538775058987898L;
                        continue block127;
                    }
                }
                break;
            }
            v52 = v49.npcInfo;
            v53 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl309
            block128: while (true) {
                v53 = (7872L ^ 6657413729286834452L) / (18628L ^ 7788906514444856297L);
lbl309:
                // 2 sources

                switch ((int)v53) {
                    case -1335009722: {
                        break block128;
                    }
                    case 20463547: {
                        continue block128;
                    }
                }
                break;
            }
            if (v45 > v52.radius * 3.0) {
                while (true) {
                    if ((v54 = (cfr_temp_10 = TwLootModule.\u13e8 - (13986L ^ -8368697883982858019L)) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
                    if (v54 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                    v54 = 30935 ^ 1890146401;
                }
                while (true) {
                    if ((v55 = (cfr_temp_11 = TwLootModule.\u13e8 - (14921L ^ 3732544348219710497L)) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
                    if (v55 == (25562 ^ -25563)) {
                        this.hero.roamMode();
                        break block140;
                    }
                    v55 = 27757 ^ 374267707;
                }
            }
            while (true) {
                if ((v56 = (cfr_temp_12 = TwLootModule.\u13e8 - (11633L ^ -1290306118659694304L)) == 0L ? 0 : (cfr_temp_12 < 0L ? -1 : 1)) == false) continue;
                if (v56 == (26993 ^ -26994)) break;
                v56 = 9690 ^ 1181434766;
            }
            v57 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl336
            block132: while (true) {
                v57 = v58 / (31136L ^ -7000130509294471604L);
lbl336:
                // 2 sources

                switch ((int)v57) {
                    case -1703569350: {
                        v58 = 3925L ^ -4723274024129200145L;
                        continue block132;
                    }
                    case -1504822981: {
                        v58 = 23426L ^ -7632807647008219286L;
                        continue block132;
                    }
                    case -1335009722: {
                        break block132;
                    }
                }
                break;
            }
            while (true) {
                if ((v59 = (cfr_temp_13 = TwLootModule.\u13e8 - (9027294357668119916L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_13 < 0L ? -1 : 1)) == false) continue;
                if (v59 == (2915 ^ -2916)) break;
                v59 = 21784 ^ 1432007785;
            }
            v60 = this.attack.target;
            while (true) {
                if ((v61 = (cfr_temp_14 = TwLootModule.\u13e8 - (26711L ^ -6032632476031635966L)) == 0L ? 0 : (cfr_temp_14 < 0L ? -1 : 1)) == false) continue;
                if (v61 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                    this.hero.attackMode(v60);
                    break;
                }
                v61 = 2382 ^ 1246520283;
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    protected boolean isAttackedByOthers(Npc npc) {
        block57: {
            while (true) {
                if ((v0 = (cfr_temp_0 = TwLootModule.\u13e8 - (3808L ^ -4092337447792265459L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v0 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v0 = 26153 ^ 1101112513;
            }
            while (true) {
                if ((v1 = (cfr_temp_1 = TwLootModule.\u13e8 - (11898L ^ -7095045149183355523L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v1 == (5492 ^ 5493)) break;
                v1 = 1958687984 >>> "\u0000\u0000".length();
            }
            var2_2 = this.ships.iterator();
            while (true) {
                v2 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl17
                block40: while (true) {
                    v2 = v3 / (2279L ^ 5864363147738028140L);
lbl17:
                    // 2 sources

                    switch ((int)v2) {
                        case -1335009722: {
                            break block40;
                        }
                        case -520960046: {
                            v3 = 32738L ^ -4666105565674837787L;
                            continue block40;
                        }
                        case 1306899237: {
                            v3 = 23649L ^ -6891596685568464041L;
                            continue block40;
                        }
                    }
                    break;
                }
                if (!var2_2.hasNext()) break block57;
                v4 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl31
                block41: while (true) {
                    v4 = v5 / (20742L ^ 8631762244902015260L);
lbl31:
                    // 2 sources

                    switch ((int)v4) {
                        case -1916426025: {
                            v5 = 8032878008310880448L >>> "\u0000\u0000".length();
                            continue block41;
                        }
                        case -1335009722: {
                            break block41;
                        }
                        case -732895830: {
                            v5 = 25356L ^ -8905034523484915716L;
                            continue block41;
                        }
                    }
                    break;
                }
                ship = var2_2.next();
                v6 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl45
                block42: while (true) {
                    v6 = v7 / (8266L ^ 7306570472812245564L);
lbl45:
                    // 2 sources

                    switch ((int)v6) {
                        case -1413151735: {
                            v7 = 8336289602895764392L >>> "\u0000\u0000".length();
                            continue block42;
                        }
                        case -1335009722: {
                            break block42;
                        }
                        case 269628223: {
                            v7 = 14837L ^ -5528732353691644555L;
                            continue block42;
                        }
                    }
                    break;
                }
                v8 = ship.address;
                while (true) {
                    if ((v9 = (cfr_temp_2 = TwLootModule.\u13e8 - (21143L ^ -4003483337306368200L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                    if (v9 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                    v9 = 6110 ^ -1246221973;
                }
                while (true) {
                    if ((v10 = (cfr_temp_3 = TwLootModule.\u13e8 - (8023L ^ 2750736406225977038L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                    if (v10 == (21710 ^ -21711)) break;
                    v10 = 3197 ^ -966119325;
                }
                if (v8 == this.hero.address) continue;
                while (true) {
                    if ((v11 = (cfr_temp_4 = TwLootModule.\u13e8 - (28948L ^ -7977676487896715302L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                    if (v11 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                    v11 = 12764 ^ -92772877;
                }
                v12 = ship.address;
                while (true) {
                    if ((v13 = (cfr_temp_5 = TwLootModule.\u13e8 - (6980914045894023136L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                    if (v13 == (9564 ^ -9565)) break;
                    v13 = 29059 ^ -1321843599;
                }
                v14 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl81
                block47: while (true) {
                    v14 = v15 / (22996L ^ -7955065617125403415L);
lbl81:
                    // 2 sources

                    switch ((int)v14) {
                        case -1335009722: {
                            break block47;
                        }
                        case 1556153420: {
                            v15 = 3254L ^ 6441167289705769659L;
                            continue block47;
                        }
                        case 1768516196: {
                            v15 = -2817636752027633824L >>> "\u0000\u0000".length();
                            continue block47;
                        }
                        case 2064618946: {
                            v15 = 7677L ^ -8007866525386314047L;
                            continue block47;
                        }
                    }
                    break;
                }
                v16 = this.hero.pet;
                while (true) {
                    if ((v17 = (cfr_temp_6 = TwLootModule.\u13e8 - (28336L ^ 5359227146269807393L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                    if (v17 == (19912 ^ -19913)) break;
                    v17 = 582 ^ 1787488585;
                }
                if (v12 == v16.address) continue;
                v18 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl104
                block49: while (true) {
                    v18 = v19 / (-7225967618501279104L >>> "\u0000\u0000".length());
lbl104:
                    // 2 sources

                    switch ((int)v18) {
                        case -1596705631: {
                            v19 = 16185L ^ 8971331953882969398L;
                            continue block49;
                        }
                        case -1335009722: {
                            break block49;
                        }
                        case -695563995: {
                            v19 = 12599L ^ 7512283817956086074L;
                            continue block49;
                        }
                    }
                    break;
                }
                if (ship.isAttacking((Ship)npc)) break;
            }
            while (true) {
                if ((v20 = (cfr_temp_7 = TwLootModule.\u13e8 - (28155L ^ 7823453425223271632L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                if (v20 == (24264 ^ -24265)) break;
                v20 = 27887 ^ -196622410;
            }
            v21 = npc.npcInfo;
            v22 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl125
            block51: while (true) {
                v22 = v23 / (27384L ^ -4989329802299055593L);
lbl125:
                // 2 sources

                switch ((int)v22) {
                    case -1335009722: {
                        break block51;
                    }
                    case -566656530: {
                        v23 = 23494L ^ 212552653334663529L;
                        continue block51;
                    }
                    case 59855518: {
                        v23 = 289472372330328812L >>> "\u0000\u0000".length();
                        continue block51;
                    }
                    case 1202870405: {
                        v23 = 7242L ^ -2275198168796158131L;
                        continue block51;
                    }
                }
                break;
            }
            v24 = v21.extra;
            v25 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl142
            block52: while (true) {
                v25 = v26 / (12936L ^ 4762513927403116486L);
lbl142:
                // 2 sources

                switch ((int)v25) {
                    case -1335009722: {
                        break block52;
                    }
                    case -663689466: {
                        v26 = 13184L ^ -6906821382107019638L;
                        continue block52;
                    }
                    case -57350784: {
                        v26 = 29931L ^ 7820494479141285179L;
                        continue block52;
                    }
                }
                break;
            }
            while (true) {
                if ((v27 = (cfr_temp_8 = TwLootModule.\u13e8 - (13997L ^ -9221090821934770605L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                if (v27 == (14323 ^ 14322)) break;
                v27 = 22656 ^ -1582879778;
            }
            if (!v24.has((NpcExtraFlag)NpcExtra.IGNORE_ATTACKED)) {
                v28 = 80000L >>> "\u0000\u0000".length();
                while (true) {
                    if ((v29 = (cfr_temp_9 = TwLootModule.\u13e8 - (353L ^ 6812311112955056088L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
                    if (v29 == (17376 ^ -17377)) {
                        npc.setTimerTo(v28);
                        break;
                    }
                    v29 = 25189 ^ 1583002177;
                }
            }
            return "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        }
        return (boolean)(655 ^ 655);
    }

    /*
     * Unable to fully structure code
     */
    protected Npc closestNpc(Location location) {
        block142: {
            block140: {
                block141: {
                    block139: {
                        while (true) {
                            if ((v0 = (cfr_temp_0 = TwLootModule.\u13e8 - (17240L ^ -6363868370751440023L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                            if (v0 == (19278 ^ 19279)) break;
                            v0 = 11335 ^ 1918229738;
                        }
                        while (true) {
                            if ((v1 = (cfr_temp_1 = TwLootModule.\u13e8 - (14992L ^ -5370223089613332209L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                            if (v1 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                            v1 = 13879 ^ 2009953723;
                        }
                        hasTarget = this.attack.hasTarget();
                        if (hasTarget) break block139;
                        while (true) {
                            if ((v2 = (cfr_temp_2 = TwLootModule.\u13e8 - (23505L ^ -6682308089531231806L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                            if (v2 == (13943 ^ 13942)) break;
                            v2 = 24129 ^ -958280102;
                        }
                        v3 = TwLootModule.\u13e8;
                        if (true) ** GOTO lbl22
                        block105: while (true) {
                            v3 = v4 / (26226L ^ -6853539140194809611L);
lbl22:
                            // 2 sources

                            switch ((int)v3) {
                                case -1374444028: {
                                    v4 = 15818L ^ -8292556215334309258L;
                                    continue block105;
                                }
                                case -1335009722: {
                                    break block105;
                                }
                                case 296421914: {
                                    v4 = 10962L ^ 7476462864490005255L;
                                    continue block105;
                                }
                                case 1772346406: {
                                    v4 = 3217L ^ -1285280680873487767L;
                                    continue block105;
                                }
                            }
                            break;
                        }
                        if (!this.twLootModuleConfig.ATTACK_ONLY_FROM_PREFERRED_REGION) break block139;
                        v5 = TwLootModule.\u13e8;
                        if (true) ** GOTO lbl39
                        block106: while (true) {
                            v5 = v6 / (28311L ^ -4470400411353094290L);
lbl39:
                            // 2 sources

                            switch ((int)v5) {
                                case -1394259027: {
                                    v6 = 17744L ^ 6156853431536063279L;
                                    continue block106;
                                }
                                case -1335009722: {
                                    break block106;
                                }
                                case -865941065: {
                                    v6 = -8153823644159351992L >>> "\u0000\u0000".length();
                                    continue block106;
                                }
                                case 250750470: {
                                    v6 = 28714L ^ 8400924654420418233L;
                                    continue block106;
                                }
                            }
                            break;
                        }
                        v7 = TwLootModule.\u13e8;
                        if (true) ** GOTO lbl55
                        block107: while (true) {
                            v7 = (1514L ^ 8023258587316675986L) / (23133L ^ -1754376680030040402L);
lbl55:
                            // 2 sources

                            switch ((int)v7) {
                                case -1335009722: {
                                    break block107;
                                }
                                case 729588514: {
                                    continue block107;
                                }
                            }
                            break;
                        }
                        v8 = this.main.mapManager;
                        v9 = TwLootModule.\u13e8;
                        if (true) ** GOTO lbl65
                        block108: while (true) {
                            v9 = v10 / (12829L ^ -8681542668128341504L);
lbl65:
                            // 2 sources

                            switch ((int)v9) {
                                case -1335009722: {
                                    break block108;
                                }
                                case -628153414: {
                                    v10 = 31846L ^ 6917243903472522530L;
                                    continue block108;
                                }
                                case -137239573: {
                                    v10 = 31178L ^ 1223984354102364675L;
                                    continue block108;
                                }
                                case 1207154881: {
                                    v10 = 16681L ^ -8046653648329537706L;
                                    continue block108;
                                }
                            }
                            break;
                        }
                        v11 = v8.preferred;
                        while (true) {
                            if ((v12 = (cfr_temp_3 = TwLootModule.\u13e8 - (-1896884058529991124L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                            if (v12 == (29581 ^ -29582)) break;
                            v12 = 15583 ^ 1909569915;
                        }
                        v13 = TwLootModule.\u13e8;
                        if (true) ** GOTO lbl87
                        block110: while (true) {
                            v13 = (19332L ^ 4563175366188451969L) / (5390L ^ 3485922754297952733L);
lbl87:
                            // 2 sources

                            switch ((int)v13) {
                                case -1335009722: {
                                    break block110;
                                }
                                case 1801172186: {
                                    continue block110;
                                }
                            }
                            break;
                        }
                        v14 = this.hero.locationInfo;
                        while (true) {
                            if ((v15 = (cfr_temp_4 = TwLootModule.\u13e8 - (6107279085929519104L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                            if (v15 == (18493 ^ -18494)) break;
                            v15 = 17124 ^ -229341707;
                        }
                        v16 = v14.now;
                        v17 = TwLootModule.\u13e8;
                        if (true) ** GOTO lbl103
                        block112: while (true) {
                            v17 = v18 / (5044L ^ 8073736934497131939L);
lbl103:
                            // 2 sources

                            switch ((int)v17) {
                                case -2094923279: {
                                    v18 = 21919L ^ -3670671457316003538L;
                                    continue block112;
                                }
                                case -1607484786: {
                                    v18 = 23941L ^ -679074044892318553L;
                                    continue block112;
                                }
                                case -1335009722: {
                                    break block112;
                                }
                            }
                            break;
                        }
                        if (!v11.contains(v16)) {
                            return null;
                        }
                    }
                    if (!hasTarget) break block140;
                    v19 = TwLootModule.\u13e8;
                    if (true) ** GOTO lbl120
                    block113: while (true) {
                        v19 = v20 / (23129L ^ 2775832827025568511L);
lbl120:
                        // 2 sources

                        switch ((int)v19) {
                            case -1774069540: {
                                v20 = 1918L ^ -2362107815561531649L;
                                continue block113;
                            }
                            case -1335009722: {
                                break block113;
                            }
                            case -420315926: {
                                v20 = 6199192769001282772L >>> "\u0000\u0000".length();
                                continue block113;
                            }
                            case 147359563: {
                                v20 = 3263L ^ -6750883891659934144L;
                                continue block113;
                            }
                        }
                        break;
                    }
                    v21 = TwLootModule.\u13e8;
                    if (true) ** GOTO lbl136
                    block114: while (true) {
                        v21 = (16799L ^ 5208985757917248942L) / (645L ^ 6124560684789760959L);
lbl136:
                        // 2 sources

                        switch ((int)v21) {
                            case -1335009722: {
                                break block114;
                            }
                            case -1015630318: {
                                continue block114;
                            }
                        }
                        break;
                    }
                    v22 = this.hero.target;
                    while (true) {
                        if ((v23 = (cfr_temp_5 = TwLootModule.\u13e8 - (25648L ^ -1914525325991151398L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                        if (v23 == (16700 ^ -16701)) break;
                        v23 = 4706 ^ -947831873;
                    }
                    v24 = TwLootModule.\u13e8;
                    if (true) ** GOTO lbl151
                    block116: while (true) {
                        v24 = v25 / (12545L ^ -390086670710631680L);
lbl151:
                        // 2 sources

                        switch ((int)v24) {
                            case -1335009722: {
                                break block116;
                            }
                            case -527355827: {
                                v25 = 11386L ^ 393948988866779657L;
                                continue block116;
                            }
                            case -187878311: {
                                v25 = 21981L ^ -1435702349647313858L;
                                continue block116;
                            }
                            case 1741808884: {
                                v25 = 28212L ^ 3949121354434137139L;
                                continue block116;
                            }
                        }
                        break;
                    }
                    if (v22 == this.attack.target) break block141;
                    v26 = TwLootModule.\u13e8;
                    if (true) ** GOTO lbl168
                    block117: while (true) {
                        v26 = v27 / (3332L ^ -2936804423136735915L);
lbl168:
                        // 2 sources

                        switch ((int)v26) {
                            case -1781907877: {
                                v27 = 14806L ^ -7419923233520857024L;
                                continue block117;
                            }
                            case -1335009722: {
                                break block117;
                            }
                            case -1024552068: {
                                v27 = 21509L ^ -4848942738211099400L;
                                continue block117;
                            }
                            case 1563829244: {
                                v27 = 2272193891405234460L >>> "\u0000\u0000".length();
                                continue block117;
                            }
                        }
                        break;
                    }
                    v28 = TwLootModule.\u13e8;
                    if (true) ** GOTO lbl184
                    block118: while (true) {
                        v28 = v29 / (14230L ^ 2721862476131008194L);
lbl184:
                        // 2 sources

                        switch ((int)v28) {
                            case -1468939707: {
                                v29 = 23306L ^ 5999404864916431951L;
                                continue block118;
                            }
                            case -1335009722: {
                                break block118;
                            }
                            case -1010315463: {
                                v29 = 15898L ^ -3311652981618539042L;
                                continue block118;
                            }
                            case -256861562: {
                                v29 = 10650L ^ -325512868677850238L;
                                continue block118;
                            }
                        }
                        break;
                    }
                    v30 = this.hero.locationInfo;
                    while (true) {
                        if ((v31 = (cfr_temp_6 = TwLootModule.\u13e8 - (9073L ^ 6605119506627832289L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                        if (v31 == (23625 ^ -23626)) break;
                        v31 = 32419 ^ 1140187999;
                    }
                    while (true) {
                        if ((v32 = (cfr_temp_7 = TwLootModule.\u13e8 - (18663L ^ 8225018184313025061L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                        if (v32 == (4683 ^ -4684)) break;
                        v32 = 28712 ^ 744982513;
                    }
                    v33 = this.attack.target;
                    v34 = TwLootModule.\u13e8;
                    if (true) ** GOTO lbl212
                    block121: while (true) {
                        v34 = (26836L ^ 5243077185464146878L) / (30700L ^ 6602236993362215492L);
lbl212:
                        // 2 sources

                        switch ((int)v34) {
                            case -1828359222: {
                                continue block121;
                            }
                            case -1335009722: {
                                break block121;
                            }
                        }
                        break;
                    }
                    if (!(v30.distance((Entity)v33) < 600.0)) break block140;
                }
                v35 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl223
                block122: while (true) {
                    v35 = v36 / (28293L ^ -5443171893155345883L);
lbl223:
                    // 2 sources

                    switch ((int)v35) {
                        case -1335009722: {
                            break block122;
                        }
                        case -184655495: {
                            v36 = 11784L ^ 6390779829363498370L;
                            continue block122;
                        }
                        case 776785574: {
                            v36 = -2621762236836742984L >>> "\u0000\u0000".length();
                            continue block122;
                        }
                        case 1713247290: {
                            v36 = 4678L ^ -4711464755840103555L;
                            continue block122;
                        }
                    }
                    break;
                }
                v37 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl239
                block123: while (true) {
                    v37 = v38 / (27225L ^ -6011678769081794872L);
lbl239:
                    // 2 sources

                    switch ((int)v37) {
                        case -1868605872: {
                            v38 = 22336L ^ 8183288920080966851L;
                            continue block123;
                        }
                        case -1501320927: {
                            v38 = 6484L ^ -1650984115130160266L;
                            continue block123;
                        }
                        case -1335009722: {
                            break block123;
                        }
                    }
                    break;
                }
                v39 = this.attack.target;
                while (true) {
                    if ((v40 = (cfr_temp_8 = TwLootModule.\u13e8 - (524L ^ 3313592131398684391L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                    if (v40 == (7581 ^ -7582)) break;
                    v40 = 16615 ^ -1436966825;
                }
                v41 = v39.health;
                v42 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl259
                block125: while (true) {
                    v42 = v43 / (20240L ^ 4110514999607584893L);
lbl259:
                    // 2 sources

                    switch ((int)v42) {
                        case -1335009722: {
                            break block125;
                        }
                        case 76544965: {
                            v43 = 15128L ^ 6678139891883014565L;
                            continue block125;
                        }
                        case 795193097: {
                            v43 = 21084L ^ 8999350199685681105L;
                            continue block125;
                        }
                        case 1334493470: {
                            v43 = 18842L ^ -4800415276138840617L;
                            continue block125;
                        }
                    }
                    break;
                }
                v44 = (27702 ^ 27682) - (int)(v41.hpPercent() * 10.0);
                break block142;
            }
            v44 = "".length() >>> "\u0000\u0000".length();
        }
        extraPriority = v44;
        v45 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl281
        block126: while (true) {
            v45 = v46 / (16201L ^ -1461172272581473225L);
lbl281:
            // 2 sources

            switch ((int)v45) {
                case -1335009722: {
                    break block126;
                }
                case -1307055753: {
                    v46 = 4108L ^ 7651096673611798989L;
                    continue block126;
                }
                case -14775160: {
                    v46 = 16516L ^ -8072900536211847465L;
                    continue block126;
                }
                case 492186936: {
                    v46 = 28086L ^ 5795417563119211016L;
                    continue block126;
                }
            }
            break;
        }
        while (true) {
            if ((v47 = (cfr_temp_9 = TwLootModule.\u13e8 - (22561L ^ -4268407453119299142L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
            if (v47 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v47 = -728629820 >>> "\u0000\u0000".length();
        }
        v48 = this.npcs.stream();
        while (true) {
            if ((v49 = (cfr_temp_10 = TwLootModule.\u13e8 - (13294L ^ -5856081575708595304L)) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
            if (v49 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v49 = 19881 ^ -2003491663;
        }
        v50 = (Predicate<Npc>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Z, lambda$closestNpc$6(com.github.manolo8.darkbot.core.entities.Npc ), (Lcom/github/manolo8/darkbot/core/entities/Npc;)Z)((TwLootModule)this);
        while (true) {
            if ((v51 = (cfr_temp_11 = TwLootModule.\u13e8 - (12986L ^ -491775758104057841L)) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
            if (v51 == (6227 ^ -6228)) break;
            v51 = 19717 ^ 0x6B66006B;
        }
        v52 = v48.filter(v50);
        while (true) {
            if ((v53 = (cfr_temp_12 = TwLootModule.\u13e8 - (5287L ^ -2877676935056333577L)) == 0L ? 0 : (cfr_temp_12 < 0L ? -1 : 1)) == false) continue;
            if (v53 == (3192 ^ -3193)) break;
            v53 = 8667 ^ -1868806795;
        }
        v54 = (ToIntFunction<Npc>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)I, lambda$closestNpc$7(int com.github.manolo8.darkbot.core.entities.Npc ), (Lcom/github/manolo8/darkbot/core/entities/Npc;)I)((TwLootModule)this, (int)extraPriority);
        while (true) {
            if ((v55 = (cfr_temp_13 = TwLootModule.\u13e8 - (3797243792217935352L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_13 < 0L ? -1 : 1)) == false) continue;
            if (v55 == (14775 ^ -14776)) break;
            v55 = 10927 ^ 790401308;
        }
        v56 = Comparator.comparingInt(v54);
        while (true) {
            if ((v57 = (cfr_temp_14 = TwLootModule.\u13e8 - (13957L ^ 6586307461399747148L)) == 0L ? 0 : (cfr_temp_14 < 0L ? -1 : 1)) == false) continue;
            if (v57 == (26387 ^ -26388)) break;
            v57 = 12232 ^ -1952513875;
        }
        v58 = (Function<Npc, Double>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, lambda$closestNpc$8(com.github.manolo8.darkbot.core.entities.Npc ), (Lcom/github/manolo8/darkbot/core/entities/Npc;)Ljava/lang/Double;)();
        v59 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl333
        block133: while (true) {
            v59 = v60 / (9780L ^ -7684312550957793937L);
lbl333:
            // 2 sources

            switch ((int)v59) {
                case -1798173076: {
                    v60 = 13515L ^ -3366900108741908781L;
                    continue block133;
                }
                case -1739022598: {
                    v60 = 25673L ^ -6373324684973235117L;
                    continue block133;
                }
                case -1335009722: {
                    break block133;
                }
            }
            break;
        }
        v61 = v56.thenComparing(v58);
        v62 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl347
        block134: while (true) {
            v62 = v63 / (14950L ^ 6130233273339805287L);
lbl347:
            // 2 sources

            switch ((int)v62) {
                case -1335009722: {
                    break block134;
                }
                case 1446471060: {
                    v63 = 13323L ^ 8382719560005860123L;
                    continue block134;
                }
                case 1500870649: {
                    v63 = 5504L ^ 6498790737290125720L;
                    continue block134;
                }
                case 2086479344: {
                    v63 = 17614L ^ -6108287764895420972L;
                    continue block134;
                }
            }
            break;
        }
        v64 = (Function<Npc, Double>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, lambda$closestNpc$9(com.github.manolo8.darkbot.core.utils.Location com.github.manolo8.darkbot.core.entities.Npc ), (Lcom/github/manolo8/darkbot/core/entities/Npc;)Ljava/lang/Double;)((Location)location);
        while (true) {
            if ((v65 = (cfr_temp_15 = TwLootModule.\u13e8 - (9058L ^ -4975210904676177270L)) == 0L ? 0 : (cfr_temp_15 < 0L ? -1 : 1)) == false) continue;
            if (v65 == (26632 ^ 26633)) break;
            v65 = -1113900556 >>> "\u0000\u0000".length();
        }
        v66 = v61.thenComparing(v64);
        v67 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl370
        block136: while (true) {
            v67 = v68 / (26818L ^ -5551804006365540492L);
lbl370:
            // 2 sources

            switch ((int)v67) {
                case -1335009722: {
                    break block136;
                }
                case -251897726: {
                    v68 = 11809L ^ -237583371645333550L;
                    continue block136;
                }
                case 2100440578: {
                    v68 = 25572L ^ 5483632034327466496L;
                    continue block136;
                }
            }
            break;
        }
        v69 = v52.min(v66);
        while (true) {
            if ((v70 = (cfr_temp_16 = TwLootModule.\u13e8 - (15593L ^ 8119912611368813040L)) == 0L ? 0 : (cfr_temp_16 < 0L ? -1 : 1)) == false) continue;
            if (v70 == (16266 ^ -16267)) break;
            v70 = 17319 ^ 2029245713;
        }
        return v69.orElse(null);
    }

    /*
     * Unable to fully structure code
     */
    protected boolean shouldKill(Npc n) {
        block117: {
            while (true) {
                if ((v0 = (cfr_temp_0 = TwLootModule.\u13e8 - (-4955014311740751772L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v0 == (26613 ^ -26614)) break;
                v0 = 13703 ^ -1352768484;
            }
            attacked = this.isAttackedByOthers(n);
            v1 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl11
            block88: while (true) {
                v1 = v2 / (19493L ^ -1781579331844272175L);
lbl11:
                // 2 sources

                switch ((int)v1) {
                    case -1747903831: {
                        v2 = 15587L ^ -8240622033859884304L;
                        continue block88;
                    }
                    case -1335009722: {
                        break block88;
                    }
                    case 82562406: {
                        v2 = 14042L ^ 8637855363916960083L;
                        continue block88;
                    }
                }
                break;
            }
            v3 = n.npcInfo;
            v4 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl25
            block89: while (true) {
                v4 = (16575L ^ -5351218259143630045L) / (11046L ^ 771266410972691752L);
lbl25:
                // 2 sources

                switch ((int)v4) {
                    case -1335009722: {
                        break block89;
                    }
                    case 2048987528: {
                        continue block89;
                    }
                }
                break;
            }
            if (!v3.kill) ** GOTO lbl-1000
            v5 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl35
            block90: while (true) {
                v5 = v6 / (15856L ^ -4159495574691427924L);
lbl35:
                // 2 sources

                switch ((int)v5) {
                    case -1660730339: {
                        v6 = 20823L ^ -5862067382747381099L;
                        continue block90;
                    }
                    case -1335009722: {
                        break block90;
                    }
                    case 1634117070: {
                        v6 = 18557L ^ 2306503409076246045L;
                        continue block90;
                    }
                    case 2046730956: {
                        v6 = -5164440087762101540L >>> "\u0000\u0000".length();
                        continue block90;
                    }
                }
                break;
            }
            if (n.isInTimer()) ** GOTO lbl-1000
            while (true) {
                if ((v7 = (cfr_temp_1 = TwLootModule.\u13e8 - (31426L ^ 8638085429128606988L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v7 == (2271 ^ -2272)) break;
                v7 = 22487 ^ 1872825947;
            }
            v8 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl57
            block92: while (true) {
                v8 = (25965L ^ 8513170062091591335L) / (23967L ^ -6524911536604371873L);
lbl57:
                // 2 sources

                switch ((int)v8) {
                    case -1335009722: {
                        break block92;
                    }
                    case 853766840: {
                        continue block92;
                    }
                }
                break;
            }
            v9 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl66
            block93: while (true) {
                v9 = v10 / (20626L ^ -2488180129250923191L);
lbl66:
                // 2 sources

                switch ((int)v9) {
                    case -1335009722: {
                        break block93;
                    }
                    case 318041797: {
                        v10 = 27010L ^ -6883708593233223623L;
                        continue block93;
                    }
                    case 703269874: {
                        v10 = 10119L ^ 8695909752731853922L;
                        continue block93;
                    }
                    case 1791819693: {
                        v10 = 12938L ^ 6860007257531574047L;
                        continue block93;
                    }
                }
                break;
            }
            if (this.hero.hasEffect(EffectManager.Effect.ENERGY_LEECH)) break block117;
            while (true) {
                if ((v11 = (cfr_temp_2 = TwLootModule.\u13e8 - (11430L ^ -6156069289957893314L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v11 == (27379 ^ 27378)) break;
                v11 = 15219 ^ 1820090473;
            }
            v12 = n.npcInfo;
            while (true) {
                if ((v13 = (cfr_temp_3 = TwLootModule.\u13e8 - (1576777384688714012L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v13 == (22312 ^ -22313)) break;
                v13 = 12128 ^ -1435554992;
            }
            v14 = v12.extra;
            while (true) {
                if ((v15 = (cfr_temp_4 = TwLootModule.\u13e8 - (29139L ^ 6779958601857244362L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v15 == (32172 ^ -32173)) break;
                v15 = 3458 ^ -54223084;
            }
            v16 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl100
            block97: while (true) {
                v16 = v17 / (13796L ^ 7377021224452610208L);
lbl100:
                // 2 sources

                switch ((int)v16) {
                    case -1582051213: {
                        v17 = 5556L ^ 5494494055652769354L;
                        continue block97;
                    }
                    case -1335009722: {
                        break block97;
                    }
                    case 636245981: {
                        v17 = 13483L ^ -6618787814743497090L;
                        continue block97;
                    }
                    case 1417860134: {
                        v17 = 27105L ^ -5013998267606646310L;
                        continue block97;
                    }
                }
                break;
            }
            if (v14.has((NpcExtraFlag)NpcExtra.LEECH_ONLY)) ** GOTO lbl-1000
        }
        v18 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl118
        block98: while (true) {
            v18 = (32472L ^ 7572300863707780320L) / (23864L ^ 8680002376017881628L);
lbl118:
            // 2 sources

            switch ((int)v18) {
                case -1342063390: {
                    continue block98;
                }
                case -1335009722: {
                    break block98;
                }
            }
            break;
        }
        v19 = n.npcInfo;
        while (true) {
            if ((v20 = (cfr_temp_5 = TwLootModule.\u13e8 - (-6312779458398816004L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
            if (v20 == (19085 ^ -19086)) break;
            v20 = 15481 ^ -269495934;
        }
        v21 = v19.extra;
        v22 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl134
        block100: while (true) {
            v22 = v23 / (21168L ^ 3610856686315054761L);
lbl134:
            // 2 sources

            switch ((int)v22) {
                case -1918434849: {
                    v23 = 9096665400642089884L >>> "\u0000\u0000".length();
                    continue block100;
                }
                case -1335009722: {
                    break block100;
                }
                case -1203774257: {
                    v23 = 13128L ^ 625511176335848635L;
                    continue block100;
                }
            }
            break;
        }
        v24 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl147
        block101: while (true) {
            v24 = (5725L ^ 578344694247820744L) / (4368L ^ -6290264901656906915L);
lbl147:
            // 2 sources

            switch ((int)v24) {
                case -1905422373: {
                    continue block101;
                }
                case -1335009722: {
                    break block101;
                }
            }
            break;
        }
        if (!v21.has((NpcExtraFlag)NpcExtra.IGNORE_ATTACKED) && attacked) ** GOTO lbl-1000
        while (true) {
            if ((v25 = (cfr_temp_6 = TwLootModule.\u13e8 - (21331L ^ -6347832205779055526L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
            if (v25 == (7536 ^ 7537)) break;
            v25 = 9481 ^ 1631436941;
        }
        v26 = n.npcInfo;
        while (true) {
            if ((v27 = (cfr_temp_7 = TwLootModule.\u13e8 - (11070L ^ -3278554173208926887L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
            if (v27 == (9156 ^ 9157)) break;
            v27 = -501908496 >>> "\u0000\u0000".length();
        }
        v28 = v26.extra;
        while (true) {
            if ((v29 = (cfr_temp_8 = TwLootModule.\u13e8 - (4028271174531076584L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
            if (v29 == (4890 ^ -4891)) break;
            v29 = 16104 ^ -764543625;
        }
        v30 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl174
        block105: while (true) {
            v30 = v31 / (8552L ^ 5603495071348635656L);
lbl174:
            // 2 sources

            switch ((int)v30) {
                case -1335009722: {
                    break block105;
                }
                case -477967722: {
                    v31 = 14161L ^ -99624708863841747L;
                    continue block105;
                }
                case 130603751: {
                    v31 = 7650917692546326360L >>> "\u0000\u0000".length();
                    continue block105;
                }
                case 1373937279: {
                    v31 = 10791L ^ -6767463157686090998L;
                    continue block105;
                }
            }
            break;
        }
        if (v28.has((NpcExtraFlag)NpcExtra.ATTACK_SECOND) && !attacked) ** GOTO lbl-1000
        v32 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl191
        block106: while (true) {
            v32 = v33 / (8285L ^ 5665012460147848794L);
lbl191:
            // 2 sources

            switch ((int)v32) {
                case -1335009722: {
                    break block106;
                }
                case -161979225: {
                    v33 = 19248L ^ 1809857801946492288L;
                    continue block106;
                }
                case 683159710: {
                    v33 = 6846L ^ 5376326461258901563L;
                    continue block106;
                }
                case 1000843897: {
                    v33 = 193921250345665476L >>> "\u0000\u0000".length();
                    continue block106;
                }
            }
            break;
        }
        v34 = n.playerInfo;
        v35 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl208
        block107: while (true) {
            v35 = v36 / (8402L ^ -2879844271429970257L);
lbl208:
            // 2 sources

            switch ((int)v35) {
                case -1335009722: {
                    break block107;
                }
                case -1032839995: {
                    v36 = 26833L ^ -8648673347418416321L;
                    continue block107;
                }
                case -285335127: {
                    v36 = 20143L ^ 6021408466027636616L;
                    continue block107;
                }
                case 1720812642: {
                    v36 = 31197L ^ -113052789306444206L;
                    continue block107;
                }
            }
            break;
        }
        v37 = v34.username;
        var4_3 = new byte[9877 ^ 9875];
        var4_3[27528 ^ 27531] = 24086 ^ -24143;
        var4_3[237 ^ 238] = 26888 ^ 26983;
        var4_3[31791 ^ 31790] = 9942 ^ 9912;
        var4_3[21504 ^ 21504] = 7856 ^ 7929;
        var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 404 >>> "\u0000\u0000".length();
        var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 11053 ^ 11078;
        var4_3[14067 ^ 14065] = 1088 ^ 1078;
        v38 = new String(var4_3);
        while (true) {
            if ((v39 = (cfr_temp_9 = TwLootModule.\u13e8 - (18473L ^ 3571278775517610629L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
            if (v39 == (16190 ^ -16191)) break;
            v39 = 28508 ^ 1516545786;
        }
        if (v37.contains(v38)) ** GOTO lbl-1000
        v40 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl240
        block109: while (true) {
            v40 = (850L ^ -6969388273540997935L) / (6063L ^ 4773849151115830923L);
lbl240:
            // 2 sources

            switch ((int)v40) {
                case -1335009722: {
                    break block109;
                }
                case 1643647215: {
                    continue block109;
                }
            }
            break;
        }
        v41 = n.npcInfo;
        v42 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl250
        block110: while (true) {
            v42 = v43 / (8916L ^ -3933500694975046648L);
lbl250:
            // 2 sources

            switch ((int)v42) {
                case -2131677957: {
                    v43 = 22826L ^ 8056685766864655351L;
                    continue block110;
                }
                case -2031061902: {
                    v43 = 2000L ^ -4902431206971737103L;
                    continue block110;
                }
                case -1335009722: {
                    break block110;
                }
                case -456331360: {
                    v43 = 79L ^ 7770618510372468488L;
                    continue block110;
                }
            }
            break;
        }
        v44 = v41.extra;
        v45 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl267
        block111: while (true) {
            v45 = (21351L ^ -2423226187048243121L) / (4089L ^ -2593415943718306263L);
lbl267:
            // 2 sources

            switch ((int)v45) {
                case -1335009722: {
                    break block111;
                }
                case -1217336635: {
                    continue block111;
                }
            }
            break;
        }
        v46 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl276
        block112: while (true) {
            v46 = v47 / (15997L ^ 5085846957342739649L);
lbl276:
            // 2 sources

            switch ((int)v46) {
                case -2060599638: {
                    v47 = 12630L ^ -7667439252732883134L;
                    continue block112;
                }
                case -1335009722: {
                    break block112;
                }
                case 1306106589: {
                    v47 = 11978L ^ -6957671905235379993L;
                    continue block112;
                }
            }
            break;
        }
        if (!v44.has((NpcExtraFlag)NpcExtra.PASSIVE)) ** GOTO lbl-1000
        v48 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl290
        block113: while (true) {
            v48 = v49 / (6041607183555654424L >>> "\u0000\u0000".length());
lbl290:
            // 2 sources

            switch ((int)v48) {
                case -1916449196: {
                    v49 = 23325L ^ 6915323917826376103L;
                    continue block113;
                }
                case -1335009722: {
                    break block113;
                }
                case -1265543787: {
                    v49 = 9450L ^ 2569373482738721985L;
                    continue block113;
                }
                case -823436318: {
                    v49 = 21182L ^ 6355214060572998938L;
                    continue block113;
                }
            }
            break;
        }
        while (true) {
            if ((v50 = (cfr_temp_10 = TwLootModule.\u13e8 - (27284L ^ -8017244682613188456L)) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
            if (v50 == (11609 ^ 11608)) break;
            v50 = 23553 ^ -1559229069;
        }
        if (n.isAttacking((Ship)this.hero)) lbl-1000:
        // 3 sources

        {
            v51 = 17125 ^ 17124;
        } else lbl-1000:
        // 6 sources

        {
            v51 = "".length() >>> "\u0000\u0000".length();
        }
        return (boolean)v51;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    @Override
    public Npc getAttackTarget() {
        long l = \u13e8;
        boolean bl = true;
        block6: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x6BB6L ^ 0x5C6DF214DED24BF5L);
            }
            switch ((int)l) {
                case -1335009722: {
                    break block6;
                }
                case -479539159: {
                    l2 = 0x7A87L ^ 0xACAC5CD3202E61CDL;
                    continue block6;
                }
                case 487562766: {
                    l2 = 0x222BL ^ 0x5E2D635730CE76D4L;
                    continue block6;
                }
                case 1631019610: {
                    l2 = 0x7BDFL ^ 0x48D8C1B223F52353L;
                    continue block6;
                }
            }
            break;
        }
        while (true) {
            long l3;
            long l4;
            if ((l4 = (l3 = \u13e8 - (0x11F2L ^ 0x6D5B8163A29761D7L)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l4 == (0x4A6E ^ 0xFFFFB591)) {
                return this.attack.target;
            }
            l4 = 0x4A61 ^ 0x746918E6;
        }
    }

    @Override
    public boolean checkDangerousAndCurrentMapPub(BooleanSupplier withRefreshPeriod) {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x712CL ^ 0x21B5CCE3DC6797DDL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == (0x9BF ^ 0xFFFFF640)) break;
            l2 = 0x7DA5 ^ 0x7A852C65;
        }
        return this.checkDangerousAndCurrentMap(withRefreshPeriod);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public boolean findTargetPub() {
        long l = \u13e8;
        block4: while (true) {
            switch ((int)l) {
                case -1335009722: {
                    return this.findTarget();
                }
                case -285848507: {
                    l = (0x67A1L ^ 0x4239DA8CE30FF8D7L) / (0x7CF6L ^ 0xAF243B8B56A3508EL);
                    continue block4;
                }
            }
            break;
        }
        return this.findTarget();
    }

    @Override
    public void moveToSafePosition() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x1663L ^ 0x2329493482D95EC2L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x67F7 ^ 0xFFFF9808)) break;
            l2 = 0x2C51 ^ 0x83C473B1;
        }
        this.moveToAnSafePosition();
    }

    @Override
    public void ignoreTarget() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0xDB7L ^ 0xE9FDA72CA6199147L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x1BD1 ^ 0xFFFFE42E)) break;
            l2 = 0x54D7 ^ 0xB7989020;
        }
        this.ignoreInvalidTarget();
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    @Override
    public void doAttackKillTargetTick() {
        long l = \u13e8;
        boolean bl = true;
        block10: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x68F1L ^ 0x51425C170159C3F8L);
            }
            switch ((int)l) {
                case -1335009722: {
                    break block10;
                }
                case -1066427913: {
                    l2 = 0x10EEL ^ 0xAC9B11B018508150L;
                    continue block10;
                }
                case 1004889213: {
                    l2 = 0x5E99L ^ 0x8FAB3D1FE6D18D79L;
                    continue block10;
                }
                case 2101233080: {
                    l2 = 0x57B6L ^ 0xA8F082D2B4377DB7L;
                    continue block10;
                }
            }
            break;
        }
        long l3 = \u13e8;
        block11: while (true) {
            switch ((int)l3) {
                case -1335009722: {
                    break block11;
                }
                case -898857853: {
                    l3 = (0x7A85L ^ 0x74C0A4A0B166051EL) / (0x1479L ^ 0x11BD02DE921B4848L);
                    continue block11;
                }
            }
            break;
        }
        this.attack.doKillTargetTick();
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    @Override
    public boolean npcSubnameInPreferredRegion(String npcSubName) {
        long l = \u13e8;
        boolean bl = true;
        block20: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x44ABL ^ 0x6D551F208C94CDFEL);
            }
            switch ((int)l) {
                case -1335009722: {
                    break block20;
                }
                case -745343022: {
                    l2 = 0x2161L ^ 0x32BBDF011F67E310L;
                    continue block20;
                }
                case 716029311: {
                    l2 = 0x3394L ^ 0x3A0F15EB320DC84AL;
                    continue block20;
                }
            }
            break;
        }
        long l3 = \u13e8;
        boolean bl2 = true;
        block21: while (true) {
            long l4;
            if (!bl2 || (bl2 = false) || !true) {
                l3 = l4 / (0x66A9L ^ 0x7349588CDDD52DE0L);
            }
            switch ((int)l3) {
                case -1335009722: {
                    break block21;
                }
                case -689797263: {
                    l4 = 8027168833301559964L >>> "\u0000\u0000".length();
                    continue block21;
                }
                case -112768713: {
                    l4 = 0x1B89L ^ 0x155CDAD1C0A1EA29L;
                    continue block21;
                }
                case 436763336: {
                    l4 = -774718190525849456L >>> "\u0000\u0000".length();
                    continue block21;
                }
            }
            break;
        }
        Stream stream = this.npcs.stream();
        long l5 = \u13e8;
        block22: while (true) {
            switch ((int)l5) {
                case -1411621888: {
                    l5 = (0x1EFBL ^ 0x5966F48744863981L) / (-5343694174372409852L >>> "\u0000\u0000".length());
                    continue block22;
                }
                case -1335009722: {
                    break block22;
                }
            }
            break;
        }
        Predicate<Npc> predicate = arg_0 -> this.lambda$npcSubnameInPreferredRegion$10(npcSubName, arg_0);
        long l6 = \u13e8;
        boolean bl3 = true;
        block23: while (true) {
            long l7;
            if (!bl3 || (bl3 = false) || !true) {
                l6 = l7 / (0x1704L ^ 0xF42D14A2AD7EBA99L);
            }
            switch ((int)l6) {
                case -1349584734: {
                    l7 = 0x6156L ^ 0xC040D1B443BD9405L;
                    continue block23;
                }
                case -1335009722: {
                    return stream.anyMatch(predicate);
                }
                case -1256328594: {
                    l7 = 0x4012L ^ 0xD5C1E0CDEDF2D940L;
                    continue block23;
                }
            }
            break;
        }
        return stream.anyMatch(predicate);
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public void setConfig(TwLootModuleConfig betterLootModuleConfig) {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x29F1L ^ 0xE423A5D2C7257C3EL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x70E8 ^ 0xFFFF8F17)) break;
            l2 = 0x418F ^ 0x515D5C66;
        }
        this.twLootModuleConfig = betterLootModuleConfig;
        long l = \u13e8;
        block10: while (true) {
            switch ((int)l) {
                case -1335009722: {
                    break block10;
                }
                case 1940948580: {
                    l = (0x3062L ^ 0xA0E5C8CC74ADF440L) / (0x6B20L ^ 0x8EC3A87A8BB35315L);
                    continue block10;
                }
            }
            break;
        }
        long l3 = \u13e8;
        boolean bl = true;
        block11: while (true) {
            long l4;
            if (!bl || (bl = false) || !true) {
                l3 = l4 / (0x4ADEL ^ 0xE05B0EC2DC016E23L);
            }
            switch ((int)l3) {
                case -1335009722: {
                    break block11;
                }
                case -559968721: {
                    l4 = 0x49DDL ^ 0xDB21ACA1BE10D716L;
                    continue block11;
                }
                case 1673048664: {
                    l4 = 0x18BCL ^ 0xADDDB6B911B7692CL;
                    continue block11;
                }
            }
            break;
        }
        this.attack.setConfig(betterLootModuleConfig);
    }

    /*
     * Unable to fully structure code
     */
    private /* synthetic */ boolean lambda$npcSubnameInPreferredRegion$10(String npcSubName, Npc npc) {
        while (true) {
            if ((v0 = (cfr_temp_0 = TwLootModule.\u13e8 - (8568012775168449664L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (22913 ^ -22914)) break;
            v0 = 2368 ^ 1082731122;
        }
        v1 = npc.playerInfo;
        while (true) {
            if ((v2 = (cfr_temp_1 = TwLootModule.\u13e8 - (8559264635712674676L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v2 == (21297 ^ -21298)) break;
            v2 = 30747 ^ -637268453;
        }
        v3 = v1.username;
        v4 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl17
        block34: while (true) {
            v4 = v5 / (1163L ^ 1059122044568373985L);
lbl17:
            // 2 sources

            switch ((int)v4) {
                case -2113698213: {
                    v5 = 21282L ^ 8865022426507353443L;
                    continue block34;
                }
                case -1335009722: {
                    break block34;
                }
                case -140228678: {
                    v5 = 20565L ^ -535667240988808276L;
                    continue block34;
                }
                case 450902939: {
                    v5 = 31169L ^ -5746228991730766087L;
                    continue block34;
                }
            }
            break;
        }
        v6 = v3.toLowerCase();
        v7 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl34
        block35: while (true) {
            v7 = v8 / (1227L ^ 6738182282049777022L);
lbl34:
            // 2 sources

            switch ((int)v7) {
                case -1335009722: {
                    break block35;
                }
                case 95991668: {
                    v8 = 2301L ^ -362685615327944022L;
                    continue block35;
                }
                case 207353789: {
                    v8 = 31214L ^ -3447667375197576767L;
                    continue block35;
                }
                case 1409710521: {
                    v8 = 2557L ^ -4001798031593040522L;
                    continue block35;
                }
            }
            break;
        }
        v9 = npcSubName.toLowerCase();
        while (true) {
            if ((v10 = (cfr_temp_2 = TwLootModule.\u13e8 - (-2815456100733628424L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v10 == (1016 ^ -1017)) break;
            v10 = 31432 ^ -1330814803;
        }
        if (!v6.contains(v9)) ** GOTO lbl-1000
        v11 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl57
        block37: while (true) {
            v11 = v12 / (2965L ^ -4894273697637119501L);
lbl57:
            // 2 sources

            switch ((int)v11) {
                case -1335009722: {
                    break block37;
                }
                case -825355298: {
                    v12 = 16311L ^ 4352911458440206138L;
                    continue block37;
                }
                case 2015054310: {
                    v12 = 519L ^ -6517327128046614969L;
                    continue block37;
                }
            }
            break;
        }
        v13 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl70
        block38: while (true) {
            v13 = v14 / (10978L ^ 7421066323796853431L);
lbl70:
            // 2 sources

            switch ((int)v13) {
                case -1546115091: {
                    v14 = 23618L ^ -5972797237799596079L;
                    continue block38;
                }
                case -1335009722: {
                    break block38;
                }
                case -564463479: {
                    v14 = 1994L ^ -4076704048090022987L;
                    continue block38;
                }
            }
            break;
        }
        v15 = this.main.mapManager;
        while (true) {
            if ((v16 = (cfr_temp_3 = TwLootModule.\u13e8 - (12059L ^ 6339989984133059815L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v16 == (7759 ^ -7760)) break;
            v16 = 13667 ^ -1777674377;
        }
        v17 = v15.preferred;
        v18 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl90
        block40: while (true) {
            v18 = v19 / (23866L ^ 1752169535005694019L);
lbl90:
            // 2 sources

            switch ((int)v18) {
                case -1335009722: {
                    break block40;
                }
                case -819178869: {
                    v19 = 16679L ^ -6121190956990498801L;
                    continue block40;
                }
                case -494071405: {
                    v19 = 5755L ^ -5580630821191937969L;
                    continue block40;
                }
                case 2007756222: {
                    v19 = 12891L ^ -1438684910163516496L;
                    continue block40;
                }
            }
            break;
        }
        v20 = npc.locationInfo;
        v21 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl107
        block41: while (true) {
            v21 = (3887269581094420692L >>> "\u0000\u0000".length()) / (7228L ^ 6856665346436605929L);
lbl107:
            // 2 sources

            switch ((int)v21) {
                case -1335009722: {
                    break block41;
                }
                case 350540920: {
                    continue block41;
                }
            }
            break;
        }
        v22 = v20.now;
        while (true) {
            if ((v23 = (cfr_temp_4 = TwLootModule.\u13e8 - (10518L ^ 7417370822647051024L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v23 == (31551 ^ -31552)) break;
            v23 = 27963 ^ -669269759;
        }
        if (v17.contains(v22)) {
            v24 = 28437 ^ 28436;
        } else lbl-1000:
        // 2 sources

        {
            v24 = 14953 ^ 14953;
        }
        return (boolean)v24;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private static /* synthetic */ Double lambda$closestNpc$9(Location location, Npc n) {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x5673L ^ 0xE9D2D3E6383B3808L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x7B3B ^ 0xFFFF84C4)) break;
            l2 = -2066803140 >>> "\u0000\u0000".length();
        }
        LocationInfo locationInfo = n.locationInfo;
        long l = \u13e8;
        block15: while (true) {
            switch ((int)l) {
                case -1335009722: {
                    break block15;
                }
                case 1571639378: {
                    l = (0x5FB1L ^ 0x66D8E8BD3DF75EB7L) / (0x1B99L ^ 0xFF998907A2F834FAL);
                    continue block15;
                }
            }
            break;
        }
        Location location2 = locationInfo.now;
        long l3 = \u13e8;
        block16: while (true) {
            switch ((int)l3) {
                case -1335009722: {
                    break block16;
                }
                case 998198879: {
                    l3 = (0x1205L ^ 0xC90CB7CE339F82F7L) / (0x60BEL ^ 0xCF63944C43AEA87EL);
                    continue block16;
                }
            }
            break;
        }
        double d = location2.distance(location);
        long l4 = \u13e8;
        boolean bl = true;
        block17: while (true) {
            long l5;
            if (!bl || (bl = false) || !true) {
                l4 = l5 / (0x1B2EL ^ 0x5706A9A2F27F6DCEL);
            }
            switch ((int)l4) {
                case -1335009722: {
                    return d;
                }
                case -1288238663: {
                    l5 = 2107064354261741992L >>> "\u0000\u0000".length();
                    continue block17;
                }
                case -586306259: {
                    l5 = 0x342DL ^ 0x5630F0F0B52C087AL;
                    continue block17;
                }
                case -514249611: {
                    l5 = -7840729848997151072L >>> "\u0000\u0000".length();
                    continue block17;
                }
            }
            break;
        }
        return d;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private static /* synthetic */ Double lambda$closestNpc$8(Npc n) {
        long l = \u13e8;
        boolean bl = true;
        block5: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x570AL ^ 0xF5BDC2AABBC7D546L);
            }
            switch ((int)l) {
                case -1335009722: {
                    break block5;
                }
                case 1251398012: {
                    l2 = 0x6E9EL ^ 0xB2D44D917BE0646DL;
                    continue block5;
                }
                case 1528723221: {
                    l2 = 0x74B4L ^ 0xD863168B87FE3E7CL;
                    continue block5;
                }
            }
            break;
        }
        Health health = n.health;
        while (true) {
            long l3;
            long l4;
            if ((l4 = (l3 = \u13e8 - (0x377AL ^ 0xC8C1D19E57C92461L)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) continue;
            if (l4 == (0x1818 ^ 0x1819)) break;
            l4 = 0x116A ^ 0x1EAED999;
        }
        double d = health.hpPercent();
        while (true) {
            long l5;
            long l6;
            if ((l6 = (l5 = \u13e8 - (0x29FAL ^ 0x5F0240079E0C19DFL)) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) continue;
            if (l6 == (0x1B0A ^ 0xFFFFE4F5)) {
                return d;
            }
            l6 = 0x5EB8 ^ 0xAD1B7338;
        }
    }

    private /* synthetic */ int lambda$closestNpc$7(int extraPriority, Npc n) {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x945L ^ 0xFA36878183D5A2B9L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x175F ^ 0xFFFFE8A0)) break;
            l2 = -474553628 >>> "\u0000\u0000".length();
        }
        NpcInfo npcInfo = n.npcInfo;
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = \u13e8 - (0x3462L ^ 0x71EA241931ABAB62L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l3 == (0x81E ^ 0xFFFFF7E1)) break;
            l3 = 0x197C ^ 0x7FF72891;
        }
        int n2 = npcInfo.priority;
        while (true) {
            long l;
            long l4;
            if ((l4 = (l = \u13e8 - (0x67FAL ^ 0xDE734D6392DC8CA6L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l4 == (0x3793 ^ 0xFFFFC86C)) break;
            l4 = 0x5C38 ^ 0xB3F67A94;
        }
        while (true) {
            long l;
            long l5;
            if ((l5 = (l = \u13e8 - (0x451L ^ 0x92A3CD8839FA6A16L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l5 == (0x34C6 ^ 0x34C7)) break;
            l5 = 0x2B1F ^ 0x8A71B377;
        }
        return n2 - (n == this.attack.target ? extraPriority : "".length() >>> "\u0000\u0000".length());
    }

    /*
     * Unable to fully structure code
     */
    private /* synthetic */ boolean lambda$closestNpc$6(Npc n) {
        block57: {
            block56: {
                while (true) {
                    if ((v0 = (cfr_temp_0 = TwLootModule.\u13e8 - (3658L ^ -7448824379950644843L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                    if (v0 == (21133 ^ 21132)) break;
                    v0 = 131 ^ 910784259;
                }
                v1 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl10
                block33: while (true) {
                    v1 = (4384L ^ -2718625853436977880L) / (6617L ^ -7376126300837992567L);
lbl10:
                    // 2 sources

                    switch ((int)v1) {
                        case -1335009722: {
                            break block33;
                        }
                        case -381430010: {
                            continue block33;
                        }
                    }
                    break;
                }
                if (n != this.attack.target) break block56;
                v2 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl20
                block34: while (true) {
                    v2 = v3 / (7640L ^ -2081685125210367307L);
lbl20:
                    // 2 sources

                    switch ((int)v2) {
                        case -2036428776: {
                            v3 = 26320L ^ 5294338131762775558L;
                            continue block34;
                        }
                        case -1371884871: {
                            v3 = 19263L ^ 6684717175640899912L;
                            continue block34;
                        }
                        case -1335009722: {
                            break block34;
                        }
                        case 1197917086: {
                            v3 = 19834L ^ -1105217288195191624L;
                            continue block34;
                        }
                    }
                    break;
                }
                while (true) {
                    if ((v4 = (cfr_temp_1 = TwLootModule.\u13e8 - (27198L ^ 6454007455778421723L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                    if (v4 == (27165 ^ -27166)) break;
                    v4 = 10391 ^ -418674355;
                }
                v5 = TwLootModule.\u13e8;
                if (true) ** GOTO lbl41
                block36: while (true) {
                    v5 = v6 / (4914693030866812488L >>> "\u0000\u0000".length());
lbl41:
                    // 2 sources

                    switch ((int)v5) {
                        case -1978240245: {
                            v6 = 7509L ^ -8367373707466378072L;
                            continue block36;
                        }
                        case -1335009722: {
                            break block36;
                        }
                        case 1431837444: {
                            v6 = 7869L ^ 8982154736772676615L;
                            continue block36;
                        }
                    }
                    break;
                }
                v7 = this.attack.target;
                while (true) {
                    if ((v8 = (cfr_temp_2 = TwLootModule.\u13e8 - (15234L ^ 3057270490601020982L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                    if (v8 == (8326 ^ -8327)) break;
                    v8 = 21024 ^ -1834687533;
                }
                if (this.hero.isAttacking((Ship)v7)) ** GOTO lbl-1000
            }
            while (true) {
                if ((v9 = (cfr_temp_3 = TwLootModule.\u13e8 - (14066L ^ -7989487324145432453L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v9 == (13487 ^ 13486)) break;
                v9 = 11480 ^ -609331868;
            }
            v10 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl67
            block39: while (true) {
                v10 = v11 / (1718L ^ 1738282646422990034L);
lbl67:
                // 2 sources

                switch ((int)v10) {
                    case -2043801479: {
                        v11 = 9993L ^ -7665509751970318326L;
                        continue block39;
                    }
                    case -1335009722: {
                        break block39;
                    }
                    case 472754254: {
                        v11 = 15805L ^ 6127085680065756503L;
                        continue block39;
                    }
                    case 816556304: {
                        v11 = 70L ^ -454046626479966505L;
                        continue block39;
                    }
                }
                break;
            }
            v12 = this.config.GENERAL;
            v13 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl84
            block40: while (true) {
                v13 = v14 / (29368L ^ -2306694432154738004L);
lbl84:
                // 2 sources

                switch ((int)v13) {
                    case -1335009722: {
                        break block40;
                    }
                    case -176941727: {
                        v14 = 5023L ^ 1174001611597338930L;
                        continue block40;
                    }
                    case 68960265: {
                        v14 = 3601L ^ -7048350391940069598L;
                        continue block40;
                    }
                    case 2008435510: {
                        v14 = 7731066096177082268L >>> "\u0000\u0000".length();
                        continue block40;
                    }
                }
                break;
            }
            v15 = v12.ROAMING;
            while (true) {
                if ((v16 = (cfr_temp_4 = TwLootModule.\u13e8 - (20014L ^ -7851332833685938998L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v16 == (14490 ^ 14491)) break;
                v16 = 4326 ^ 1893501235;
            }
            if (!v15.ONLY_KILL_PREFERRED) break block57;
            while (true) {
                if ((v17 = (cfr_temp_5 = TwLootModule.\u13e8 - (27113L ^ -6359497940735123129L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                if (v17 == (32312 ^ 32313)) break;
                v17 = 31654 ^ 1246652102;
            }
            v18 = TwLootModule.\u13e8;
            if (true) ** GOTO lbl112
            block43: while (true) {
                v18 = v19 / (5563L ^ -6902102559284196733L);
lbl112:
                // 2 sources

                switch ((int)v18) {
                    case -2134786292: {
                        v19 = 20264L ^ -9011243095703443950L;
                        continue block43;
                    }
                    case -1335009722: {
                        break block43;
                    }
                    case 307420563: {
                        v19 = 5763L ^ -5710305334406999338L;
                        continue block43;
                    }
                }
                break;
            }
            v20 = this.main.mapManager;
            while (true) {
                if ((v21 = (cfr_temp_6 = TwLootModule.\u13e8 - (22767L ^ -1229923739532504501L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                if (v21 == (25340 ^ -25341)) break;
                v21 = 29089 ^ -437242786;
            }
            v22 = v20.preferred;
            while (true) {
                if ((v23 = (cfr_temp_7 = TwLootModule.\u13e8 - (10424L ^ -5742872347072168941L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                if (v23 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v23 = 15004 ^ -1327376533;
            }
            v24 = n.locationInfo;
            while (true) {
                if ((v25 = (cfr_temp_8 = TwLootModule.\u13e8 - (19538L ^ 7171495644810037809L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                if (v25 == (26118 ^ -26119)) break;
                v25 = 16335 ^ 1614830371;
            }
            v26 = v24.now;
            while (true) {
                if ((v27 = (cfr_temp_9 = TwLootModule.\u13e8 - (24891L ^ 4135345379943787879L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
                if (v27 == (21790 ^ -21791)) break;
                v27 = 15192 ^ -169982222;
            }
            if (!v22.contains(v26)) ** GOTO lbl-1000
        }
        while (true) {
            if ((v28 = (cfr_temp_10 = TwLootModule.\u13e8 - (11551L ^ -8556525519761742620L)) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
            if (v28 == (2098 ^ 2099)) break;
            v28 = 22042 ^ -391919305;
        }
        if (this.shouldKill(n)) {
            while (true) {
                if ((v29 = (cfr_temp_11 = TwLootModule.\u13e8 - (6095L ^ -2173077720280254074L)) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
                if (v29 == (1406 ^ -1407)) break;
                v29 = 31153 ^ -918380901;
            }
            while (true) {
                if ((v30 = (cfr_temp_12 = TwLootModule.\u13e8 - (3365L ^ 7839383916106513001L)) == 0L ? 0 : (cfr_temp_12 < 0L ? -1 : 1)) == false) continue;
                if (v30 == (30026 ^ -30027)) break;
                v30 = 25000 ^ 1686182572;
            }
            v31 = n.locationInfo;
            while (true) {
                if ((v32 = (cfr_temp_13 = TwLootModule.\u13e8 - (-2359362143820195844L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_13 < 0L ? -1 : 1)) == false) continue;
                if (v32 == (2839 ^ -2840)) break;
                v32 = 14625 ^ -1904269916;
            }
            v33 = v31.now;
            while (true) {
                if ((v34 = (cfr_temp_14 = TwLootModule.\u13e8 - (-6851198809527971240L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_14 < 0L ? -1 : 1)) == false) continue;
                if (v34 == (9552 ^ -9553)) break;
                v34 = 26910 ^ 1590969800;
            }
            ** if (!(this.drive.closestDistance((Location)v33) < 500.0)) goto lbl-1000
        }
        ** GOTO lbl-1000
lbl-1000:
        // 2 sources

        {
            v35 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
            ** GOTO lbl180
        }
lbl-1000:
        // 3 sources

        {
            v35 = "".length() >>> "\u0000\u0000".length();
        }
lbl180:
        // 2 sources

        return (boolean)v35;
    }

    /*
     * Unable to fully structure code
     */
    private static /* synthetic */ double lambda$score$5(Location loc, Npc n) {
        while (true) {
            if ((v0 = (cfr_temp_0 = TwLootModule.\u13e8 - (31188L ^ -7931040776520975639L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (15591 ^ 15590)) break;
            v0 = 29889 ^ -127195569;
        }
        v1 = n.npcInfo;
        while (true) {
            if ((v2 = (cfr_temp_1 = TwLootModule.\u13e8 - (30303L ^ 8414314255438058928L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v2 == (29022 ^ -29023)) break;
            v2 = 29232 ^ -860265130;
        }
        v3 = v1.radius;
        while (true) {
            if ((v4 = (cfr_temp_2 = TwLootModule.\u13e8 - (31221L ^ 5620677354282512583L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v4 == (15318 ^ -15319)) break;
            v4 = 7223 ^ -1352901742;
        }
        v5 = n.locationInfo;
        while (true) {
            if ((v6 = (cfr_temp_3 = TwLootModule.\u13e8 - (30341L ^ 6082145603345436588L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v6 == (14752 ^ -14753)) break;
            v6 = 19142 ^ -559480187;
        }
        v7 = v5.now;
        v8 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl29
        block14: while (true) {
            v8 = v9 / (27585L ^ 6650765776055057900L);
lbl29:
            // 2 sources

            switch ((int)v8) {
                case -1922949108: {
                    v9 = 21046L ^ 7051236022519349604L;
                    continue block14;
                }
                case -1335009722: {
                    break block14;
                }
                case -901868036: {
                    v9 = 11231L ^ -4078737161816502983L;
                    continue block14;
                }
            }
            break;
        }
        v10 = v3 - v7.distance(loc);
        v11 = TwLootModule.\u13e8;
        if (true) ** GOTO lbl43
        block15: while (true) {
            v11 = v12 / (6338L ^ -4861684157458975689L);
lbl43:
            // 2 sources

            switch ((int)v11) {
                case -1985025146: {
                    v12 = 26401L ^ 5289204218187463992L;
                    continue block15;
                }
                case -1335009722: {
                    break block15;
                }
                case -3585306: {
                    v12 = 16530L ^ -3399226936829272125L;
                    continue block15;
                }
            }
            break;
        }
        return Math.max(0.0, v10);
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private /* synthetic */ boolean lambda$score$4(Npc n) {
        int n2;
        long l = \u13e8;
        boolean bl = true;
        block10: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x3193L ^ 0x4503107CC229DAD1L);
            }
            switch ((int)l) {
                case -1335009722: {
                    break block10;
                }
                case -1244469303: {
                    l2 = 0x1E99L ^ 0x873B4CCB7E383E1AL;
                    continue block10;
                }
                case 814179331: {
                    l2 = 4095559579161974676L >>> "\u0000\u0000".length();
                    continue block10;
                }
                case 1357887758: {
                    l2 = 0x594DL ^ 0xF9BD24B8D9040A27L;
                    continue block10;
                }
            }
            break;
        }
        long l3 = \u13e8;
        block11: while (true) {
            switch ((int)l3) {
                case -1335009722: {
                    break block11;
                }
                case -1272375394: {
                    l3 = (0x5A18L ^ 0x1D26AB297E366457L) / (0x48BCL ^ 0x19C5BB0C28B981C0L);
                    continue block11;
                }
            }
            break;
        }
        if (this.attack.target != n) {
            n2 = 0x5C9E ^ 0x5C9F;
            return n2 != 0;
        }
        n2 = "".length() >>> "\u0000\u0000".length();
        return n2 != 0;
    }

    private static /* synthetic */ boolean lambda$checkDangerousAndCurrentMap$3() {
        return (0x904 ^ 0x905) != 0;
    }
}

