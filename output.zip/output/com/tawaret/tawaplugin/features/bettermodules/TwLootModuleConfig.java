/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.config.types.Num
 *  com.github.manolo8.darkbot.config.types.Option
 */
package com.tawaret.tawaplugin.features.bettermodules;

import com.github.manolo8.darkbot.config.types.Num;
import com.github.manolo8.darkbot.config.types.Option;
import com.tawaret.tawaplugin.features.maptravellers.TwMapTravellerConfig;

public class TwLootModuleConfig {
    @Option(value="Attack only from preferred region", description="Ignores npcs until your ship is in a preferred region")
    public boolean ATTACK_ONLY_FROM_PREFERRED_REGION;
    @Option(value="Use RSB on first attack")
    public boolean USE_RSB_FOR_FIRST_ATTACK;
    @Option(value="RSB switch delay (Ms)")
    @Num(min=250, max=1000, step=5)
    public int RSB_SWITCH_DELAY;
    @Option(value="Enable instant attack")
    public boolean INSTANT_LOCK;
    @Option(value="Map Traveller")
    public TwMapTravellerConfig MAP_TRAVELLER_CONFIG;
    static long \u13e8 = -2817362007476062060L;

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public TwLootModuleConfig() {
        long l = \u13e8;
        boolean bl = true;
        block10: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x72CDL ^ 0xCF7D0A56443CFC97L);
            }
            switch ((int)l) {
                case -625978445: {
                    l2 = 0x4FBEL ^ 0xF1DD0F8991FE0721L;
                    continue block10;
                }
                case 997001388: {
                    l2 = 0xFDDL ^ 0xE5121839DC357BFCL;
                    continue block10;
                }
                case 1689598100: {
                    break block10;
                }
                case 1872935929: {
                    l2 = 0x2228L ^ 0xB72D47A4CA686435L;
                    continue block10;
                }
            }
            break;
        }
        int n = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        while (true) {
            long l3;
            long l4;
            if ((l4 = (l3 = \u13e8 - (0x5368L ^ 0x5BAA53E5E3C16C1DL)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) continue;
            if (l4 == (0x5DE5 ^ 0xFFFFA21A)) break;
            l4 = 0x3515 ^ 0x79F101F3;
        }
        this.ATTACK_ONLY_FROM_PREFERRED_REGION = n;
        while (true) {
            long l5;
            long l6;
            if ((l6 = (l5 = \u13e8 - (0x731CL ^ 0x7B948D54112757B7L)) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) continue;
            if (l6 == (0x676D ^ 0xFFFF9892)) break;
            l6 = "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() ^ 0xD83632F4;
        }
        this.USE_RSB_FOR_FIRST_ATTACK = 0x4884 ^ 0x4884;
        int n2 = 1000 >>> "\u0000\u0000".length();
        while (true) {
            long l7;
            long l8;
            if ((l8 = (l7 = \u13e8 - (0x7578L ^ 0x5F3B3F92B9DE5258L)) == 0L ? 0 : (l7 < 0L ? -1 : 1)) == false) continue;
            if (l8 == (0x39A6 ^ 0xFFFFC659)) break;
            l8 = 0xA68 ^ 0x70C81505;
        }
        this.RSB_SWITCH_DELAY = n2;
        while (true) {
            long l9;
            long l10;
            if ((l10 = (l9 = \u13e8 - (0x21DFL ^ 0x91575415AD3A2ECBL)) == 0L ? 0 : (l9 < 0L ? -1 : 1)) == false) continue;
            if (l10 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l10 = 0x6F32 ^ 0xE3E080C3;
        }
        this.INSTANT_LOCK = 0x3B3C ^ 0x3B3C;
        while (true) {
            long l11;
            long l12;
            if ((l12 = (l11 = \u13e8 - (0x666CL ^ 0x3D342D956D618180L)) == 0L ? 0 : (l11 < 0L ? -1 : 1)) == false) continue;
            if (l12 == (0xA1 ^ 0xFFFFFF5E)) break;
            l12 = 0x6609 ^ 0x610EF8A4;
        }
        long l13 = \u13e8;
        block16: while (true) {
            switch ((int)l13) {
                case -906293167: {
                    l13 = (0x5DA3L ^ 0x70075A15CDD7DBA8L) / (0x7504L ^ 0x6779D7A27F049A30L);
                    continue block16;
                }
                case 1689598100: {
                    break block16;
                }
            }
            break;
        }
        TwMapTravellerConfig twMapTravellerConfig = new TwMapTravellerConfig();
        while (true) {
            long l14;
            long l15;
            if ((l15 = (l14 = \u13e8 - (0x7918L ^ 0x4A63BF1DA669BEDFL)) == 0L ? 0 : (l14 < 0L ? -1 : 1)) == false) continue;
            if (l15 == (0x3782 ^ 0xFFFFC87D)) {
                this.MAP_TRAVELLER_CONFIG = twMapTravellerConfig;
                return;
            }
            l15 = 0x6AF8 ^ 0xC9F3B8BF;
        }
    }
}

