/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.Main
 *  com.github.manolo8.darkbot.config.Config
 *  com.github.manolo8.darkbot.config.NpcExtra
 *  com.github.manolo8.darkbot.config.NpcExtraFlag
 *  com.github.manolo8.darkbot.core.entities.Entity
 *  com.github.manolo8.darkbot.core.itf.Module
 *  com.github.manolo8.darkbot.core.manager.HeroManager
 *  com.github.manolo8.darkbot.core.manager.PetManager
 *  com.github.manolo8.darkbot.core.utils.Drive
 *  com.github.manolo8.darkbot.modules.CollectorModule
 *  com.github.manolo8.darkbot.utils.I18n
 */
package com.tawaret.tawaplugin.features.bettermodules;

import com.github.manolo8.darkbot.Main;
import com.github.manolo8.darkbot.config.Config;
import com.github.manolo8.darkbot.config.NpcExtra;
import com.github.manolo8.darkbot.config.NpcExtraFlag;
import com.github.manolo8.darkbot.core.entities.Entity;
import com.github.manolo8.darkbot.core.itf.Module;
import com.github.manolo8.darkbot.core.manager.HeroManager;
import com.github.manolo8.darkbot.core.manager.PetManager;
import com.github.manolo8.darkbot.core.utils.Drive;
import com.github.manolo8.darkbot.modules.CollectorModule;
import com.github.manolo8.darkbot.utils.I18n;
import com.tawaret.tawaplugin.features.bettermodules.TwLootModule;

public class TwLootNCollectModule
implements Module {
    public TwLootModule lootModule;
    public CollectorModule collectorModule;
    protected PetManager pet;
    protected HeroManager hero;
    protected Drive drive;
    protected Config config;
    private static long \u13e8 = -715057202638724648L;

    /*
     * Unable to fully structure code
     */
    public TwLootNCollectModule() {
        while (true) {
            if ((v0 = (cfr_temp_0 = TwLootNCollectModule.\u13e8 - (24124L ^ -7241894524473088930L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v0 = 7371 ^ 1298201830;
        }
        super();
        v1 = TwLootNCollectModule.\u13e8;
        if (true) ** GOTO lbl11
        block15: while (true) {
            v1 = v2 / (29289L ^ -7881906246617824982L);
lbl11:
            // 2 sources

            switch ((int)v1) {
                case -306750268: {
                    v2 = 17975L ^ -7471146473093827673L;
                    continue block15;
                }
                case 1042892685: {
                    v2 = 25376L ^ 3174350533923984638L;
                    continue block15;
                }
                case 1117938136: {
                    break block15;
                }
            }
            break;
        }
        while (true) {
            if ((v3 = (cfr_temp_1 = TwLootNCollectModule.\u13e8 - (8367L ^ 197578624776232781L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v3 == (1828 ^ -1829)) break;
            v3 = 328 ^ -1151687589;
        }
        v4 = new TwLootModule();
        while (true) {
            if ((v5 = (cfr_temp_2 = TwLootNCollectModule.\u13e8 - (605L ^ -4173678119334840615L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v5 == (15052 ^ 15053)) break;
            v5 = 27580 ^ 520749718;
        }
        this.lootModule = v4;
        v6 = TwLootNCollectModule.\u13e8;
        if (true) ** GOTO lbl36
        block18: while (true) {
            v6 = (28437L ^ -1660709222424961633L) / (22151L ^ -1381071601264682448L);
lbl36:
            // 2 sources

            switch ((int)v6) {
                case 1117938136: {
                    break block18;
                }
                case 1796686244: {
                    continue block18;
                }
            }
            break;
        }
        v7 = TwLootNCollectModule.\u13e8;
        if (true) ** GOTO lbl45
        block19: while (true) {
            v7 = v8 / (7702L ^ 8976710566573783191L);
lbl45:
            // 2 sources

            switch ((int)v7) {
                case -2019002496: {
                    v8 = 25428L ^ 5073607852668872788L;
                    continue block19;
                }
                case -1313073280: {
                    v8 = 25778L ^ -7049573232647296963L;
                    continue block19;
                }
                case 1117938136: {
                    break block19;
                }
            }
            break;
        }
        v9 = new CollectorModule();
        while (true) {
            if ((v10 = (cfr_temp_3 = TwLootNCollectModule.\u13e8 - (30497L ^ 9194947732808263652L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v10 == (15161 ^ -15162)) break;
            v10 = -128499008 >>> "\u0000\u0000".length();
        }
        this.collectorModule = v9;
    }

    /*
     * Unable to fully structure code
     */
    public void install(Main main) {
        while (true) {
            if ((v0 = (cfr_temp_0 = TwLootNCollectModule.\u13e8 - (19408L ^ -306528204032646854L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (30510 ^ -30511)) break;
            v0 = 22034 ^ -1127692157;
        }
        while (true) {
            if ((v1 = (cfr_temp_1 = TwLootNCollectModule.\u13e8 - (3939803023637993768L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v1 == (27960 ^ -27961)) break;
            v1 = 26563 ^ -839732308;
        }
        this.lootModule.install(main);
        while (true) {
            if ((v2 = (cfr_temp_2 = TwLootNCollectModule.\u13e8 - (3268L ^ -7335147835677969657L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v2 == (11030 ^ 11031)) break;
            v2 = 32195 ^ -59322523;
        }
        while (true) {
            if ((v3 = (cfr_temp_3 = TwLootNCollectModule.\u13e8 - (27271L ^ -7174320950513572711L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v3 == (15872 ^ 15873)) break;
            v3 = 4004 ^ 1049827634;
        }
        this.collectorModule.install(main);
        while (true) {
            if ((v4 = (cfr_temp_4 = TwLootNCollectModule.\u13e8 - (21908L ^ 6532649558800454564L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v4 == (32742 ^ -32743)) break;
            v4 = 17532 ^ 1060223499;
        }
        v5 = main.guiManager;
        while (true) {
            if ((v6 = (cfr_temp_5 = TwLootNCollectModule.\u13e8 - (31035L ^ -1956727305125682411L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
            if (v6 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v6 = 14268 ^ 1746619739;
        }
        v7 = v5.pet;
        v8 = TwLootNCollectModule.\u13e8;
        if (true) ** GOTO lbl39
        block22: while (true) {
            v8 = (18402L ^ 5239175481002190833L) / (20155L ^ -7872851670691893147L);
lbl39:
            // 2 sources

            switch ((int)v8) {
                case 1117938136: {
                    break block22;
                }
                case 1356484367: {
                    continue block22;
                }
            }
            break;
        }
        this.pet = v7;
        while (true) {
            if ((v9 = (cfr_temp_6 = TwLootNCollectModule.\u13e8 - (20079L ^ -4815208868319114377L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
            if (v9 == (4530 ^ 4531)) break;
            v9 = 19219 ^ -2132252979;
        }
        v10 = main.hero;
        while (true) {
            if ((v11 = (cfr_temp_7 = TwLootNCollectModule.\u13e8 - (19958L ^ 8477622574955847267L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
            if (v11 == (8413 ^ -8414)) break;
            v11 = 17739 ^ -893448912;
        }
        this.hero = v10;
        v12 = TwLootNCollectModule.\u13e8;
        if (true) ** GOTO lbl61
        block25: while (true) {
            v12 = v13 / (25219L ^ -4255643392661378910L);
lbl61:
            // 2 sources

            switch ((int)v12) {
                case -908252193: {
                    v13 = 7497L ^ 6725425997363150571L;
                    continue block25;
                }
                case 472794685: {
                    v13 = 25312L ^ -6104128683851850397L;
                    continue block25;
                }
                case 1117938136: {
                    break block25;
                }
                case 1297315076: {
                    v13 = 2333L ^ 6672500721305350396L;
                    continue block25;
                }
            }
            break;
        }
        v14 = main.hero;
        while (true) {
            if ((v15 = (cfr_temp_8 = TwLootNCollectModule.\u13e8 - (22525L ^ 1018553993556392919L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
            if (v15 == (18528 ^ -18529)) break;
            v15 = 825682080 >>> "\u0000\u0000".length();
        }
        v16 = v14.drive;
        while (true) {
            if ((v17 = (cfr_temp_9 = TwLootNCollectModule.\u13e8 - (8642521126232130904L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
            if (v17 == (5883 ^ -5884)) break;
            v17 = 7060 ^ -695184798;
        }
        this.drive = v16;
        while (true) {
            if ((v18 = (cfr_temp_10 = TwLootNCollectModule.\u13e8 - (29678L ^ -141978648190829657L)) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
            if (v18 == (5591 ^ -5592)) break;
            v18 = 32322 ^ -1069570112;
        }
        v19 = main.config;
        v20 = TwLootNCollectModule.\u13e8;
        if (true) ** GOTO lbl96
        block29: while (true) {
            v20 = v21 / (-216567116842487824L >>> "\u0000\u0000".length());
lbl96:
            // 2 sources

            switch ((int)v20) {
                case -1986244581: {
                    v21 = 13009L ^ -5556191776837567153L;
                    continue block29;
                }
                case -1191957386: {
                    v21 = 17633L ^ -2954415333211896273L;
                    continue block29;
                }
                case 721920428: {
                    v21 = 28094L ^ 8459962565754497108L;
                    continue block29;
                }
                case 1117938136: {
                    break block29;
                }
            }
            break;
        }
        this.config = v19;
    }

    /*
     * Unable to fully structure code
     */
    public String status() {
        var2_1 = new byte[17857 ^ 17885];
        var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 5726 ^ -5758;
        var2_1[8089 ^ 8082] = 27760 ^ 27695;
        var2_1[21216 ^ 21240] = 17865 ^ 17832;
        var2_1[15331 ^ 15329] = 2211 ^ 2247;
        var2_1[23422 ^ 23400] = 13273 ^ 13226;
        var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 30482 ^ 30583;
        var2_1[31183 ^ 31182] = 444 >>> "\u0000\u0000".length();
        var2_1[7428 ^ 7440] = 11475 ^ 11431;
        var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 464 >>> "\u0000\u0000".length();
        var2_1[15775 ^ 15752] = 11473 ^ 11429;
        var2_1[21068 ^ 21061] = 1977 ^ 2005;
        var2_1[20291 ^ 20297] = 432 >>> "\u0000\u0000".length();
        var2_1[16544 ^ 16544] = 436 >>> "\u0000\u0000".length();
        var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 468 >>> "\u0000\u0000".length();
        var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 3221 ^ 3321;
        var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 404 >>> "\u0000\u0000".length();
        var2_1[13281 ^ 13286] = 13355 ^ 13376;
        var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 12954 ^ 13049;
        var2_1[7165 ^ 7163] = 184 >>> "\u0000\u0000".length();
        var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() ^ "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length()] = 7043 ^ 7149;
        var2_1[4225 ^ 4244] = 13076 ^ 13114;
        var2_1[31630 ^ 31637] = 3796 ^ 3751;
        var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 31618 ^ 31725;
        var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 28181 ^ 28281;
        var2_1[28716 ^ 28706] = 17885 ^ 17854;
        var2_1[30703 ^ 30690] = 380 >>> "\u0000\u0000".length();
        var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 3038 ^ 2987;
        var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 30895 ^ 30915;
        var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 420 >>> "\u0000\u0000".length();
        v0 = new String(var2_1);
        v1 = new Object[28166 ^ 28164];
        v2 = "".length() >>> "\u0000\u0000".length();
        v3 = TwLootNCollectModule.\u13e8;
        if (true) ** GOTO lbl38
        block20: while (true) {
            v3 = v4 / (1732L ^ -6116168855685282371L);
lbl38:
            // 2 sources

            switch ((int)v3) {
                case -812996328: {
                    v4 = 5169L ^ 6215000889008070378L;
                    continue block20;
                }
                case 527958794: {
                    v4 = 15761L ^ -6707036435212239901L;
                    continue block20;
                }
                case 1117938136: {
                    break block20;
                }
                case 2057219404: {
                    v4 = 7631L ^ 6705350698045018878L;
                    continue block20;
                }
            }
            break;
        }
        while (true) {
            if ((v5 = (cfr_temp_0 = TwLootNCollectModule.\u13e8 - (776L ^ -5485463855829884126L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v5 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v5 = 5130 ^ -1038231612;
        }
        v1[v2] = this.lootModule.status();
        v6 = TwLootNCollectModule.\u13e8;
        if (true) ** GOTO lbl61
        block22: while (true) {
            v6 = v7 / (24269L ^ -8181306108451912935L);
lbl61:
            // 2 sources

            switch ((int)v6) {
                case 1117938136: {
                    break block22;
                }
                case 1213539165: {
                    v7 = 24163L ^ -3991840802807653083L;
                    continue block22;
                }
                case 1241714786: {
                    v7 = 17576L ^ -4936416670800827946L;
                    continue block22;
                }
            }
            break;
        }
        v8 = TwLootNCollectModule.\u13e8;
        if (true) ** GOTO lbl74
        block23: while (true) {
            v8 = (31414L ^ 7088034180350216560L) / (12899L ^ -5263916866592015453L);
lbl74:
            // 2 sources

            switch ((int)v8) {
                case -1036182699: {
                    continue block23;
                }
                case 1117938136: {
                    break block23;
                }
            }
            break;
        }
        v1[11018 ^ 11019] = this.collectorModule.status();
        v9 = TwLootNCollectModule.\u13e8;
        if (true) ** GOTO lbl84
        block24: while (true) {
            v9 = v10 / (-9085278515650907096L >>> "\u0000\u0000".length());
lbl84:
            // 2 sources

            switch ((int)v9) {
                case -2048058596: {
                    v10 = 15358L ^ 2300731471251862536L;
                    continue block24;
                }
                case -978439839: {
                    v10 = 17745L ^ -862582678009310846L;
                    continue block24;
                }
                case 1117938136: {
                    break block24;
                }
            }
            break;
        }
        return I18n.get((String)v0, (Object[])v1);
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean canRefresh() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x755EL ^ 0x84FD92642CDE73A4L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l2 = 0x3BBC ^ 0x7DD5C8AA;
        }
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = \u13e8 - (0x33C4L ^ 0x49EA0BBE3C857F68L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l3 == (0x7647 ^ 0xFFFF89B8)) break;
            l3 = 0x1136 ^ 0xD6202F60;
        }
        if (!this.collectorModule.isNotWaiting()) return (0x4FEB ^ 0x4FEB) != 0;
        long l = \u13e8;
        block6: while (true) {
            switch ((int)l) {
                case -47320211: {
                    l = (0xAB2L ^ 0xD2B8031A903DD0F4L) / (0x4109L ^ 0xBD1ED93EC8405605L);
                    continue block6;
                }
                case 1117938136: {
                    break block6;
                }
            }
            break;
        }
        while (true) {
            long l4;
            long l5;
            if ((l5 = (l4 = \u13e8 - (0x15FEL ^ 0xDD37253996FD19CFL)) == 0L ? 0 : (l4 < 0L ? -1 : 1)) == false) continue;
            if (l5 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                return this.lootModule.canRefresh();
            }
            l5 = 0x13A1 ^ 0x77EC962B;
        }
    }

    public void tickStopped() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x5CE5L ^ 0x4A16371EBBE762AFL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x3D64 ^ 0xFFFFC29B)) break;
            l2 = 0x788B ^ 0xA58918C0;
        }
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = \u13e8 - (0x67F7L ^ 0x36033D0835C6073DL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l3 == (0x6096 ^ 0xFFFF9F69)) break;
            l3 = 1390964408 >>> "\u0000\u0000".length();
        }
        this.lootModule.tickStopped();
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    public void tick() {
        block228: {
            block233: {
                block229: {
                    block227: {
                        block232: {
                            block230: {
                                block231: {
                                    while (true) {
                                        if ((v0 = (cfr_temp_0 = TwLootNCollectModule.\u13e8 - (851L ^ -3439396204149681318L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                                        if (v0 == (31074 ^ 31075)) break;
                                        v0 = 21188 ^ -296183234;
                                    }
                                    v1 = TwLootNCollectModule.\u13e8;
                                    if (true) ** GOTO lbl10
                                    block164: while (true) {
                                        v1 = v2 / (5883L ^ -5890663346639471002L);
lbl10:
                                        // 2 sources

                                        switch ((int)v1) {
                                            case -1793522628: {
                                                v2 = 18128L ^ -3601753822559565512L;
                                                continue block164;
                                            }
                                            case 607937870: {
                                                v2 = 1693L ^ 2279197675866870744L;
                                                continue block164;
                                            }
                                            case 1117938136: {
                                                break block164;
                                            }
                                            case 1552411553: {
                                                v2 = 2123441256895135492L >>> "\u0000\u0000".length();
                                                continue block164;
                                            }
                                        }
                                        break;
                                    }
                                    if (!this.collectorModule.isNotWaiting()) break block228;
                                    v3 = TwLootNCollectModule.\u13e8;
                                    if (true) ** GOTO lbl27
                                    block165: while (true) {
                                        v3 = (14745L ^ 230159095974016961L) / (16074L ^ -7076642035551639854L);
lbl27:
                                        // 2 sources

                                        switch ((int)v3) {
                                            case 284173515: {
                                                continue block165;
                                            }
                                            case 1117938136: {
                                                break block165;
                                            }
                                        }
                                        break;
                                    }
                                    v4 = TwLootNCollectModule.\u13e8;
                                    if (true) ** GOTO lbl36
                                    block166: while (true) {
                                        v4 = v5 / (28764L ^ -2311438327161890947L);
lbl36:
                                        // 2 sources

                                        switch ((int)v4) {
                                            case -804209245: {
                                                v5 = 12956L ^ -8375391843333514713L;
                                                continue block166;
                                            }
                                            case 120457448: {
                                                v5 = 11372L ^ 23334299043688876L;
                                                continue block166;
                                            }
                                            case 1117938136: {
                                                break block166;
                                            }
                                            case 1929999010: {
                                                v5 = 31121L ^ 5971365928039812348L;
                                                continue block166;
                                            }
                                        }
                                        break;
                                    }
                                    if (!this.lootModule.checkDangerousAndCurrentMap()) break block228;
                                    while (true) {
                                        if ((v6 = (cfr_temp_1 = TwLootNCollectModule.\u13e8 - (19113L ^ 8450851275463704627L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                                        if (v6 == (5183 ^ -5184)) break;
                                        v6 = 26104 ^ -1571065838;
                                    }
                                    v7 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
                                    v8 = TwLootNCollectModule.\u13e8;
                                    if (true) ** GOTO lbl59
                                    block168: while (true) {
                                        v8 = (2783L ^ 5455344755802402649L) / (14436L ^ 940102840109571891L);
lbl59:
                                        // 2 sources

                                        switch ((int)v8) {
                                            case 303646793: {
                                                continue block168;
                                            }
                                            case 1117938136: {
                                                break block168;
                                            }
                                        }
                                        break;
                                    }
                                    this.pet.setEnabled(v7);
                                    v9 = TwLootNCollectModule.\u13e8;
                                    if (true) ** GOTO lbl69
                                    block169: while (true) {
                                        v9 = v10 / (2167059915270044556L >>> "\u0000\u0000".length());
lbl69:
                                        // 2 sources

                                        switch ((int)v9) {
                                            case -1897317436: {
                                                v10 = 9654L ^ 9083514325208314868L;
                                                continue block169;
                                            }
                                            case -1804713604: {
                                                v10 = 4868946825637018176L >>> "\u0000\u0000".length();
                                                continue block169;
                                            }
                                            case 1117938136: {
                                                break block169;
                                            }
                                        }
                                        break;
                                    }
                                    while (true) {
                                        if ((v11 = (cfr_temp_2 = TwLootNCollectModule.\u13e8 - (8805L ^ -891512267282846942L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                                        if (v11 == (3099 ^ 3098)) break;
                                        v11 = 12230 ^ 253056366;
                                    }
                                    if (!this.lootModule.findTarget()) break block229;
                                    while (true) {
                                        if ((v12 = (cfr_temp_3 = TwLootNCollectModule.\u13e8 - (29498L ^ 5855622614860612059L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                                        if (v12 == (23329 ^ -23330)) break;
                                        v12 = 29247 ^ -2010223228;
                                    }
                                    v13 = TwLootNCollectModule.\u13e8;
                                    if (true) ** GOTO lbl93
                                    block172: while (true) {
                                        v13 = v14 / (-1027337701334089432L >>> "\u0000\u0000".length());
lbl93:
                                        // 2 sources

                                        switch ((int)v13) {
                                            case -1890599757: {
                                                v14 = 29091L ^ 885999512106084838L;
                                                continue block172;
                                            }
                                            case -959286178: {
                                                v14 = 11143L ^ -729116315616794347L;
                                                continue block172;
                                            }
                                            case -858738005: {
                                                v14 = 11107L ^ 1198228869926187545L;
                                                continue block172;
                                            }
                                            case 1117938136: {
                                                break block172;
                                            }
                                        }
                                        break;
                                    }
                                    this.collectorModule.findBox();
                                    while (true) {
                                        if ((v15 = (cfr_temp_4 = TwLootNCollectModule.\u13e8 - (4340L ^ 7632339061565250570L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                                        if (v15 == (8192 ^ -8193)) break;
                                        v15 = 29288 ^ -330810420;
                                    }
                                    v16 = TwLootNCollectModule.\u13e8;
                                    if (true) ** GOTO lbl115
                                    block174: while (true) {
                                        v16 = v17 / (18088L ^ -5047718782780560755L);
lbl115:
                                        // 2 sources

                                        switch ((int)v16) {
                                            case -1429056817: {
                                                v17 = 14529L ^ 5223650645963779958L;
                                                continue block174;
                                            }
                                            case 1117938136: {
                                                break block174;
                                            }
                                            case 1396512622: {
                                                v17 = 12443L ^ -8295175976022584459L;
                                                continue block174;
                                            }
                                        }
                                        break;
                                    }
                                    box = this.collectorModule.current;
                                    while (true) {
                                        if ((v18 = (cfr_temp_5 = TwLootNCollectModule.\u13e8 - (32122L ^ -93044788056687204L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                                        if (v18 == (1052 ^ -1053)) break;
                                        v18 = 31288 ^ 1442277668;
                                    }
                                    while (true) {
                                        if ((v19 = (cfr_temp_6 = TwLootNCollectModule.\u13e8 - (1311583865806917220L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                                        if (v19 == (9980 ^ -9981)) break;
                                        v19 = 14933 ^ -1273887971;
                                    }
                                    v20 = this.lootModule.attack;
                                    v21 = TwLootNCollectModule.\u13e8;
                                    if (true) ** GOTO lbl140
                                    block177: while (true) {
                                        v21 = v22 / (14016L ^ 5780759804398714154L);
lbl140:
                                        // 2 sources

                                        switch ((int)v21) {
                                            case -785039366: {
                                                v22 = 7089L ^ 7839492670740185235L;
                                                continue block177;
                                            }
                                            case -541936766: {
                                                v22 = 18991L ^ 6389524380248361100L;
                                                continue block177;
                                            }
                                            case 1117938136: {
                                                break block177;
                                            }
                                            case 1586442509: {
                                                v22 = 11442L ^ -5260562832402743103L;
                                                continue block177;
                                            }
                                        }
                                        break;
                                    }
                                    npc = v20.target;
                                    if (box == null) break block230;
                                    v23 = TwLootNCollectModule.\u13e8;
                                    if (true) ** GOTO lbl158
                                    block178: while (true) {
                                        v23 = v24 / (19434L ^ -6613414534415532827L);
lbl158:
                                        // 2 sources

                                        switch ((int)v23) {
                                            case -652228369: {
                                                v24 = 19131L ^ -4763209184735498628L;
                                                continue block178;
                                            }
                                            case -346590848: {
                                                v24 = 1589L ^ 6776363969613372046L;
                                                continue block178;
                                            }
                                            case 1117938136: {
                                                break block178;
                                            }
                                        }
                                        break;
                                    }
                                    if (box.removed) break block230;
                                    v25 = TwLootNCollectModule.\u13e8;
                                    if (true) ** GOTO lbl172
                                    block179: while (true) {
                                        v25 = v26 / (6402510625824594468L >>> "\u0000\u0000".length());
lbl172:
                                        // 2 sources

                                        switch ((int)v25) {
                                            case 877799431: {
                                                v26 = 5910L ^ 637276575110575812L;
                                                continue block179;
                                            }
                                            case 1117938136: {
                                                break block179;
                                            }
                                            case 1209434945: {
                                                v26 = 10027L ^ -4206199021568436638L;
                                                continue block179;
                                            }
                                        }
                                        break;
                                    }
                                    v27 = box.locationInfo;
                                    while (true) {
                                        if ((v28 = (cfr_temp_7 = TwLootNCollectModule.\u13e8 - (19509L ^ 1227348165544398676L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                                        if (v28 == (3438 ^ -3439)) break;
                                        v28 = 21617 ^ 1862792057;
                                    }
                                    while (true) {
                                        if ((v29 = (cfr_temp_8 = TwLootNCollectModule.\u13e8 - (8578L ^ -8744994630290273335L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                                        if (v29 == (14847 ^ 14846)) break;
                                        v29 = 7537 ^ -432449378;
                                    }
                                    v30 = v27.distance((Entity)this.hero);
                                    while (true) {
                                        if ((v31 = (cfr_temp_9 = TwLootNCollectModule.\u13e8 - (24656L ^ -480709971716495494L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
                                        if (v31 == (17023 ^ -17024)) break;
                                        v31 = 2537 ^ -418761898;
                                    }
                                    while (true) {
                                        if ((v32 = (cfr_temp_10 = TwLootNCollectModule.\u13e8 - (23782L ^ -8978577545122989464L)) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
                                        if (v32 == (30851 ^ 30850)) break;
                                        v32 = 10140 ^ -298652557;
                                    }
                                    v33 = this.config.COLLECT;
                                    while (true) {
                                        if ((v34 = (cfr_temp_11 = TwLootNCollectModule.\u13e8 - (31540L ^ 8116266157626840606L)) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
                                        if (v34 == (25114 ^ -25115)) break;
                                        v34 = 21019 ^ 883609642;
                                    }
                                    if (v30 > (double)v33.RADIUS) break block230;
                                    v35 = TwLootNCollectModule.\u13e8;
                                    if (true) ** GOTO lbl214
                                    block185: while (true) {
                                        v35 = v36 / (21121L ^ -357037881545730221L);
lbl214:
                                        // 2 sources

                                        switch ((int)v35) {
                                            case -1018394588: {
                                                v36 = 6926L ^ 7904661048525710520L;
                                                continue block185;
                                            }
                                            case 638500224: {
                                                v36 = 1551L ^ 809784277858639903L;
                                                continue block185;
                                            }
                                            case 1117938136: {
                                                break block185;
                                            }
                                        }
                                        break;
                                    }
                                    v37 = npc.npcInfo;
                                    v38 = TwLootNCollectModule.\u13e8;
                                    if (true) ** GOTO lbl228
                                    block186: while (true) {
                                        v38 = (20159L ^ 2195616479689045058L) / (4843L ^ -5518943834321151367L);
lbl228:
                                        // 2 sources

                                        switch ((int)v38) {
                                            case -1851324065: {
                                                continue block186;
                                            }
                                            case 1117938136: {
                                                break block186;
                                            }
                                        }
                                        break;
                                    }
                                    v39 = v37.extra;
                                    while (true) {
                                        if ((v40 = (cfr_temp_12 = TwLootNCollectModule.\u13e8 - (25041L ^ 5259741323364879977L)) == 0L ? 0 : (cfr_temp_12 < 0L ? -1 : 1)) == false) continue;
                                        if (v40 == (14286 ^ -14287)) break;
                                        v40 = 8627 ^ 1985064630;
                                    }
                                    v41 = TwLootNCollectModule.\u13e8;
                                    if (true) ** GOTO lbl243
                                    block188: while (true) {
                                        v41 = v42 / (16554L ^ 8867838038469321720L);
lbl243:
                                        // 2 sources

                                        switch ((int)v41) {
                                            case -554917657: {
                                                v42 = 1283L ^ -5718679930267313092L;
                                                continue block188;
                                            }
                                            case -200230664: {
                                                v42 = 240L ^ -612222192689137907L;
                                                continue block188;
                                            }
                                            case 1043627328: {
                                                v42 = 23243L ^ -8304523514212106582L;
                                                continue block188;
                                            }
                                            case 1117938136: {
                                                break block188;
                                            }
                                        }
                                        break;
                                    }
                                    if (!v39.has((NpcExtraFlag)NpcExtra.IGNORE_BOXES)) break block231;
                                    while (true) {
                                        if ((v43 = (cfr_temp_13 = TwLootNCollectModule.\u13e8 - (7205L ^ 1389141773791811157L)) == 0L ? 0 : (cfr_temp_13 < 0L ? -1 : 1)) == false) continue;
                                        if (v43 == (31787 ^ -31788)) break;
                                        v43 = 1663332880 >>> "\u0000\u0000".length();
                                    }
                                    v44 = npc.locationInfo;
                                    while (true) {
                                        if ((v45 = (cfr_temp_14 = TwLootNCollectModule.\u13e8 - (23132L ^ 4984830988797497965L)) == 0L ? 0 : (cfr_temp_14 < 0L ? -1 : 1)) == false) continue;
                                        if (v45 == (13380 ^ -13381)) break;
                                        v45 = 27924 ^ 1622301092;
                                    }
                                    v46 = v44.distance((Entity)box);
                                    while (true) {
                                        if ((v47 = (cfr_temp_15 = TwLootNCollectModule.\u13e8 - (29396L ^ 8303783838451705331L)) == 0L ? 0 : (cfr_temp_15 < 0L ? -1 : 1)) == false) continue;
                                        if (v47 == (2293 ^ -2294)) break;
                                        v47 = 8635 ^ -833986532;
                                    }
                                    v48 = npc.npcInfo;
                                    while (true) {
                                        if ((v49 = (cfr_temp_16 = TwLootNCollectModule.\u13e8 - (1430970576664491436L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_16 < 0L ? -1 : 1)) == false) continue;
                                        if (v49 == (25686 ^ -25687)) break;
                                        v49 = 19924 ^ 104542175;
                                    }
                                    v50 = v48.radius * 2.0;
                                    v51 = TwLootNCollectModule.\u13e8;
                                    if (true) ** GOTO lbl284
                                    block193: while (true) {
                                        v51 = v52 / (1356L ^ 247675814261219441L);
lbl284:
                                        // 2 sources

                                        switch ((int)v51) {
                                            case -1498318747: {
                                                v52 = 1091059332604526180L >>> "\u0000\u0000".length();
                                                continue block193;
                                            }
                                            case 354811483: {
                                                v52 = 23669L ^ -6134097859645868881L;
                                                continue block193;
                                            }
                                            case 1009428309: {
                                                v52 = 13668L ^ 3470185642133624246L;
                                                continue block193;
                                            }
                                            case 1117938136: {
                                                break block193;
                                            }
                                        }
                                        break;
                                    }
                                    if (v46 > Math.min(800.0, v50)) break block230;
                                }
                                while (true) {
                                    if ((v53 = (cfr_temp_17 = TwLootNCollectModule.\u13e8 - (20176L ^ -984506219341534390L)) == 0L ? 0 : (cfr_temp_17 < 0L ? -1 : 1)) == false) continue;
                                    if (v53 == (5785 ^ 5784)) break;
                                    v53 = 15817 ^ 1434666987;
                                }
                                v54 = TwLootNCollectModule.\u13e8;
                                if (true) ** GOTO lbl307
                                block195: while (true) {
                                    v54 = v55 / (30827L ^ 7091371063627655912L);
lbl307:
                                    // 2 sources

                                    switch ((int)v54) {
                                        case -2098975308: {
                                            v55 = 6072272711777109224L >>> "\u0000\u0000".length();
                                            continue block195;
                                        }
                                        case -1728177099: {
                                            v55 = 30884L ^ -8467103910041634256L;
                                            continue block195;
                                        }
                                        case 1117938136: {
                                            break block195;
                                        }
                                        case 1745278896: {
                                            v55 = 25148L ^ -2660128648598452236L;
                                            continue block195;
                                        }
                                    }
                                    break;
                                }
                                v56 = this.lootModule.attack;
                                while (true) {
                                    if ((v57 = (cfr_temp_18 = TwLootNCollectModule.\u13e8 - (-74438436744714128L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_18 < 0L ? -1 : 1)) == false) continue;
                                    if (v57 == (15714 ^ -15715)) break;
                                    v57 = 18596 ^ -1931803355;
                                }
                                v58 = v56.target;
                                while (true) {
                                    if ((v59 = (cfr_temp_19 = TwLootNCollectModule.\u13e8 - (3328063789982784864L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_19 < 0L ? -1 : 1)) == false) continue;
                                    if (v59 == (7937 ^ -7938)) break;
                                    v59 = 32043 ^ 989138701;
                                }
                                v60 = v58.health;
                                v61 = TwLootNCollectModule.\u13e8;
                                if (true) ** GOTO lbl336
                                block198: while (true) {
                                    v61 = v62 / (25718L ^ 7589341204899086075L);
lbl336:
                                    // 2 sources

                                    switch ((int)v61) {
                                        case -1424380590: {
                                            v62 = 16301L ^ 6793491367310270292L;
                                            continue block198;
                                        }
                                        case -445122680: {
                                            v62 = 23001L ^ -8724556160070177619L;
                                            continue block198;
                                        }
                                        case -104560444: {
                                            v62 = 22734L ^ -7695808814843777984L;
                                            continue block198;
                                        }
                                        case 1117938136: {
                                            break block198;
                                        }
                                    }
                                    break;
                                }
                                if (!(v60.hpPercent() < 0.25)) break block232;
                            }
                            v63 = TwLootNCollectModule.\u13e8;
                            if (true) ** GOTO lbl354
                            block199: while (true) {
                                v63 = v64 / (28398L ^ 4962574487791703054L);
lbl354:
                                // 2 sources

                                switch ((int)v63) {
                                    case -245569755: {
                                        v64 = 30095L ^ 4969493501234362317L;
                                        continue block199;
                                    }
                                    case 465677687: {
                                        v64 = 8764L ^ -4548281822376401797L;
                                        continue block199;
                                    }
                                    case 1117938136: {
                                        break block199;
                                    }
                                    case 1892348055: {
                                        v64 = 21630L ^ 2236155408010655701L;
                                        continue block199;
                                    }
                                }
                                break;
                            }
                            while (true) {
                                if ((v65 = (cfr_temp_20 = TwLootNCollectModule.\u13e8 - (20793L ^ 3986950680816816327L)) == 0L ? 0 : (cfr_temp_20 < 0L ? -1 : 1)) == false) continue;
                                if (v65 == (29748 ^ -29749)) {
                                    this.lootModule.moveToAnSafePosition();
                                    break block227;
                                }
                                v65 = 17269 ^ 1234047207;
                            }
                        }
                        while (true) {
                            if ((v66 = (cfr_temp_21 = TwLootNCollectModule.\u13e8 - (14527L ^ -812496415831466296L)) == 0L ? 0 : (cfr_temp_21 < 0L ? -1 : 1)) == false) continue;
                            if (v66 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                            v66 = 31556 ^ -597691541;
                        }
                        v67 = TwLootNCollectModule.\u13e8;
                        if (true) ** GOTO lbl383
                        block202: while (true) {
                            v67 = v68 / (22687L ^ 5299229355961961252L);
lbl383:
                            // 2 sources

                            switch ((int)v67) {
                                case 444617546: {
                                    v68 = 3409758339533507772L >>> "\u0000\u0000".length();
                                    continue block202;
                                }
                                case 1117938136: {
                                    break block202;
                                }
                                case 1257482127: {
                                    v68 = 31377L ^ -3211267018927047319L;
                                    continue block202;
                                }
                                case 1962537128: {
                                    v68 = 20207L ^ 5409317198074861489L;
                                    continue block202;
                                }
                            }
                            break;
                        }
                        v69 = TwLootNCollectModule.\u13e8;
                        if (true) ** GOTO lbl399
                        block203: while (true) {
                            v69 = v70 / (20339L ^ 3480057733388105580L);
lbl399:
                            // 2 sources

                            switch ((int)v69) {
                                case 123742917: {
                                    v70 = 3150L ^ 2301162089399687156L;
                                    continue block203;
                                }
                                case 699561538: {
                                    v70 = 24932L ^ 4905277330524749225L;
                                    continue block203;
                                }
                                case 1117938136: {
                                    break block203;
                                }
                                case 1679224394: {
                                    v70 = 3218L ^ 7110060695252407015L;
                                    continue block203;
                                }
                            }
                            break;
                        }
                        v71 = this.collectorModule.current;
                        while (true) {
                            if ((v72 = (cfr_temp_22 = TwLootNCollectModule.\u13e8 - (13726L ^ 1815983269258635187L)) == 0L ? 0 : (cfr_temp_22 < 0L ? -1 : 1)) == false) continue;
                            if (v72 == (2105 ^ -2106)) break;
                            v72 = 16604 ^ -1839918435;
                        }
                        v73 = v71.locationInfo;
                        v74 = TwLootNCollectModule.\u13e8;
                        if (true) ** GOTO lbl422
                        block205: while (true) {
                            v74 = v75 / (22960L ^ -3416984810364605673L);
lbl422:
                            // 2 sources

                            switch ((int)v74) {
                                case -1640153879: {
                                    v75 = 6805084476822643252L >>> "\u0000\u0000".length();
                                    continue block205;
                                }
                                case -1618502781: {
                                    v75 = 2926249180682255504L >>> "\u0000\u0000".length();
                                    continue block205;
                                }
                                case 1117938136: {
                                    break block205;
                                }
                                case 1342866214: {
                                    v75 = 17591L ^ -1396890513558691829L;
                                    continue block205;
                                }
                            }
                            break;
                        }
                        v76 = v73.now;
                        v77 = TwLootNCollectModule.\u13e8;
                        if (true) ** GOTO lbl439
                        block206: while (true) {
                            v77 = (19873L ^ -3845151387599190607L) / (11045L ^ -7414729324953927811L);
lbl439:
                            // 2 sources

                            switch ((int)v77) {
                                case -1355225121: {
                                    continue block206;
                                }
                                case 1117938136: {
                                    break block206;
                                }
                            }
                            break;
                        }
                        this.lootModule.setConfig(v76);
                        while (true) {
                            if ((v78 = (cfr_temp_23 = TwLootNCollectModule.\u13e8 - (16549L ^ -385481423393406507L)) == 0L ? 0 : (cfr_temp_23 < 0L ? -1 : 1)) == false) continue;
                            if (v78 == (894 ^ -895)) break;
                            v78 = 18291 ^ 1487596131;
                        }
                        v79 = TwLootNCollectModule.\u13e8;
                        if (true) ** GOTO lbl454
                        block208: while (true) {
                            v79 = (23216L ^ 3632379016848787397L) / (627180222740658972L >>> "\u0000\u0000".length());
lbl454:
                            // 2 sources

                            switch ((int)v79) {
                                case 584360094: {
                                    continue block208;
                                }
                                case 1117938136: {
                                    break block208;
                                }
                            }
                            break;
                        }
                        this.collectorModule.tryCollectNearestBox();
                    }
                    while (true) {
                        if ((v80 = (cfr_temp_24 = TwLootNCollectModule.\u13e8 - (6546L ^ -1999937021363166873L)) == 0L ? 0 : (cfr_temp_24 < 0L ? -1 : 1)) == false) continue;
                        if (v80 == (3644 ^ 3645)) break;
                        v80 = 30656 ^ 1490608566;
                    }
                    v81 = TwLootNCollectModule.\u13e8;
                    if (true) ** GOTO lbl471
                    block210: while (true) {
                        v81 = (6528968333709981948L >>> "\u0000\u0000".length()) / (1798069798633630520L >>> "\u0000\u0000".length());
lbl471:
                        // 2 sources

                        switch ((int)v81) {
                            case 1031949926: {
                                continue block210;
                            }
                            case 1117938136: {
                                break block210;
                            }
                        }
                        break;
                    }
                    this.lootModule.ignoreInvalidTarget();
                    v82 = TwLootNCollectModule.\u13e8;
                    if (true) ** GOTO lbl481
                    block211: while (true) {
                        v82 = v83 / (32023L ^ 4874122137531489280L);
lbl481:
                        // 2 sources

                        switch ((int)v82) {
                            case -1512058299: {
                                v83 = 19889L ^ -5095201277589722840L;
                                continue block211;
                            }
                            case -602701523: {
                                v83 = 29136L ^ 5688015288470883463L;
                                continue block211;
                            }
                            case -256536304: {
                                v83 = 30202L ^ -7652530175140188600L;
                                continue block211;
                            }
                            case 1117938136: {
                                break block211;
                            }
                        }
                        break;
                    }
                    v84 = TwLootNCollectModule.\u13e8;
                    if (true) ** GOTO lbl497
                    block212: while (true) {
                        v84 = v85 / (1300L ^ -5450903514273390549L);
lbl497:
                        // 2 sources

                        switch ((int)v84) {
                            case -320534932: {
                                v85 = 23366L ^ 792930441201230105L;
                                continue block212;
                            }
                            case -119941781: {
                                v85 = 18737L ^ 1135241152887550020L;
                                continue block212;
                            }
                            case 578999204: {
                                v85 = 32298L ^ -456671838263492814L;
                                continue block212;
                            }
                            case 1117938136: {
                                break block212;
                            }
                        }
                        break;
                    }
                    v86 = this.lootModule.attack;
                    v87 = TwLootNCollectModule.\u13e8;
                    if (true) ** GOTO lbl514
                    block213: while (true) {
                        v87 = v88 / (22079L ^ -8764632431923749631L);
lbl514:
                        // 2 sources

                        switch ((int)v87) {
                            case -1139702308: {
                                v88 = 29771L ^ 5043609107586445456L;
                                continue block213;
                            }
                            case 783390582: {
                                v88 = 22017L ^ 7565837408850309279L;
                                continue block213;
                            }
                            case 1117938136: {
                                break block213;
                            }
                        }
                        break;
                    }
                    v86.doKillTargetTick();
                    break block228;
                }
                while (true) {
                    if ((v89 = (cfr_temp_25 = TwLootNCollectModule.\u13e8 - (19354L ^ -3964534419975754594L)) == 0L ? 0 : (cfr_temp_25 < 0L ? -1 : 1)) == false) continue;
                    if (v89 == (31777 ^ 31776)) break;
                    v89 = 14615 ^ 1779074253;
                }
                while (true) {
                    if ((v90 = (cfr_temp_26 = TwLootNCollectModule.\u13e8 - (6568L ^ -341700734146153173L)) == 0L ? 0 : (cfr_temp_26 < 0L ? -1 : 1)) == false) continue;
                    if (v90 == (12956 ^ -12957)) break;
                    v90 = 30231 ^ 1922425308;
                }
                this.hero.roamMode();
                while (true) {
                    if ((v91 = (cfr_temp_27 = TwLootNCollectModule.\u13e8 - (30474L ^ -1125091138526444557L)) == 0L ? 0 : (cfr_temp_27 < 0L ? -1 : 1)) == false) continue;
                    if (v91 == (10209 ^ 10208)) break;
                    v91 = 26028 ^ -867539176;
                }
                while (true) {
                    if ((v92 = (cfr_temp_28 = TwLootNCollectModule.\u13e8 - (13663L ^ -4015008123833267609L)) == 0L ? 0 : (cfr_temp_28 < 0L ? -1 : 1)) == false) continue;
                    if (v92 == (28834 ^ 28835)) break;
                    v92 = 9065 ^ -399612517;
                }
                this.collectorModule.findBox();
                v93 = TwLootNCollectModule.\u13e8;
                if (true) ** GOTO lbl552
                block218: while (true) {
                    v93 = v94 / (1911L ^ -3967660884341300951L);
lbl552:
                    // 2 sources

                    switch ((int)v93) {
                        case -1474447652: {
                            v94 = 13061L ^ -582257443961190403L;
                            continue block218;
                        }
                        case -636576745: {
                            v94 = 27214L ^ -5151850962115823059L;
                            continue block218;
                        }
                        case 852261992: {
                            v94 = 16721L ^ 2809939024728379756L;
                            continue block218;
                        }
                        case 1117938136: {
                            break block218;
                        }
                    }
                    break;
                }
                while (true) {
                    if ((v95 = (cfr_temp_29 = TwLootNCollectModule.\u13e8 - (19486L ^ 6409338476767158465L)) == 0L ? 0 : (cfr_temp_29 < 0L ? -1 : 1)) == false) continue;
                    if (v95 == (32480 ^ -32481)) break;
                    v95 = 9996 ^ -2028309241;
                }
                if (this.collectorModule.tryCollectNearestBox()) break block228;
                v96 = TwLootNCollectModule.\u13e8;
                if (true) ** GOTO lbl574
                block220: while (true) {
                    v96 = v97 / (25687L ^ 5562547048738863819L);
lbl574:
                    // 2 sources

                    switch ((int)v96) {
                        case -1443841875: {
                            v97 = 20943L ^ -9141794165407653496L;
                            continue block220;
                        }
                        case -867612887: {
                            v97 = 27373L ^ 5454585238892990580L;
                            continue block220;
                        }
                        case 1117938136: {
                            break block220;
                        }
                    }
                    break;
                }
                v98 = TwLootNCollectModule.\u13e8;
                if (true) ** GOTO lbl587
                block221: while (true) {
                    v98 = v99 / (411426064490890952L >>> "\u0000\u0000".length());
lbl587:
                    // 2 sources

                    switch ((int)v98) {
                        case -1913973598: {
                            v99 = 2399L ^ -8470022187654164852L;
                            continue block221;
                        }
                        case -1445179106: {
                            v99 = 22473L ^ -1992057655618357563L;
                            continue block221;
                        }
                        case 904166946: {
                            v99 = 28657L ^ -6946619249511099125L;
                            continue block221;
                        }
                        case 1117938136: {
                            break block221;
                        }
                    }
                    break;
                }
                if (!this.drive.isMoving()) break block233;
                v100 = TwLootNCollectModule.\u13e8;
                if (true) ** GOTO lbl604
                block222: while (true) {
                    v100 = (5576L ^ 2609278372024490228L) / (8279284237976885828L >>> "\u0000\u0000".length());
lbl604:
                    // 2 sources

                    switch ((int)v100) {
                        case 1117938136: {
                            break block222;
                        }
                        case 1400123965: {
                            continue block222;
                        }
                    }
                    break;
                }
                while (true) {
                    if ((v101 = (cfr_temp_30 = TwLootNCollectModule.\u13e8 - (24204L ^ 6356772337567894203L)) == 0L ? 0 : (cfr_temp_30 < 0L ? -1 : 1)) == false) continue;
                    if (v101 == (31846 ^ -31847)) break;
                    v101 = 1498983240 >>> "\u0000\u0000".length();
                }
                if (!this.drive.isOutOfMap()) break block228;
            }
            while (true) {
                if ((v102 = (cfr_temp_31 = TwLootNCollectModule.\u13e8 - (29152L ^ 1385438528605393796L)) == 0L ? 0 : (cfr_temp_31 < 0L ? -1 : 1)) == false) continue;
                if (v102 == (9380 ^ -9381)) break;
                v102 = 14107 ^ 1406856406;
            }
            v103 = TwLootNCollectModule.\u13e8;
            if (true) ** GOTO lbl625
            block225: while (true) {
                v103 = (1534L ^ 1385905991511765431L) / (3611254005193939328L >>> "\u0000\u0000".length());
lbl625:
                // 2 sources

                switch ((int)v103) {
                    case -32144682: {
                        continue block225;
                    }
                    case 1117938136: {
                        break block225;
                    }
                }
                break;
            }
            this.drive.moveRandom();
        }
    }
}

