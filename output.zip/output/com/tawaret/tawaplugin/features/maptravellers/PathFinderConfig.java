/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.config.types.Num
 *  com.github.manolo8.darkbot.config.types.Option
 */
package com.tawaret.tawaplugin.features.maptravellers;

import com.github.manolo8.darkbot.config.types.Num;
import com.github.manolo8.darkbot.config.types.Option;

public class PathFinderConfig {
    @Option(value="Travel through rad zone")
    public boolean TRAVEL_THROUGH_RAD_ZONE;
    @Option(value="Only use rad zone if above Hp (%)", description="Bot will not travel into rad zone if Hp below this. If bot is already in radiation zone, travel is uneffected")
    @Num(min=10, max=99, step=1)
    public int RAD_ZONE_HP_THESH;
    private static long \u13e8 = -1757468943211511918L;

    public PathFinderConfig() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x3251L ^ 0xA5E79810451039F1L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x1948 ^ 0x1949)) break;
            l2 = 0x6DE6 ^ 0x9A0D8829;
        }
        int n = "".length() >>> "\u0000\u0000".length();
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = \u13e8 - (-5343767322015701560L >>> "\u0000\u0000".length())) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l3 == (0x1DA ^ 0xFFFFFE25)) break;
            l3 = 0x595E ^ 0x8B508A5E;
        }
        this.TRAVEL_THROUGH_RAD_ZONE = n;
        int n2 = 160 >>> "\u0000\u0000".length();
        while (true) {
            long l;
            long l4;
            if ((l4 = (l = \u13e8 - (0x359DL ^ 0x576212E6C63BC02DL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l4 == (0x7BD3 ^ 0xFFFF842C)) break;
            l4 = 0x56C4 ^ 0xFE655EF2;
        }
        this.RAD_ZONE_HP_THESH = n2;
    }
}

