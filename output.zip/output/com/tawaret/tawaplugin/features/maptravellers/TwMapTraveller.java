/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.Main
 *  com.github.manolo8.darkbot.config.Config$General
 *  com.github.manolo8.darkbot.core.manager.PetManager
 *  com.github.manolo8.darkbot.core.manager.StarManager
 *  com.github.manolo8.darkbot.modules.utils.MapTraveler
 */
package com.tawaret.tawaplugin.features.maptravellers;

import com.github.manolo8.darkbot.Main;
import com.github.manolo8.darkbot.config.Config;
import com.github.manolo8.darkbot.core.manager.PetManager;
import com.github.manolo8.darkbot.core.manager.StarManager;
import com.github.manolo8.darkbot.modules.utils.MapTraveler;
import com.tawaret.tawaplugin.features.maptravellers.ITwMapTraveller;
import com.tawaret.tawaplugin.features.maptravellers.TwMapTravellerConfig;

public class TwMapTraveller
implements ITwMapTraveller {
    private MapTraveler mapTraveler;
    private int travellingToMapId;
    private StarManager starManager;
    private Config.General mainConfigGeneral;
    private Main main;
    private PetManager pet;
    public static long \u13e8 = -8350325139652827016L;

    public TwMapTraveller() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x6776L ^ 0xE38E867E22048ADL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x1816 ^ 0xFFFFE7E9)) break;
            l2 = 0x5995 ^ 0x7D426DFE;
        }
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = \u13e8 - (0x692L ^ 0xC0AB32A152C04F66L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l3 == (0x495E ^ 0xFFFFB6A1)) break;
            l3 = 0x1492 ^ 0x87185781;
        }
        this.mapTraveler = null;
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public void setTargetMap(int mapId) {
        while (true) {
            if ((v0 = (cfr_temp_0 = TwMapTraveller.\u13e8 - (9454L ^ -5876793654869313359L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (284 ^ -285)) break;
            v0 = -436081712 >>> "\u0000\u0000".length();
        }
        while (true) {
            if ((v1 = (cfr_temp_1 = TwMapTraveller.\u13e8 - (18180L ^ 1442367083954382205L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v1 == (25756 ^ -25757)) break;
            v1 = 21967 ^ 1264908989;
        }
        this.mainConfigGeneral.WORKING_MAP = mapId;
        while (true) {
            if ((v2 = (cfr_temp_2 = TwMapTraveller.\u13e8 - (13904L ^ 6610673602262314105L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v2 == (7088 ^ -7089)) break;
            v2 = -1571727024 >>> "\u0000\u0000".length();
        }
        this.travellingToMapId = mapId;
        v3 = TwMapTraveller.\u13e8;
        if (true) ** GOTO lbl22
        block31: while (true) {
            v3 = v4 / (2513628777886564588L >>> "\u0000\u0000".length());
lbl22:
            // 2 sources

            switch ((int)v3) {
                case -407207236: {
                    v4 = 3492L ^ -2583144703949771741L;
                    continue block31;
                }
                case 66758776: {
                    break block31;
                }
                case 1317417551: {
                    v4 = 29155L ^ -1155870456032346269L;
                    continue block31;
                }
                case 1505340949: {
                    v4 = 17676L ^ 5838401565072950928L;
                    continue block31;
                }
            }
            break;
        }
        while (true) {
            if ((v5 = (cfr_temp_3 = TwMapTraveller.\u13e8 - (5295L ^ 8064365308781821063L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v5 == (18122 ^ -18123)) break;
            v5 = 9830 ^ -189473918;
        }
        this.mapTraveler.uninstall();
        while (true) {
            if ((v6 = (cfr_temp_4 = TwMapTraveller.\u13e8 - (24123L ^ 4912405222865734345L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v6 == (32473 ^ -32474)) break;
            v6 = 20113 ^ -344406066;
        }
        v7 = TwMapTraveller.\u13e8;
        if (true) ** GOTO lbl49
        block34: while (true) {
            v7 = v8 / (16942L ^ 8294820126891691680L);
lbl49:
            // 2 sources

            switch ((int)v7) {
                case -53453922: {
                    v8 = -1903124177307393988L >>> "\u0000\u0000".length();
                    continue block34;
                }
                case 66758776: {
                    break block34;
                }
                case 187019775: {
                    v8 = 44942388821750884L >>> "\u0000\u0000".length();
                    continue block34;
                }
            }
            break;
        }
        while (true) {
            if ((v9 = (cfr_temp_5 = TwMapTraveller.\u13e8 - (20253L ^ -8307368518144216939L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
            if (v9 == (32515 ^ -32516)) break;
            v9 = 3939 ^ 121005194;
        }
        v10 = new MapTraveler(this.main);
        while (true) {
            if ((v11 = (cfr_temp_6 = TwMapTraveller.\u13e8 - (11122L ^ -8740959810947974201L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
            if (v11 == (10590 ^ 10591)) break;
            v11 = 27243 ^ 1237559238;
        }
        this.mapTraveler = v10;
        v12 = TwMapTraveller.\u13e8;
        if (true) ** GOTO lbl74
        block37: while (true) {
            v12 = v13 / (31806L ^ -1556128724412694288L);
lbl74:
            // 2 sources

            switch ((int)v12) {
                case -253096400: {
                    v13 = 2983L ^ 3512356262429142999L;
                    continue block37;
                }
                case 35645510: {
                    v13 = 4200L ^ -2247523186918431211L;
                    continue block37;
                }
                case 66758776: {
                    break block37;
                }
                case 1604426075: {
                    v13 = 6757977241737296860L >>> "\u0000\u0000".length();
                    continue block37;
                }
            }
            break;
        }
        v14 = TwMapTraveller.\u13e8;
        if (true) ** GOTO lbl90
        block38: while (true) {
            v14 = v15 / (16917L ^ 4299006705320886242L);
lbl90:
            // 2 sources

            switch ((int)v14) {
                case -1997140056: {
                    v15 = 27234L ^ -1967822093272211391L;
                    continue block38;
                }
                case -859004129: {
                    v15 = 19475L ^ -1925240519450162202L;
                    continue block38;
                }
                case 66758776: {
                    break block38;
                }
                case 1385850242: {
                    v15 = 21942L ^ 7611084998061930301L;
                    continue block38;
                }
            }
            break;
        }
        v16 = TwMapTraveller.\u13e8;
        if (true) ** GOTO lbl106
        block39: while (true) {
            v16 = v17 / (8092L ^ 4890515079044084643L);
lbl106:
            // 2 sources

            switch ((int)v16) {
                case -1245653280: {
                    v17 = 16094L ^ 7602165592906033584L;
                    continue block39;
                }
                case 66758776: {
                    break block39;
                }
                case 1804829757: {
                    v17 = 18630L ^ -7151053981953241300L;
                    continue block39;
                }
            }
            break;
        }
        v18 = this.starManager.byId(mapId);
        while (true) {
            if ((v19 = (cfr_temp_7 = TwMapTraveller.\u13e8 - (11715L ^ 2369510913486571150L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
            if (v19 == (19162 ^ -19163)) break;
            v19 = 6893 ^ 117524849;
        }
        this.mapTraveler.setTarget(v18);
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public boolean isDone() {
        v0 = TwMapTraveller.\u13e8;
        if (true) ** GOTO lbl5
        block10: while (true) {
            v0 = v1 / (31277L ^ 4022644696293989413L);
lbl5:
            // 2 sources

            switch ((int)v0) {
                case 66758776: {
                    break block10;
                }
                case 811608262: {
                    v1 = 21632L ^ 3565334306832477357L;
                    continue block10;
                }
                case 1218365538: {
                    v1 = 27589L ^ 7823945074649423350L;
                    continue block10;
                }
            }
            break;
        }
        if (this.mapTraveler == null) ** GOTO lbl-1000
        while (true) {
            if ((v2 = (cfr_temp_0 = TwMapTraveller.\u13e8 - (10617L ^ -6401821612713423972L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v2 == (16374 ^ -16375)) break;
            v2 = 24005 ^ 1484512153;
        }
        v3 = TwMapTraveller.\u13e8;
        if (true) ** GOTO lbl25
        block12: while (true) {
            v3 = v4 / (6782L ^ -3739678300020859842L);
lbl25:
            // 2 sources

            switch ((int)v3) {
                case -1993253284: {
                    v4 = 28740L ^ 4728985249838687394L;
                    continue block12;
                }
                case -1270365807: {
                    v4 = 476L ^ 6627491946968812049L;
                    continue block12;
                }
                case 66758776: {
                    break block12;
                }
            }
            break;
        }
        if (this.mapTraveler.isDone()) lbl-1000:
        // 2 sources

        {
            v5 = 1586 ^ 1587;
        } else {
            v5 = "".length() >>> "\u0000\u0000".length();
        }
        return (boolean)v5;
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public void install(Main main) {
        block57: {
            while (true) {
                if ((v0 = (cfr_temp_0 = TwMapTraveller.\u13e8 - (7695251384760322480L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v0 == (18843 ^ -18844)) break;
                v0 = 10936 ^ -884109126;
            }
            this.main = main;
            v1 = TwMapTraveller.\u13e8;
            if (true) ** GOTO lbl11
            block44: while (true) {
                v1 = v2 / (32751L ^ -1472550123278932145L);
lbl11:
                // 2 sources

                switch ((int)v1) {
                    case 66758776: {
                        break block44;
                    }
                    case 649462057: {
                        v2 = 9555L ^ -4196952109632123904L;
                        continue block44;
                    }
                    case 2143185334: {
                        v2 = 1190L ^ 7423681524667395274L;
                        continue block44;
                    }
                }
                break;
            }
            v3 = main.starManager;
            v4 = TwMapTraveller.\u13e8;
            if (true) ** GOTO lbl25
            block45: while (true) {
                v4 = v5 / (30029L ^ 8493663066134272692L);
lbl25:
                // 2 sources

                switch ((int)v4) {
                    case -950794114: {
                        v5 = 202L ^ -1809785230405730779L;
                        continue block45;
                    }
                    case 66758776: {
                        break block45;
                    }
                    case 2109247166: {
                        v5 = 24216L ^ -2410317346674953785L;
                        continue block45;
                    }
                }
                break;
            }
            this.starManager = v3;
            v6 = TwMapTraveller.\u13e8;
            if (true) ** GOTO lbl39
            block46: while (true) {
                v6 = v7 / (9608L ^ 5146691119136443142L);
lbl39:
                // 2 sources

                switch ((int)v6) {
                    case -1901688583: {
                        v7 = 3420L ^ -2841880637920933094L;
                        continue block46;
                    }
                    case -1680310930: {
                        v7 = 15098L ^ -1878616196974587347L;
                        continue block46;
                    }
                    case 66758776: {
                        break block46;
                    }
                }
                break;
            }
            v8 = main.config;
            v9 = TwMapTraveller.\u13e8;
            if (true) ** GOTO lbl53
            block47: while (true) {
                v9 = v10 / (6407L ^ -6363726184587785871L);
lbl53:
                // 2 sources

                switch ((int)v9) {
                    case -1280572478: {
                        v10 = -3082189120222965880L >>> "\u0000\u0000".length();
                        continue block47;
                    }
                    case 66758776: {
                        break block47;
                    }
                    case 1756688110: {
                        v10 = 5079L ^ -4439303562151793008L;
                        continue block47;
                    }
                    case 1942202868: {
                        v10 = 25445L ^ -2713235323042020851L;
                        continue block47;
                    }
                }
                break;
            }
            v11 = v8.GENERAL;
            while (true) {
                if ((v12 = (cfr_temp_1 = TwMapTraveller.\u13e8 - (26462L ^ 7163409557548440679L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v12 == (31570 ^ -31571)) break;
                v12 = 7957 ^ 2042429350;
            }
            this.mainConfigGeneral = v11;
            v13 = TwMapTraveller.\u13e8;
            if (true) ** GOTO lbl76
            block49: while (true) {
                v13 = v14 / (29786L ^ 9033900586551741089L);
lbl76:
                // 2 sources

                switch ((int)v13) {
                    case -1813773709: {
                        v14 = 23805L ^ -443569987872755105L;
                        continue block49;
                    }
                    case -756361426: {
                        v14 = 17804L ^ -2035582011562288100L;
                        continue block49;
                    }
                    case 66758776: {
                        break block49;
                    }
                    case 1296661004: {
                        v14 = 24069L ^ 9038841968069783367L;
                        continue block49;
                    }
                }
                break;
            }
            if (this.mapTraveler != null) break block57;
            v15 = TwMapTraveller.\u13e8;
            if (true) ** GOTO lbl93
            block50: while (true) {
                v15 = v16 / (15553L ^ 8200828786961481323L);
lbl93:
                // 2 sources

                switch ((int)v15) {
                    case -1498541870: {
                        v16 = 8041L ^ -6991522135858049871L;
                        continue block50;
                    }
                    case -1288285447: {
                        v16 = 3957L ^ -8712332019178734212L;
                        continue block50;
                    }
                    case 66758776: {
                        break block50;
                    }
                }
                break;
            }
            while (true) {
                if ((v17 = (cfr_temp_2 = TwMapTraveller.\u13e8 - (881L ^ -3475615603104864654L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v17 == (31244 ^ -31245)) break;
                v17 = 28020 ^ -556876953;
            }
            v18 = new MapTraveler(main);
            while (true) {
                if ((v19 = (cfr_temp_3 = TwMapTraveller.\u13e8 - (11583L ^ -8291906205235602207L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v19 == (16820 ^ -16821)) {
                    this.mapTraveler = v18;
                    break;
                }
                v19 = 12372 ^ 547280182;
            }
        }
        while (true) {
            if ((v20 = (cfr_temp_4 = TwMapTraveller.\u13e8 - (3018L ^ -5432822977712985138L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v20 == (24105 ^ -24106)) break;
            v20 = 17070 ^ 1509520510;
        }
        v21 = main.guiManager;
        v22 = TwMapTraveller.\u13e8;
        if (true) ** GOTO lbl126
        block54: while (true) {
            v22 = v23 / (7055L ^ -2584628156421806058L);
lbl126:
            // 2 sources

            switch ((int)v22) {
                case -1099771087: {
                    v23 = -5253254919633481452L >>> "\u0000\u0000".length();
                    continue block54;
                }
                case 66758776: {
                    break block54;
                }
                case 1700878400: {
                    v23 = 6445881079595348980L >>> "\u0000\u0000".length();
                    continue block54;
                }
            }
            break;
        }
        v24 = v21.pet;
        v25 = TwMapTraveller.\u13e8;
        if (true) ** GOTO lbl140
        block55: while (true) {
            v25 = v26 / (26901L ^ -546437434875435105L);
lbl140:
            // 2 sources

            switch ((int)v25) {
                case -685120563: {
                    v26 = 8770L ^ -2370111333995042689L;
                    continue block55;
                }
                case 66758776: {
                    break block55;
                }
                case 590812934: {
                    v26 = 2426L ^ -5133029229436255449L;
                    continue block55;
                }
                case 2136888520: {
                    v26 = 2052L ^ -1777518650925706007L;
                    continue block55;
                }
            }
            break;
        }
        this.pet = v24;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    @Override
    public void uninstall() {
        long l = \u13e8;
        boolean bl = true;
        block15: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x5AD7L ^ 0x5AB3686A7281D766L);
            }
            switch ((int)l) {
                case -1415000689: {
                    l2 = 0x1519L ^ 0x9C82BE571E0CB172L;
                    continue block15;
                }
                case -1150806106: {
                    l2 = 0x6321L ^ 0xA4EE66659473652AL;
                    continue block15;
                }
                case -1081508521: {
                    l2 = 0x2864L ^ 0xA96E552C6F21ED79L;
                    continue block15;
                }
                case 66758776: {
                    break block15;
                }
            }
            break;
        }
        if (this.mapTraveler != null) {
            while (true) {
                long l3;
                long l4;
                if ((l4 = (l3 = \u13e8 - (0x53EFL ^ 0xCD8A4CAB51D653B6L)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) continue;
                if (l4 == (0x5A3C ^ 0xFFFFA5C3)) break;
                l4 = 0x445F ^ 0x9E5AAC65;
            }
            long l5 = \u13e8;
            block17: while (true) {
                switch ((int)l5) {
                    case -2145384894: {
                        l5 = (0x1E8EL ^ 0x7EF8C6A82CC6E1EFL) / (0x569CL ^ 0x802EC321C125876FL);
                        continue block17;
                    }
                    case 66758776: {
                        break block17;
                    }
                }
                break;
            }
            this.mapTraveler.uninstall();
            long l6 = \u13e8;
            boolean bl2 = true;
            block18: while (true) {
                long l7;
                if (!bl2 || (bl2 = false) || !true) {
                    l6 = l7 / (0x7387L ^ 0x7E8BE96246728890L);
                }
                switch ((int)l6) {
                    case 66758776: {
                        break block18;
                    }
                    case 754852639: {
                        l7 = 0x3ECDL ^ 0x61D9E2EA3048A2CCL;
                        continue block18;
                    }
                    case 1325953900: {
                        l7 = 0x4C35L ^ 0x635577564EB5B737L;
                        continue block18;
                    }
                }
                break;
            }
            this.mapTraveler = null;
        }
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public void tick(TwMapTravellerConfig config) {
        while (true) {
            if ((v0 = (cfr_temp_0 = TwMapTraveller.\u13e8 - (14615L ^ -4232807701222716791L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (26172 ^ -26173)) break;
            v0 = 19733 ^ -1043689522;
        }
        v1 = TwMapTraveller.\u13e8;
        if (true) ** GOTO lbl10
        block27: while (true) {
            v1 = v2 / (2580L ^ -1873925648545636867L);
lbl10:
            // 2 sources

            switch ((int)v1) {
                case -2009348835: {
                    v2 = 7292L ^ 6551847307215668326L;
                    continue block27;
                }
                case -554642747: {
                    v2 = 29216L ^ -4934662561483281528L;
                    continue block27;
                }
                case 66758776: {
                    break block27;
                }
            }
            break;
        }
        workingMapId = this.mainConfigGeneral.WORKING_MAP;
        v3 = TwMapTraveller.\u13e8;
        if (true) ** GOTO lbl24
        block28: while (true) {
            v3 = v4 / (2680L ^ 7786075501063812676L);
lbl24:
            // 2 sources

            switch ((int)v3) {
                case -1222770022: {
                    v4 = 17381L ^ 5872129165480933775L;
                    continue block28;
                }
                case -618277110: {
                    v4 = 9190286376981194588L >>> "\u0000\u0000".length();
                    continue block28;
                }
                case -321669581: {
                    v4 = 7133L ^ 867006345806166031L;
                    continue block28;
                }
                case 66758776: {
                    break block28;
                }
            }
            break;
        }
        if (this.travellingToMapId != workingMapId) {
            while (true) {
                if ((v5 = (cfr_temp_1 = TwMapTraveller.\u13e8 - (23339L ^ 7947427274726913444L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v5 == (30022 ^ -30023)) {
                    this.setTargetMap(workingMapId);
                    break;
                }
                v5 = 11150 ^ 951761979;
            }
        }
        v6 = TwMapTraveller.\u13e8;
        if (true) ** GOTO lbl48
        block30: while (true) {
            v6 = (16375L ^ 7440410228984651710L) / (11346L ^ 9176826867539768878L);
lbl48:
            // 2 sources

            switch ((int)v6) {
                case -378591222: {
                    continue block30;
                }
                case 66758776: {
                    break block30;
                }
            }
            break;
        }
        v7 = TwMapTraveller.\u13e8;
        if (true) ** GOTO lbl57
        block31: while (true) {
            v7 = v8 / (1813L ^ 8947183554359367273L);
lbl57:
            // 2 sources

            switch ((int)v7) {
                case 66758776: {
                    break block31;
                }
                case 1662015147: {
                    v8 = 3517L ^ -5654052240998170916L;
                    continue block31;
                }
                case 2098211486: {
                    v8 = 8335L ^ 2415752923988375002L;
                    continue block31;
                }
            }
            break;
        }
        this.mapTraveler.tick();
        v9 = TwMapTraveller.\u13e8;
        if (true) ** GOTO lbl71
        block32: while (true) {
            v9 = v10 / (23911L ^ -255240804662247883L);
lbl71:
            // 2 sources

            switch ((int)v9) {
                case -820696764: {
                    v10 = 6872L ^ 3568770476046439121L;
                    continue block32;
                }
                case 66758776: {
                    break block32;
                }
                case 2017994305: {
                    v10 = 7127L ^ -5905505319975142488L;
                    continue block32;
                }
                case 2026258321: {
                    v10 = 13038L ^ -3032131142318989864L;
                    continue block32;
                }
            }
            break;
        }
        while (true) {
            if ((v11 = (cfr_temp_2 = TwMapTraveller.\u13e8 - (4005L ^ -3292225583242625767L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v11 == (23477 ^ -23478)) break;
            v11 = 21550 ^ 402370469;
        }
        v12 = config.PET_OUT_WHILE_TRAVELLING;
        while (true) {
            if ((v13 = (cfr_temp_3 = TwMapTraveller.\u13e8 - (27119L ^ 5624178518608803068L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v13 == (29170 ^ -29171)) break;
            v13 = -2079916740 >>> "\u0000\u0000".length();
        }
        this.pet.setEnabled(v12);
    }
}

