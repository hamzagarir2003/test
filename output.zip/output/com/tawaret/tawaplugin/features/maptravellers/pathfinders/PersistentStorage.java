/*
 * Decompiled with CFR 0.152.
 */
package com.tawaret.tawaplugin.features.maptravellers.pathfinders;

import com.tawaret.tawaplugin.features.mapcyclemodule.states.PersistentState;

public class PersistentStorage {
    public com.tawaret.tawaplugin.behaviors.stingerwarper.PersistentState STINGER_WARPER;
    public PersistentState MAP_CYCLE;
    protected static long \u13e8 = -7893687019033912601L;

    /*
     * Unable to fully structure code
     */
    public PersistentStorage() {
        while (true) {
            if ((v0 = (cfr_temp_0 = PersistentStorage.\u13e8 - (28872L ^ -195537504818892657L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (31944 ^ -31945)) break;
            v0 = 21206 ^ -1537504026;
        }
        super();
        while (true) {
            if ((v1 = (cfr_temp_1 = PersistentStorage.\u13e8 - (25057L ^ 7012137046789240381L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v1 == (8389 ^ -8390)) break;
            v1 = 5939 ^ -534063627;
        }
        while (true) {
            if ((v2 = (cfr_temp_2 = PersistentStorage.\u13e8 - (7105L ^ 7396634554864608824L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v2 == (9888 ^ -9889)) break;
            v2 = 13943 ^ 1073847592;
        }
        v3 = new com.tawaret.tawaplugin.behaviors.stingerwarper.PersistentState();
        while (true) {
            if ((v4 = (cfr_temp_3 = PersistentStorage.\u13e8 - (6375L ^ 4958696490037324795L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v4 == (5697 ^ -5698)) break;
            v4 = 10654 ^ -1624111349;
        }
        this.STINGER_WARPER = v3;
        while (true) {
            if ((v5 = (cfr_temp_4 = PersistentStorage.\u13e8 - (11883L ^ -1449799349676116503L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v5 == (5703 ^ -5704)) break;
            v5 = 7141 ^ 1449869320;
        }
        v6 = PersistentStorage.\u13e8;
        if (true) ** GOTO lbl33
        block16: while (true) {
            v6 = v7 / (6416L ^ 3911015588987225888L);
lbl33:
            // 2 sources

            switch ((int)v6) {
                case -1906369817: {
                    break block16;
                }
                case -316919214: {
                    v7 = 25197L ^ 3421630326429155476L;
                    continue block16;
                }
                case 1811025236: {
                    v7 = 1027L ^ 8147442759713025566L;
                    continue block16;
                }
            }
            break;
        }
        v8 = new PersistentState();
        v9 = PersistentStorage.\u13e8;
        if (true) ** GOTO lbl47
        block17: while (true) {
            v9 = v10 / (7837L ^ 6480084219251446704L);
lbl47:
            // 2 sources

            switch ((int)v9) {
                case -2085183106: {
                    v10 = -8448402076216607480L >>> "\u0000\u0000".length();
                    continue block17;
                }
                case -1906369817: {
                    break block17;
                }
                case -427376327: {
                    v10 = 23707L ^ -1296405601484194159L;
                    continue block17;
                }
                case -221944416: {
                    v10 = 10871L ^ 2528108998457109755L;
                    continue block17;
                }
            }
            break;
        }
        this.MAP_CYCLE = v8;
    }
}

