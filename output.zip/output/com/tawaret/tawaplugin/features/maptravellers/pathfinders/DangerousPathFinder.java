/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.core.manager.HeroManager
 *  com.github.manolo8.darkbot.core.manager.MapManager
 *  com.github.manolo8.darkbot.core.utils.pathfinder.PathFinder
 *  eu.darkbot.api.game.other.Locatable
 */
package com.tawaret.tawaplugin.features.maptravellers.pathfinders;

import com.github.manolo8.darkbot.core.manager.HeroManager;
import com.github.manolo8.darkbot.core.manager.MapManager;
import com.github.manolo8.darkbot.core.utils.pathfinder.PathFinder;
import com.tawaret.tawaplugin.features.maptravellers.PathFinderConfig;
import eu.darkbot.api.game.other.Locatable;

public class DangerousPathFinder
extends PathFinder {
    private PathFinderConfig config;
    private HeroManager hero;
    static long \u13e8 = 3109430064040035351L;

    /*
     * Enabled aggressive block sorting
     */
    public DangerousPathFinder(MapManager map) {
        long l = \u13e8;
        block4: while (true) {
            switch ((int)l) {
                case -2086911515: {
                    l = (1514398146790427824L >>> "\u0000\u0000".length()) / (0x4D2CL ^ 0xB8EAAD0D9DF95F63L);
                    continue block4;
                }
                case 889635863: {
                    break block4;
                }
            }
            break;
        }
        super(map, null);
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public boolean isOutOfMap(Locatable loc) {
        block24: {
            while (true) {
                long l;
                long l2;
                if ((l2 = (l = \u13e8 - (0x4C92L ^ 0x89B6314C57A0C970L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (l2 == (0x5563 ^ 0x5562)) {
                    if (this.canCheckConfig()) {
                        break;
                    }
                    break block24;
                }
                l2 = 0x7BDE ^ 0x4307B38E;
            }
            while (true) {
                long l;
                long l3;
                if ((l3 = (l = \u13e8 - (0x7E18L ^ 0xC5430A23A9AEFF46L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (l3 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                l3 = 0x15D9 ^ 0xFF1C6646;
            }
            while (true) {
                long l;
                long l4;
                if ((l4 = (l = \u13e8 - (0x2C98L ^ 0x1F8BBC4A051B8D4FL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (l4 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                    if (this.config.TRAVEL_THROUGH_RAD_ZONE) {
                        break;
                    }
                    break block24;
                }
                l4 = -397059108 >>> "\u0000\u0000".length();
            }
            while (true) {
                long l;
                long l5;
                if ((l5 = (l = \u13e8 - (0x4ECCL ^ 0x7F079B03C92AA8E4L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (l5 == (0x411B ^ 0xFFFFBEE4)) break;
                l5 = 0x5DCF ^ 0xF07651FE;
            }
            while (true) {
                long l;
                long l6;
                if ((l6 = (l = \u13e8 - (0x1584L ^ 0x64614A12179F7A65L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (l6 == (0x4B62 ^ 0xFFFFB49D)) {
                    if (this.canUseRadiationZone(this.hero)) {
                        return (0x2006 ^ 0x2006) != 0;
                    }
                    break;
                }
                l6 = 0x714B ^ 0x4CDC8927;
            }
        }
        long l = \u13e8;
        boolean bl = true;
        block11: while (true) {
            long l7;
            if (!bl || (bl = false) || !true) {
                l = l7 / (0x3D57L ^ 0x4A84CCA3415DA363L);
            }
            switch ((int)l) {
                case -1237066682: {
                    l7 = -4434205788734424540L >>> "\u0000\u0000".length();
                    continue block11;
                }
                case -470507931: {
                    l7 = 0x6631L ^ 0xFA46CEBC2DD5B265L;
                    continue block11;
                }
                case -421506664: {
                    l7 = 0x679AL ^ 0xC0A6F63C9B9C80F7L;
                    continue block11;
                }
                case 889635863: {
                    return super.isOutOfMap(loc);
                }
            }
            break;
        }
        return super.isOutOfMap(loc);
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public boolean isOutOfMap(double x, double y) {
        block31: {
            long l = \u13e8;
            boolean bl = true;
            block14: while (true) {
                long l2;
                if (!bl || (bl = false) || !true) {
                    l = l2 / (-7300272776022769056L >>> "\u0000\u0000".length());
                }
                switch ((int)l) {
                    case -1379189797: {
                        l2 = 0x4C86L ^ 0xD4569816133145DCL;
                        continue block14;
                    }
                    case -289893823: {
                        l2 = 0x291EL ^ 0xF0100B2B60B1DA24L;
                        continue block14;
                    }
                    case 889635863: {
                        break block14;
                    }
                }
                break;
            }
            if (this.canCheckConfig()) {
                long l3 = \u13e8;
                boolean bl2 = true;
                block15: while (true) {
                    long l4;
                    if (!bl2 || (bl2 = false) || !true) {
                        l3 = l4 / (0x4048L ^ 0x3CDF281657A2514CL);
                    }
                    switch ((int)l3) {
                        case -1195329001: {
                            l4 = 0x454CL ^ 0xED255CFA0C83ABCEL;
                            continue block15;
                        }
                        case 889635863: {
                            break block15;
                        }
                        case 1581139813: {
                            l4 = -7718104804220166088L >>> "\u0000\u0000".length();
                            continue block15;
                        }
                    }
                    break;
                }
                while (true) {
                    long l5;
                    long l6;
                    if ((l6 = (l5 = \u13e8 - (0x7022L ^ 0x4E4F96376B4815EAL)) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) {
                        continue;
                    }
                    if (l6 == (0x7D96 ^ 0xFFFF8269)) {
                        if (this.config.TRAVEL_THROUGH_RAD_ZONE) {
                            break;
                        }
                        break block31;
                    }
                    l6 = 0xAD2 ^ 0x9B406329;
                }
                long l7 = \u13e8;
                block17: while (true) {
                    switch ((int)l7) {
                        case 91281877: {
                            l7 = (0x7667L ^ 0xE14D6E90CEC52E96L) / (0xC0L ^ 0x5CA8D9F7556C8C22L);
                            continue block17;
                        }
                        case 889635863: {
                            break block17;
                        }
                    }
                    break;
                }
                while (true) {
                    long l8;
                    long l9;
                    if ((l9 = (l8 = \u13e8 - (0x1D3FL ^ 0xC70259962A2637F0L)) == 0L ? 0 : (l8 < 0L ? -1 : 1)) == false) {
                        continue;
                    }
                    if (l9 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                        if (this.canUseRadiationZone(this.hero)) {
                            return (0x3801 ^ 0x3801) != 0;
                        }
                        break;
                    }
                    l9 = 0x7FE5 ^ 0x7B9F83E7;
                }
            }
        }
        while (true) {
            long l;
            long l10;
            if ((l10 = (l = \u13e8 - (0x56B4L ^ 0xCFCC4E57D1958B53L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l10 == (0x55AF ^ 0x55AE)) {
                return super.isOutOfMap(x, y);
            }
            l10 = 0x1BFA ^ 0x8E510D9F;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private boolean canCheckConfig() {
        int n;
        block10: {
            while (true) {
                long l;
                long l2;
                if ((l2 = (l = \u13e8 - (0x38DCL ^ 0x6D2495C7E7616381L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (l2 == (0xC3 ^ 0xFFFFFF3C)) {
                    if (this.config != null) {
                        break;
                    }
                    break block10;
                }
                l2 = 0x18F0 ^ 0xDA3B3362;
            }
            long l = \u13e8;
            block5: while (true) {
                switch ((int)l) {
                    case 681312206: {
                        l = (0x57D2L ^ 0x96E875D6B1D1A80BL) / (0x6EADL ^ 0xECCB75E9B3928F5DL);
                        continue block5;
                    }
                    case 889635863: {
                        break block5;
                    }
                }
                break;
            }
            if (this.hero != null) {
                n = 0x7A54 ^ 0x7A55;
                return n != 0;
            }
        }
        n = "".length() >>> "\u0000\u0000".length();
        return n != 0;
    }

    /*
     * Unable to fully structure code
     */
    private boolean canUseRadiationZone(HeroManager hero) {
        while (true) {
            if ((v0 = (cfr_temp_0 = DangerousPathFinder.\u13e8 - (11184L ^ -2370222404321348611L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v0 = 17109 ^ 1713309433;
        }
        v1 = hero.locationInfo;
        v2 = DangerousPathFinder.\u13e8;
        if (true) ** GOTO lbl11
        block16: while (true) {
            v2 = v3 / (7827127726547344308L >>> "\u0000\u0000".length());
lbl11:
            // 2 sources

            switch ((int)v2) {
                case 178947330: {
                    v3 = 22528L ^ 6306147837221755020L;
                    continue block16;
                }
                case 710255616: {
                    v3 = 20245L ^ -4607447866903097024L;
                    continue block16;
                }
                case 889635863: {
                    break block16;
                }
            }
            break;
        }
        v4 = v1.now;
        while (true) {
            if ((v5 = (cfr_temp_1 = DangerousPathFinder.\u13e8 - (2676L ^ -498656454570482925L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v5 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v5 = 28250 ^ 1903103680;
        }
        if (super.isOutOfMap((Locatable)v4)) {
            return "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        }
        while (true) {
            if ((v6 = (cfr_temp_2 = DangerousPathFinder.\u13e8 - (29852L ^ 7172704779819120134L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v6 == (21471 ^ -21472)) break;
            v6 = 31948 ^ 756068707;
        }
        v7 = hero.health;
        v8 = DangerousPathFinder.\u13e8;
        if (true) ** GOTO lbl38
        block19: while (true) {
            v8 = v9 / (12307L ^ 5204637196277162550L);
lbl38:
            // 2 sources

            switch ((int)v8) {
                case 889635863: {
                    break block19;
                }
                case 1179257409: {
                    v9 = 22384L ^ 3370569509876910869L;
                    continue block19;
                }
                case 1806054703: {
                    v9 = 17549L ^ -7762619261868878596L;
                    continue block19;
                }
            }
            break;
        }
        v10 = v7.hpPercent() * 100.0;
        while (true) {
            if ((v11 = (cfr_temp_3 = DangerousPathFinder.\u13e8 - (22986L ^ -6077209931211532067L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v11 == (32138 ^ 32139)) break;
            v11 = 664354036 >>> "\u0000\u0000".length();
        }
        v12 = DangerousPathFinder.\u13e8;
        if (true) ** GOTO lbl57
        block21: while (true) {
            v12 = v13 / (25392L ^ 2015549196491411444L);
lbl57:
            // 2 sources

            switch ((int)v12) {
                case -2135438291: {
                    v13 = 13659L ^ -4539438543239694262L;
                    continue block21;
                }
                case -54492833: {
                    v13 = 6180L ^ 6004251253580845310L;
                    continue block21;
                }
                case 889635863: {
                    break block21;
                }
            }
            break;
        }
        return (boolean)(v10 >= (double)this.config.RAD_ZONE_HP_THESH ? "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length() : 17952 ^ 17952);
    }

    public void clearConfig() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x1ED2L ^ 0xAC07188D31AD5EBDL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x7643 ^ 0x7642)) break;
            l2 = 0x73C0 ^ 0xC0177E7A;
        }
        this.setConfig(null, null);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void setConfig(PathFinderConfig config, HeroManager hero) {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x659CL ^ 0x8DCE2342481D06CAL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l2 = 0x35A1 ^ 0x56A264F2;
        }
        this.config = config;
        long l = \u13e8;
        block5: while (true) {
            switch ((int)l) {
                case 889635863: {
                    break block5;
                }
                case 1015455611: {
                    l = (0x2883L ^ 0xFA60EEABDECAEA74L) / (1712850068320893704L >>> "\u0000\u0000".length());
                    continue block5;
                }
            }
            break;
        }
        this.hero = hero;
    }
}

