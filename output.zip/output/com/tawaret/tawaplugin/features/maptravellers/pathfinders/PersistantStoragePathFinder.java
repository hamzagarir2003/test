/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.core.manager.HeroManager
 *  com.github.manolo8.darkbot.core.manager.MapManager
 *  com.github.manolo8.darkbot.core.utils.Drive
 *  com.github.manolo8.darkbot.core.utils.pathfinder.PathFinder
 *  eu.darkbot.api.managers.ConfigAPI
 */
package com.tawaret.tawaplugin.features.maptravellers.pathfinders;

import com.github.manolo8.darkbot.core.manager.HeroManager;
import com.github.manolo8.darkbot.core.manager.MapManager;
import com.github.manolo8.darkbot.core.utils.Drive;
import com.github.manolo8.darkbot.core.utils.pathfinder.PathFinder;
import com.tawaret.tawaplugin.features.maptravellers.pathfinders.PersistentStorage;
import eu.darkbot.api.managers.ConfigAPI;

public class PersistantStoragePathFinder
extends PathFinder {
    private static PersistantStoragePathFinder instance;
    private final PersistentStorage persistentState;
    static long \u13e8 = 8314883716439729220L;

    /*
     * Enabled aggressive block sorting
     */
    private PersistantStoragePathFinder(MapManager map, ConfigAPI configAPI) {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x6880L ^ 0xA853E0BDA2C6705DL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x3023 ^ 0x3022)) break;
            l2 = 0x4256 ^ 0x4F7DE757;
        }
        super(map, configAPI);
        long l = \u13e8;
        block9: while (true) {
            switch ((int)l) {
                case -1693326268: {
                    break block9;
                }
                case -897552386: {
                    l = (0x2AC3L ^ 0xF38483D959DC53ADL) / (0x2852L ^ 0x4724CDCA45E9447BL);
                    continue block9;
                }
            }
            break;
        }
        while (true) {
            long l3;
            long l4;
            if ((l4 = (l3 = \u13e8 - (0x5180L ^ 0x9921959AF0E41AA1L)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) continue;
            if (l4 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l4 = 0x1C41 ^ 0x1BC69F0C;
        }
        PersistentStorage persistentStorage = new PersistentStorage();
        long l5 = \u13e8;
        block11: while (true) {
            switch ((int)l5) {
                case -1693326268: {
                    break block11;
                }
                case 1629187002: {
                    l5 = (0x2C0EL ^ 0x5404891F7E8EEA9FL) / (0x3C3CL ^ 0x941FA50E7BCD78C5L);
                    continue block11;
                }
            }
            break;
        }
        this.persistentState = persistentStorage;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public static PersistantStoragePathFinder getInstance(MapManager map, ConfigAPI configAPI, HeroManager heroManager) {
        long l = \u13e8;
        boolean bl = true;
        block21: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x1BCAL ^ 0xC0009D0F672B3951L);
            }
            switch ((int)l) {
                case -1744397802: {
                    l2 = 0x5179L ^ 0x9BC1BE54201EC984L;
                    continue block21;
                }
                case -1693326268: {
                    break block21;
                }
                case -111862639: {
                    l2 = 0x1528L ^ 0x79280790B5C3EB62L;
                    continue block21;
                }
                case 1080012682: {
                    l2 = 0x5BB4L ^ 0xA35D9238CE0D38E2L;
                    continue block21;
                }
            }
            break;
        }
        Drive drive = heroManager.drive;
        long l3 = \u13e8;
        boolean bl2 = true;
        block22: while (true) {
            long l4;
            if (!bl2 || (bl2 = false) || !true) {
                l3 = l4 / (0x2F20L ^ 0x4699B05AD2EE2D6CL);
            }
            switch ((int)l3) {
                case -1693326268: {
                    break block22;
                }
                case -840505493: {
                    l4 = 6025535297663166900L >>> "\u0000\u0000".length();
                    continue block22;
                }
                case 1929126383: {
                    l4 = 0x6E5EL ^ 0x399E7036A28DDB27L;
                    continue block22;
                }
            }
            break;
        }
        PathFinder current = drive.pathFinder;
        if (current instanceof PersistantStoragePathFinder) {
            PersistantStoragePathFinder persistantStoragePathFinder = (PersistantStoragePathFinder)current;
            long l5 = \u13e8;
            block23: while (true) {
                switch ((int)l5) {
                    case -1693326268: {
                        break block23;
                    }
                    case -1509157329: {
                        l5 = (0x489DL ^ 0xCD6A782DAB279B79L) / (0x242DL ^ 0x8642F88285C017CBL);
                        continue block23;
                    }
                }
                break;
            }
            instance = persistantStoragePathFinder;
        }
        long l6 = \u13e8;
        boolean bl3 = true;
        block24: while (true) {
            long l7;
            if (!bl3 || (bl3 = false) || !true) {
                l6 = l7 / (3143946585761550796L >>> "\u0000\u0000".length());
            }
            switch ((int)l6) {
                case -1693326268: {
                    break block24;
                }
                case -1387816698: {
                    l7 = 0x2F28L ^ 0x554184426CFD47A8L;
                    continue block24;
                }
                case -1072119855: {
                    l7 = 0x69F4L ^ 0xDEE3099DDCC0285AL;
                    continue block24;
                }
                case 317979282: {
                    l7 = 0x40B2L ^ 0x265AA683F84A11E3L;
                    continue block24;
                }
            }
            break;
        }
        if (instance == null) {
            while (true) {
                long l8;
                long l9;
                if ((l9 = (l8 = \u13e8 - (0x791AL ^ 0x5D7F75ED81F27A3DL)) == 0L ? 0 : (l8 < 0L ? -1 : 1)) == false) continue;
                if (l9 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                l9 = 0x58A6 ^ 0x29E51E32;
            }
            while (true) {
                long l10;
                long l11;
                if ((l11 = (l10 = \u13e8 - (0x2DB1L ^ 0x1951D96F79ECAD06L)) == 0L ? 0 : (l10 < 0L ? -1 : 1)) == false) continue;
                if (l11 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                l11 = -916728100 >>> "\u0000\u0000".length();
            }
            PersistantStoragePathFinder persistantStoragePathFinder = new PersistantStoragePathFinder(map, configAPI);
            while (true) {
                long l12;
                long l13;
                if ((l13 = (l12 = \u13e8 - (0xADL ^ 0xEAD0FA35C5E27B23L)) == 0L ? 0 : (l12 < 0L ? -1 : 1)) == false) continue;
                if (l13 == (0x2834 ^ 0x2835)) {
                    instance = persistantStoragePathFinder;
                    break;
                }
                l13 = 0x2FBD ^ 0x53E324EA;
            }
        }
        while (true) {
            long l14;
            long l15;
            if ((l15 = (l14 = \u13e8 - (0x5EC0L ^ 0x29F5DCA8A4C59C72L)) == 0L ? 0 : (l14 < 0L ? -1 : 1)) == false) continue;
            if (l15 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l15 = 0x54AE ^ 0x46D868C0;
        }
        while (true) {
            long l16;
            long l17;
            if ((l17 = (l16 = \u13e8 - (0x261CL ^ 0x276633AF9B8FA387L)) == 0L ? 0 : (l16 < 0L ? -1 : 1)) == false) continue;
            if (l17 == (0x2DCE ^ 0x2DCF)) break;
            l17 = 378619220 >>> "\u0000\u0000".length();
        }
        instance.set(heroManager);
        while (true) {
            long l18;
            long l19;
            if ((l19 = (l18 = \u13e8 - (3609324670779349240L >>> "\u0000\u0000".length())) == 0L ? 0 : (l18 < 0L ? -1 : 1)) == false) continue;
            if (l19 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                return instance;
            }
            l19 = 1631590924 >>> "\u0000\u0000".length();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public static PersistantStoragePathFinder getInstance() {
        long l = \u13e8;
        block4: while (true) {
            switch ((int)l) {
                case -1693326268: {
                    return instance;
                }
                case 2086883854: {
                    l = (0x2936L ^ 0x77784E2651E1C349L) / (0x79B1L ^ 0x5B3DDCB557051B47L);
                    continue block4;
                }
            }
            break;
        }
        return instance;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private void set(HeroManager heroManager) {
        long l = \u13e8;
        boolean bl = true;
        block20: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (-4659973805689300484L >>> "\u0000\u0000".length());
            }
            switch ((int)l) {
                case -1693326268: {
                    break block20;
                }
                case 1106815030: {
                    l2 = 0x532DL ^ 0xC70A0DB6988C9EEBL;
                    continue block20;
                }
                case 1266181545: {
                    l2 = 0x40E9L ^ 0xCFE9FF665EEA409EL;
                    continue block20;
                }
            }
            break;
        }
        Drive drive = heroManager.drive;
        long l3 = \u13e8;
        boolean bl2 = true;
        block21: while (true) {
            long l4;
            if (!bl2 || (bl2 = false) || !true) {
                l3 = l4 / (0x531EL ^ 0x25A13DBFDB54132L);
            }
            switch ((int)l3) {
                case -1693326268: {
                    break block21;
                }
                case -485508431: {
                    l4 = -4141817886275854180L >>> "\u0000\u0000".length();
                    continue block21;
                }
                case 1296241750: {
                    l4 = 7039333845549755192L >>> "\u0000\u0000".length();
                    continue block21;
                }
            }
            break;
        }
        if (drive.pathFinder != this) {
            long l5 = \u13e8;
            boolean bl3 = true;
            block22: while (true) {
                long l6;
                if (!bl3 || (bl3 = false) || !true) {
                    l5 = l6 / (0xCECL ^ 0xC424A879973A9401L);
                }
                switch ((int)l5) {
                    case -1693326268: {
                        break block22;
                    }
                    case -842444544: {
                        l6 = 0x4340L ^ 0x428866917B4BFA45L;
                        continue block22;
                    }
                    case 230107558: {
                        l6 = 0x2A89L ^ 0x75E8584AB1DF250BL;
                        continue block22;
                    }
                }
                break;
            }
            Drive drive2 = heroManager.drive;
            long l7 = \u13e8;
            boolean bl4 = true;
            block23: while (true) {
                long l8;
                if (!bl4 || (bl4 = false) || !true) {
                    l7 = l8 / (4061854670026969664L >>> "\u0000\u0000".length());
                }
                switch ((int)l7) {
                    case -1693326268: {
                        break block23;
                    }
                    case -1689970214: {
                        l8 = 0x6709L ^ 0x78BA9D161F4246A0L;
                        continue block23;
                    }
                    case 1459906526: {
                        l8 = 0x2EA8L ^ 0x4642C80676BEF393L;
                        continue block23;
                    }
                }
                break;
            }
            drive2.pathFinder = this;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public PersistentStorage getPersistentState() {
        long l = \u13e8;
        block4: while (true) {
            switch ((int)l) {
                case -1693326268: {
                    return this.persistentState;
                }
                case -250402087: {
                    l = (0x3166L ^ 0x654C32B215532777L) / (0x34CEL ^ 0x747010965A14729CL);
                    continue block4;
                }
            }
            break;
        }
        return this.persistentState;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    static {
        long l = \u13e8;
        boolean bl = true;
        block5: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (2803449913134808576L >>> "\u0000\u0000".length());
            }
            switch ((int)l) {
                case -1693326268: {
                    break block5;
                }
                case -883327686: {
                    l2 = -3838409458032661764L >>> "\u0000\u0000".length();
                    continue block5;
                }
                case -80315542: {
                    l2 = 0x7AAL ^ 0xE9F3F979DC63B91AL;
                    continue block5;
                }
            }
            break;
        }
        instance = null;
    }
}

