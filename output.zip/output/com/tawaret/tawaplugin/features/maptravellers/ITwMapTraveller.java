/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.Main
 */
package com.tawaret.tawaplugin.features.maptravellers;

import com.github.manolo8.darkbot.Main;
import com.tawaret.tawaplugin.debugging.IDebuggable;
import com.tawaret.tawaplugin.features.maptravellers.TwMapTravellerConfig;

public interface ITwMapTraveller
extends IDebuggable {
    public void setTargetMap(int var1);

    public boolean isDone();

    public void install(Main var1);

    public void uninstall();

    public void tick(TwMapTravellerConfig var1);
}

