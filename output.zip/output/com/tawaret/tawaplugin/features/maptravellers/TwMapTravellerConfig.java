/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.config.types.Option
 */
package com.tawaret.tawaplugin.features.maptravellers;

import com.github.manolo8.darkbot.config.types.Option;

public class TwMapTravellerConfig {
    @Option(value="Keep PET out while travelling", description="Pet will remain out while travelling between maps")
    public boolean PET_OUT_WHILE_TRAVELLING;
    static long \u13e8 = 4848276660589098521L;

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public TwMapTravellerConfig() {
        long l = \u13e8;
        boolean bl = true;
        block5: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x7675L ^ 0xB4007B810BD19C50L);
            }
            switch ((int)l) {
                case -617018369: {
                    l2 = 0x5450L ^ 0x6AB3D0C56427759EL;
                    continue block5;
                }
                case 1897486339: {
                    l2 = 0x5906L ^ 0x2A7EFD98F1A542B4L;
                    continue block5;
                }
                case 2134570521: {
                    break block5;
                }
            }
            break;
        }
        while (true) {
            long l3;
            long l4;
            if ((l4 = (l3 = \u13e8 - (0x4A3BL ^ 0x9C1C9F9AB95D19FFL)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l4 == (0x2040 ^ 0x2041)) {
                this.PET_OUT_WHILE_TRAVELLING = 0x4F88 ^ 0x4F88;
                return;
            }
            l4 = 0x7989 ^ 0x70C6C3B5;
        }
    }
}

