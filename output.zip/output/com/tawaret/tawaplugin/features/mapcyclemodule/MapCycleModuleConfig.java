/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.config.Config$ShipConfig
 *  com.github.manolo8.darkbot.config.types.Editor
 *  com.github.manolo8.darkbot.config.types.Num
 *  com.github.manolo8.darkbot.config.types.Option
 *  com.github.manolo8.darkbot.core.utils.Lazy
 *  com.github.manolo8.darkbot.core.utils.Lazy$NoCache
 */
package com.tawaret.tawaplugin.features.mapcyclemodule;

import com.github.manolo8.darkbot.config.Config;
import com.github.manolo8.darkbot.config.types.Editor;
import com.github.manolo8.darkbot.config.types.Num;
import com.github.manolo8.darkbot.config.types.Option;
import com.github.manolo8.darkbot.core.utils.Lazy;
import com.tawaret.tawaplugin.features.bettermodules.TwLootModuleConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.AdaptiveChecksConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.AfterKillConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.GroupConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.KeyFirstLockConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.MapCycleBoxCollectConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.MapCyclePetConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.MapCycleRefreshConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.MapCycleSafetyConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.MiscellaneousConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.NpcRewardConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.PredictNpcSpawnConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.ServerRestartHandlerConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.conditionconfigs.MapChangeConditionConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.models.MapInfo;
import com.tawaret.tawaplugin.gui.components.JMapCycleInfoTable;
import java.util.HashMap;
import java.util.Map;

public class MapCycleModuleConfig {
    @Option(value="NPC subname (lower-case)", description="Used when cannot detect kill from logs, by checking locked npc name for this (empty to disable)")
    public String NPC_SUBNAME;
    @Editor(value=JMapCycleInfoTable.class, shared=true)
    @Option
    public Map<String, MapInfo> CYCLE_MAP_INFOS;
    public transient Lazy<String> MODIFIED_CYCLE_MAP;
    @Option(value="Enable anchor position", description="Uses the anchor position coordinate as primary roam location if defined")
    public boolean ENABLE_ANCHOR_POSITION;
    @Option(value="Anchor radius", description="Radius to randomly generate anchor position to move to, 0 to stay at anchor")
    @Num(min=0, max=600, step=10)
    public int ANCHOR_RADIUS;
    @Option(value="Random roam every (Seconds)", description="Ship will move around the anchor every this seconds, 0 for stationary")
    @Num(min=0, max=60, step=1)
    public int STATIONARY_RANDOM_ROAM_SECONDS;
    @Option(value="Move if under attack")
    public boolean MOVE_IF_UNDER_ATTACK;
    @Option(value="Preferred region travel config")
    public Config.ShipConfig PREFERRED_REGION_TRAVEL_CONFIG;
    @Option(value="Diamond travel config", description="Bot will use this config if travelling and below the rad zone % Hp threshold (diamond formation recommended)")
    public Config.ShipConfig LOW_HP_PREFERRED_REGION_TRAVEL_CONFIG;
    @Option(value="Map Change Conditions")
    public MapChangeConditionConfig MAP_CHANGE_COND_CONFIG;
    @Option(value="Auto configure cycle maps")
    public AdaptiveChecksConfig ADAPTIVE_CHECKS_CONFIG;
    @Option(value="After Kill")
    public AfterKillConfig AFTER_KILL_CONFIG;
    @Option(value="Key First Lock (KFL)")
    public KeyFirstLockConfig KEY_FIRST_LOCK_CONFIG;
    @Option(value="PET")
    public MapCyclePetConfig PET_CONFIG;
    @Option(value="Box Collecting")
    public MapCycleBoxCollectConfig BOX_COLLECT_CONFIG;
    @Option(value="Server Restart Handling")
    public ServerRestartHandlerConfig SERVER_RESTART_HANDLER_CONFIG;
    @Option(value="Npc Killer")
    public TwLootModuleConfig BETTER_LOOT_MODULE_CONFIG;
    @Option(value="Safety")
    public MapCycleSafetyConfig SAFETY_CONFIG;
    @Option(value="Predict Npc Spawn")
    public PredictNpcSpawnConfig PREDICT_NPC_SPAWN_CONFIG;
    @Option(value="Refresh")
    public MapCycleRefreshConfig REFRESH_CONFIG;
    @Option(value="Npc Reward", description="For veteran before npc dies")
    public NpcRewardConfig NPC_REWARD_CONFIG;
    @Option(value="Group")
    public GroupConfig GROUP_CONFIG;
    @Option(value="Miscellaneous")
    public MiscellaneousConfig MISC_CONFIG;
    protected static long \u13e8 = -2226200618637857960L;

    /*
     * Unable to fully structure code
     */
    public MapCycleModuleConfig() {
        while (true) {
            if ((v0 = (cfr_temp_0 = MapCycleModuleConfig.\u13e8 - (776L ^ 9153763398565822700L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (21469 ^ -21470)) break;
            v0 = 6509 ^ -1527353127;
        }
        super();
        var2_1 = new byte["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
        var2_1[1483 ^ 1486] = 4647 ^ -4661;
        var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 444 >>> "\u0000\u0000".length();
        var2_1[17545 ^ 17545] = 30122 ^ 30152;
        var2_1[18781 ^ 18778] = 416 >>> "\u0000\u0000".length();
        var2_1["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 28431 ^ 28522;
        var2_1[27674 ^ 27673] = 404 >>> "\u0000\u0000".length();
        var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 22762 ^ 22663;
        var2_1[25446 ^ 25440] = 1754 ^ 1710;
        var2_1[1167 ^ 1165] = 416 >>> "\u0000\u0000".length();
        v1 = new String(var2_1);
        while (true) {
            if ((v2 = (cfr_temp_1 = MapCycleModuleConfig.\u13e8 - (584L ^ -4261285074002709100L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v2 == (18006 ^ 18007)) break;
            v2 = 25347 ^ -2018038496;
        }
        this.NPC_SUBNAME = v1;
        while (true) {
            if ((v3 = (cfr_temp_2 = MapCycleModuleConfig.\u13e8 - (32020L ^ -6802735795405769365L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v3 == (11872 ^ 11873)) break;
            v3 = 9661 ^ -1798535121;
        }
        v4 = MapCycleModuleConfig.\u13e8;
        if (true) ** GOTO lbl33
        block182: while (true) {
            v4 = (-573088860711235616L >>> "\u0000\u0000".length()) / (24327L ^ -3712009124641103392L);
lbl33:
            // 2 sources

            switch ((int)v4) {
                case 257289048: {
                    break block182;
                }
                case 1968229177: {
                    continue block182;
                }
            }
            break;
        }
        v5 = new HashMap<String, MapInfo>();
        v6 = MapCycleModuleConfig.\u13e8;
        if (true) ** GOTO lbl43
        block183: while (true) {
            v6 = v7 / (11061L ^ 5389824670119662939L);
lbl43:
            // 2 sources

            switch ((int)v6) {
                case -2115340365: {
                    v7 = 18605L ^ -3439213217793145496L;
                    continue block183;
                }
                case 257289048: {
                    break block183;
                }
                case 1067761463: {
                    v7 = -6314525420728243308L >>> "\u0000\u0000".length();
                    continue block183;
                }
                case 1464710879: {
                    v7 = 3214798090638768920L >>> "\u0000\u0000".length();
                    continue block183;
                }
            }
            break;
        }
        this.CYCLE_MAP_INFOS = v5;
        v8 = MapCycleModuleConfig.\u13e8;
        if (true) ** GOTO lbl60
        block184: while (true) {
            v8 = v9 / (25994L ^ -7701105648657744131L);
lbl60:
            // 2 sources

            switch ((int)v8) {
                case -1091941005: {
                    v9 = 10958L ^ -2478006191906888263L;
                    continue block184;
                }
                case 257289048: {
                    break block184;
                }
                case 1722100165: {
                    v9 = 21972L ^ -5503489054861202003L;
                    continue block184;
                }
            }
            break;
        }
        while (true) {
            if ((v10 = (cfr_temp_3 = MapCycleModuleConfig.\u13e8 - (21400L ^ -838391479060686021L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v10 == (21676 ^ -21677)) break;
            v10 = 23955 ^ -2121968061;
        }
        v11 = new Lazy.NoCache();
        v12 = MapCycleModuleConfig.\u13e8;
        if (true) ** GOTO lbl79
        block186: while (true) {
            v12 = (4469L ^ 5306860775930289076L) / (11806L ^ -2686868316673474931L);
lbl79:
            // 2 sources

            switch ((int)v12) {
                case 257289048: {
                    break block186;
                }
                case 1923724010: {
                    continue block186;
                }
            }
            break;
        }
        this.MODIFIED_CYCLE_MAP = v11;
        v13 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        while (true) {
            if ((v14 = (cfr_temp_4 = MapCycleModuleConfig.\u13e8 - (-7360922932174409840L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v14 == (23629 ^ -23630)) break;
            v14 = 18976 ^ -1094547208;
        }
        this.ENABLE_ANCHOR_POSITION = v13;
        v15 = 400 >>> "\u0000\u0000".length();
        while (true) {
            if ((v16 = (cfr_temp_5 = MapCycleModuleConfig.\u13e8 - (11407L ^ -7391078840895134820L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
            if (v16 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v16 = 727295336 >>> "\u0000\u0000".length();
        }
        this.ANCHOR_RADIUS = v15;
        v17 = "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        while (true) {
            if ((v18 = (cfr_temp_6 = MapCycleModuleConfig.\u13e8 - (32702L ^ 1779305050392752409L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
            if (v18 == (32504 ^ -32505)) break;
            v18 = 25717 ^ -1601070555;
        }
        this.STATIONARY_RANDOM_ROAM_SECONDS = v17;
        while (true) {
            if ((v19 = (cfr_temp_7 = MapCycleModuleConfig.\u13e8 - (25792L ^ -7793292464442657594L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
            if (v19 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v19 = 26120 ^ -127333718;
        }
        this.MOVE_IF_UNDER_ATTACK = 7648 ^ 7649;
        v20 = MapCycleModuleConfig.\u13e8;
        if (true) ** GOTO lbl116
        block191: while (true) {
            v20 = v21 / (31835L ^ 4992380274932666342L);
lbl116:
            // 2 sources

            switch ((int)v20) {
                case 257289048: {
                    break block191;
                }
                case 349377288: {
                    v21 = 10482L ^ 5213561988557576862L;
                    continue block191;
                }
                case 619470741: {
                    v21 = 4552L ^ -5929662233749878974L;
                    continue block191;
                }
                case 1289728924: {
                    v21 = 3226L ^ -4606655762682809479L;
                    continue block191;
                }
            }
            break;
        }
        v22 = MapCycleModuleConfig.\u13e8;
        if (true) ** GOTO lbl132
        block192: while (true) {
            v22 = (14616L ^ 3477749324685358279L) / (4028621019455117740L >>> "\u0000\u0000".length());
lbl132:
            // 2 sources

            switch ((int)v22) {
                case -746955304: {
                    continue block192;
                }
                case 257289048: {
                    break block192;
                }
            }
            break;
        }
        v23 = Character.valueOf((char)(28582 ^ 28575));
        v24 = MapCycleModuleConfig.\u13e8;
        if (true) ** GOTO lbl142
        block193: while (true) {
            v24 = (28163L ^ 7553337328702540450L) / (13727L ^ -5006617685143824222L);
lbl142:
            // 2 sources

            switch ((int)v24) {
                case 236622366: {
                    continue block193;
                }
                case 257289048: {
                    break block193;
                }
            }
            break;
        }
        v25 = new Config.ShipConfig(21720 ^ 21722, v23);
        v26 = MapCycleModuleConfig.\u13e8;
        if (true) ** GOTO lbl152
        block194: while (true) {
            v26 = (32088L ^ 1060625435568161094L) / (8786L ^ -7389229883444446406L);
lbl152:
            // 2 sources

            switch ((int)v26) {
                case -1091337360: {
                    continue block194;
                }
                case 257289048: {
                    break block194;
                }
            }
            break;
        }
        this.PREFERRED_REGION_TRAVEL_CONFIG = v25;
        v27 = MapCycleModuleConfig.\u13e8;
        if (true) ** GOTO lbl162
        block195: while (true) {
            v27 = v28 / (-2538349778075474228L >>> "\u0000\u0000".length());
lbl162:
            // 2 sources

            switch ((int)v27) {
                case -17359523: {
                    v28 = 1426L ^ -190810095754669163L;
                    continue block195;
                }
                case 257289048: {
                    break block195;
                }
                case 726179428: {
                    v28 = 25426L ^ -1577374750793449273L;
                    continue block195;
                }
                case 770807360: {
                    v28 = 23460L ^ -101218876997250125L;
                    continue block195;
                }
            }
            break;
        }
        v29 = "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        v30 = 228 >>> "\u0000\u0000".length();
        v31 = MapCycleModuleConfig.\u13e8;
        if (true) ** GOTO lbl180
        block196: while (true) {
            v31 = (15650L ^ -7769457883578349160L) / (28113L ^ 5578828222825044117L);
lbl180:
            // 2 sources

            switch ((int)v31) {
                case -1032457448: {
                    continue block196;
                }
                case 257289048: {
                    break block196;
                }
            }
            break;
        }
        v32 = Character.valueOf(v30);
        while (true) {
            if ((v33 = (cfr_temp_8 = MapCycleModuleConfig.\u13e8 - (5659L ^ -4702997106570702100L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
            if (v33 == (8987 ^ 8986)) break;
            v33 = 29386 ^ -1094142721;
        }
        v34 = new Config.ShipConfig(v29, v32);
        v35 = MapCycleModuleConfig.\u13e8;
        if (true) ** GOTO lbl196
        block198: while (true) {
            v35 = v36 / (24668L ^ -2159784989242398983L);
lbl196:
            // 2 sources

            switch ((int)v35) {
                case -1069704456: {
                    v36 = 8748684556638967500L >>> "\u0000\u0000".length();
                    continue block198;
                }
                case 257289048: {
                    break block198;
                }
                case 262593838: {
                    v36 = 9239L ^ -975817963244295110L;
                    continue block198;
                }
            }
            break;
        }
        this.LOW_HP_PREFERRED_REGION_TRAVEL_CONFIG = v34;
        v37 = MapCycleModuleConfig.\u13e8;
        if (true) ** GOTO lbl210
        block199: while (true) {
            v37 = v38 / (32697L ^ -8842215009860423559L);
lbl210:
            // 2 sources

            switch ((int)v37) {
                case -12410145: {
                    v38 = 27124L ^ 3848632672491904127L;
                    continue block199;
                }
                case 257289048: {
                    break block199;
                }
                case 1379697822: {
                    v38 = 4240051414331658772L >>> "\u0000\u0000".length();
                    continue block199;
                }
            }
            break;
        }
        v39 = MapCycleModuleConfig.\u13e8;
        if (true) ** GOTO lbl223
        block200: while (true) {
            v39 = (3796L ^ 5988561578753882819L) / (11791L ^ 5405312514409007146L);
lbl223:
            // 2 sources

            switch ((int)v39) {
                case 257289048: {
                    break block200;
                }
                case 1043659302: {
                    continue block200;
                }
            }
            break;
        }
        v40 = new MapChangeConditionConfig();
        v41 = MapCycleModuleConfig.\u13e8;
        if (true) ** GOTO lbl233
        block201: while (true) {
            v41 = v42 / (14574L ^ -579201124218676230L);
lbl233:
            // 2 sources

            switch ((int)v41) {
                case 257289048: {
                    break block201;
                }
                case 824119969: {
                    v42 = 22847L ^ -1096550895688506037L;
                    continue block201;
                }
                case 952873501: {
                    v42 = 29088L ^ -6760780307972589471L;
                    continue block201;
                }
            }
            break;
        }
        this.MAP_CHANGE_COND_CONFIG = v40;
        while (true) {
            if ((v43 = (cfr_temp_9 = MapCycleModuleConfig.\u13e8 - (23873L ^ -7454085084802976412L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
            if (v43 == (15305 ^ 15304)) break;
            v43 = 31925 ^ 1520245681;
        }
        while (true) {
            if ((v44 = (cfr_temp_10 = MapCycleModuleConfig.\u13e8 - (4421345995767979924L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
            if (v44 == (22224 ^ -22225)) break;
            v44 = -878528748 >>> "\u0000\u0000".length();
        }
        v45 = new AdaptiveChecksConfig();
        v46 = MapCycleModuleConfig.\u13e8;
        if (true) ** GOTO lbl258
        block204: while (true) {
            v46 = v47 / (8971L ^ 259634882136801010L);
lbl258:
            // 2 sources

            switch ((int)v46) {
                case -1148961486: {
                    v47 = 22434L ^ -7074200787228886723L;
                    continue block204;
                }
                case 19977409: {
                    v47 = 23198L ^ -265637139791186873L;
                    continue block204;
                }
                case 257289048: {
                    break block204;
                }
                case 1086280496: {
                    v47 = -7365151733870472244L >>> "\u0000\u0000".length();
                    continue block204;
                }
            }
            break;
        }
        this.ADAPTIVE_CHECKS_CONFIG = v45;
        while (true) {
            if ((v48 = (cfr_temp_11 = MapCycleModuleConfig.\u13e8 - (11369L ^ -8583902897137701887L)) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
            if (v48 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v48 = 4556 ^ 1915430334;
        }
        v49 = MapCycleModuleConfig.\u13e8;
        if (true) ** GOTO lbl280
        block206: while (true) {
            v49 = v50 / (308L ^ 6985525750734368941L);
lbl280:
            // 2 sources

            switch ((int)v49) {
                case -870921577: {
                    v50 = 26654L ^ 5427351297530922107L;
                    continue block206;
                }
                case -534108717: {
                    v50 = 22182L ^ 2938621154580859182L;
                    continue block206;
                }
                case 257289048: {
                    break block206;
                }
                case 1119183184: {
                    v50 = 12131L ^ -1799896966085245722L;
                    continue block206;
                }
            }
            break;
        }
        v51 = new AfterKillConfig();
        v52 = MapCycleModuleConfig.\u13e8;
        if (true) ** GOTO lbl297
        block207: while (true) {
            v52 = (5509L ^ -1625670000189247566L) / (2080L ^ -3291234115415737734L);
lbl297:
            // 2 sources

            switch ((int)v52) {
                case 257289048: {
                    break block207;
                }
                case 1777896162: {
                    continue block207;
                }
            }
            break;
        }
        this.AFTER_KILL_CONFIG = v51;
        v53 = MapCycleModuleConfig.\u13e8;
        if (true) ** GOTO lbl307
        block208: while (true) {
            v53 = v54 / (29921L ^ 7020290957596378091L);
lbl307:
            // 2 sources

            switch ((int)v53) {
                case -1323512574: {
                    v54 = 30755L ^ -2083567729729227396L;
                    continue block208;
                }
                case 257289048: {
                    break block208;
                }
                case 310038487: {
                    v54 = -7127311200778176780L >>> "\u0000\u0000".length();
                    continue block208;
                }
            }
            break;
        }
        v55 = MapCycleModuleConfig.\u13e8;
        if (true) ** GOTO lbl320
        block209: while (true) {
            v55 = (28442L ^ -8231268415226565842L) / (8074L ^ -6918401418408003528L);
lbl320:
            // 2 sources

            switch ((int)v55) {
                case -108052102: {
                    continue block209;
                }
                case 257289048: {
                    break block209;
                }
            }
            break;
        }
        v56 = new KeyFirstLockConfig();
        v57 = MapCycleModuleConfig.\u13e8;
        if (true) ** GOTO lbl330
        block210: while (true) {
            v57 = v58 / (12345L ^ 4199067667364598405L);
lbl330:
            // 2 sources

            switch ((int)v57) {
                case -1446110395: {
                    v58 = 3587L ^ 2005284074181618680L;
                    continue block210;
                }
                case -1005967065: {
                    v58 = -3758766283477148020L >>> "\u0000\u0000".length();
                    continue block210;
                }
                case -675337833: {
                    v58 = 14783L ^ -8185299734805856912L;
                    continue block210;
                }
                case 257289048: {
                    break block210;
                }
            }
            break;
        }
        this.KEY_FIRST_LOCK_CONFIG = v56;
        v59 = MapCycleModuleConfig.\u13e8;
        if (true) ** GOTO lbl347
        block211: while (true) {
            v59 = v60 / (2423472512254491676L >>> "\u0000\u0000".length());
lbl347:
            // 2 sources

            switch ((int)v59) {
                case -1621579629: {
                    v60 = 2586L ^ 6560349773835644788L;
                    continue block211;
                }
                case -1430236033: {
                    v60 = 9890L ^ -1982506554073522884L;
                    continue block211;
                }
                case -52900713: {
                    v60 = 8018L ^ 1431676163218657641L;
                    continue block211;
                }
                case 257289048: {
                    break block211;
                }
            }
            break;
        }
        while (true) {
            if ((v61 = (cfr_temp_12 = MapCycleModuleConfig.\u13e8 - (29773L ^ -2129388617768311741L)) == 0L ? 0 : (cfr_temp_12 < 0L ? -1 : 1)) == false) continue;
            if (v61 == (29341 ^ -29342)) break;
            v61 = 30305 ^ -2109340912;
        }
        v62 = new MapCyclePetConfig();
        while (true) {
            if ((v63 = (cfr_temp_13 = MapCycleModuleConfig.\u13e8 - (24643L ^ -8233959297868768098L)) == 0L ? 0 : (cfr_temp_13 < 0L ? -1 : 1)) == false) continue;
            if (v63 == (9870 ^ 9871)) break;
            v63 = -1518034848 >>> "\u0000\u0000".length();
        }
        this.PET_CONFIG = v62;
        v64 = MapCycleModuleConfig.\u13e8;
        if (true) ** GOTO lbl375
        block214: while (true) {
            v64 = v65 / (22820L ^ 8672368714161525429L);
lbl375:
            // 2 sources

            switch ((int)v64) {
                case -1173686453: {
                    v65 = 19178L ^ 2148425394555776381L;
                    continue block214;
                }
                case 100581200: {
                    v65 = -2056584209834507768L >>> "\u0000\u0000".length();
                    continue block214;
                }
                case 257289048: {
                    break block214;
                }
            }
            break;
        }
        while (true) {
            if ((v66 = (cfr_temp_14 = MapCycleModuleConfig.\u13e8 - (26452L ^ -7627972279028164810L)) == 0L ? 0 : (cfr_temp_14 < 0L ? -1 : 1)) == false) continue;
            if (v66 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v66 = 11157 ^ -1914176419;
        }
        v67 = new MapCycleBoxCollectConfig();
        v68 = MapCycleModuleConfig.\u13e8;
        if (true) ** GOTO lbl394
        block216: while (true) {
            v68 = v69 / (14885L ^ -7848674423910124613L);
lbl394:
            // 2 sources

            switch ((int)v68) {
                case -1776808334: {
                    v69 = 31835L ^ -1767344650496784201L;
                    continue block216;
                }
                case -99816708: {
                    v69 = 7825L ^ -4284704733858383120L;
                    continue block216;
                }
                case 257289048: {
                    break block216;
                }
                case 510485428: {
                    v69 = 16988L ^ -5498710399043302360L;
                    continue block216;
                }
            }
            break;
        }
        this.BOX_COLLECT_CONFIG = v67;
        v70 = MapCycleModuleConfig.\u13e8;
        if (true) ** GOTO lbl411
        block217: while (true) {
            v70 = (2715L ^ -2239625599084229067L) / (8465L ^ -8804908014541883290L);
lbl411:
            // 2 sources

            switch ((int)v70) {
                case -923634335: {
                    continue block217;
                }
                case 257289048: {
                    break block217;
                }
            }
            break;
        }
        v71 = MapCycleModuleConfig.\u13e8;
        if (true) ** GOTO lbl420
        block218: while (true) {
            v71 = v72 / (7889L ^ -7868700224837720181L);
lbl420:
            // 2 sources

            switch ((int)v71) {
                case -1639153051: {
                    v72 = 7488L ^ -5917278806824828423L;
                    continue block218;
                }
                case -56004324: {
                    v72 = 29695L ^ -1692305458006086047L;
                    continue block218;
                }
                case 78564489: {
                    v72 = 7280L ^ -7312020188030722289L;
                    continue block218;
                }
                case 257289048: {
                    break block218;
                }
            }
            break;
        }
        v73 = new ServerRestartHandlerConfig();
        while (true) {
            if ((v74 = (cfr_temp_15 = MapCycleModuleConfig.\u13e8 - (6771L ^ -6924053502497960583L)) == 0L ? 0 : (cfr_temp_15 < 0L ? -1 : 1)) == false) continue;
            if (v74 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v74 = 22441 ^ -821225985;
        }
        this.SERVER_RESTART_HANDLER_CONFIG = v73;
        v75 = MapCycleModuleConfig.\u13e8;
        if (true) ** GOTO lbl443
        block220: while (true) {
            v75 = (-1542047187803131788L >>> "\u0000\u0000".length()) / (12436L ^ -106335998659361868L);
lbl443:
            // 2 sources

            switch ((int)v75) {
                case 257289048: {
                    break block220;
                }
                case 1324930672: {
                    continue block220;
                }
            }
            break;
        }
        v76 = MapCycleModuleConfig.\u13e8;
        if (true) ** GOTO lbl452
        block221: while (true) {
            v76 = (3527893117052191576L >>> "\u0000\u0000".length()) / (12484L ^ -5807737442572855324L);
lbl452:
            // 2 sources

            switch ((int)v76) {
                case -1556504776: {
                    continue block221;
                }
                case 257289048: {
                    break block221;
                }
            }
            break;
        }
        v77 = new TwLootModuleConfig();
        while (true) {
            if ((v78 = (cfr_temp_16 = MapCycleModuleConfig.\u13e8 - (26091L ^ -7086176994896910855L)) == 0L ? 0 : (cfr_temp_16 < 0L ? -1 : 1)) == false) continue;
            if (v78 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v78 = 26785 ^ 1209599184;
        }
        this.BETTER_LOOT_MODULE_CONFIG = v77;
        v79 = MapCycleModuleConfig.\u13e8;
        if (true) ** GOTO lbl468
        block223: while (true) {
            v79 = v80 / (27420L ^ -237322297600142051L);
lbl468:
            // 2 sources

            switch ((int)v79) {
                case 257289048: {
                    break block223;
                }
                case 1522644665: {
                    v80 = 14123L ^ 7580188647379788501L;
                    continue block223;
                }
                case 1707487970: {
                    v80 = 26585L ^ 7362591824798820876L;
                    continue block223;
                }
            }
            break;
        }
        v81 = MapCycleModuleConfig.\u13e8;
        if (true) ** GOTO lbl481
        block224: while (true) {
            v81 = v82 / (16469L ^ 9055704364314867068L);
lbl481:
            // 2 sources

            switch ((int)v81) {
                case -1104790689: {
                    v82 = 11135L ^ 6544085025365636441L;
                    continue block224;
                }
                case -299439608: {
                    v82 = 31171L ^ 6516266605064028587L;
                    continue block224;
                }
                case 257289048: {
                    break block224;
                }
                case 925928333: {
                    v82 = 28505L ^ -2142458668554755058L;
                    continue block224;
                }
            }
            break;
        }
        v83 = new MapCycleSafetyConfig();
        v84 = MapCycleModuleConfig.\u13e8;
        if (true) ** GOTO lbl498
        block225: while (true) {
            v84 = v85 / (15377L ^ 6142316777308603871L);
lbl498:
            // 2 sources

            switch ((int)v84) {
                case 257289048: {
                    break block225;
                }
                case 1091411099: {
                    v85 = 27313L ^ 5943783542985915651L;
                    continue block225;
                }
                case 1528023211: {
                    v85 = 30148L ^ 957649257552547156L;
                    continue block225;
                }
            }
            break;
        }
        this.SAFETY_CONFIG = v83;
        v86 = MapCycleModuleConfig.\u13e8;
        if (true) ** GOTO lbl512
        block226: while (true) {
            v86 = v87 / (3643L ^ -1162473318410379519L);
lbl512:
            // 2 sources

            switch ((int)v86) {
                case -1524791494: {
                    v87 = 10143L ^ -3096729577083212968L;
                    continue block226;
                }
                case 257289048: {
                    break block226;
                }
                case 1439855527: {
                    v87 = 31505L ^ -7184279708592285276L;
                    continue block226;
                }
                case 1671878762: {
                    v87 = 14784L ^ -3131108078842639928L;
                    continue block226;
                }
            }
            break;
        }
        v88 = MapCycleModuleConfig.\u13e8;
        if (true) ** GOTO lbl528
        block227: while (true) {
            v88 = (7930L ^ 7352136553502807677L) / (29835L ^ -7497517261272322207L);
lbl528:
            // 2 sources

            switch ((int)v88) {
                case -709731891: {
                    continue block227;
                }
                case 257289048: {
                    break block227;
                }
            }
            break;
        }
        v89 = new PredictNpcSpawnConfig();
        while (true) {
            if ((v90 = (cfr_temp_17 = MapCycleModuleConfig.\u13e8 - (8882933654801673624L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_17 < 0L ? -1 : 1)) == false) continue;
            if (v90 == (11241 ^ -11242)) break;
            v90 = 12487 ^ 1310883918;
        }
        this.PREDICT_NPC_SPAWN_CONFIG = v89;
        v91 = MapCycleModuleConfig.\u13e8;
        if (true) ** GOTO lbl544
        block229: while (true) {
            v91 = v92 / (-9098593117234807772L >>> "\u0000\u0000".length());
lbl544:
            // 2 sources

            switch ((int)v91) {
                case -1649945869: {
                    v92 = 18342L ^ 6823229468976330612L;
                    continue block229;
                }
                case -1027061122: {
                    v92 = 6186L ^ 274629130789910137L;
                    continue block229;
                }
                case 257289048: {
                    break block229;
                }
            }
            break;
        }
        while (true) {
            if ((v93 = (cfr_temp_18 = MapCycleModuleConfig.\u13e8 - (1593626728398933436L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_18 < 0L ? -1 : 1)) == false) continue;
            if (v93 == (27019 ^ -27020)) break;
            v93 = 31663 ^ -1140419427;
        }
        v94 = new MapCycleRefreshConfig();
        v95 = MapCycleModuleConfig.\u13e8;
        if (true) ** GOTO lbl563
        block231: while (true) {
            v95 = v96 / (21024L ^ -655344499757415553L);
lbl563:
            // 2 sources

            switch ((int)v95) {
                case 257289048: {
                    break block231;
                }
                case 395214451: {
                    v96 = 32459L ^ 6710529416339117891L;
                    continue block231;
                }
                case 689065819: {
                    v96 = 17586L ^ -5959319522219181006L;
                    continue block231;
                }
                case 1250375632: {
                    v96 = 3018L ^ 153878386620049066L;
                    continue block231;
                }
            }
            break;
        }
        this.REFRESH_CONFIG = v94;
        while (true) {
            if ((v97 = (cfr_temp_19 = MapCycleModuleConfig.\u13e8 - (32501L ^ 8253045990364484888L)) == 0L ? 0 : (cfr_temp_19 < 0L ? -1 : 1)) == false) continue;
            if (v97 == (9937 ^ -9938)) break;
            v97 = 19589 ^ 1890932385;
        }
        v98 = MapCycleModuleConfig.\u13e8;
        if (true) ** GOTO lbl585
        block233: while (true) {
            v98 = v99 / (4712L ^ 8892076543434719061L);
lbl585:
            // 2 sources

            switch ((int)v98) {
                case -1152928970: {
                    v99 = 953L ^ -260306935972199016L;
                    continue block233;
                }
                case 257289048: {
                    break block233;
                }
                case 1965224659: {
                    v99 = 12696L ^ 7794912473961313251L;
                    continue block233;
                }
            }
            break;
        }
        v100 = new NpcRewardConfig();
        while (true) {
            if ((v101 = (cfr_temp_20 = MapCycleModuleConfig.\u13e8 - (12530L ^ -7330356270434401040L)) == 0L ? 0 : (cfr_temp_20 < 0L ? -1 : 1)) == false) continue;
            if (v101 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v101 = 1175 ^ -1090741815;
        }
        this.NPC_REWARD_CONFIG = v100;
        v102 = MapCycleModuleConfig.\u13e8;
        if (true) ** GOTO lbl605
        block235: while (true) {
            v102 = v103 / (1454L ^ 1223858490188317468L);
lbl605:
            // 2 sources

            switch ((int)v102) {
                case 69917387: {
                    v103 = 1868321476217965692L >>> "\u0000\u0000".length();
                    continue block235;
                }
                case 257289048: {
                    break block235;
                }
                case 279366902: {
                    v103 = 19417L ^ 486278427191162350L;
                    continue block235;
                }
            }
            break;
        }
        while (true) {
            if ((v104 = (cfr_temp_21 = MapCycleModuleConfig.\u13e8 - (965L ^ -8560555999925500983L)) == 0L ? 0 : (cfr_temp_21 < 0L ? -1 : 1)) == false) continue;
            if (v104 == (2106 ^ 2107)) break;
            v104 = 32190 ^ -1049130982;
        }
        v105 = new GroupConfig();
        while (true) {
            if ((v106 = (cfr_temp_22 = MapCycleModuleConfig.\u13e8 - (13509L ^ -3553702773490393268L)) == 0L ? 0 : (cfr_temp_22 < 0L ? -1 : 1)) == false) continue;
            if (v106 == (3426 ^ 3427)) break;
            v106 = 1697 ^ -1993677095;
        }
        this.GROUP_CONFIG = v105;
        while (true) {
            if ((v107 = (cfr_temp_23 = MapCycleModuleConfig.\u13e8 - (22582L ^ 1017339136140989886L)) == 0L ? 0 : (cfr_temp_23 < 0L ? -1 : 1)) == false) continue;
            if (v107 == (26895 ^ -26896)) break;
            v107 = 7248 ^ 1728222631;
        }
        while (true) {
            if ((v108 = (cfr_temp_24 = MapCycleModuleConfig.\u13e8 - (6012L ^ 7172223062497602492L)) == 0L ? 0 : (cfr_temp_24 < 0L ? -1 : 1)) == false) continue;
            if (v108 == (24513 ^ -24514)) break;
            v108 = 29331 ^ 603262329;
        }
        v109 = new MiscellaneousConfig();
        while (true) {
            if ((v110 = (cfr_temp_25 = MapCycleModuleConfig.\u13e8 - (2355L ^ 6620848898862851423L)) == 0L ? 0 : (cfr_temp_25 < 0L ? -1 : 1)) == false) continue;
            if (v110 == (12362 ^ -12363)) break;
            v110 = 22450 ^ -1644134148;
        }
        this.MISC_CONFIG = v109;
    }
}

