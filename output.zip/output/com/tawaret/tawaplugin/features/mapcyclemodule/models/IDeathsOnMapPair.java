/*
 * Decompiled with CFR 0.152.
 */
package com.tawaret.tawaplugin.features.mapcyclemodule.models;

public interface IDeathsOnMapPair {
    public int getMapId();

    public int incrementDeaths();

    public void resetDeaths();

    public void resetChangeMapId(int var1);

    public int getDeaths();
}

