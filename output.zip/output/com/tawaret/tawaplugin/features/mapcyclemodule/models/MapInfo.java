/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.config.types.Option
 */
package com.tawaret.tawaplugin.features.mapcyclemodule.models;

import com.github.manolo8.darkbot.config.types.Option;

@Option(key="config.map_cycle_module.cycle_map_table.map_name")
public class MapInfo {
    @Option(value="Enabled", description="Enable if the map is part of the cycle")
    public boolean isPartOfCycle;
    @Option(value="Priority", description="Starts cycle from LOW to HIGH, e.g.: cycle 1 => 2 => 3 => 1 ...")
    public int priority;
    @Option(value="Refreshable", description="Enable refresh on map")
    public boolean isRefreshable;
    @Option(value="KAK", description="Enable Key After Kill press")
    public boolean enableKeyPressAfterKill;
    @Option(value="KFL", description="Enable Key First Lock press")
    public boolean enableKeyPressOnFirstLock;
    @Option(value="X", description="Anchor map X coordinate")
    public int anchor_x;
    @Option(value="Y", description="Anchor map Y coordinate")
    public int anchor_y;
    public Integer cachedMapId;
    protected static long \u13e8 = -2680406292380974420L;

    /*
     * Unable to fully structure code
     */
    public MapInfo(boolean isPartOfCycle, int priority, boolean isRefreshable, Integer cachedMapId, boolean enableKeyPressAfterKill, boolean enableKeyPressOnFirstLock, int anchor_x, int anchor_y) {
        while (true) {
            if ((v0 = (cfr_temp_0 = MapInfo.\u13e8 - (7925L ^ -9086698297882447259L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v0 = 9264 ^ -600221074;
        }
        super();
        v1 = MapInfo.\u13e8;
        if (true) ** GOTO lbl11
        block31: while (true) {
            v1 = (27433L ^ -4198225124031352853L) / (18044L ^ -8307370620890417654L);
lbl11:
            // 2 sources

            switch ((int)v1) {
                case -1380489067: {
                    continue block31;
                }
                case -1326906708: {
                    break block31;
                }
            }
            break;
        }
        this.cachedMapId = null;
        v2 = MapInfo.\u13e8;
        if (true) ** GOTO lbl21
        block32: while (true) {
            v2 = v3 / (18542L ^ -3499772899432939002L);
lbl21:
            // 2 sources

            switch ((int)v2) {
                case -1326906708: {
                    break block32;
                }
                case -840623361: {
                    v3 = 7441L ^ -532999130415767198L;
                    continue block32;
                }
                case 330725539: {
                    v3 = 14566L ^ 7955599781232803837L;
                    continue block32;
                }
                case 1526550250: {
                    v3 = 14285L ^ 8484143503989227921L;
                    continue block32;
                }
            }
            break;
        }
        this.isPartOfCycle = isPartOfCycle;
        while (true) {
            if ((v4 = (cfr_temp_1 = MapInfo.\u13e8 - (14895L ^ -6072110359350456803L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v4 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v4 = 24401 ^ 2005832651;
        }
        this.priority = priority;
        while (true) {
            if ((v5 = (cfr_temp_2 = MapInfo.\u13e8 - (22729L ^ -2366455087929158793L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v5 == (26074 ^ -26075)) break;
            v5 = 3230 ^ -3226334;
        }
        this.isRefreshable = isRefreshable;
        v6 = MapInfo.\u13e8;
        if (true) ** GOTO lbl50
        block35: while (true) {
            v6 = v7 / (12237L ^ -9207668669660315544L);
lbl50:
            // 2 sources

            switch ((int)v6) {
                case -1454209363: {
                    v7 = 4961L ^ -999616012821434988L;
                    continue block35;
                }
                case -1326906708: {
                    break block35;
                }
                case -125368522: {
                    v7 = 6345L ^ 2536199865371103902L;
                    continue block35;
                }
            }
            break;
        }
        this.cachedMapId = cachedMapId;
        v8 = MapInfo.\u13e8;
        if (true) ** GOTO lbl64
        block36: while (true) {
            v8 = v9 / (21872L ^ -6791038405917599741L);
lbl64:
            // 2 sources

            switch ((int)v8) {
                case -1326906708: {
                    break block36;
                }
                case -753107396: {
                    v9 = 16591L ^ -5884169991784655951L;
                    continue block36;
                }
                case -350347804: {
                    v9 = -2593917008198232148L >>> "\u0000\u0000".length();
                    continue block36;
                }
                case 516068383: {
                    v9 = 7163L ^ -6749966606008511478L;
                    continue block36;
                }
            }
            break;
        }
        this.enableKeyPressAfterKill = enableKeyPressAfterKill;
        while (true) {
            if ((v10 = (cfr_temp_3 = MapInfo.\u13e8 - (19676L ^ -1867810310455484444L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v10 == (27205 ^ -27206)) break;
            v10 = 26010 ^ -159388450;
        }
        this.enableKeyPressOnFirstLock = enableKeyPressOnFirstLock;
        v11 = MapInfo.\u13e8;
        if (true) ** GOTO lbl87
        block38: while (true) {
            v11 = (24740L ^ -3443907227145521143L) / (26242L ^ -4324533168131213805L);
lbl87:
            // 2 sources

            switch ((int)v11) {
                case -1326906708: {
                    break block38;
                }
                case -458338574: {
                    continue block38;
                }
            }
            break;
        }
        this.anchor_x = anchor_x;
        v12 = MapInfo.\u13e8;
        if (true) ** GOTO lbl97
        block39: while (true) {
            v12 = v13 / (14027L ^ -6929606669142993344L);
lbl97:
            // 2 sources

            switch ((int)v12) {
                case -1842676183: {
                    v13 = 2228L ^ -8187062244941778958L;
                    continue block39;
                }
                case -1326906708: {
                    break block39;
                }
                case -332802896: {
                    v13 = 20129L ^ -4191137935790028387L;
                    continue block39;
                }
            }
            break;
        }
        this.anchor_y = anchor_y;
    }
}

