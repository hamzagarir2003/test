/*
 * Decompiled with CFR 0.152.
 */
package com.tawaret.tawaplugin.features.mapcyclemodule.models;

import com.tawaret.tawaplugin.features.mapcyclemodule.models.DeathsOnMapPair;
import com.tawaret.tawaplugin.features.mapcyclemodule.models.IDeathsOnMapPair;

public class DeathsOnMapPairFactory {
    protected static long \u13e8 = 7363440776209795599L;

    /*
     * Enabled aggressive block sorting
     */
    public DeathsOnMapPairFactory() {
        long l = \u13e8;
        block4: while (true) {
            switch ((int)l) {
                case -941176185: {
                    l = (0x5B6FL ^ 0xC575630AA0BA4157L) / (0x294AL ^ 0xC7F9C8F79D1853C5L);
                    continue block4;
                }
                case 1855752719: {
                    break block4;
                }
            }
            break;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public static IDeathsOnMapPair Initial() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x1224L ^ 0x6678394C45D35A1BL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x345F ^ 0xFFFFCBA0)) break;
            l2 = 0x24E9 ^ 0xC333F863;
        }
        long l = \u13e8;
        block5: while (true) {
            switch ((int)l) {
                case -1622853015: {
                    l = (0xBFFL ^ 0xF3CBFB42D9F009D1L) / (0x2F92L ^ 0x8731D6AAA1F6D614L);
                    continue block5;
                }
                case 1855752719: {
                    return new DeathsOnMapPair(0x6C18 ^ 0xFFFF93E7, 0x1EF5 ^ 0x1EF5);
                }
            }
            break;
        }
        return new DeathsOnMapPair(0x6C18 ^ 0xFFFF93E7, 0x1EF5 ^ 0x1EF5);
    }
}

