/*
 * Decompiled with CFR 0.152.
 */
package com.tawaret.tawaplugin.features.mapcyclemodule.models;

import com.tawaret.tawaplugin.features.mapcyclemodule.models.IDeathsOnMapPair;

public class DeathsOnMapPair
implements IDeathsOnMapPair {
    private int mapId;
    private int deathCount;
    public static long \u13e8 = -3128592470584689856L;

    /*
     * Unable to fully structure code
     */
    public DeathsOnMapPair(int startMapId, int startDeathCount) {
        while (true) {
            if ((v0 = (cfr_temp_0 = DeathsOnMapPair.\u13e8 - (17539L ^ -4975694390212512545L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (13301 ^ 13300)) break;
            v0 = 5739 ^ -1885259734;
        }
        super();
        v1 = DeathsOnMapPair.\u13e8;
        if (true) ** GOTO lbl11
        block6: while (true) {
            v1 = v2 / (5698L ^ -8503150268899250870L);
lbl11:
            // 2 sources

            switch ((int)v1) {
                case 220941349: {
                    v2 = 15127L ^ -4173654369156580193L;
                    continue block6;
                }
                case 1473674048: {
                    break block6;
                }
                case 2108999391: {
                    v2 = 20735L ^ 6213990676495895714L;
                    continue block6;
                }
            }
            break;
        }
        this.mapId = startMapId;
        while (true) {
            if ((v3 = (cfr_temp_1 = DeathsOnMapPair.\u13e8 - (2306L ^ -1135803699458677229L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v3 == (17490 ^ -17491)) break;
            v3 = 18425 ^ 286461505;
        }
        this.deathCount = startDeathCount;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public int getMapId() {
        long l = \u13e8;
        block4: while (true) {
            switch ((int)l) {
                case -578278795: {
                    l = (3260177940473037264L >>> "\u0000\u0000".length()) / (4321456002351231612L >>> "\u0000\u0000".length());
                    continue block4;
                }
                case 1473674048: {
                    return this.mapId;
                }
            }
            break;
        }
        return this.mapId;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    @Override
    public int incrementDeaths() {
        long l = \u13e8;
        boolean bl = true;
        block5: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x761CL ^ 0xABC31769D4ABC125L);
            }
            switch ((int)l) {
                case -1762037214: {
                    l2 = 0x4809L ^ 0xBBAF808B5983ACFAL;
                    continue block5;
                }
                case -1720014539: {
                    l2 = 0x5ABDL ^ 0xE916BCA83EAAC1A4L;
                    continue block5;
                }
                case 1473674048: {
                    break block5;
                }
            }
            break;
        }
        while (true) {
            long l3;
            long l4;
            if ((l4 = (l3 = \u13e8 - (0x4403L ^ 0x59C86ADB3D877545L)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l4 == (0x7FC1 ^ 0xFFFF803E)) {
                return this.deathCount += 0x2863 ^ 0x2862;
            }
            l4 = -1094288324 >>> "\u0000\u0000".length();
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    @Override
    public void resetDeaths() {
        long l = \u13e8;
        boolean bl = true;
        block6: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x1676L ^ 0xDE028D29E595C19DL);
            }
            switch ((int)l) {
                case -434399400: {
                    l2 = 0x889L ^ 0x7055A717559C98D2L;
                    continue block6;
                }
                case -399618350: {
                    l2 = 0x331CL ^ 0xBF638E97963FF3C4L;
                    continue block6;
                }
                case 1313761557: {
                    l2 = 0x2F07L ^ 0x52E8E57D95C41822L;
                    continue block6;
                }
                case 1473674048: {
                    break block6;
                }
            }
            break;
        }
        this.deathCount = 0x3F9E ^ 0x3F9E;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    @Override
    public void resetChangeMapId(int mapId) {
        long l = \u13e8;
        boolean bl = true;
        block12: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x63DAL ^ 0xE9805D73C11CE0C4L);
            }
            switch ((int)l) {
                case -1637475042: {
                    l2 = 0x20EDL ^ 0xBD14819D0E31DCBDL;
                    continue block12;
                }
                case -1538602894: {
                    l2 = 0x345FL ^ 0x7A30CCC404959AF6L;
                    continue block12;
                }
                case 301104448: {
                    l2 = 0x5875L ^ 0xF834F656258CDCAL;
                    continue block12;
                }
                case 1473674048: {
                    break block12;
                }
            }
            break;
        }
        this.mapId = mapId;
        long l3 = \u13e8;
        boolean bl2 = true;
        block13: while (true) {
            long l4;
            if (!bl2 || (bl2 = false) || !true) {
                l3 = l4 / (0x24FBL ^ 0x54F215AC5A0592B0L);
            }
            switch ((int)l3) {
                case -2080213952: {
                    l4 = 0x997L ^ 0xEA3AB0F3438487EEL;
                    continue block13;
                }
                case -1218293466: {
                    l4 = 0x2EC0L ^ 0x78D0BF41EDE01702L;
                    continue block13;
                }
                case 204702092: {
                    l4 = 2632354670235841924L >>> "\u0000\u0000".length();
                    continue block13;
                }
                case 1473674048: {
                    break block13;
                }
            }
            break;
        }
        this.resetDeaths();
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    @Override
    public int getDeaths() {
        long l = \u13e8;
        boolean bl = true;
        block5: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x457AL ^ 0xFF4F9AB649E51AE7L);
            }
            switch ((int)l) {
                case -705549936: {
                    l2 = 0x1CFBL ^ 0xC67D216C35BB858AL;
                    continue block5;
                }
                case -397574146: {
                    l2 = 0x3048L ^ 0x7891C04FD3197EEAL;
                    continue block5;
                }
                case 1473674048: {
                    return this.deathCount;
                }
            }
            break;
        }
        return this.deathCount;
    }
}

