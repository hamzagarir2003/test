/*
 * Decompiled with CFR 0.152.
 */
package com.tawaret.tawaplugin.features.mapcyclemodule.models;

import com.tawaret.tawaplugin.features.mapcyclemodule.models.MapInfo;

public class MapInfoFactory {
    protected static long \u13e8 = -8400322475776874079L;

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public MapInfoFactory() {
        long l = \u13e8;
        boolean bl = true;
        block5: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x6D6CL ^ 0xE40C598AA99FCACAL);
            }
            switch ((int)l) {
                case -311271055: {
                    l2 = 0x10D1L ^ 0xA0925BE3D787A578L;
                    continue block5;
                }
                case -251333726: {
                    l2 = 1120074856400123128L >>> "\u0000\u0000".length();
                    continue block5;
                }
                case 278325665: {
                    break block5;
                }
            }
            break;
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public static MapInfo Default() {
        long l = \u13e8;
        boolean bl = true;
        block10: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x3123L ^ 0xBF0687514F446222L);
            }
            switch ((int)l) {
                case 278325665: {
                    break block10;
                }
                case 425382803: {
                    l2 = -2953410742054808300L >>> "\u0000\u0000".length();
                    continue block10;
                }
                case 667584465: {
                    l2 = 0x71B9L ^ 0x7AB2E1C0474A431BL;
                    continue block10;
                }
                case 836496363: {
                    l2 = 0x24A4L ^ 0xEA3DC6D074B712A5L;
                    continue block10;
                }
            }
            break;
        }
        int n = "".length() >>> "\u0000\u0000".length();
        long l3 = \u13e8;
        block11: while (true) {
            switch ((int)l3) {
                case -1949308888: {
                    l3 = (0x7C45L ^ 0xE5CCFB950F4E7768L) / (0x6527L ^ 0x4D8D9B5DE09B0A40L);
                    continue block11;
                }
                case 278325665: {
                    return new MapInfo((0x21FE ^ 0x21FE) != 0, n, (0x782C ^ 0x782C) != 0, null, (0xE18 ^ 0xE19) != 0, (0x17F7 ^ 0x17F6) != 0, 0x5802 ^ 0xFFFFA7FD, 0x7271 ^ 0xFFFF8D8E);
                }
            }
            break;
        }
        return new MapInfo((0x21FE ^ 0x21FE) != 0, n, (0x782C ^ 0x782C) != 0, null, (0xE18 ^ 0xE19) != 0, (0x17F7 ^ 0x17F6) != 0, 0x5802 ^ 0xFFFFA7FD, 0x7271 ^ 0xFFFF8D8E);
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    public static MapInfo Refreshable(int mapId) {
        while (true) {
            if ((v0 = (cfr_temp_0 = MapInfoFactory.\u13e8 - (3002L ^ -5564996391770690842L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (23752 ^ -23753)) break;
            v0 = 28919 ^ 2038297300;
        }
        v1 = "".length() >>> "\u0000\u0000".length();
        while (true) {
            if ((v2 = (cfr_temp_1 = MapInfoFactory.\u13e8 - (6297L ^ 4291450106609527129L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v2 == (17294 ^ -17295)) break;
            v2 = 16754 ^ -1942714791;
        }
        v3 = mapId;
        v4 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        v5 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        v6 = MapInfoFactory.\u13e8;
        if (true) ** GOTO lbl19
        block8: while (true) {
            v6 = v7 / (24211L ^ -5731899741261562186L);
lbl19:
            // 2 sources

            switch ((int)v6) {
                case -1323492751: {
                    v7 = 26454L ^ 1815560182939770489L;
                    continue block8;
                }
                case 278325665: {
                    break block8;
                }
                case 981196126: {
                    v7 = 21406L ^ -4891247464568471063L;
                    continue block8;
                }
                case 1923861786: {
                    v7 = 27537L ^ -2813861987886142505L;
                    continue block8;
                }
            }
            break;
        }
        return new MapInfo((boolean)(968 ^ 968), v1, (boolean)(14868 ^ 14869), v3, v4, v5, 31111 ^ -31112, 31343 ^ -31344);
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    public static MapInfo NotRefreshable(int mapId) {
        while (true) {
            if ((v0 = (cfr_temp_0 = MapInfoFactory.\u13e8 - (32302L ^ -6600967547199750423L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (12183 ^ -12184)) break;
            v0 = 2261 ^ -622599019;
        }
        v1 = "".length() >>> "\u0000\u0000".length();
        v2 = "".length() >>> "\u0000\u0000".length();
        v3 = "".length() >>> "\u0000\u0000".length();
        while (true) {
            if ((v4 = (cfr_temp_1 = MapInfoFactory.\u13e8 - (11280L ^ -366407807763255189L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v4 == (3364 ^ -3365)) break;
            v4 = 23814 ^ 1596093415;
        }
        v5 = mapId;
        v6 = MapInfoFactory.\u13e8;
        if (true) ** GOTO lbl19
        block8: while (true) {
            v6 = v7 / (895L ^ -8421649032916731957L);
lbl19:
            // 2 sources

            switch ((int)v6) {
                case -1415442012: {
                    v7 = 11221L ^ -7425006966818885471L;
                    continue block8;
                }
                case 247665966: {
                    v7 = 361L ^ -3980917128265433719L;
                    continue block8;
                }
                case 278325665: {
                    break block8;
                }
                case 1495753658: {
                    v7 = 8728L ^ 628164699009889600L;
                    continue block8;
                }
            }
            break;
        }
        return new MapInfo(v1, v2, v3, v5, (boolean)(7659 ^ 7658), (boolean)(26132 ^ 26133), 10536 ^ -10537, 180 ^ -181);
    }

    public static MapInfo DefaultPartOfCycle(int priority, boolean isRefreshable, int mapId, int x, int y) {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (1360749362220952924L >>> "\u0000\u0000".length())) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x5D45 ^ 0xFFFFA2BA)) break;
            l2 = 0x348 ^ 0x543129FE;
        }
        boolean bl = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = \u13e8 - (0x4777L ^ 0xD629FE80F2E87F3DL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l3 == (0x6447 ^ 0xFFFF9BB8)) break;
            l3 = 0x5D58 ^ 0xF7B3F710;
        }
        Integer n = mapId;
        while (true) {
            long l;
            long l4;
            if ((l4 = (l = \u13e8 - (0x390AL ^ 0x875C2C6FDCC0AE7BL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l4 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l4 = 0xD16 ^ 0xBB4E73DA;
        }
        return new MapInfo(bl, priority, isRefreshable, n, (0x53CE ^ 0x53CF) != 0, (0x11E6 ^ 0x11E7) != 0, x, y);
    }
}

