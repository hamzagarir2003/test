/*
 * Decompiled with CFR 0.152.
 */
package com.tawaret.tawaplugin.features.mapcyclemodule.statusProviders;

import com.tawaret.tawaplugin.features.mapcyclemodule.IMapCycleModule;
import com.tawaret.tawaplugin.features.mapcyclemodule.statusProviders.MapCycleStatusBuilder;
import com.tawaret.tawaplugin.utils.StatusProviders.IStatusProvider;

public class MapCycleStoppedStatusProvider
implements IStatusProvider<IMapCycleModule> {
    public static long \u13e8 = 5396376587570449137L;

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public MapCycleStoppedStatusProvider() {
        long l = \u13e8;
        boolean bl = true;
        block6: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x56EL ^ 0xD2A49EF71FFA7206L);
            }
            switch ((int)l) {
                case -1426108323: {
                    l2 = 0x51F4L ^ 0xB7B41C57905EC7ACL;
                    continue block6;
                }
                case -390453334: {
                    l2 = 0x1BDCL ^ 0xB7BDEFBB204296D5L;
                    continue block6;
                }
                case -56573850: {
                    l2 = 0x5308L ^ 0xEDF4EBB6DF3054EAL;
                    continue block6;
                }
                case 1214188273: {
                    break block6;
                }
            }
            break;
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    @Override
    public String getStatusMsg(IMapCycleModule module) {
        long l = \u13e8;
        block28: while (true) {
            switch ((int)l) {
                case 201434590: {
                    l = (0x2779L ^ 0xBCCBFDCA1C312128L) / (0x47DEL ^ 0xD9A4D87DDBB84E04L);
                    continue block28;
                }
                case 1214188273: {
                    break block28;
                }
            }
            break;
        }
        long l2 = \u13e8;
        boolean bl = true;
        block29: while (true) {
            long l3;
            if (!bl || (bl = false) || !true) {
                l2 = l3 / (4237697710331143252L >>> "\u0000\u0000".length());
            }
            switch ((int)l2) {
                case -158192894: {
                    l3 = 0x2CA2L ^ 0x82DB12BF46614D16L;
                    continue block29;
                }
                case 1150140474: {
                    l3 = 0x149EL ^ 0x4D8A867504822E54L;
                    continue block29;
                }
                case 1214188273: {
                    break block29;
                }
            }
            break;
        }
        MapCycleStatusBuilder mapCycleStatusBuilder = new MapCycleStatusBuilder(module);
        long l4 = \u13e8;
        block30: while (true) {
            switch ((int)l4) {
                case -755864997: {
                    l4 = (0x59F0L ^ 0xFC8791C05241A134L) / (0x4BCBL ^ 0xFD3870362942EFD9L);
                    continue block30;
                }
                case 1214188273: {
                    break block30;
                }
            }
            break;
        }
        MapCycleStatusBuilder mapCycleStatusBuilder2 = mapCycleStatusBuilder.withNumBoxesInSight();
        long l5 = \u13e8;
        boolean bl2 = true;
        block31: while (true) {
            long l6;
            if (!bl2 || (bl2 = false) || !true) {
                l5 = l6 / (0x3BCCL ^ 0x294A27E848DEE1ADL);
            }
            switch ((int)l5) {
                case -667817227: {
                    l6 = 0x943L ^ 0xC7DDB032D5E3D75CL;
                    continue block31;
                }
                case 1214188273: {
                    break block31;
                }
                case 2084270381: {
                    l6 = 0x5BEDL ^ 0x8EE99601F50EF22CL;
                    continue block31;
                }
            }
            break;
        }
        MapCycleStatusBuilder mapCycleStatusBuilder3 = mapCycleStatusBuilder2.withNpcWillSpawnInSeconds();
        long l7 = \u13e8;
        boolean bl3 = true;
        block32: while (true) {
            long l8;
            if (!bl3 || (bl3 = false) || !true) {
                l7 = l8 / (0x4E0DL ^ 0x436DD1B13F8F9F6EL);
            }
            switch ((int)l7) {
                case -2111814149: {
                    l8 = 0x35C7L ^ 0xB2BAD3E8156E67B2L;
                    continue block32;
                }
                case 340757077: {
                    l8 = 6677916996205301828L >>> "\u0000\u0000".length();
                    continue block32;
                }
                case 1057577421: {
                    l8 = 0x1C36L ^ 0x12B48C0C07C508F2L;
                    continue block32;
                }
                case 1214188273: {
                    break block32;
                }
            }
            break;
        }
        MapCycleStatusBuilder mapCycleStatusBuilder4 = mapCycleStatusBuilder3.withWaitTillNextMapSeconds();
        long l9 = \u13e8;
        block33: while (true) {
            switch ((int)l9) {
                case -421411789: {
                    l9 = (0x5F4FL ^ 0x474FB4DBB00D1E15L) / (0x344DL ^ 0xEF7320B5C101BA73L);
                    continue block33;
                }
                case 1214188273: {
                    return mapCycleStatusBuilder4.build();
                }
            }
            break;
        }
        return mapCycleStatusBuilder4.build();
    }
}

