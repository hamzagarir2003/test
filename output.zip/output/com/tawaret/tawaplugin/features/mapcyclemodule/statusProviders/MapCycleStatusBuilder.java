/*
 * Decompiled with CFR 0.152.
 */
package com.tawaret.tawaplugin.features.mapcyclemodule.statusProviders;

import com.tawaret.tawaplugin.features.mapcyclemodule.IMapCycleModule;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class MapCycleStatusBuilder {
    private final List<String> statusMsgs;
    private final IMapCycleModule module;
    public static long \u13e8 = -6535291537190955103L;

    /*
     * Unable to fully structure code
     */
    public MapCycleStatusBuilder(IMapCycleModule module) {
        while (true) {
            if ((v0 = (cfr_temp_0 = MapCycleStatusBuilder.\u13e8 - (30675L ^ -4645391544150526037L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (4770 ^ -4771)) break;
            v0 = 20965 ^ -1267021028;
        }
        super();
        v1 = MapCycleStatusBuilder.\u13e8;
        if (true) ** GOTO lbl11
        block23: while (true) {
            v1 = v2 / (2563L ^ -5511353031206812072L);
lbl11:
            // 2 sources

            switch ((int)v1) {
                case -300034143: {
                    break block23;
                }
                case 124465725: {
                    v2 = 2911672236102101372L >>> "\u0000\u0000".length();
                    continue block23;
                }
                case 499880724: {
                    v2 = 22301L ^ -4230864291209594955L;
                    continue block23;
                }
                case 1968613118: {
                    v2 = 28972L ^ -474027388646754381L;
                    continue block23;
                }
            }
            break;
        }
        this.module = module;
        v3 = MapCycleStatusBuilder.\u13e8;
        if (true) ** GOTO lbl28
        block24: while (true) {
            v3 = (18875L ^ 2633952430389869332L) / (32387L ^ -5409038401317744309L);
lbl28:
            // 2 sources

            switch ((int)v3) {
                case -300034143: {
                    break block24;
                }
                case 1020964588: {
                    continue block24;
                }
            }
            break;
        }
        v4 = MapCycleStatusBuilder.\u13e8;
        if (true) ** GOTO lbl37
        block25: while (true) {
            v4 = v5 / (32691L ^ 3794268151487143161L);
lbl37:
            // 2 sources

            switch ((int)v4) {
                case -884084336: {
                    v5 = 2737L ^ 2112691039917006031L;
                    continue block25;
                }
                case -300034143: {
                    break block25;
                }
                case 1085684596: {
                    v5 = 21921L ^ 2807319592055201265L;
                    continue block25;
                }
                case 1534230682: {
                    v5 = 13047L ^ -5693256630459827604L;
                    continue block25;
                }
            }
            break;
        }
        v6 = new ArrayList<String>();
        v7 = MapCycleStatusBuilder.\u13e8;
        if (true) ** GOTO lbl54
        block26: while (true) {
            v7 = v8 / (6361L ^ 6480697358955782734L);
lbl54:
            // 2 sources

            switch ((int)v7) {
                case -1526199595: {
                    v8 = 29475L ^ -3601798122896944308L;
                    continue block26;
                }
                case -300034143: {
                    break block26;
                }
                case 962531149: {
                    v8 = 471940016299991648L >>> "\u0000\u0000".length();
                    continue block26;
                }
                case 1376952374: {
                    v8 = 11275L ^ -3710620210523688812L;
                    continue block26;
                }
            }
            break;
        }
        this.statusMsgs = v6;
    }

    /*
     * Unable to fully structure code
     */
    public MapCycleStatusBuilder withNumBoxesInSight() {
        block11: {
            while (true) {
                if ((v0 = (cfr_temp_0 = MapCycleStatusBuilder.\u13e8 - (29072L ^ -1666899947578054212L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v0 == (29143 ^ -29144)) break;
                v0 = 26572 ^ -1285263411;
            }
            while (true) {
                if ((v1 = (cfr_temp_1 = MapCycleStatusBuilder.\u13e8 - (21424L ^ 8694345117980890477L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v1 == (31453 ^ -31454)) break;
                v1 = 24105 ^ 1122017420;
            }
            numBoxesInSight = this.module.getNumberOfBoxesInSight();
            if (numBoxesInSight == null) break block11;
            while (true) {
                if ((v2 = (cfr_temp_2 = MapCycleStatusBuilder.\u13e8 - (1048L ^ 5544169271588900945L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v2 == (8416 ^ -8417)) break;
                v2 = 16071 ^ -1493173692;
            }
            var3_2 = new byte["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
            var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
            var3_2[31950 ^ 31947] = 15859 ^ 15817;
            var3_2["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 24187 ^ 24084;
            var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 480 >>> "\u0000\u0000".length();
            var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 460 >>> "\u0000\u0000".length();
            var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 30056 ^ 30024;
            var3_2[15242 ^ 15241] = 404 >>> "\u0000\u0000".length();
            var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 29265 ^ 29237;
            var3_2[3655 ^ 3648] = 148 >>> "\u0000\u0000".length();
            var3_2["".length() >>> "\u0000\u0000".length()] = 264 >>> "\u0000\u0000".length();
            v3 = new String(var3_2);
            v4 = new Object["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
            v4["".length() >>> "\u0000\u0000".length()] = numBoxesInSight;
            while (true) {
                if ((v5 = (cfr_temp_3 = MapCycleStatusBuilder.\u13e8 - (1692L ^ -7290959000826603640L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v5 == (4239 ^ 4238)) break;
                v5 = 22352 ^ 1224917996;
            }
            v6 = String.format(v3, v4);
            v7 = MapCycleStatusBuilder.\u13e8;
            if (true) ** GOTO lbl42
            block10: while (true) {
                v7 = v8 / (-708547521699074820L >>> "\u0000\u0000".length());
lbl42:
                // 2 sources

                switch ((int)v7) {
                    case -916264831: {
                        v8 = 31308L ^ 1705715098945974294L;
                        continue block10;
                    }
                    case -300034143: {
                        break block10;
                    }
                    case 386446004: {
                        v8 = 1086L ^ 7688484312182778201L;
                        continue block10;
                    }
                    case 842849149: {
                        v8 = 7463L ^ -3698964962793052261L;
                        continue block10;
                    }
                }
                break;
            }
            this.statusMsgs.add(v6);
        }
        return this;
    }

    /*
     * Unable to fully structure code
     */
    public MapCycleStatusBuilder withWaitTillNextMapSeconds() {
        block50: {
            v0 = MapCycleStatusBuilder.\u13e8;
            if (true) ** GOTO lbl5
            block36: while (true) {
                v0 = (16502L ^ -1035884973306342767L) / (21597L ^ -2096980523243757940L);
lbl5:
                // 2 sources

                switch ((int)v0) {
                    case -300034143: {
                        break block36;
                    }
                    case 615721258: {
                        continue block36;
                    }
                }
                break;
            }
            v1 = MapCycleStatusBuilder.\u13e8;
            if (true) ** GOTO lbl14
            block37: while (true) {
                v1 = (1453L ^ 4682021489138825131L) / (4127L ^ -8643643765920128205L);
lbl14:
                // 2 sources

                switch ((int)v1) {
                    case -300034143: {
                        break block37;
                    }
                    case 1433321924: {
                        continue block37;
                    }
                }
                break;
            }
            nextMapIdAfterWaitKillPeriod = this.module.getNextMapIdAfterWaitKillPeriod();
            if (nextMapIdAfterWaitKillPeriod == null) break block50;
            v2 = MapCycleStatusBuilder.\u13e8;
            if (true) ** GOTO lbl25
            block38: while (true) {
                v2 = v3 / (26863L ^ 4705574681525351184L);
lbl25:
                // 2 sources

                switch ((int)v2) {
                    case -300034143: {
                        break block38;
                    }
                    case 416661666: {
                        v3 = 1808095463853042372L >>> "\u0000\u0000".length();
                        continue block38;
                    }
                    case 1111807160: {
                        v3 = 5498464522444310020L >>> "\u0000\u0000".length();
                        continue block38;
                    }
                }
                break;
            }
            while (true) {
                if ((v4 = (cfr_temp_0 = MapCycleStatusBuilder.\u13e8 - (27362L ^ -3830410455753438850L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v4 == (30903 ^ -30904)) break;
                v4 = 19113 ^ -267164917;
            }
            secondsPastAfterNpcKill = this.module.getAfterNpcKillSecondsPast();
            v5 = MapCycleStatusBuilder.\u13e8;
            if (true) ** GOTO lbl44
            block40: while (true) {
                v5 = (11885L ^ -3304355671738177338L) / (4595L ^ -1206634490767967426L);
lbl44:
                // 2 sources

                switch ((int)v5) {
                    case -300034143: {
                        break block40;
                    }
                    case 84155660: {
                        continue block40;
                    }
                }
                break;
            }
            while (true) {
                if ((v6 = (cfr_temp_1 = MapCycleStatusBuilder.\u13e8 - (3025L ^ -5200693066025586684L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v6 == (5852 ^ -5853)) break;
                v6 = 24878 ^ 2037994762;
            }
            waitSecondsAfterKill = this.module.getWaitSecondsAfterKill();
            if (secondsPastAfterNpcKill == null) break block50;
            v7 = MapCycleStatusBuilder.\u13e8;
            if (true) ** GOTO lbl60
            block42: while (true) {
                v7 = v8 / (28775L ^ -5038255823144416178L);
lbl60:
                // 2 sources

                switch ((int)v7) {
                    case -300034143: {
                        break block42;
                    }
                    case 108741386: {
                        v8 = 11979L ^ -5995117557558991167L;
                        continue block42;
                    }
                    case 530513394: {
                        v8 = 24189L ^ -1297673716812669162L;
                        continue block42;
                    }
                    case 2078573322: {
                        v8 = 2221L ^ 2208937410213219195L;
                        continue block42;
                    }
                }
                break;
            }
            var5_4 = new byte[11077 ^ 11108];
            var5_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 16557 ^ -16612;
            var5_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 17931 ^ 18022;
            var5_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 420 >>> "\u0000\u0000".length();
            var5_4["".length() >>> "\u0000\u0000".length()] = 665 ^ 718;
            var5_4[15477 ^ 15466] = 27064 ^ 27037;
            var5_4[15938 ^ 15963] = 444 >>> "\u0000\u0000".length();
            var5_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 17758 ^ 17721;
            var5_4[3442 ^ 3429] = 11153 ^ 11185;
            var5_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 244 ^ 156;
            var5_4[14767 ^ 14757] = 17489 ^ 17461;
            var5_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 19472 ^ 19573;
            var5_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 128 >>> "\u0000\u0000".length();
            var5_4[15789 ^ 15778] = 432 >>> "\u0000\u0000".length();
            var5_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 188 >>> "\u0000\u0000".length();
            var5_4[24793 ^ 24781] = 4502 ^ 4600;
            var5_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 400 >>> "\u0000\u0000".length();
            var5_4[6569 ^ 6581] = 2780 ^ 2749;
            var5_4[4007 ^ 4010] = 29977 ^ 30064;
            var5_4[20415 ^ 20398] = 396 >>> "\u0000\u0000".length();
            var5_4[2257 ^ 2261] = 21234 ^ 21192;
            var5_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 128 >>> "\u0000\u0000".length();
            var5_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 464 >>> "\u0000\u0000".length();
            var5_4["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 388 >>> "\u0000\u0000".length();
            var5_4[23408 ^ 23395] = 31988 ^ 31893;
            var5_4[8629 ^ 8613] = 23967 ^ 23999;
            var5_4[17474 ^ 17476] = 5821 ^ 5784;
            var5_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 432 >>> "\u0000\u0000".length();
            var5_4[8436 ^ 8428] = 464 >>> "\u0000\u0000".length();
            var5_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 9509 ^ 9553;
            var5_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 128 >>> "\u0000\u0000".length();
            var5_4[19506 ^ 19474] = 30095 ^ 30204;
            var5_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 1046 ^ 1078;
            var5_4[20985 ^ 20976] = 1519 ^ 1482;
            var5_4[21084 ^ 21057] = 448 >>> "\u0000\u0000".length();
            v9 = new String(var5_4);
            v10 = new Object["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
            v10["".length() >>> "\u0000\u0000".length()] = secondsPastAfterNpcKill;
            v11 = MapCycleStatusBuilder.\u13e8;
            if (true) ** GOTO lbl114
            block43: while (true) {
                v11 = (19206L ^ 6347651980683250756L) / (6697L ^ 8485584611266754886L);
lbl114:
                // 2 sources

                switch ((int)v11) {
                    case -923897126: {
                        continue block43;
                    }
                    case -300034143: {
                        break block43;
                    }
                }
                break;
            }
            v10[16166 ^ 16167] = waitSecondsAfterKill;
            v12 = MapCycleStatusBuilder.\u13e8;
            if (true) ** GOTO lbl124
            block44: while (true) {
                v12 = (18696L ^ 8237026687290352615L) / (26821L ^ -7647801932053920635L);
lbl124:
                // 2 sources

                switch ((int)v12) {
                    case -1665002388: {
                        continue block44;
                    }
                    case -300034143: {
                        break block44;
                    }
                }
                break;
            }
            v13 = MapCycleStatusBuilder.\u13e8;
            if (true) ** GOTO lbl133
            block45: while (true) {
                v13 = v14 / (25926L ^ -7516195561819904923L);
lbl133:
                // 2 sources

                switch ((int)v13) {
                    case -300034143: {
                        break block45;
                    }
                    case -75954544: {
                        v14 = -4610155471607925884L >>> "\u0000\u0000".length();
                        continue block45;
                    }
                    case 1271219868: {
                        v14 = 25158L ^ -9190443840199242871L;
                        continue block45;
                    }
                }
                break;
            }
            v15 = nextMapIdAfterWaitKillPeriod;
            while (true) {
                if ((v16 = (cfr_temp_2 = MapCycleStatusBuilder.\u13e8 - (18008L ^ -1819273214619122595L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v16 == (11669 ^ -11670)) break;
                v16 = 26893 ^ -2021915986;
            }
            v10[28851 ^ 28849] = this.module.getMapName(v15);
            while (true) {
                if ((v17 = (cfr_temp_3 = MapCycleStatusBuilder.\u13e8 - (23986L ^ 3544539595364807048L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v17 == (21900 ^ -21901)) break;
                v17 = 1554 ^ -1803294476;
            }
            v18 = String.format(v9, v10);
            while (true) {
                if ((v19 = (cfr_temp_4 = MapCycleStatusBuilder.\u13e8 - (6761943794678943544L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v19 == (18381 ^ -18382)) {
                    this.statusMsgs.add(v18);
                    break;
                }
                v19 = 18545 ^ 369498586;
            }
        }
        return this;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public MapCycleStatusBuilder withNpcWillSpawnInSeconds() {
        Long msTillWithinSpawnPeriod;
        long l = \u13e8;
        block28: while (true) {
            switch ((int)l) {
                case -300034143: {
                    break block28;
                }
                case 943201392: {
                    l = (0xA52L ^ 0xC8394FCA7E9FE193L) / (0x6CF9L ^ 0xBC225291014E5DD2L);
                    continue block28;
                }
            }
            break;
        }
        while (true) {
            long l2;
            long l3;
            if ((l3 = (l2 = \u13e8 - (0x2E0FL ^ 0x88CA0D71DA8F3AA3L)) == 0L ? 0 : (l2 < 0L ? -1 : 1)) == false) continue;
            if (l3 == (0x214F ^ 0x214E)) {
                msTillWithinSpawnPeriod = this.module.getMsTillWithinNPCSpawnPeriod();
                if (msTillWithinSpawnPeriod == null) return this;
                break;
            }
            l3 = 0x8AC ^ 0xF34C9D63;
        }
        while (true) {
            long l4;
            long l5;
            if ((l5 = (l4 = \u13e8 - (6271178041021617628L >>> "\u0000\u0000".length())) == 0L ? 0 : (l4 < 0L ? -1 : 1)) == false) continue;
            if (l5 == (0x271A ^ 0xFFFFD8E5)) {
                if (msTillWithinSpawnPeriod < (0x58F8L ^ 0x58F8L)) return this;
                break;
            }
            l5 = 0x5F57 ^ 0x4E97D8DF;
        }
        long l6 = \u13e8;
        boolean bl = true;
        block31: while (true) {
            long l7;
            if (!bl || (bl = false) || !true) {
                l6 = l7 / (0x4F0L ^ 0xD8AC812337408DEBL);
            }
            switch ((int)l6) {
                case -423522521: {
                    l7 = 0x5EA4L ^ 0x79D5FBB1058FC8AFL;
                    continue block31;
                }
                case -346321066: {
                    l7 = 0x2A06L ^ 0x166B2070CA2211E8L;
                    continue block31;
                }
                case -300034143: {
                    break block31;
                }
            }
            break;
        }
        byte[] byArray = new byte["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x7560 ^ 0xFFFF8AFF;
        byArray[0x7239 ^ 0x723A] = 476 >>> "\u0000\u0000".length();
        byArray[0x35D8 ^ 0x35C9] = 0x333D ^ 0x3353;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 420 >>> "\u0000\u0000".length();
        byArray[0x71F2 ^ 0x71F8] = 148 >>> "\u0000\u0000".length();
        byArray[0x7349 ^ 0x7344] = 460 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 440 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x6AE7 ^ 0x6A82;
        byArray[0x4E61 ^ 0x4E64] = 128 >>> "\u0000\u0000".length();
        byArray[0x5343 ^ 0x534B] = 232 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x1513 ^ 0x1570;
        byArray[0x2261 ^ 0x2268] = 0x3340 ^ 0x3360;
        byArray[0x1780 ^ 0x1787] = 440 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x3A7F ^ 0x3A1E;
        byArray[0x2B55 ^ 0x2B46] = 0x49A6 ^ 0x49D5;
        byArray[0x1F8A ^ 0x1F86] = 0x217C ^ 0x215C;
        byArray[0x845 ^ 0x844] = 448 >>> "\u0000\u0000".length();
        byArray["".length() >>> "\u0000\u0000".length()] = 0x9E6 ^ 0x9B5;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 400 >>> "\u0000\u0000".length();
        byArray[0x823 ^ 0x833] = 444 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x508F ^ 0x50EB;
        String string = new String(byArray);
        Object[] objectArray = new Object[0x6F12 ^ 0x6F13];
        long l8 = \u13e8;
        boolean bl2 = true;
        block32: while (true) {
            long l9;
            if (!bl2 || (bl2 = false) || !true) {
                l8 = l9 / (0x60EFL ^ 0xA42CA6BC3879BCEEL);
            }
            switch ((int)l8) {
                case -300034143: {
                    break block32;
                }
                case 90772282: {
                    l9 = 0x77E3L ^ 0x57159E7615DE9018L;
                    continue block32;
                }
                case 619365622: {
                    l9 = 0x63F3L ^ 0xDDDE1B451843A0ADL;
                    continue block32;
                }
            }
            break;
        }
        long l10 = \u13e8;
        boolean bl3 = true;
        block33: while (true) {
            long l11;
            if (!bl3 || (bl3 = false) || !true) {
                l10 = l11 / (0x185BL ^ 0x866C8115AE00A9D9L);
            }
            switch ((int)l10) {
                case -300034143: {
                    break block33;
                }
                case 379376994: {
                    l11 = 0x6605L ^ 0xC9B96F0ED5E49439L;
                    continue block33;
                }
                case 2109144710: {
                    l11 = -6760318902144595472L >>> "\u0000\u0000".length();
                    continue block33;
                }
            }
            break;
        }
        long l12 = msTillWithinSpawnPeriod;
        long l13 = \u13e8;
        boolean bl4 = true;
        block34: while (true) {
            long l14;
            if (!bl4 || (bl4 = false) || !true) {
                l13 = l14 / (0x4394L ^ 0x78310C8D4FBD57D1L);
            }
            switch ((int)l13) {
                case -300034143: {
                    break block34;
                }
                case 529762004: {
                    l14 = 0x21B9L ^ 0x7B1BD03F92472C4AL;
                    continue block34;
                }
                case 947352925: {
                    l14 = 0x2D1L ^ 0xF09EDEE4CD2E169L;
                    continue block34;
                }
            }
            break;
        }
        long l15 = TimeUnit.MILLISECONDS.toSeconds(l12);
        while (true) {
            long l16;
            long l17;
            if ((l17 = (l16 = \u13e8 - (0x2639L ^ 0xD601D7AB116E8517L)) == 0L ? 0 : (l16 < 0L ? -1 : 1)) == false) continue;
            if (l17 == (0x5800 ^ 0xFFFFA7FF)) break;
            l17 = 0x7192 ^ 0xF06518AB;
        }
        objectArray[0x232F ^ 0x232F] = l15;
        while (true) {
            long l18;
            long l19;
            if ((l19 = (l18 = \u13e8 - (-6819348078461123104L >>> "\u0000\u0000".length())) == 0L ? 0 : (l18 < 0L ? -1 : 1)) == false) continue;
            if (l19 == (0x266E ^ 0xFFFFD991)) break;
            l19 = 0x7441 ^ 0x49F62461;
        }
        String string2 = String.format(string, objectArray);
        long l20 = \u13e8;
        block37: while (true) {
            switch ((int)l20) {
                case -300034143: {
                    break block37;
                }
                case 124220317: {
                    l20 = (0x22A3L ^ 0x548430812C000AABL) / (0x5435L ^ 0x610D0B91F1E7295EL);
                    continue block37;
                }
            }
            break;
        }
        this.statusMsgs.add(string2);
        return this;
    }

    /*
     * Unable to fully structure code
     */
    public MapCycleStatusBuilder withExcessPredictedSpawnSeconds() {
        block24: {
            while (true) {
                if ((v0 = (cfr_temp_0 = MapCycleStatusBuilder.\u13e8 - (3764L ^ 8433930855626714553L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v0 == (17791 ^ -17792)) break;
                v0 = 11146 ^ 376035392;
            }
            while (true) {
                if ((v1 = (cfr_temp_1 = MapCycleStatusBuilder.\u13e8 - (9314L ^ 8574258557740117366L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v1 == (30403 ^ -30404)) break;
                v1 = 21707 ^ -2086695206;
            }
            excessSeconds = this.module.getExcessSecondsAfterPredictedSpawn();
            while (true) {
                if ((v2 = (cfr_temp_2 = MapCycleStatusBuilder.\u13e8 - (-8443691965488786540L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v2 == (5089 ^ -5090)) break;
                v2 = 4568 ^ -327325769;
            }
            v3 = MapCycleStatusBuilder.\u13e8;
            if (true) ** GOTO lbl21
            block20: while (true) {
                v3 = v4 / (27955L ^ -2207394728790930236L);
lbl21:
                // 2 sources

                switch ((int)v3) {
                    case -743572214: {
                        v4 = 23286L ^ 5289148093371521046L;
                        continue block20;
                    }
                    case -300034143: {
                        break block20;
                    }
                    case 658260958: {
                        v4 = -8849746651642798556L >>> "\u0000\u0000".length();
                        continue block20;
                    }
                    case 1215476788: {
                        v4 = 25809L ^ -4788584143511600261L;
                        continue block20;
                    }
                }
                break;
            }
            excessBoundary = this.module.getExcessSecondsMax();
            if (excessSeconds == null || excessBoundary == null) break block24;
            v5 = MapCycleStatusBuilder.\u13e8;
            if (true) ** GOTO lbl39
            block21: while (true) {
                v5 = v6 / (31464L ^ 7572850916793343366L);
lbl39:
                // 2 sources

                switch ((int)v5) {
                    case -300034143: {
                        break block21;
                    }
                    case 1298880786: {
                        v6 = 31588L ^ 8883519945219683788L;
                        continue block21;
                    }
                    case 1842063121: {
                        v6 = 28830L ^ 13004069157678663L;
                        continue block21;
                    }
                }
                break;
            }
            var4_3 = new byte[22057 ^ 22069];
            var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 17340 ^ 17356;
            var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 148 >>> "\u0000\u0000".length();
            var4_3[16626 ^ 16632] = 28003 ^ 27906;
            var4_3[19851 ^ 19870] = 460 >>> "\u0000\u0000".length();
            var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 400 >>> "\u0000\u0000".length();
            var4_3[9232 ^ 9232] = 30504 ^ 30567;
            var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 440 >>> "\u0000\u0000".length();
            var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 404 >>> "\u0000\u0000".length();
            var4_3[1286 ^ 1288] = 18390 ^ 18422;
            var4_3[29821 ^ 29822] = 456 >>> "\u0000\u0000".length();
            var4_3[19812 ^ 19817] = 20438 ^ 20460;
            var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 460 >>> "\u0000\u0000".length();
            var4_3[7192 ^ 7188] = 440 >>> "\u0000\u0000".length();
            var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 375 ^ 338;
            var4_3[14312 ^ 14329] = 3134 ^ 3089;
            var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 404 >>> "\u0000\u0000".length();
            var4_3[8796 ^ 8779] = 2502 ^ 2469;
            var4_3[18374 ^ 18370] = 400 >>> "\u0000\u0000".length();
            var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 5685 ^ 5712;
            var4_3[21712 ^ 21717] = 23333 ^ 23376;
            var4_3[30285 ^ 30302] = 400 >>> "\u0000\u0000".length();
            var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 29522 ^ 29494;
            var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 27548 ^ 27635;
            var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 7893 ^ 7925;
            var4_3[15664 ^ 15675] = 15154 ^ 15173;
            var4_3[12004 ^ 12013] = 448 >>> "\u0000\u0000".length();
            var4_3["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 22011 ^ 21901;
            var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 32668 ^ 32751;
            var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 128 >>> "\u0000\u0000".length();
            v7 = new String(var4_3);
            v8 = new Object[25197 ^ 25199];
            v8[11938 ^ 11938] = excessSeconds;
            v8["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = excessBoundary;
            while (true) {
                if ((v9 = (cfr_temp_3 = MapCycleStatusBuilder.\u13e8 - (1475L ^ -2943051821867269040L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v9 == (22293 ^ -22294)) break;
                v9 = 12465 ^ -2130193539;
            }
            v10 = String.format(v7, v8);
            v11 = MapCycleStatusBuilder.\u13e8;
            if (true) ** GOTO lbl92
            block23: while (true) {
                v11 = v12 / (14822L ^ 1498469446031392134L);
lbl92:
                // 2 sources

                switch ((int)v11) {
                    case -1143926067: {
                        v12 = 20794L ^ -2796926768647482837L;
                        continue block23;
                    }
                    case -300034143: {
                        break block23;
                    }
                    case 156093009: {
                        v12 = 5396L ^ -4906203782032540696L;
                        continue block23;
                    }
                    case 186792745: {
                        v12 = 11118L ^ -5256655300847656986L;
                        continue block23;
                    }
                }
                break;
            }
            this.statusMsgs.add(v10);
        }
        return this;
    }

    /*
     * Unable to fully structure code
     */
    public MapCycleStatusBuilder withWaitTillKflSeconds() {
        block27: {
            v0 = MapCycleStatusBuilder.\u13e8;
            if (true) ** GOTO lbl5
            block16: while (true) {
                v0 = (7133949544309673936L >>> "\u0000\u0000".length()) / (30527L ^ -4446731886076163746L);
lbl5:
                // 2 sources

                switch ((int)v0) {
                    case -300034143: {
                        break block16;
                    }
                    case 939125443: {
                        continue block16;
                    }
                }
                break;
            }
            while (true) {
                if ((v1 = (cfr_temp_0 = MapCycleStatusBuilder.\u13e8 - (27785L ^ 4702865323201462138L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v1 == (27778 ^ -27779)) break;
                v1 = 30394 ^ -1548511817;
            }
            msKeyFirstLockSecondsPast = this.module.getKeyFirstLockMsPast();
            if (msKeyFirstLockSecondsPast == null) break block27;
            while (true) {
                if ((v2 = (cfr_temp_1 = MapCycleStatusBuilder.\u13e8 - (14681L ^ -6013050731347761314L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v2 == (2167 ^ -2168)) break;
                v2 = 23625 ^ -98322173;
            }
            v3 = MapCycleStatusBuilder.\u13e8;
            if (true) ** GOTO lbl26
            block19: while (true) {
                v3 = v4 / (278L ^ -9173474549833067041L);
lbl26:
                // 2 sources

                switch ((int)v3) {
                    case -300034143: {
                        break block19;
                    }
                    case 936760971: {
                        v4 = 744L ^ -8467257250058645740L;
                        continue block19;
                    }
                    case 1365484272: {
                        v4 = 5395L ^ -7432099225682092332L;
                        continue block19;
                    }
                    case 1766819634: {
                        v4 = 5979L ^ -4337968792745645470L;
                        continue block19;
                    }
                }
                break;
            }
            v5 = this.module.getKeyFirstLockConfig();
            while (true) {
                if ((v6 = (cfr_temp_2 = MapCycleStatusBuilder.\u13e8 - (11502L ^ 6137264836842725442L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v6 == (13520 ^ -13521)) break;
                v6 = 21484 ^ 1554566397;
            }
            endMs = v5.WAIT_MS_AFTER_FIRST_LOCK;
            while (true) {
                if ((v7 = (cfr_temp_3 = MapCycleStatusBuilder.\u13e8 - (16696L ^ 1997315567477330598L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v7 == (5796 ^ -5797)) break;
                v7 = 572971648 >>> "\u0000\u0000".length();
            }
            if (msKeyFirstLockSecondsPast > (long)endMs) break block27;
            while (true) {
                if ((v8 = (cfr_temp_4 = MapCycleStatusBuilder.\u13e8 - (8808L ^ -6329818596295678044L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v8 == (21819 ^ -21820)) break;
                v8 = 18648 ^ -922685715;
            }
            var4_3 = new byte["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
            var4_3[24220 ^ 24196] = 32371 ^ -32339;
            var4_3[11733 ^ 11725] = 6954 ^ 7001;
            var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 1441 ^ 1477;
            var4_3[28558 ^ 28552] = 148 >>> "\u0000\u0000".length();
            var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 232 >>> "\u0000\u0000".length();
            var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 14987 ^ 15022;
            var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 188 >>> "\u0000\u0000".length();
            var4_3[24357 ^ 24368] = 448 >>> "\u0000\u0000".length();
            var4_3[30764 ^ 30779] = 404 >>> "\u0000\u0000".length();
            var4_3["".length() >>> "\u0000\u0000".length()] = 348 >>> "\u0000\u0000".length();
            var4_3[5463 ^ 5460] = 16594 ^ 16550;
            var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 128 >>> "\u0000\u0000".length();
            var4_3[27801 ^ 27798] = 432 >>> "\u0000\u0000".length();
            var4_3[19788 ^ 19778] = 432 >>> "\u0000\u0000".length();
            var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 420 >>> "\u0000\u0000".length();
            var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 26759 ^ 26827;
            var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 460 >>> "\u0000\u0000".length();
            var4_3[14138 ^ 14123] = 300 >>> "\u0000\u0000".length();
            var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 23359 ^ 23417;
            var4_3[23207 ^ 23211] = 464 >>> "\u0000\u0000".length();
            var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 400 >>> "\u0000\u0000".length();
            var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 206 ^ 238;
            var4_3[15062 ^ 15059] = 4521 ^ 4489;
            var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 31101 ^ 30996;
            var4_3[182 ^ 183] = 388 >>> "\u0000\u0000".length();
            var4_3[4408 ^ 4392] = 128 >>> "\u0000\u0000".length();
            var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 17858 ^ 17840;
            v9 = new String(var4_3);
            v10 = new Object[8256 ^ 8258];
            v10["".length() >>> "\u0000\u0000".length()] = msKeyFirstLockSecondsPast;
            v11 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
            v12 = MapCycleStatusBuilder.\u13e8;
            if (true) ** GOTO lbl92
            block23: while (true) {
                v12 = v13 / (14157L ^ 5911868752513546345L);
lbl92:
                // 2 sources

                switch ((int)v12) {
                    case -2091407923: {
                        v13 = 31990L ^ -4725098876873175421L;
                        continue block23;
                    }
                    case -300034143: {
                        break block23;
                    }
                    case 793901008: {
                        v13 = 1446L ^ -1593762369557912887L;
                        continue block23;
                    }
                    case 809780820: {
                        v13 = 30061L ^ -3567326666826560395L;
                        continue block23;
                    }
                }
                break;
            }
            v10[v11] = endMs;
            while (true) {
                if ((v14 = (cfr_temp_5 = MapCycleStatusBuilder.\u13e8 - (28305L ^ -7499617748559148772L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                if (v14 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v14 = 29603 ^ 1765360804;
            }
            v15 = String.format(v9, v10);
            while (true) {
                if ((v16 = (cfr_temp_6 = MapCycleStatusBuilder.\u13e8 - (10241L ^ -1784605207239006750L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                if (v16 == (6223 ^ -6224)) {
                    this.statusMsgs.add(v15);
                    break;
                }
                v16 = 2772 ^ 1663498012;
            }
        }
        return this;
    }

    /*
     * Unable to fully structure code
     */
    public MapCycleStatusBuilder withAwaitingRevive() {
        block23: {
            v0 = MapCycleStatusBuilder.\u13e8;
            if (true) ** GOTO lbl5
            block16: while (true) {
                v0 = v1 / (3625L ^ 3650002563428496762L);
lbl5:
                // 2 sources

                switch ((int)v0) {
                    case -1036141255: {
                        v1 = 29435L ^ -4022783639116258118L;
                        continue block16;
                    }
                    case -300034143: {
                        break block16;
                    }
                    case -106950851: {
                        v1 = 815L ^ 6498326511869862557L;
                        continue block16;
                    }
                    case 1988236574: {
                        v1 = 30921L ^ 8851355797556204812L;
                        continue block16;
                    }
                }
                break;
            }
            v2 = MapCycleStatusBuilder.\u13e8;
            if (true) ** GOTO lbl21
            block17: while (true) {
                v2 = (24524L ^ -4317793859708523418L) / (5758L ^ 9011560032445717793L);
lbl21:
                // 2 sources

                switch ((int)v2) {
                    case -300034143: {
                        break block17;
                    }
                    case 1567017153: {
                        continue block17;
                    }
                }
                break;
            }
            v3 = this.module.getAwaitingRevive();
            while (true) {
                if ((v4 = (cfr_temp_0 = MapCycleStatusBuilder.\u13e8 - (10397L ^ -4619265088410690213L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (v4 == (5827 ^ -5828)) break;
                v4 = 12733 ^ -358539986;
            }
            if (!v3.booleanValue()) break block23;
            while (true) {
                if ((v5 = (cfr_temp_1 = MapCycleStatusBuilder.\u13e8 - (25042L ^ -6226417637097053281L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (v5 == (21289 ^ -21290)) break;
                v5 = 14911 ^ -159989674;
            }
            var2_1 = new byte[13207 ^ 13189];
            var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
            var2_1[11563 ^ 11561] = 388 >>> "\u0000\u0000".length();
            var2_1[14386 ^ 14371] = 184 >>> "\u0000\u0000".length();
            var2_1[26986 ^ 26978] = 128 >>> "\u0000\u0000".length();
            var2_1[1689 ^ 1689] = 24718 ^ 24783;
            var2_1[13556 ^ 13557] = 476 >>> "\u0000\u0000".length();
            var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 184 >>> "\u0000\u0000".length();
            var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 26949 ^ 26935;
            var2_1[14463 ^ 14451] = 1459 ^ 1498;
            var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 16236 ^ 16152;
            var2_1[10044 ^ 10028] = 184 >>> "\u0000\u0000".length();
            var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 9117 ^ 9204;
            var2_1[20320 ^ 20330] = 404 >>> "\u0000\u0000".length();
            var2_1[7974 ^ 7971] = 420 >>> "\u0000\u0000".length();
            var2_1[12048 ^ 12054] = 440 >>> "\u0000\u0000".length();
            var2_1[14372 ^ 14383] = 472 >>> "\u0000\u0000".length();
            var2_1[19353 ^ 19351] = 404 >>> "\u0000\u0000".length();
            var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 25196 ^ 25099;
            var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 472 >>> "\u0000\u0000".length();
            v6 = new String(var2_1);
            v7 = MapCycleStatusBuilder.\u13e8;
            if (true) ** GOTO lbl65
            block20: while (true) {
                v7 = v8 / (19682L ^ 4006188802704192185L);
lbl65:
                // 2 sources

                switch ((int)v7) {
                    case -1959852336: {
                        v8 = 27906L ^ -6277315406649902921L;
                        continue block20;
                    }
                    case -1815224285: {
                        v8 = 13938L ^ -684117150874663077L;
                        continue block20;
                    }
                    case -1791209539: {
                        v8 = 26160L ^ -3148776423445773858L;
                        continue block20;
                    }
                    case -300034143: {
                        break block20;
                    }
                }
                break;
            }
            this.statusMsgs.add(v6);
        }
        return this;
    }

    /*
     * Unable to fully structure code
     */
    public MapCycleStatusBuilder withSwitchingMaps() {
        block45: {
            v0 = MapCycleStatusBuilder.\u13e8;
            if (true) ** GOTO lbl5
            block31: while (true) {
                v0 = (6540L ^ -3147466466584585488L) / (8651L ^ -8353841529364642233L);
lbl5:
                // 2 sources

                switch ((int)v0) {
                    case -446231793: {
                        continue block31;
                    }
                    case -300034143: {
                        break block31;
                    }
                }
                break;
            }
            while (true) {
                if ((v1 = (cfr_temp_0 = MapCycleStatusBuilder.\u13e8 - (23634L ^ -1875532104085553831L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v1 == (20442 ^ -20443)) break;
                v1 = 13295 ^ 897343939;
            }
            heroMap = this.module.getCurrentHeroMap();
            v2 = MapCycleStatusBuilder.\u13e8;
            if (true) ** GOTO lbl20
            block33: while (true) {
                v2 = v3 / (17279L ^ -8107623515429762790L);
lbl20:
                // 2 sources

                switch ((int)v2) {
                    case -302988434: {
                        v3 = 24132L ^ -5565305897311107692L;
                        continue block33;
                    }
                    case -300034143: {
                        break block33;
                    }
                    case -172823395: {
                        v3 = 17079L ^ 4499261397499474494L;
                        continue block33;
                    }
                    case 1374385533: {
                        v3 = 3674L ^ -532862833395936995L;
                        continue block33;
                    }
                }
                break;
            }
            while (true) {
                if ((v4 = (cfr_temp_1 = MapCycleStatusBuilder.\u13e8 - (1944L ^ -9096975597879872726L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v4 == (23746 ^ 23747)) break;
                v4 = 24998 ^ 848963684;
            }
            generalBotWorkingMapId = this.module.getGeneralBotWorkingMapId();
            while (true) {
                if ((v5 = (cfr_temp_2 = MapCycleStatusBuilder.\u13e8 - (15993L ^ 8229210674064480212L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v5 == (14388 ^ -14389)) break;
                v5 = 19018 ^ 1855695562;
            }
            v6 = generalBotWorkingMapId;
            v7 = MapCycleStatusBuilder.\u13e8;
            if (true) ** GOTO lbl48
            block36: while (true) {
                v7 = v8 / (26090L ^ -6441297434247977914L);
lbl48:
                // 2 sources

                switch ((int)v7) {
                    case -1083412894: {
                        v8 = 30755L ^ -7188395340557872966L;
                        continue block36;
                    }
                    case -554507676: {
                        v8 = 12128L ^ -1979235000683257676L;
                        continue block36;
                    }
                    case -300034143: {
                        break block36;
                    }
                    case 360904253: {
                        v8 = 16892L ^ 5904143872365989898L;
                        continue block36;
                    }
                }
                break;
            }
            if (v6 == heroMap.id) break block45;
            while (true) {
                if ((v9 = (cfr_temp_3 = MapCycleStatusBuilder.\u13e8 - (8632L ^ -3763985463931118997L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v9 == (20089 ^ -20090)) break;
                v9 = 6258 ^ -1869308548;
            }
            currentMapName = heroMap.name;
            while (true) {
                if ((v10 = (cfr_temp_4 = MapCycleStatusBuilder.\u13e8 - (10136L ^ 2191932391246894409L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v10 == (8508 ^ -8509)) break;
                v10 = 11712 ^ 1429227318;
            }
            var5_4 = new byte[22502 ^ 22515];
            var5_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 8299 ^ -8310;
            var5_4[595 ^ 603] = 16124 ^ 16029;
            var5_4[31161 ^ 31156] = 148 >>> "\u0000\u0000".length();
            var5_4[30334 ^ 30328] = 20135 ^ 20103;
            var5_4["".length() >>> "\u0000\u0000".length()] = 332 >>> "\u0000\u0000".length();
            var5_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 26682 ^ 26650;
            var5_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 460 >>> "\u0000\u0000".length();
            var5_4[29980 ^ 29979] = 26594 ^ 26511;
            var5_4[1985 ^ 1994] = 23970 ^ 23960;
            var5_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 420 >>> "\u0000\u0000".length();
            var5_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 29020 ^ 28980;
            var5_4[30227 ^ 30210] = 248 >>> "\u0000\u0000".length();
            var5_4[25933 ^ 25951] = 128 >>> "\u0000\u0000".length();
            var5_4[24665 ^ 24663] = 14502 ^ 14549;
            var5_4[3914 ^ 3929] = 148 >>> "\u0000\u0000".length();
            var5_4[15844 ^ 15854] = 7569 ^ 7650;
            var5_4[20193 ^ 20197] = 28592 ^ 28627;
            var5_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 180 >>> "\u0000\u0000".length();
            var5_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 26103 ^ 25991;
            var5_4[6942 ^ 6943] = 23339 ^ 23388;
            var5_4[22102 ^ 22101] = 5906 ^ 5990;
            var5_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 128 >>> "\u0000\u0000".length();
            v11 = new String(var5_4);
            v12 = new Object[23956 ^ 23958];
            v12["".length() >>> "\u0000\u0000".length()] = currentMapName;
            v13 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
            while (true) {
                if ((v14 = (cfr_temp_5 = MapCycleStatusBuilder.\u13e8 - (18720L ^ -2802751290452245467L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                if (v14 == (23655 ^ -23656)) break;
                v14 = 30991 ^ -121213256;
            }
            v15 = MapCycleStatusBuilder.\u13e8;
            if (true) ** GOTO lbl108
            block40: while (true) {
                v15 = v16 / (29846L ^ -2915578315722763411L);
lbl108:
                // 2 sources

                switch ((int)v15) {
                    case -2100573623: {
                        v16 = -6025648616508345392L >>> "\u0000\u0000".length();
                        continue block40;
                    }
                    case -632892480: {
                        v16 = 6032L ^ 5675747961401679196L;
                        continue block40;
                    }
                    case -300034143: {
                        break block40;
                    }
                }
                break;
            }
            v17 = generalBotWorkingMapId;
            v18 = MapCycleStatusBuilder.\u13e8;
            if (true) ** GOTO lbl122
            block41: while (true) {
                v18 = v19 / (21266L ^ -8478513147173468187L);
lbl122:
                // 2 sources

                switch ((int)v18) {
                    case -1738334887: {
                        v19 = 2926L ^ 5679359133117909842L;
                        continue block41;
                    }
                    case -1501265966: {
                        v19 = 28403L ^ -6568312199920197204L;
                        continue block41;
                    }
                    case -300034143: {
                        break block41;
                    }
                }
                break;
            }
            v12[v13] = this.module.getMapName(v17);
            v20 = MapCycleStatusBuilder.\u13e8;
            if (true) ** GOTO lbl136
            block42: while (true) {
                v20 = v21 / (1224L ^ -6694148970536538420L);
lbl136:
                // 2 sources

                switch ((int)v20) {
                    case -2107171550: {
                        v21 = 4096L ^ 2824722576076450486L;
                        continue block42;
                    }
                    case -300034143: {
                        break block42;
                    }
                    case -208978541: {
                        v21 = 26536L ^ 8810087731261028140L;
                        continue block42;
                    }
                }
                break;
            }
            v22 = String.format(v11, v12);
            while (true) {
                if ((v23 = (cfr_temp_6 = MapCycleStatusBuilder.\u13e8 - (226L ^ 2634000859479642463L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                if (v23 == (5742 ^ -5743)) {
                    this.statusMsgs.add(v22);
                    break;
                }
                v23 = 7974 ^ -1206864288;
            }
        }
        return this;
    }

    /*
     * Unable to fully structure code
     */
    public MapCycleStatusBuilder withFallback() {
        while (true) {
            if ((v0 = (cfr_temp_0 = MapCycleStatusBuilder.\u13e8 - (18994L ^ -7903631834329073045L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v0 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v0 = 22437 ^ -1314883742;
        }
        while (true) {
            if ((v1 = (cfr_temp_1 = MapCycleStatusBuilder.\u13e8 - (16540L ^ 2941530883871109420L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v1 == (7661 ^ -7662)) break;
            v1 = 7376 ^ 1317243720;
        }
        v2 = MapCycleStatusBuilder.\u13e8;
        if (true) ** GOTO lbl17
        block11: while (true) {
            v2 = v3 / (23697L ^ -5417334283089336409L);
lbl17:
            // 2 sources

            switch ((int)v2) {
                case -300034143: {
                    break block11;
                }
                case 692274817: {
                    v3 = -9211460612481044328L >>> "\u0000\u0000".length();
                    continue block11;
                }
                case 2112585766: {
                    v3 = 4274L ^ 7316536242800166803L;
                    continue block11;
                }
            }
            break;
        }
        v4 = this.module.getFallbackStatusMsg();
        v5 = MapCycleStatusBuilder.\u13e8;
        if (true) ** GOTO lbl31
        block12: while (true) {
            v5 = (19164L ^ -6590076900439997884L) / (4384L ^ 8764092612810001405L);
lbl31:
            // 2 sources

            switch ((int)v5) {
                case -300034143: {
                    break block12;
                }
                case -86453252: {
                    continue block12;
                }
            }
            break;
        }
        this.statusMsgs.add(v4);
        return this;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public String build() {
        byte[] byArray = new byte[0x372F ^ 0x372C];
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x1A4B ^ 0xFFFFE5AE;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x699A ^ 0x69BA;
        byArray[0x5D8C ^ 0x5D8C] = 0x4EB8 ^ 0x4E98;
        byArray[0x65CE ^ 0x65CF] = 496 >>> "\u0000\u0000".length();
        String string = new String(byArray);
        long l = \u13e8;
        boolean bl = true;
        block5: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x46E7L ^ 0x601841A0A7F21924L);
            }
            switch ((int)l) {
                case -1099003154: {
                    l2 = 0x6739L ^ 0x65C60EDAA2FA3511L;
                    continue block5;
                }
                case -840434201: {
                    l2 = 4803018387986136592L >>> "\u0000\u0000".length();
                    continue block5;
                }
                case -300034143: {
                    break block5;
                }
            }
            break;
        }
        while (true) {
            long l3;
            long l4;
            if ((l4 = (l3 = \u13e8 - (0x347FL ^ 0x7B6625B0762EAB8AL)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l4 == (0x4F3E ^ 0xFFFFB0C1)) {
                return String.join((CharSequence)string, this.statusMsgs);
            }
            l4 = 0x446A ^ 0x3226A847;
        }
    }
}

