/*
 * Decompiled with CFR 0.152.
 */
package com.tawaret.tawaplugin.features.mapcyclemodule.statusProviders;

import com.tawaret.tawaplugin.features.mapcyclemodule.IMapCycleModule;
import com.tawaret.tawaplugin.features.mapcyclemodule.statusProviders.MapCycleStatusBuilder;
import com.tawaret.tawaplugin.utils.StatusProviders.IStatusProvider;

public class MapCycleStatusProvider
implements IStatusProvider<IMapCycleModule> {
    protected static long \u13e8 = 7504004811290527895L;

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public MapCycleStatusProvider() {
        long l = \u13e8;
        boolean bl = true;
        block5: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x46FCL ^ 0x7B421C27B3A97FD3L);
            }
            switch ((int)l) {
                case -478384734: {
                    l2 = 0x3B51L ^ 0xBB7BA168BD28A465L;
                    continue block5;
                }
                case 835405975: {
                    break block5;
                }
                case 1465920985: {
                    l2 = 0x7B3DL ^ 0xF8D0D4CCE80F781EL;
                    continue block5;
                }
            }
            break;
        }
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public String getStatusMsg(IMapCycleModule module) {
        while (true) {
            if ((v0 = (cfr_temp_0 = MapCycleStatusProvider.\u13e8 - (15332L ^ -7015472790324783784L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (15648 ^ 15649)) break;
            v0 = 15193 ^ -1284034474;
        }
        while (true) {
            if ((v1 = (cfr_temp_1 = MapCycleStatusProvider.\u13e8 - (17142L ^ -1717466970849979346L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v1 == (27818 ^ 27819)) break;
            v1 = 25988 ^ -1085411081;
        }
        v2 = new MapCycleStatusBuilder(module);
        v3 = MapCycleStatusProvider.\u13e8;
        if (true) ** GOTO lbl16
        block27: while (true) {
            v3 = v4 / (8860L ^ -8281918726129342886L);
lbl16:
            // 2 sources

            switch ((int)v3) {
                case -1208034832: {
                    v4 = 26351L ^ -5414769491795714544L;
                    continue block27;
                }
                case -576393730: {
                    v4 = -637887563388217232L >>> "\u0000\u0000".length();
                    continue block27;
                }
                case 69829296: {
                    v4 = 5014L ^ -9100981551541233874L;
                    continue block27;
                }
                case 835405975: {
                    break block27;
                }
            }
            break;
        }
        v5 = v2.withNumBoxesInSight();
        v6 = MapCycleStatusProvider.\u13e8;
        if (true) ** GOTO lbl33
        block28: while (true) {
            v6 = v7 / (9843L ^ -2089800021954072619L);
lbl33:
            // 2 sources

            switch ((int)v6) {
                case -1963163576: {
                    v7 = 8189L ^ 1073823235209164161L;
                    continue block28;
                }
                case -1854793069: {
                    v7 = 3994357305476789384L >>> "\u0000\u0000".length();
                    continue block28;
                }
                case 835405975: {
                    break block28;
                }
            }
            break;
        }
        v8 = v5.withNpcWillSpawnInSeconds();
        while (true) {
            if ((v9 = (cfr_temp_2 = MapCycleStatusProvider.\u13e8 - (18010L ^ 9170287270331817731L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v9 == (29692 ^ -29693)) break;
            v9 = 20581 ^ 2065637708;
        }
        v10 = v8.withExcessPredictedSpawnSeconds();
        v11 = MapCycleStatusProvider.\u13e8;
        if (true) ** GOTO lbl53
        block30: while (true) {
            v11 = v12 / (3687L ^ 901304090768512295L);
lbl53:
            // 2 sources

            switch ((int)v11) {
                case -2077096892: {
                    v12 = 7602L ^ -2619282791527521245L;
                    continue block30;
                }
                case -234563015: {
                    v12 = 8179L ^ 4255878593290785747L;
                    continue block30;
                }
                case 835405975: {
                    break block30;
                }
            }
            break;
        }
        v13 = v10.withSwitchingMaps();
        while (true) {
            if ((v14 = (cfr_temp_3 = MapCycleStatusProvider.\u13e8 - (19817L ^ 6076041317797293776L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v14 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v14 = 8718 ^ 654639779;
        }
        v15 = v13.withWaitTillKflSeconds();
        while (true) {
            if ((v16 = (cfr_temp_4 = MapCycleStatusProvider.\u13e8 - (21166L ^ -313905394900572963L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v16 == (27230 ^ 27231)) break;
            v16 = 5118 ^ -815679924;
        }
        v17 = v15.withWaitTillNextMapSeconds();
        while (true) {
            if ((v18 = (cfr_temp_5 = MapCycleStatusProvider.\u13e8 - (2580L ^ -3599186993413182175L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
            if (v18 == (25045 ^ 25044)) break;
            v18 = 11185 ^ 661831825;
        }
        v19 = v17.withAwaitingRevive();
        v20 = MapCycleStatusProvider.\u13e8;
        if (true) ** GOTO lbl85
        block34: while (true) {
            v20 = v21 / (322070082387296480L >>> "\u0000\u0000".length());
lbl85:
            // 2 sources

            switch ((int)v20) {
                case -1316188324: {
                    v21 = 10929L ^ 9209365806532662728L;
                    continue block34;
                }
                case -1077474766: {
                    v21 = 328777101042540064L >>> "\u0000\u0000".length();
                    continue block34;
                }
                case 835405975: {
                    break block34;
                }
            }
            break;
        }
        v22 = v19.withFallback();
        v23 = MapCycleStatusProvider.\u13e8;
        if (true) ** GOTO lbl99
        block35: while (true) {
            v23 = (16504L ^ 7123765966492393157L) / (168L ^ 4876047168609205846L);
lbl99:
            // 2 sources

            switch ((int)v23) {
                case -1299011760: {
                    continue block35;
                }
                case 835405975: {
                    break block35;
                }
            }
            break;
        }
        return v22.build();
    }
}

