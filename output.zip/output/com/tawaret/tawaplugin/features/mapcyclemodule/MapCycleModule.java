/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.Main
 *  com.github.manolo8.darkbot.backpage.BackpageManager
 *  com.github.manolo8.darkbot.config.BoxInfo
 *  com.github.manolo8.darkbot.config.Config
 *  com.github.manolo8.darkbot.config.Config$Collect
 *  com.github.manolo8.darkbot.config.Config$ShipConfig
 *  com.github.manolo8.darkbot.config.NpcExtra
 *  com.github.manolo8.darkbot.config.NpcExtraFlag
 *  com.github.manolo8.darkbot.config.types.suppliers.PetGearSupplier$Gears
 *  com.github.manolo8.darkbot.core.entities.Box
 *  com.github.manolo8.darkbot.core.entities.Entity
 *  com.github.manolo8.darkbot.core.itf.Configurable
 *  com.github.manolo8.darkbot.core.itf.Module
 *  com.github.manolo8.darkbot.core.itf.Task
 *  com.github.manolo8.darkbot.core.manager.GroupManager
 *  com.github.manolo8.darkbot.core.manager.GuiManager
 *  com.github.manolo8.darkbot.core.manager.HeroManager
 *  com.github.manolo8.darkbot.core.manager.MapManager
 *  com.github.manolo8.darkbot.core.manager.PetManager
 *  com.github.manolo8.darkbot.core.manager.StarManager
 *  com.github.manolo8.darkbot.core.objects.Health
 *  com.github.manolo8.darkbot.core.objects.Map
 *  com.github.manolo8.darkbot.core.utils.Drive
 *  com.github.manolo8.darkbot.core.utils.Location
 *  com.github.manolo8.darkbot.extensions.features.Feature
 *  com.github.manolo8.darkbot.modules.CollectorModule
 *  com.github.manolo8.darkbot.modules.DisconnectModule
 *  com.github.manolo8.darkbot.modules.utils.SafetyFinder
 *  com.github.manolo8.darkbot.utils.AuthAPI
 *  eu.darkbot.api.PluginAPI
 *  eu.darkbot.api.extensions.ExtraMenus
 *  eu.darkbot.api.managers.ConfigAPI
 *  eu.darkbot.api.managers.EventBrokerAPI
 */
package com.tawaret.tawaplugin.features.mapcyclemodule;

import com.github.manolo8.darkbot.Main;
import com.github.manolo8.darkbot.backpage.BackpageManager;
import com.github.manolo8.darkbot.config.BoxInfo;
import com.github.manolo8.darkbot.config.Config;
import com.github.manolo8.darkbot.config.NpcExtra;
import com.github.manolo8.darkbot.config.NpcExtraFlag;
import com.github.manolo8.darkbot.config.types.suppliers.PetGearSupplier;
import com.github.manolo8.darkbot.core.entities.Box;
import com.github.manolo8.darkbot.core.entities.Entity;
import com.github.manolo8.darkbot.core.itf.Configurable;
import com.github.manolo8.darkbot.core.itf.Module;
import com.github.manolo8.darkbot.core.itf.Task;
import com.github.manolo8.darkbot.core.manager.GroupManager;
import com.github.manolo8.darkbot.core.manager.GuiManager;
import com.github.manolo8.darkbot.core.manager.HeroManager;
import com.github.manolo8.darkbot.core.manager.MapManager;
import com.github.manolo8.darkbot.core.manager.PetManager;
import com.github.manolo8.darkbot.core.manager.StarManager;
import com.github.manolo8.darkbot.core.objects.Health;
import com.github.manolo8.darkbot.core.utils.Drive;
import com.github.manolo8.darkbot.core.utils.Location;
import com.github.manolo8.darkbot.extensions.features.Feature;
import com.github.manolo8.darkbot.modules.CollectorModule;
import com.github.manolo8.darkbot.modules.DisconnectModule;
import com.github.manolo8.darkbot.modules.utils.SafetyFinder;
import com.github.manolo8.darkbot.utils.AuthAPI;
import com.tawaret.tawaplugin.features.bettermodules.TwLootModule;
import com.tawaret.tawaplugin.features.bettermodules.TwLootModuleConfig;
import com.tawaret.tawaplugin.features.bettermodules.TwLootNCollectModule;
import com.tawaret.tawaplugin.features.mapcyclemodule.IMapCycleModule;
import com.tawaret.tawaplugin.features.mapcyclemodule.MapCycleModuleConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.AdaptiveChecksConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.AfterKillConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.ExtraSecondsOnRefreshableMapsConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.GroupConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.KeyFirstLockConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.MapCycleBoxCollectConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.MapCyclePetConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.MapCycleRefreshConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.MapCycleSafetyConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.MiscellaneousConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.NpcRewardConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.PredictNpcSpawnConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.ServerRestartHandlerConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.TempExtraWaitSecondsConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.conditionconfigs.DeathCountConditionConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.conditionconfigs.LoglineSubstringConditionConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.conditionconfigs.MapChangeConditionConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.conditionconfigs.NpcSubnameConditionConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.logging.UserLogs;
import com.tawaret.tawaplugin.features.mapcyclemodule.models.DeathsOnMapPairFactory;
import com.tawaret.tawaplugin.features.mapcyclemodule.models.IDeathsOnMapPair;
import com.tawaret.tawaplugin.features.mapcyclemodule.models.MapInfo;
import com.tawaret.tawaplugin.features.mapcyclemodule.states.ShootingBeheState;
import com.tawaret.tawaplugin.features.mapcyclemodule.statusProviders.MapCycleStatusProvider;
import com.tawaret.tawaplugin.features.mapcyclemodule.statusProviders.MapCycleStoppedStatusProvider;
import com.tawaret.tawaplugin.features.maptravellers.pathfinders.PersistantStoragePathFinder;
import com.tawaret.tawaplugin.logging.ILoggable;
import com.tawaret.tawaplugin.services.licenseVerifiers.ITwLicenseVerifier;
import com.tawaret.tawaplugin.services.licenseVerifiers.LicenseData;
import com.tawaret.tawaplugin.services.licenseVerifiers.TwLicenseVerifierFactory;
import com.tawaret.tawaplugin.utils.Api.ApiExtensions;
import com.tawaret.tawaplugin.utils.Backpage.DoShop;
import com.tawaret.tawaplugin.utils.ExtraMenuExtensions;
import com.tawaret.tawaplugin.utils.GroupManager.GroupManagerExtensions;
import com.tawaret.tawaplugin.utils.ScheduledActionManager.IAction;
import com.tawaret.tawaplugin.utils.ScheduledActionManager.ScheduledActionManager;
import com.tawaret.tawaplugin.utils.StatusProviders.IStatusProvider;
import com.tawaret.tawaplugin.utils.hero.HeroExtensions;
import com.tawaret.tawaplugin.utils.logReaders.FlashLogReader;
import com.tawaret.tawaplugin.utils.logReaders.ILogsReader;
import com.tawaret.tawaplugin.utils.mapmanager.MapManagerExtensions;
import eu.darkbot.api.PluginAPI;
import eu.darkbot.api.extensions.ExtraMenus;
import eu.darkbot.api.managers.ConfigAPI;
import eu.darkbot.api.managers.EventBrokerAPI;
import java.lang.invoke.LambdaMetafactory;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.swing.JComponent;
import javax.swing.JLabel;

@Feature(name="Map Cycle", description="Cycles through a list of maps conditionally (Requires license)", enabledByDefault=false)
public class MapCycleModule
implements Configurable<MapCycleModuleConfig>,
ILoggable,
IMapCycleModule,
Task,
ExtraMenus {
    private final IStatusProvider<IMapCycleModule> stoppedStatusProvider;
    private final ScheduledActionManager scheduledActionManager;
    private final ConfigAPI configAPI;
    private final EventBrokerAPI eventBrokerAPI;
    private MapCycleModuleConfig mapCycleConfig;
    private DeathCountConditionConfig deathCountConditionConfig;
    private LoglineSubstringConditionConfig loglineSubstringConditionConfig;
    private NpcSubnameConditionConfig npcSubnameConditionConfig;
    private AdaptiveChecksConfig adaptiveChecksConfig;
    private AfterKillConfig afterKillConfig;
    private ExtraSecondsOnRefreshableMapsConfig extraSecondsOnRefreshableMapsConfig;
    private KeyFirstLockConfig keyFirstLockConfig;
    private MapCycleBoxCollectConfig mapCycleBoxCollectConfig;
    private MapCyclePetConfig mapCyclePetConfig;
    private MapCycleRefreshConfig mapCycleRefreshConfig;
    private MapCycleSafetyConfig mapCycleSafetyConfig;
    private MiscellaneousConfig miscellaneousConfig;
    private NpcRewardConfig npcRewardConfig;
    private PredictNpcSpawnConfig predictNpcSpawnConfig;
    private ServerRestartHandlerConfig serverRestartHandlerConfig;
    private TempExtraWaitSecondsConfig tempExtraWaitSecondsConfig;
    private Main main;
    private int lastKnownDeaths;
    private boolean awaitingRevive;
    private final TwLootNCollectModule twLootNCollectModule;
    private final TwLootModule lootModule;
    private final CollectorModule collectorModule;
    private Long npcKilledTimeStampMs;
    private final String BEHE_BOX_NAME;
    private Integer nextMapIdAfterWaitKillPeriod;
    private final IDeathsOnMapPair deathsOnCurrentMap;
    private Config mainConfig;
    private GroupManager groupManager;
    private HeroManager hero;
    private Drive drive;
    private PetManager pet;
    private ILogsReader unseenLogsReader;
    private final IStatusProvider<IMapCycleModule> statusProvider;
    private final ITwLicenseVerifier licenseVerifier;
    private MapChangeConditionConfig mapchangeConditionConfig;
    private SafetyFinder safety;
    private final ShootingBeheState shootingBeheState;
    private GroupConfig groupConfig;
    private TwLootModuleConfig betterLootModuleConfig;
    private MapManager mapManager;
    private List<Integer> cachedGetAllRefreshableMapIds;
    private long cacheExpiresGetAllRefreshableMapIdsStartMilis;
    private boolean requiresChangeToRefreshConfig;
    private boolean startedHandlerAfterServerRestart;
    private Boolean decrementWaitTicksOnRefreshableMap;
    private Boolean oldPredictNpcSpawnMapChangeCondConfigEnableState;
    private boolean sentPetGuardModeKey;
    private boolean initiatedGuard;
    private List<Integer> cachedPrioritySortedCycleWorkMapIds;
    private long cachedPrioritySortedCycleWorkMapIdsStartMS;
    private boolean inDiamondMode;
    private long collectorConfigFormationKeyPressMs;
    private long instaShieldKeyStartMs;
    private long safetyKeyStartMS;
    private long waitingForSafetyCloakStartMs;
    private long lastIsUnsafeCheckMs;
    private boolean cachedIsUnsafe;
    private long safenessOfAreaCheckStartMs;
    private boolean pressedKeyOnPredictedSpawnPeriodStart;
    private long moveToNpcSubnameStartMs;
    private boolean pressedKeyNpcBelowHp;
    private long lastStationaryRandomRoamMs;
    private long outsideAnchorCheckStartMilis;
    private long keepShipInpreferedRegionStartMilis;
    private static final int GAME_TO_MINIMAP_COORDS_MULTIPLIER = 100;
    private long onlyShootDuringWaitTicksPeriodStartMilis;
    private boolean onlyShootDuringWaitPeriod_cachedRet;
    private final HashMap<Integer, Long> mapIdToSubnameKillStartMS;
    private int cachedNextWorkMapId;
    private final HashMap<Integer, Long> mapIdToTickCountBucket;
    private boolean preventTimeSpentUpdates;
    private Map.Entry<Integer, Long> cachedLongestTimeSpentEntry;
    private Integer longestWaitCycleMapId;
    private Long adaptiveCheckStartTimestampMs;
    private Long timeSpentOnMapUpdateStartMs;
    private boolean __cachedHasLicense;
    private long lastUpdateLicenseStatusLabel;
    private long lastUpdateLicenseDisplayLabel;
    private final JLabel twLicenseStatusLabel;
    private final JLabel twLicenseLabel;
    private static long \u13e8 = -3025956135386871612L;

    /*
     * Unable to fully structure code
     */
    public MapCycleModule(ConfigAPI configAPI, EventBrokerAPI eventBrokerAPI) {
        while (true) {
            if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (7969895966596337740L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (10907 ^ -10908)) break;
            v0 = 24515 ^ -438179697;
        }
        super();
        while (true) {
            if ((v1 = (cfr_temp_1 = MapCycleModule.\u13e8 - (29201L ^ 7869520817229258791L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v1 == (4901 ^ -4902)) break;
            v1 = 521731920 >>> "\u0000\u0000".length();
        }
        this.main = null;
        v2 = "".length() >>> "\u0000\u0000".length();
        while (true) {
            if ((v3 = (cfr_temp_2 = MapCycleModule.\u13e8 - (21569L ^ -6164943990505526423L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v3 == (17458 ^ 17459)) break;
            v3 = 31204 ^ -1713616839;
        }
        this.lastKnownDeaths = v2;
        v4 = "".length() >>> "\u0000\u0000".length();
        while (true) {
            if ((v5 = (cfr_temp_3 = MapCycleModule.\u13e8 - (12774L ^ -1523154539168559519L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v5 == (27831 ^ -27832)) break;
            v5 = -824249688 >>> "\u0000\u0000".length();
        }
        this.awaitingRevive = v4;
        while (true) {
            if ((v6 = (cfr_temp_4 = MapCycleModule.\u13e8 - (8914L ^ -7738213029002251349L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v6 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v6 = 25914 ^ 514940599;
        }
        this.nextMapIdAfterWaitKillPeriod = null;
        while (true) {
            if ((v7 = (cfr_temp_5 = MapCycleModule.\u13e8 - (4386814196323069812L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
            if (v7 == (12673 ^ -12674)) break;
            v7 = 16883 ^ -241007601;
        }
        this.cachedGetAllRefreshableMapIds = null;
        while (true) {
            if ((v8 = (cfr_temp_6 = MapCycleModule.\u13e8 - (17815L ^ -6231238971983167755L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
            if (v8 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v8 = 26136 ^ -574976896;
        }
        v9 = System.currentTimeMillis();
        v10 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl49
        block242: while (true) {
            v10 = v11 / (14852L ^ -873108638448633673L);
lbl49:
            // 2 sources

            switch ((int)v10) {
                case -2028141184: {
                    v11 = 25980L ^ 8386336295009148008L;
                    continue block242;
                }
                case 752734935: {
                    v11 = 5297L ^ 5901150458360976444L;
                    continue block242;
                }
                case 1415186628: {
                    break block242;
                }
            }
            break;
        }
        this.cacheExpiresGetAllRefreshableMapIdsStartMilis = v9;
        v12 = "".length() >>> "\u0000\u0000".length();
        v13 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl64
        block243: while (true) {
            v13 = v14 / (8319L ^ -1794565076309059588L);
lbl64:
            // 2 sources

            switch ((int)v13) {
                case -1568111291: {
                    v14 = 19715L ^ 5354649161102309775L;
                    continue block243;
                }
                case 635388035: {
                    v14 = 25204L ^ -9168916361066452842L;
                    continue block243;
                }
                case 1415186628: {
                    break block243;
                }
            }
            break;
        }
        this.requiresChangeToRefreshConfig = v12;
        v15 = "".length() >>> "\u0000\u0000".length();
        v16 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl79
        block244: while (true) {
            v16 = v17 / (14950L ^ 5067851282818877316L);
lbl79:
            // 2 sources

            switch ((int)v16) {
                case -1792770900: {
                    v17 = 21643L ^ -6671232781803994881L;
                    continue block244;
                }
                case -191943466: {
                    v17 = 28652L ^ -2722088579828203992L;
                    continue block244;
                }
                case 1415186628: {
                    break block244;
                }
            }
            break;
        }
        this.startedHandlerAfterServerRestart = v15;
        v18 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl93
        block245: while (true) {
            v18 = v19 / (18646L ^ -1465656825225155146L);
lbl93:
            // 2 sources

            switch ((int)v18) {
                case -1993530135: {
                    v19 = 18296L ^ 9176587933948409609L;
                    continue block245;
                }
                case -862232537: {
                    v19 = 25801L ^ -1011233864031412804L;
                    continue block245;
                }
                case 1415186628: {
                    break block245;
                }
            }
            break;
        }
        this.decrementWaitTicksOnRefreshableMap = null;
        v20 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl107
        block246: while (true) {
            v20 = v21 / (18557L ^ 3503340962072185158L);
lbl107:
            // 2 sources

            switch ((int)v20) {
                case -1359339194: {
                    v21 = 3341L ^ 5637136666711007346L;
                    continue block246;
                }
                case -948129021: {
                    v21 = 26269L ^ 6854524083132570019L;
                    continue block246;
                }
                case 1415186628: {
                    break block246;
                }
            }
            break;
        }
        this.oldPredictNpcSpawnMapChangeCondConfigEnableState = null;
        while (true) {
            if ((v22 = (cfr_temp_7 = MapCycleModule.\u13e8 - (22579L ^ -6907077127499481720L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
            if (v22 == (23918 ^ 23919)) break;
            v22 = 4731 ^ -806572425;
        }
        this.sentPetGuardModeKey = 29042 ^ 29042;
        while (true) {
            if ((v23 = (cfr_temp_8 = MapCycleModule.\u13e8 - (3640L ^ -8890675910225744853L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
            if (v23 == (16870 ^ 16871)) break;
            v23 = 27584 ^ -1513261269;
        }
        this.initiatedGuard = 18368 ^ 18368;
        v24 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl133
        block249: while (true) {
            v24 = v25 / (19888L ^ 6618740423558861535L);
lbl133:
            // 2 sources

            switch ((int)v24) {
                case -2036409292: {
                    v25 = -4125028549619486508L >>> "\u0000\u0000".length();
                    continue block249;
                }
                case 741581776: {
                    v25 = 20826L ^ 6541141816250065472L;
                    continue block249;
                }
                case 1415186628: {
                    break block249;
                }
            }
            break;
        }
        this.cachedPrioritySortedCycleWorkMapIds = null;
        while (true) {
            if ((v26 = (cfr_temp_9 = MapCycleModule.\u13e8 - (6449L ^ 5449272943518097362L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
            if (v26 == (27181 ^ -27182)) break;
            v26 = 14225 ^ -252893602;
        }
        v27 = System.currentTimeMillis();
        v28 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl153
        block251: while (true) {
            v28 = v29 / (31579L ^ -701159507571355526L);
lbl153:
            // 2 sources

            switch ((int)v28) {
                case -1196314769: {
                    v29 = 1902L ^ -5603068532897087684L;
                    continue block251;
                }
                case 402045088: {
                    v29 = 31382L ^ 5868354797855992512L;
                    continue block251;
                }
                case 1415186628: {
                    break block251;
                }
                case 1442566282: {
                    v29 = 17920L ^ -2648607643713503535L;
                    continue block251;
                }
            }
            break;
        }
        this.cachedPrioritySortedCycleWorkMapIdsStartMS = v27;
        v30 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl170
        block252: while (true) {
            v30 = (24771L ^ 3001075182771070845L) / (-5312863583563928688L >>> "\u0000\u0000".length());
lbl170:
            // 2 sources

            switch ((int)v30) {
                case 605031846: {
                    continue block252;
                }
                case 1415186628: {
                    break block252;
                }
            }
            break;
        }
        this.inDiamondMode = 23145 ^ 23145;
        v31 = 0L >>> "\u0000\u0000".length();
        v32 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl181
        block253: while (true) {
            v32 = v33 / (-6027065526143760924L >>> "\u0000\u0000".length());
lbl181:
            // 2 sources

            switch ((int)v32) {
                case -346465868: {
                    v33 = 21667L ^ -5921452014125587824L;
                    continue block253;
                }
                case 1415186628: {
                    break block253;
                }
                case 2130629842: {
                    v33 = -4819620914338042448L >>> "\u0000\u0000".length();
                    continue block253;
                }
            }
            break;
        }
        this.collectorConfigFormationKeyPressMs = v31;
        v34 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl195
        block254: while (true) {
            v34 = v35 / (7196L ^ 4749556092371245160L);
lbl195:
            // 2 sources

            switch ((int)v34) {
                case 122574679: {
                    v35 = 31483L ^ 8134300840591409684L;
                    continue block254;
                }
                case 832716867: {
                    v35 = 5674L ^ -5698076684532019340L;
                    continue block254;
                }
                case 1415186628: {
                    break block254;
                }
                case 1749549815: {
                    v35 = 17883L ^ -655729750577831577L;
                    continue block254;
                }
            }
            break;
        }
        v36 = System.currentTimeMillis();
        v37 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl212
        block255: while (true) {
            v37 = v38 / (15194L ^ 9087817883043351849L);
lbl212:
            // 2 sources

            switch ((int)v37) {
                case 406094875: {
                    v38 = 30077L ^ 8344656294319810674L;
                    continue block255;
                }
                case 680689474: {
                    v38 = 15667L ^ -1735940838643577556L;
                    continue block255;
                }
                case 1415186628: {
                    break block255;
                }
            }
            break;
        }
        this.instaShieldKeyStartMs = v36;
        v39 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl226
        block256: while (true) {
            v39 = v40 / (9498L ^ 5452537208572597142L);
lbl226:
            // 2 sources

            switch ((int)v39) {
                case -894775470: {
                    v40 = -7891256523250927164L >>> "\u0000\u0000".length();
                    continue block256;
                }
                case 43465669: {
                    v40 = 19291L ^ -9148330580772150577L;
                    continue block256;
                }
                case 578317481: {
                    v40 = 26556L ^ -7077920861968474846L;
                    continue block256;
                }
                case 1415186628: {
                    break block256;
                }
            }
            break;
        }
        v41 = System.currentTimeMillis();
        while (true) {
            if ((v42 = (cfr_temp_10 = MapCycleModule.\u13e8 - (11542L ^ -902282832509174156L)) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
            if (v42 == (16237 ^ -16238)) break;
            v42 = 622469316 >>> "\u0000\u0000".length();
        }
        this.safetyKeyStartMS = v41;
        while (true) {
            if ((v43 = (cfr_temp_11 = MapCycleModule.\u13e8 - (3304L ^ -548052608528839799L)) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
            if (v43 == (30714 ^ -30715)) break;
            v43 = 32311 ^ -1434958636;
        }
        v44 = System.currentTimeMillis();
        v45 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl255
        block259: while (true) {
            v45 = v46 / (14129L ^ -3665344140498402149L);
lbl255:
            // 2 sources

            switch ((int)v45) {
                case -389348328: {
                    v46 = 9885L ^ 5066771556803646624L;
                    continue block259;
                }
                case 89090355: {
                    v46 = 6529L ^ 2027241855376007607L;
                    continue block259;
                }
                case 1235746201: {
                    v46 = 16211L ^ -5775150357091789437L;
                    continue block259;
                }
                case 1415186628: {
                    break block259;
                }
            }
            break;
        }
        this.waitingForSafetyCloakStartMs = v44;
        v47 = 0L >>> "\u0000\u0000".length();
        while (true) {
            if ((v48 = (cfr_temp_12 = MapCycleModule.\u13e8 - (1848L ^ 3672117097548995733L)) == 0L ? 0 : (cfr_temp_12 < 0L ? -1 : 1)) == false) continue;
            if (v48 == (8598 ^ -8599)) break;
            v48 = 1536463112 >>> "\u0000\u0000".length();
        }
        this.lastIsUnsafeCheckMs = v47;
        while (true) {
            if ((v49 = (cfr_temp_13 = MapCycleModule.\u13e8 - (25357038162401824L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_13 < 0L ? -1 : 1)) == false) continue;
            if (v49 == (22821 ^ -22822)) break;
            v49 = 30378 ^ 1447405059;
        }
        this.cachedIsUnsafe = 23677 ^ 23677;
        v50 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl285
        block262: while (true) {
            v50 = (11504L ^ -3869879548224729070L) / (-3027838643398968212L >>> "\u0000\u0000".length());
lbl285:
            // 2 sources

            switch ((int)v50) {
                case -503552047: {
                    continue block262;
                }
                case 1415186628: {
                    break block262;
                }
            }
            break;
        }
        v51 = System.currentTimeMillis();
        v52 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl295
        block263: while (true) {
            v52 = v53 / (8135L ^ -5336527716467610973L);
lbl295:
            // 2 sources

            switch ((int)v52) {
                case -1174144911: {
                    v53 = 19510L ^ -5468549010768741405L;
                    continue block263;
                }
                case -910080568: {
                    v53 = 2018L ^ -2255881562483343038L;
                    continue block263;
                }
                case -350969082: {
                    v53 = 23939L ^ 4917628295390740773L;
                    continue block263;
                }
                case 1415186628: {
                    break block263;
                }
            }
            break;
        }
        this.safenessOfAreaCheckStartMs = v51;
        v54 = "".length() >>> "\u0000\u0000".length();
        v55 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl313
        block264: while (true) {
            v55 = (20771L ^ 7290856053400634889L) / (17498L ^ -664959107333758171L);
lbl313:
            // 2 sources

            switch ((int)v55) {
                case 813210458: {
                    continue block264;
                }
                case 1415186628: {
                    break block264;
                }
            }
            break;
        }
        this.pressedKeyOnPredictedSpawnPeriodStart = v54;
        v56 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl323
        block265: while (true) {
            v56 = v57 / (32501L ^ -1350909201964050727L);
lbl323:
            // 2 sources

            switch ((int)v56) {
                case -947844083: {
                    v57 = 1901L ^ -6060695399681283368L;
                    continue block265;
                }
                case -223894018: {
                    v57 = 26473L ^ -484704993838918807L;
                    continue block265;
                }
                case 1415186628: {
                    break block265;
                }
                case 1589523364: {
                    v57 = 9435L ^ -5861866506248561053L;
                    continue block265;
                }
            }
            break;
        }
        this.moveToNpcSubnameStartMs = 22986L ^ 22986L;
        v58 = "".length() >>> "\u0000\u0000".length();
        while (true) {
            if ((v59 = (cfr_temp_14 = MapCycleModule.\u13e8 - (13352L ^ -503305140500371115L)) == 0L ? 0 : (cfr_temp_14 < 0L ? -1 : 1)) == false) continue;
            if (v59 == (2606 ^ -2607)) break;
            v59 = 13430 ^ -450333972;
        }
        this.pressedKeyNpcBelowHp = v58;
        while (true) {
            if ((v60 = (cfr_temp_15 = MapCycleModule.\u13e8 - (31557L ^ 9109012570512798101L)) == 0L ? 0 : (cfr_temp_15 < 0L ? -1 : 1)) == false) continue;
            if (v60 == (24960 ^ -24961)) break;
            v60 = 5521 ^ 1928910044;
        }
        this.lastStationaryRandomRoamMs = 1112L ^ 1112L;
        v61 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl353
        block268: while (true) {
            v61 = (12810L ^ -8732073342580869267L) / (-2469004167986509724L >>> "\u0000\u0000".length());
lbl353:
            // 2 sources

            switch ((int)v61) {
                case 1039634011: {
                    continue block268;
                }
                case 1415186628: {
                    break block268;
                }
            }
            break;
        }
        v62 = System.currentTimeMillis();
        while (true) {
            if ((v63 = (cfr_temp_16 = MapCycleModule.\u13e8 - (17842L ^ 4713847624722408667L)) == 0L ? 0 : (cfr_temp_16 < 0L ? -1 : 1)) == false) continue;
            if (v63 == (11169 ^ -11170)) break;
            v63 = 28292 ^ -792720746;
        }
        this.outsideAnchorCheckStartMilis = v62;
        v64 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl369
        block270: while (true) {
            v64 = v65 / (29306L ^ -6662428665146769137L);
lbl369:
            // 2 sources

            switch ((int)v64) {
                case -1256888795: {
                    v65 = 8273L ^ 6533818444705555933L;
                    continue block270;
                }
                case 901307084: {
                    v65 = 438L ^ -1919854909335119727L;
                    continue block270;
                }
                case 1415186628: {
                    break block270;
                }
                case 2047899757: {
                    v65 = -8677299639913258284L >>> "\u0000\u0000".length();
                    continue block270;
                }
            }
            break;
        }
        v66 = System.currentTimeMillis();
        v67 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl386
        block271: while (true) {
            v67 = (24752L ^ -6113603060425793645L) / (19427L ^ 1972571828024397134L);
lbl386:
            // 2 sources

            switch ((int)v67) {
                case -495584502: {
                    continue block271;
                }
                case 1415186628: {
                    break block271;
                }
            }
            break;
        }
        this.keepShipInpreferedRegionStartMilis = v66;
        v68 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl396
        block272: while (true) {
            v68 = (25772L ^ -298827584666138360L) / (25195L ^ 2820456419539393136L);
lbl396:
            // 2 sources

            switch ((int)v68) {
                case 640527052: {
                    continue block272;
                }
                case 1415186628: {
                    break block272;
                }
            }
            break;
        }
        v69 = System.currentTimeMillis();
        while (true) {
            if ((v70 = (cfr_temp_17 = MapCycleModule.\u13e8 - (7392L ^ -1810651499536670980L)) == 0L ? 0 : (cfr_temp_17 < 0L ? -1 : 1)) == false) continue;
            if (v70 == (8031 ^ -8032)) break;
            v70 = 14246 ^ -1974968059;
        }
        this.onlyShootDuringWaitTicksPeriodStartMilis = v69;
        v71 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl412
        block274: while (true) {
            v71 = v72 / (2659L ^ 6079369856638535828L);
lbl412:
            // 2 sources

            switch ((int)v71) {
                case -1363445658: {
                    v72 = 14881L ^ -1518149321621765058L;
                    continue block274;
                }
                case -370082859: {
                    v72 = -2412664035123493192L >>> "\u0000\u0000".length();
                    continue block274;
                }
                case -174611403: {
                    v72 = 27674L ^ 2823718719337137872L;
                    continue block274;
                }
                case 1415186628: {
                    break block274;
                }
            }
            break;
        }
        this.onlyShootDuringWaitPeriod_cachedRet = 6403 ^ 6403;
        v73 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl429
        block275: while (true) {
            v73 = v74 / (18575L ^ 938691958981736583L);
lbl429:
            // 2 sources

            switch ((int)v73) {
                case -1469748189: {
                    v74 = 5020L ^ -8403320598610252518L;
                    continue block275;
                }
                case 1177819445: {
                    v74 = -5997970795586345884L >>> "\u0000\u0000".length();
                    continue block275;
                }
                case 1415186628: {
                    break block275;
                }
                case 1629821808: {
                    v74 = 31447L ^ -1156208173453183043L;
                    continue block275;
                }
            }
            break;
        }
        v75 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl445
        block276: while (true) {
            v75 = v76 / (26839L ^ -5337208383084720872L);
lbl445:
            // 2 sources

            switch ((int)v75) {
                case -1836396208: {
                    v76 = 12317L ^ -7360494479737014022L;
                    continue block276;
                }
                case 967022050: {
                    v76 = 6356L ^ -2981260332090435983L;
                    continue block276;
                }
                case 1403448862: {
                    v76 = -4135875906266129448L >>> "\u0000\u0000".length();
                    continue block276;
                }
                case 1415186628: {
                    break block276;
                }
            }
            break;
        }
        v77 = new HashMap<K, V>();
        while (true) {
            if ((v78 = (cfr_temp_18 = MapCycleModule.\u13e8 - (13659L ^ 4459883626532893472L)) == 0L ? 0 : (cfr_temp_18 < 0L ? -1 : 1)) == false) continue;
            if (v78 == (13894 ^ -13895)) break;
            v78 = 9868 ^ -362629779;
        }
        this.mapIdToSubnameKillStartMS = v77;
        while (true) {
            if ((v79 = (cfr_temp_19 = MapCycleModule.\u13e8 - (15925L ^ -3551287596232391272L)) == 0L ? 0 : (cfr_temp_19 < 0L ? -1 : 1)) == false) continue;
            if (v79 == (6547 ^ 6546)) break;
            v79 = 379645984 >>> "\u0000\u0000".length();
        }
        this.cachedNextWorkMapId = 7282 ^ -7283;
        while (true) {
            if ((v80 = (cfr_temp_20 = MapCycleModule.\u13e8 - (-6290173077002087040L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_20 < 0L ? -1 : 1)) == false) continue;
            if (v80 == (27155 ^ -27156)) break;
            v80 = 1298 ^ -123945331;
        }
        v81 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl479
        block280: while (true) {
            v81 = (16494L ^ 1065701852141488423L) / (1674794364126862776L >>> "\u0000\u0000".length());
lbl479:
            // 2 sources

            switch ((int)v81) {
                case -1962861759: {
                    continue block280;
                }
                case 1415186628: {
                    break block280;
                }
            }
            break;
        }
        v82 = new HashMap<K, V>();
        while (true) {
            if ((v83 = (cfr_temp_21 = MapCycleModule.\u13e8 - (9301L ^ -5562054177108424043L)) == 0L ? 0 : (cfr_temp_21 < 0L ? -1 : 1)) == false) continue;
            if (v83 == (3509 ^ 3508)) break;
            v83 = 11678 ^ 744789417;
        }
        this.mapIdToTickCountBucket = v82;
        v84 = "".length() >>> "\u0000\u0000".length();
        v85 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl496
        block282: while (true) {
            v85 = v86 / (27508L ^ -1523706745780255513L);
lbl496:
            // 2 sources

            switch ((int)v85) {
                case -1998515321: {
                    v86 = 19210L ^ -6753242514022919337L;
                    continue block282;
                }
                case -170383380: {
                    v86 = 28927L ^ -4552235974354781793L;
                    continue block282;
                }
                case 1415186628: {
                    break block282;
                }
            }
            break;
        }
        this.preventTimeSpentUpdates = v84;
        v87 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl510
        block283: while (true) {
            v87 = v88 / (-6251921775942339148L >>> "\u0000\u0000".length());
lbl510:
            // 2 sources

            switch ((int)v87) {
                case -1557234408: {
                    v88 = 9648L ^ 6102882067477831591L;
                    continue block283;
                }
                case -849713506: {
                    v88 = 6870327518679159072L >>> "\u0000\u0000".length();
                    continue block283;
                }
                case 1415186628: {
                    break block283;
                }
            }
            break;
        }
        this.cachedLongestTimeSpentEntry = null;
        while (true) {
            if ((v89 = (cfr_temp_22 = MapCycleModule.\u13e8 - (2387L ^ 8251244244405070924L)) == 0L ? 0 : (cfr_temp_22 < 0L ? -1 : 1)) == false) continue;
            if (v89 == (29595 ^ -29596)) break;
            v89 = 16741 ^ 313568622;
        }
        this.longestWaitCycleMapId = null;
        v90 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl530
        block285: while (true) {
            v90 = v91 / (2887L ^ -5374123036516280811L);
lbl530:
            // 2 sources

            switch ((int)v90) {
                case -2091038169: {
                    v91 = 15160L ^ -4570528106430676555L;
                    continue block285;
                }
                case 1415186628: {
                    break block285;
                }
                case 1697258189: {
                    v91 = 26785L ^ 9073722590161792189L;
                    continue block285;
                }
            }
            break;
        }
        this.adaptiveCheckStartTimestampMs = null;
        v92 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl544
        block286: while (true) {
            v92 = v93 / (16397L ^ -2226747246458036110L);
lbl544:
            // 2 sources

            switch ((int)v92) {
                case -913162596: {
                    v93 = 20821L ^ 583431509530683008L;
                    continue block286;
                }
                case -429895968: {
                    v93 = 22639L ^ -5870106869417324037L;
                    continue block286;
                }
                case 1415186628: {
                    break block286;
                }
            }
            break;
        }
        this.timeSpentOnMapUpdateStartMs = null;
        v94 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl558
        block287: while (true) {
            v94 = v95 / (6543L ^ 1539361521677941055L);
lbl558:
            // 2 sources

            switch ((int)v94) {
                case -567528228: {
                    v95 = 17054L ^ 3837168653605355116L;
                    continue block287;
                }
                case 1415186628: {
                    break block287;
                }
                case 1998228697: {
                    v95 = 2953L ^ -4803052047515657718L;
                    continue block287;
                }
            }
            break;
        }
        this.__cachedHasLicense = 12304 ^ 12304;
        v96 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl572
        block288: while (true) {
            v96 = (23610L ^ 8028603728625015264L) / (-990935278634024828L >>> "\u0000\u0000".length());
lbl572:
            // 2 sources

            switch ((int)v96) {
                case 1179572953: {
                    continue block288;
                }
                case 1415186628: {
                    break block288;
                }
            }
            break;
        }
        this.lastUpdateLicenseStatusLabel = 2743L ^ 2743L;
        v97 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl582
        block289: while (true) {
            v97 = v98 / (23596L ^ 2778430538853090914L);
lbl582:
            // 2 sources

            switch ((int)v97) {
                case -1014671747: {
                    v98 = 23388L ^ -3216647760755861913L;
                    continue block289;
                }
                case 642762041: {
                    v98 = 10703L ^ 7234213949540483720L;
                    continue block289;
                }
                case 1110251556: {
                    v98 = -6669744872528488136L >>> "\u0000\u0000".length();
                    continue block289;
                }
                case 1415186628: {
                    break block289;
                }
            }
            break;
        }
        this.lastUpdateLicenseDisplayLabel = 18258L ^ 18258L;
        while (true) {
            if ((v99 = (cfr_temp_23 = MapCycleModule.\u13e8 - (15967L ^ 5281931160117721442L)) == 0L ? 0 : (cfr_temp_23 < 0L ? -1 : 1)) == false) continue;
            if (v99 == (30124 ^ -30125)) break;
            v99 = 9245 ^ 1574415865;
        }
        while (true) {
            if ((v100 = (cfr_temp_24 = MapCycleModule.\u13e8 - (24389L ^ -6465913593546545892L)) == 0L ? 0 : (cfr_temp_24 < 0L ? -1 : 1)) == false) continue;
            if (v100 == (26773 ^ 26772)) break;
            v100 = 15999 ^ -182405467;
        }
        v101 = new JLabel();
        while (true) {
            if ((v102 = (cfr_temp_25 = MapCycleModule.\u13e8 - (-7976323889414151988L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_25 < 0L ? -1 : 1)) == false) continue;
            if (v102 == (1293 ^ -1294)) break;
            v102 = 15596 ^ -2146004933;
        }
        this.twLicenseStatusLabel = v101;
        while (true) {
            if ((v103 = (cfr_temp_26 = MapCycleModule.\u13e8 - (-5906705867022323896L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_26 < 0L ? -1 : 1)) == false) continue;
            if (v103 == (23570 ^ -23571)) break;
            v103 = 22144 ^ -571735742;
        }
        while (true) {
            if ((v104 = (cfr_temp_27 = MapCycleModule.\u13e8 - (9889L ^ -6318294399086141289L)) == 0L ? 0 : (cfr_temp_27 < 0L ? -1 : 1)) == false) continue;
            if (v104 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v104 = 22556 ^ 1825521481;
        }
        v105 = new JLabel();
        while (true) {
            if ((v106 = (cfr_temp_28 = MapCycleModule.\u13e8 - (32472L ^ 5148793636773387360L)) == 0L ? 0 : (cfr_temp_28 < 0L ? -1 : 1)) == false) continue;
            if (v106 == (27258 ^ -27259)) break;
            v106 = 15576 ^ -2100489156;
        }
        this.twLicenseLabel = v105;
        while (true) {
            if ((v107 = (cfr_temp_29 = MapCycleModule.\u13e8 - (9137L ^ -6665808232856040634L)) == 0L ? 0 : (cfr_temp_29 < 0L ? -1 : 1)) == false) continue;
            if (v107 == (19320 ^ 19321)) break;
            v107 = 21957 ^ 1291571654;
        }
        this.configAPI = configAPI;
        while (true) {
            if ((v108 = (cfr_temp_30 = MapCycleModule.\u13e8 - (12838L ^ -5151348140488075003L)) == 0L ? 0 : (cfr_temp_30 < 0L ? -1 : 1)) == false) continue;
            if (v108 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v108 = 25908 ^ 515135162;
        }
        this.eventBrokerAPI = eventBrokerAPI;
        v109 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl645
        block298: while (true) {
            v109 = v110 / (18599L ^ -5803583438004329129L);
lbl645:
            // 2 sources

            switch ((int)v109) {
                case 119751628: {
                    v110 = 29273L ^ -2729874695047530615L;
                    continue block298;
                }
                case 1015213062: {
                    v110 = 9069L ^ -4162657553894279450L;
                    continue block298;
                }
                case 1100934526: {
                    v110 = 3550042104979679712L >>> "\u0000\u0000".length();
                    continue block298;
                }
                case 1415186628: {
                    break block298;
                }
            }
            break;
        }
        while (true) {
            if ((v111 = (cfr_temp_31 = MapCycleModule.\u13e8 - (998L ^ -4728757241678848036L)) == 0L ? 0 : (cfr_temp_31 < 0L ? -1 : 1)) == false) continue;
            if (v111 == (24561 ^ 24560)) break;
            v111 = 9786 ^ -1398575729;
        }
        v112 = new MapCycleStoppedStatusProvider();
        v113 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl667
        block300: while (true) {
            v113 = v114 / (18474L ^ -3189725818198631760L);
lbl667:
            // 2 sources

            switch ((int)v113) {
                case 270909074: {
                    v114 = 16451L ^ -2741664209164779411L;
                    continue block300;
                }
                case 1415186628: {
                    break block300;
                }
                case 2065278175: {
                    v114 = 4587014567346126044L >>> "\u0000\u0000".length();
                    continue block300;
                }
            }
            break;
        }
        this.stoppedStatusProvider = v112;
        v115 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl681
        block301: while (true) {
            v115 = v116 / (5939L ^ 4833356201558262907L);
lbl681:
            // 2 sources

            switch ((int)v115) {
                case 36702549: {
                    v116 = 30891L ^ 8890903219532209633L;
                    continue block301;
                }
                case 287238215: {
                    v116 = 15886L ^ -5366717932168264336L;
                    continue block301;
                }
                case 1415186628: {
                    break block301;
                }
                case 2099690295: {
                    v116 = 30930L ^ -6069583241648810198L;
                    continue block301;
                }
            }
            break;
        }
        v117 = DeathsOnMapPairFactory.Initial();
        while (true) {
            if ((v118 = (cfr_temp_32 = MapCycleModule.\u13e8 - (2581L ^ 5858118134354639049L)) == 0L ? 0 : (cfr_temp_32 < 0L ? -1 : 1)) == false) continue;
            if (v118 == (29006 ^ -29007)) break;
            v118 = 347034340 >>> "\u0000\u0000".length();
        }
        this.deathsOnCurrentMap = v117;
        var4_3 = new byte["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
        var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 25157 ^ 25129;
        var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 8489 ^ 8545;
        var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 5240 ^ 5162;
        var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 304 >>> "\u0000\u0000".length();
        var4_3[187 ^ 179] = 260 >>> "\u0000\u0000".length();
        var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 19246 ^ 19309;
        var4_3[21426 ^ 21435] = 332 >>> "\u0000\u0000".length();
        var4_3[1266 ^ 1266] = 332 >>> "\u0000\u0000".length();
        var4_3[30327 ^ 30322] = 1852 ^ 1891;
        var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 28047 ^ 28099;
        var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 260 >>> "\u0000\u0000".length();
        var4_3["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 316 >>> "\u0000\u0000".length();
        v119 = new String(var4_3);
        while (true) {
            if ((v120 = (cfr_temp_33 = MapCycleModule.\u13e8 - (5378L ^ 5439287632921423182L)) == 0L ? 0 : (cfr_temp_33 < 0L ? -1 : 1)) == false) continue;
            if (v120 == (23764 ^ -23765)) break;
            v120 = 23032 ^ 1608820538;
        }
        this.BEHE_BOX_NAME = v119;
        while (true) {
            if ((v121 = (cfr_temp_34 = MapCycleModule.\u13e8 - (-449440429164672276L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_34 < 0L ? -1 : 1)) == false) continue;
            if (v121 == (11989 ^ -11990)) break;
            v121 = 23747 ^ -1842850140;
        }
        this.npcKilledTimeStampMs = null;
        v122 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl730
        block305: while (true) {
            v122 = v123 / (812L ^ -3551583196336646892L);
lbl730:
            // 2 sources

            switch ((int)v122) {
                case -2102612569: {
                    v123 = 11069L ^ 7943267153241933171L;
                    continue block305;
                }
                case -2092809125: {
                    v123 = 16778L ^ -185853981767996375L;
                    continue block305;
                }
                case -1011766335: {
                    v123 = 1037L ^ -3910689046480568832L;
                    continue block305;
                }
                case 1415186628: {
                    break block305;
                }
            }
            break;
        }
        while (true) {
            if ((v124 = (cfr_temp_35 = MapCycleModule.\u13e8 - (10578L ^ 5416433267512137016L)) == 0L ? 0 : (cfr_temp_35 < 0L ? -1 : 1)) == false) continue;
            if (v124 == (13913 ^ -13914)) break;
            v124 = 16639 ^ -1036825129;
        }
        v125 = new TwLootNCollectModule();
        while (true) {
            if ((v126 = (cfr_temp_36 = MapCycleModule.\u13e8 - (31028L ^ 3375046017940545510L)) == 0L ? 0 : (cfr_temp_36 < 0L ? -1 : 1)) == false) continue;
            if (v126 == (14648 ^ -14649)) break;
            v126 = 14309 ^ 1229244050;
        }
        this.twLootNCollectModule = v125;
        v127 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl758
        block308: while (true) {
            v127 = v128 / (31542L ^ -7724963939859211533L);
lbl758:
            // 2 sources

            switch ((int)v127) {
                case 100802564: {
                    v128 = 26138L ^ 5594296583448829497L;
                    continue block308;
                }
                case 1149117670: {
                    v128 = 17042L ^ -2287080941392623867L;
                    continue block308;
                }
                case 1415186628: {
                    break block308;
                }
                case 1835632001: {
                    v128 = -9043173776182048252L >>> "\u0000\u0000".length();
                    continue block308;
                }
            }
            break;
        }
        while (true) {
            if ((v129 = (cfr_temp_37 = MapCycleModule.\u13e8 - (28393L ^ 7229846936716277296L)) == 0L ? 0 : (cfr_temp_37 < 0L ? -1 : 1)) == false) continue;
            if (v129 == (1336 ^ -1337)) break;
            v129 = 5093 ^ -866827645;
        }
        v130 = this.twLootNCollectModule.lootModule;
        while (true) {
            if ((v131 = (cfr_temp_38 = MapCycleModule.\u13e8 - (6971L ^ -691288829442926787L)) == 0L ? 0 : (cfr_temp_38 < 0L ? -1 : 1)) == false) continue;
            if (v131 == (27134 ^ -27135)) break;
            v131 = 6484 ^ -891123328;
        }
        this.lootModule = v130;
        v132 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl786
        block311: while (true) {
            v132 = (8391051832500412512L >>> "\u0000\u0000".length()) / (2071L ^ 6265805915364401562L);
lbl786:
            // 2 sources

            switch ((int)v132) {
                case 364920163: {
                    continue block311;
                }
                case 1415186628: {
                    break block311;
                }
            }
            break;
        }
        v133 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl795
        block312: while (true) {
            v133 = (24683L ^ -6623299883998023623L) / (-434254369889954512L >>> "\u0000\u0000".length());
lbl795:
            // 2 sources

            switch ((int)v133) {
                case -1150256606: {
                    continue block312;
                }
                case 1415186628: {
                    break block312;
                }
            }
            break;
        }
        v134 = this.twLootNCollectModule.collectorModule;
        v135 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl805
        block313: while (true) {
            v135 = v136 / (15068L ^ -2360078836186668431L);
lbl805:
            // 2 sources

            switch ((int)v135) {
                case -1545221862: {
                    v136 = 25367L ^ -6495350136901330534L;
                    continue block313;
                }
                case 128932115: {
                    v136 = 2281L ^ -4409206422219685188L;
                    continue block313;
                }
                case 1415186628: {
                    break block313;
                }
            }
            break;
        }
        this.collectorModule = v134;
        v137 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl819
        block314: while (true) {
            v137 = v138 / (-2600289902998727744L >>> "\u0000\u0000".length());
lbl819:
            // 2 sources

            switch ((int)v137) {
                case -2131572948: {
                    v138 = 20496L ^ -3376381426551750233L;
                    continue block314;
                }
                case 1415186628: {
                    break block314;
                }
                case 1481112033: {
                    v138 = 14688L ^ 7230168172996295936L;
                    continue block314;
                }
            }
            break;
        }
        while (true) {
            if ((v139 = (cfr_temp_39 = MapCycleModule.\u13e8 - (806361908689768676L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_39 < 0L ? -1 : 1)) == false) continue;
            if (v139 == (7279 ^ -7280)) break;
            v139 = 29722 ^ 1144506089;
        }
        v140 = new MapCycleStatusProvider();
        v141 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl838
        block316: while (true) {
            v141 = v142 / (23752L ^ 4687517555604843626L);
lbl838:
            // 2 sources

            switch ((int)v141) {
                case -1472319398: {
                    v142 = 25100L ^ -4288139174428544831L;
                    continue block316;
                }
                case 760491254: {
                    v142 = 28709L ^ -19954735113896894L;
                    continue block316;
                }
                case 1341502819: {
                    v142 = 6783L ^ -7493422746802809483L;
                    continue block316;
                }
                case 1415186628: {
                    break block316;
                }
            }
            break;
        }
        this.statusProvider = v140;
        while (true) {
            if ((v143 = (cfr_temp_40 = MapCycleModule.\u13e8 - (3296L ^ -5145521634929560520L)) == 0L ? 0 : (cfr_temp_40 < 0L ? -1 : 1)) == false) continue;
            if (v143 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v143 = 6214 ^ 2118953163;
        }
        v144 = TwLicenseVerifierFactory.CompilationMode();
        v145 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl861
        block318: while (true) {
            v145 = (16280L ^ 5657422978237285345L) / (28551L ^ -5861122178685742419L);
lbl861:
            // 2 sources

            switch ((int)v145) {
                case 364650882: {
                    continue block318;
                }
                case 1415186628: {
                    break block318;
                }
            }
            break;
        }
        this.licenseVerifier = v144;
        v146 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl871
        block319: while (true) {
            v146 = (5344745003873072456L >>> "\u0000\u0000".length()) / (28620L ^ 8617801522464338920L);
lbl871:
            // 2 sources

            switch ((int)v146) {
                case -470723661: {
                    continue block319;
                }
                case 1415186628: {
                    break block319;
                }
            }
            break;
        }
        while (true) {
            if ((v147 = (cfr_temp_41 = MapCycleModule.\u13e8 - (23032L ^ 1319388733339187567L)) == 0L ? 0 : (cfr_temp_41 < 0L ? -1 : 1)) == false) continue;
            if (v147 == (26071 ^ -26072)) break;
            v147 = 27490 ^ 1428250566;
        }
        v148 = new ScheduledActionManager();
        v149 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl886
        block321: while (true) {
            v149 = v150 / (4357L ^ 6994070786426567999L);
lbl886:
            // 2 sources

            switch ((int)v149) {
                case -399541548: {
                    v150 = 16819L ^ 7327104964260067250L;
                    continue block321;
                }
                case 342796569: {
                    v150 = 12790L ^ -1824011457700132574L;
                    continue block321;
                }
                case 1415186628: {
                    break block321;
                }
            }
            break;
        }
        this.scheduledActionManager = v148;
        while (true) {
            if ((v151 = (cfr_temp_42 = MapCycleModule.\u13e8 - (15511L ^ -1009285592309503902L)) == 0L ? 0 : (cfr_temp_42 < 0L ? -1 : 1)) == false) continue;
            if (v151 == (6198 ^ -6199)) break;
            v151 = 31236 ^ 1891713597;
        }
        while (true) {
            if ((v152 = (cfr_temp_43 = MapCycleModule.\u13e8 - (-4756298475151026092L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_43 < 0L ? -1 : 1)) == false) continue;
            if (v152 == (26048 ^ -26049)) break;
            v152 = 21844 ^ 1825930882;
        }
        v153 = new ShootingBeheState();
        v154 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl911
        block324: while (true) {
            v154 = v155 / (13800L ^ -1585221139308884749L);
lbl911:
            // 2 sources

            switch ((int)v154) {
                case -1922659960: {
                    v155 = 20779L ^ -1853346737476914323L;
                    continue block324;
                }
                case -866874408: {
                    v155 = 2052L ^ 6483707626626947507L;
                    continue block324;
                }
                case 1269703407: {
                    v155 = 13176L ^ 6320800196305938964L;
                    continue block324;
                }
                case 1415186628: {
                    break block324;
                }
            }
            break;
        }
        this.shootingBeheState = v153;
    }

    /*
     * Unable to fully structure code
     */
    public void setConfig(MapCycleModuleConfig config) {
        while (true) {
            if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (29271L ^ -7130000337226496564L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v0 = 399366724 >>> "\u0000\u0000".length();
        }
        this.mapCycleConfig = config;
        v1 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl11
        block127: while (true) {
            v1 = (12665L ^ -6835713302590090289L) / (13104L ^ 7782460426619426495L);
lbl11:
            // 2 sources

            switch ((int)v1) {
                case -1345329595: {
                    continue block127;
                }
                case 1415186628: {
                    break block127;
                }
            }
            break;
        }
        v2 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl20
        block128: while (true) {
            v2 = v3 / (21470L ^ -8395815120257782276L);
lbl20:
            // 2 sources

            switch ((int)v2) {
                case 56091281: {
                    v3 = 3002L ^ 7187210235390030673L;
                    continue block128;
                }
                case 1415186628: {
                    break block128;
                }
                case 1435667156: {
                    v3 = 7825L ^ -3452284095612589477L;
                    continue block128;
                }
                case 1633761780: {
                    v3 = 12242L ^ 3163276663281392873L;
                    continue block128;
                }
            }
            break;
        }
        v4 = config.BETTER_LOOT_MODULE_CONFIG;
        while (true) {
            if ((v5 = (cfr_temp_1 = MapCycleModule.\u13e8 - (-4321655524188987748L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v5 == (7235 ^ -7236)) break;
            v5 = 19593 ^ 1155149217;
        }
        this.lootModule.setConfig(v4);
        v6 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl43
        block130: while (true) {
            v6 = v7 / (19749L ^ -7417341147562776623L);
lbl43:
            // 2 sources

            switch ((int)v6) {
                case 675113946: {
                    v7 = 29955L ^ 5402184388046244903L;
                    continue block130;
                }
                case 1415186628: {
                    break block130;
                }
                case 1485181799: {
                    v7 = 2543495663114525112L >>> "\u0000\u0000".length();
                    continue block130;
                }
            }
            break;
        }
        v8 = config.BETTER_LOOT_MODULE_CONFIG;
        while (true) {
            if ((v9 = (cfr_temp_2 = MapCycleModule.\u13e8 - (31979L ^ -7417819513193761630L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v9 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v9 = 3293 ^ -15057918;
        }
        this.betterLootModuleConfig = v8;
        v10 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl63
        block132: while (true) {
            v10 = v11 / (18405L ^ 1545952192297757016L);
lbl63:
            // 2 sources

            switch ((int)v10) {
                case -1999400349: {
                    v11 = 18525L ^ -8017007571504340511L;
                    continue block132;
                }
                case 608455846: {
                    v11 = 6991L ^ -1685293375144322088L;
                    continue block132;
                }
                case 1372601569: {
                    v11 = 6144395619454185072L >>> "\u0000\u0000".length();
                    continue block132;
                }
                case 1415186628: {
                    break block132;
                }
            }
            break;
        }
        v12 = config.MAP_CHANGE_COND_CONFIG;
        v13 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl80
        block133: while (true) {
            v13 = (24093L ^ -2072961337134506746L) / (17512L ^ -1210205681776059053L);
lbl80:
            // 2 sources

            switch ((int)v13) {
                case -40486116: {
                    continue block133;
                }
                case 1415186628: {
                    break block133;
                }
            }
            break;
        }
        this.mapchangeConditionConfig = v12;
        while (true) {
            if ((v14 = (cfr_temp_3 = MapCycleModule.\u13e8 - (25696L ^ 7291287728956097251L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v14 == (30336 ^ -30337)) break;
            v14 = 2016 ^ -873015985;
        }
        v15 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl95
        block135: while (true) {
            v15 = v16 / (31558L ^ -4905860762591962858L);
lbl95:
            // 2 sources

            switch ((int)v15) {
                case -1534649683: {
                    v16 = 1534L ^ 6324507752343800984L;
                    continue block135;
                }
                case 1217358201: {
                    v16 = 14974L ^ -2511267167229198582L;
                    continue block135;
                }
                case 1415186628: {
                    break block135;
                }
                case 1672962715: {
                    v16 = 5575L ^ -3636450782821501560L;
                    continue block135;
                }
            }
            break;
        }
        v17 = this.mapchangeConditionConfig.DEATH_COUNT_CONFIG;
        while (true) {
            if ((v18 = (cfr_temp_4 = MapCycleModule.\u13e8 - (26586L ^ -1135952748141629432L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v18 == (4385 ^ -4386)) break;
            v18 = 27185 ^ -975252903;
        }
        this.deathCountConditionConfig = v17;
        v19 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl118
        block137: while (true) {
            v19 = v20 / (22487L ^ 1366423073719517843L);
lbl118:
            // 2 sources

            switch ((int)v19) {
                case -2071787007: {
                    v20 = 719L ^ -4949798593594853438L;
                    continue block137;
                }
                case -88513746: {
                    v20 = 21411L ^ -582458609073321629L;
                    continue block137;
                }
                case 1415186628: {
                    break block137;
                }
                case 1936014503: {
                    v20 = 16745L ^ -8855451810224549420L;
                    continue block137;
                }
            }
            break;
        }
        v21 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl134
        block138: while (true) {
            v21 = v22 / (30984L ^ -4764543958323066047L);
lbl134:
            // 2 sources

            switch ((int)v21) {
                case -1516393472: {
                    v22 = 29168L ^ 8977456289147793945L;
                    continue block138;
                }
                case -649601555: {
                    v22 = 16768L ^ 4658710927119889535L;
                    continue block138;
                }
                case 1415186628: {
                    break block138;
                }
            }
            break;
        }
        v23 = this.mapchangeConditionConfig.LOG_LINE_SUBSTRING_CONFIG;
        while (true) {
            if ((v24 = (cfr_temp_5 = MapCycleModule.\u13e8 - (6811760763633102916L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
            if (v24 == (26956 ^ -26957)) break;
            v24 = 17759 ^ 2106133928;
        }
        this.loglineSubstringConditionConfig = v23;
        while (true) {
            if ((v25 = (cfr_temp_6 = MapCycleModule.\u13e8 - (1479582588191814624L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
            if (v25 == (8254 ^ -8255)) break;
            v25 = 11379 ^ -402673888;
        }
        v26 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl159
        block141: while (true) {
            v26 = v27 / (9250L ^ 8410088521297563977L);
lbl159:
            // 2 sources

            switch ((int)v26) {
                case -1466624463: {
                    v27 = -8678134394429790724L >>> "\u0000\u0000".length();
                    continue block141;
                }
                case -208428027: {
                    v27 = 21083L ^ -3864455726479871404L;
                    continue block141;
                }
                case 1415186628: {
                    break block141;
                }
            }
            break;
        }
        v28 = this.mapchangeConditionConfig.NPC_SUBNAME_CONFIG;
        while (true) {
            if ((v29 = (cfr_temp_7 = MapCycleModule.\u13e8 - (3929L ^ -4960159482709544584L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
            if (v29 == (10205 ^ 10204)) break;
            v29 = 16165 ^ 2026069810;
        }
        this.npcSubnameConditionConfig = v28;
        while (true) {
            if ((v30 = (cfr_temp_8 = MapCycleModule.\u13e8 - (11627L ^ -7884955905674257539L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
            if (v30 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v30 = 10779 ^ -1300661983;
        }
        v31 = config.ADAPTIVE_CHECKS_CONFIG;
        v32 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl185
        block144: while (true) {
            v32 = v33 / (3691367154464614704L >>> "\u0000\u0000".length());
lbl185:
            // 2 sources

            switch ((int)v32) {
                case -1459534356: {
                    v33 = 1429439047606860380L >>> "\u0000\u0000".length();
                    continue block144;
                }
                case -417436182: {
                    v33 = 8031L ^ 4587512970742091370L;
                    continue block144;
                }
                case 1415186628: {
                    break block144;
                }
            }
            break;
        }
        this.adaptiveChecksConfig = v31;
        v34 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl199
        block145: while (true) {
            v34 = v35 / (28801L ^ -6340754070860809254L);
lbl199:
            // 2 sources

            switch ((int)v34) {
                case -1599241800: {
                    v35 = 10509L ^ -1926924788092417917L;
                    continue block145;
                }
                case 305821539: {
                    v35 = 31073L ^ 4379696909455660219L;
                    continue block145;
                }
                case 1386833684: {
                    v35 = -6330211738244642412L >>> "\u0000\u0000".length();
                    continue block145;
                }
                case 1415186628: {
                    break block145;
                }
            }
            break;
        }
        v36 = config.AFTER_KILL_CONFIG;
        while (true) {
            if ((v37 = (cfr_temp_9 = MapCycleModule.\u13e8 - (6373L ^ -6439488833325932109L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
            if (v37 == (14718 ^ 14719)) break;
            v37 = 17211 ^ -1978370498;
        }
        this.afterKillConfig = v36;
        while (true) {
            if ((v38 = (cfr_temp_10 = MapCycleModule.\u13e8 - (22151L ^ -9089354254596646708L)) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
            if (v38 == (24839 ^ 24838)) break;
            v38 = 7853 ^ -704162282;
        }
        v39 = config.REFRESH_CONFIG;
        while (true) {
            if ((v40 = (cfr_temp_11 = MapCycleModule.\u13e8 - (24109L ^ -5839063959646951879L)) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
            if (v40 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v40 = 2643 ^ -483584308;
        }
        v41 = v39.EXTRA_SECONDS_ON_REFRESHABLE_MAPS_CONFIG;
        v42 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl234
        block149: while (true) {
            v42 = v43 / (5787L ^ -3983101181311542114L);
lbl234:
            // 2 sources

            switch ((int)v42) {
                case -1960966719: {
                    v43 = -7698460726280755896L >>> "\u0000\u0000".length();
                    continue block149;
                }
                case -1874969778: {
                    v43 = 30107L ^ 9210656488683671509L;
                    continue block149;
                }
                case 354720752: {
                    v43 = 1813L ^ 7027455525965777162L;
                    continue block149;
                }
                case 1415186628: {
                    break block149;
                }
            }
            break;
        }
        this.extraSecondsOnRefreshableMapsConfig = v41;
        v44 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl251
        block150: while (true) {
            v44 = (9281L ^ -480006615315039256L) / (28559L ^ -7079806591806033659L);
lbl251:
            // 2 sources

            switch ((int)v44) {
                case 429201780: {
                    continue block150;
                }
                case 1415186628: {
                    break block150;
                }
            }
            break;
        }
        v45 = config.KEY_FIRST_LOCK_CONFIG;
        v46 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl261
        block151: while (true) {
            v46 = v47 / (13510L ^ -1138544836017666526L);
lbl261:
            // 2 sources

            switch ((int)v46) {
                case -1835102959: {
                    v47 = 15881L ^ 8104432668395862016L;
                    continue block151;
                }
                case -757094800: {
                    v47 = 10087L ^ 8757086438825172287L;
                    continue block151;
                }
                case 1415186628: {
                    break block151;
                }
                case 1652734651: {
                    v47 = 24467L ^ -5254664367928284522L;
                    continue block151;
                }
            }
            break;
        }
        this.keyFirstLockConfig = v45;
        v48 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl278
        block152: while (true) {
            v48 = v49 / (24132L ^ -8251580554785337993L);
lbl278:
            // 2 sources

            switch ((int)v48) {
                case -1660454414: {
                    v49 = 30563L ^ -4606662143387124942L;
                    continue block152;
                }
                case -1583666557: {
                    v49 = 19163L ^ -4665062659425346388L;
                    continue block152;
                }
                case -626176539: {
                    v49 = 8587L ^ -8967504866344580295L;
                    continue block152;
                }
                case 1415186628: {
                    break block152;
                }
            }
            break;
        }
        v50 = config.BOX_COLLECT_CONFIG;
        while (true) {
            if ((v51 = (cfr_temp_12 = MapCycleModule.\u13e8 - (373L ^ -4590712729435709704L)) == 0L ? 0 : (cfr_temp_12 < 0L ? -1 : 1)) == false) continue;
            if (v51 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v51 = 11067 ^ 1468799814;
        }
        this.mapCycleBoxCollectConfig = v50;
        while (true) {
            if ((v52 = (cfr_temp_13 = MapCycleModule.\u13e8 - (11937L ^ -4370835006540704325L)) == 0L ? 0 : (cfr_temp_13 < 0L ? -1 : 1)) == false) continue;
            if (v52 == (28308 ^ 28309)) break;
            v52 = 1596 ^ 1926873659;
        }
        v53 = config.PET_CONFIG;
        while (true) {
            if ((v54 = (cfr_temp_14 = MapCycleModule.\u13e8 - (29605L ^ -2057584870960028620L)) == 0L ? 0 : (cfr_temp_14 < 0L ? -1 : 1)) == false) continue;
            if (v54 == (10940 ^ -10941)) break;
            v54 = 15054 ^ 1327763379;
        }
        this.mapCyclePetConfig = v53;
        v55 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl313
        block156: while (true) {
            v55 = v56 / (-3996290010551295824L >>> "\u0000\u0000".length());
lbl313:
            // 2 sources

            switch ((int)v55) {
                case -1211417972: {
                    v56 = 1090630211261060472L >>> "\u0000\u0000".length();
                    continue block156;
                }
                case 1408455157: {
                    v56 = 24622L ^ -2466598191272722282L;
                    continue block156;
                }
                case 1415186628: {
                    break block156;
                }
                case 1591649007: {
                    v56 = 6513602793495136156L >>> "\u0000\u0000".length();
                    continue block156;
                }
            }
            break;
        }
        v57 = config.REFRESH_CONFIG;
        while (true) {
            if ((v58 = (cfr_temp_15 = MapCycleModule.\u13e8 - (7053L ^ -9002230405949507319L)) == 0L ? 0 : (cfr_temp_15 < 0L ? -1 : 1)) == false) continue;
            if (v58 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v58 = 22204 ^ -1579326092;
        }
        this.mapCycleRefreshConfig = v57;
        while (true) {
            if ((v59 = (cfr_temp_16 = MapCycleModule.\u13e8 - (7994092183497740112L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_16 < 0L ? -1 : 1)) == false) continue;
            if (v59 == (3323 ^ -3324)) break;
            v59 = 28458 ^ 1578598220;
        }
        v60 = config.SAFETY_CONFIG;
        while (true) {
            if ((v61 = (cfr_temp_17 = MapCycleModule.\u13e8 - (16745L ^ -1813124599442559211L)) == 0L ? 0 : (cfr_temp_17 < 0L ? -1 : 1)) == false) continue;
            if (v61 == (18179 ^ -18180)) break;
            v61 = 2330 ^ 870269122;
        }
        this.mapCycleSafetyConfig = v60;
        v62 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl348
        block160: while (true) {
            v62 = v63 / (5143L ^ -638775301196066087L);
lbl348:
            // 2 sources

            switch ((int)v62) {
                case -1418168279: {
                    v63 = 4896L ^ 5261617092982709682L;
                    continue block160;
                }
                case 1188112796: {
                    v63 = 7842L ^ 2612874481350865590L;
                    continue block160;
                }
                case 1415186628: {
                    break block160;
                }
            }
            break;
        }
        v64 = config.MISC_CONFIG;
        v65 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl362
        block161: while (true) {
            v65 = (27657L ^ 6401977456890343747L) / (32516L ^ -715562422414830430L);
lbl362:
            // 2 sources

            switch ((int)v65) {
                case 1415186628: {
                    break block161;
                }
                case 1650944342: {
                    continue block161;
                }
            }
            break;
        }
        this.miscellaneousConfig = v64;
        while (true) {
            if ((v66 = (cfr_temp_18 = MapCycleModule.\u13e8 - (1375L ^ 4204113328364723095L)) == 0L ? 0 : (cfr_temp_18 < 0L ? -1 : 1)) == false) continue;
            if (v66 == (8374 ^ -8375)) break;
            v66 = 22029 ^ -828377164;
        }
        v67 = config.NPC_REWARD_CONFIG;
        v68 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl378
        block163: while (true) {
            v68 = v69 / (20385L ^ -8298063737125280678L);
lbl378:
            // 2 sources

            switch ((int)v68) {
                case -1133248315: {
                    v69 = 1867L ^ 7124689903407103095L;
                    continue block163;
                }
                case -1088228918: {
                    v69 = 19008L ^ 3940034317266655499L;
                    continue block163;
                }
                case 209293559: {
                    v69 = 29451L ^ 5203009817123963722L;
                    continue block163;
                }
                case 1415186628: {
                    break block163;
                }
            }
            break;
        }
        this.npcRewardConfig = v67;
        v70 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl395
        block164: while (true) {
            v70 = v71 / (30449L ^ 5177222834658081854L);
lbl395:
            // 2 sources

            switch ((int)v70) {
                case -1217416655: {
                    v71 = 21663L ^ 6759920737593050027L;
                    continue block164;
                }
                case -1083804589: {
                    v71 = 10791L ^ -4266196726494571787L;
                    continue block164;
                }
                case -215891893: {
                    v71 = 26860L ^ 7417680820092473710L;
                    continue block164;
                }
                case 1415186628: {
                    break block164;
                }
            }
            break;
        }
        v72 = config.PREDICT_NPC_SPAWN_CONFIG;
        v73 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl412
        block165: while (true) {
            v73 = v74 / (32213L ^ 3375818361345206645L);
lbl412:
            // 2 sources

            switch ((int)v73) {
                case 262232402: {
                    v74 = 21221L ^ 2038056736013825013L;
                    continue block165;
                }
                case 1390589672: {
                    v74 = -5366832076974888640L >>> "\u0000\u0000".length();
                    continue block165;
                }
                case 1415186628: {
                    break block165;
                }
            }
            break;
        }
        this.predictNpcSpawnConfig = v72;
        v75 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl426
        block166: while (true) {
            v75 = v76 / (3343366605755489472L >>> "\u0000\u0000".length());
lbl426:
            // 2 sources

            switch ((int)v75) {
                case -1322585573: {
                    v76 = 26058L ^ -346902036499670893L;
                    continue block166;
                }
                case 1140252532: {
                    v76 = 10928L ^ 8775681886749971593L;
                    continue block166;
                }
                case 1168256045: {
                    v76 = 4449L ^ -6967913547369613000L;
                    continue block166;
                }
                case 1415186628: {
                    break block166;
                }
            }
            break;
        }
        v77 = config.SERVER_RESTART_HANDLER_CONFIG;
        while (true) {
            if ((v78 = (cfr_temp_19 = MapCycleModule.\u13e8 - (15060L ^ -3734849734618839725L)) == 0L ? 0 : (cfr_temp_19 < 0L ? -1 : 1)) == false) continue;
            if (v78 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v78 = 8558 ^ -476685808;
        }
        this.serverRestartHandlerConfig = v77;
        v79 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl449
        block168: while (true) {
            v79 = (16940L ^ -1782752071087818193L) / (20019L ^ -4299001419179627236L);
lbl449:
            // 2 sources

            switch ((int)v79) {
                case 1381752019: {
                    continue block168;
                }
                case 1415186628: {
                    break block168;
                }
            }
            break;
        }
        v80 = config.SERVER_RESTART_HANDLER_CONFIG;
        v81 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl459
        block169: while (true) {
            v81 = (23523L ^ -4355332412913919466L) / (31710L ^ 8282578554368466693L);
lbl459:
            // 2 sources

            switch ((int)v81) {
                case 1415186628: {
                    break block169;
                }
                case 1663846285: {
                    continue block169;
                }
            }
            break;
        }
        v82 = v80.TEMP_EXTRA_WAIT_SECONDS_CONFIG;
        while (true) {
            if ((v83 = (cfr_temp_20 = MapCycleModule.\u13e8 - (12147L ^ 7022658356671677767L)) == 0L ? 0 : (cfr_temp_20 < 0L ? -1 : 1)) == false) continue;
            if (v83 == (14059 ^ -14060)) break;
            v83 = 19258 ^ -2119210508;
        }
        this.tempExtraWaitSecondsConfig = v82;
        while (true) {
            if ((v84 = (cfr_temp_21 = MapCycleModule.\u13e8 - (27353L ^ 7757097526968112090L)) == 0L ? 0 : (cfr_temp_21 < 0L ? -1 : 1)) == false) continue;
            if (v84 == (17275 ^ -17276)) break;
            v84 = 24136 ^ -394024681;
        }
        v85 = config.GROUP_CONFIG;
        while (true) {
            if ((v86 = (cfr_temp_22 = MapCycleModule.\u13e8 - (29211L ^ -6899943229455147594L)) == 0L ? 0 : (cfr_temp_22 < 0L ? -1 : 1)) == false) continue;
            if (v86 == (11872 ^ 11873)) break;
            v86 = 3058 ^ -1814803341;
        }
        this.groupConfig = v85;
    }

    /*
     * Unable to fully structure code
     */
    public void install(Main main) {
        while (true) {
            if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (12592L ^ -1312796166663604934L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (17667 ^ -17668)) break;
            v0 = 32030 ^ -1421229029;
        }
        while (true) {
            if ((v1 = (cfr_temp_1 = MapCycleModule.\u13e8 - (6488L ^ -4436274708543109755L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v1 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v1 = 12619 ^ -382602911;
        }
        this.twLootNCollectModule.install(main);
        v2 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl16
        block55: while (true) {
            v2 = (-2031672854460661996L >>> "\u0000\u0000".length()) / (19602L ^ -8246321418744191413L);
lbl16:
            // 2 sources

            switch ((int)v2) {
                case -2031296434: {
                    continue block55;
                }
                case 1415186628: {
                    break block55;
                }
            }
            break;
        }
        this.main = main;
        while (true) {
            if ((v3 = (cfr_temp_2 = MapCycleModule.\u13e8 - (20920L ^ 527373853032023270L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v3 == (19947 ^ -19948)) break;
            v3 = 9658 ^ 1873772816;
        }
        v4 = main.hero;
        while (true) {
            if ((v5 = (cfr_temp_3 = MapCycleModule.\u13e8 - (28180L ^ -3435294670197718828L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v5 == (19185 ^ 19184)) break;
            v5 = 18472 ^ -522898193;
        }
        v6 = v4.drive;
        while (true) {
            if ((v7 = (cfr_temp_4 = MapCycleModule.\u13e8 - (22816L ^ 7237879107144784041L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v7 == (145 ^ -146)) break;
            v7 = 12098 ^ 2010108970;
        }
        this.drive = v6;
        while (true) {
            if ((v8 = (cfr_temp_5 = MapCycleModule.\u13e8 - (25410L ^ 5824375569306088904L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
            if (v8 == (295 ^ -296)) break;
            v8 = 23153 ^ 1341856855;
        }
        v9 = main.guiManager;
        v10 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl50
        block60: while (true) {
            v10 = v11 / (7151L ^ 5193280594770742190L);
lbl50:
            // 2 sources

            switch ((int)v10) {
                case -1590684782: {
                    v11 = 8668L ^ 5363179003896449269L;
                    continue block60;
                }
                case 825810490: {
                    v11 = 16588L ^ -4495703151175289457L;
                    continue block60;
                }
                case 1415186628: {
                    break block60;
                }
            }
            break;
        }
        v12 = v9.group;
        v13 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl64
        block61: while (true) {
            v13 = v14 / (31502L ^ -676786618436639379L);
lbl64:
            // 2 sources

            switch ((int)v13) {
                case -806479672: {
                    v14 = 19188L ^ -4533767027215211923L;
                    continue block61;
                }
                case 453287279: {
                    v14 = 21399L ^ -6260359154445311067L;
                    continue block61;
                }
                case 1415186628: {
                    break block61;
                }
                case 1446647056: {
                    v14 = 4531L ^ 2530138687623962760L;
                    continue block61;
                }
            }
            break;
        }
        this.groupManager = v12;
        while (true) {
            if ((v15 = (cfr_temp_6 = MapCycleModule.\u13e8 - (1672L ^ -221859184260039693L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
            if (v15 == (8816 ^ -8817)) break;
            v15 = 29192 ^ 1621328057;
        }
        v16 = main.config;
        v17 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl87
        block63: while (true) {
            v17 = v18 / (25961L ^ -6383400248965963499L);
lbl87:
            // 2 sources

            switch ((int)v17) {
                case -1669229491: {
                    v18 = 2372790400757528568L >>> "\u0000\u0000".length();
                    continue block63;
                }
                case -1315019823: {
                    v18 = -1059944416404973496L >>> "\u0000\u0000".length();
                    continue block63;
                }
                case 1415186628: {
                    break block63;
                }
            }
            break;
        }
        this.mainConfig = v16;
        while (true) {
            if ((v19 = (cfr_temp_7 = MapCycleModule.\u13e8 - (29951L ^ -6704346751933561511L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
            if (v19 == (29041 ^ 29040)) break;
            v19 = 9883 ^ -1445356397;
        }
        v20 = main.hero;
        v21 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl107
        block65: while (true) {
            v21 = (22589L ^ -5573421045182500400L) / (22820L ^ -5091270003298874936L);
lbl107:
            // 2 sources

            switch ((int)v21) {
                case -63612908: {
                    continue block65;
                }
                case 1415186628: {
                    break block65;
                }
            }
            break;
        }
        this.hero = v20;
        while (true) {
            if ((v22 = (cfr_temp_8 = MapCycleModule.\u13e8 - (26303L ^ -4404106038338824148L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
            if (v22 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v22 = 24565 ^ 443643793;
        }
        v23 = main.guiManager;
        v24 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl123
        block67: while (true) {
            v24 = v25 / (21821L ^ 8818201635113018528L);
lbl123:
            // 2 sources

            switch ((int)v24) {
                case -811053720: {
                    v25 = 23683L ^ 7245688782068620280L;
                    continue block67;
                }
                case 1415186628: {
                    break block67;
                }
                case 1686228822: {
                    v25 = 30874L ^ -487850928648058880L;
                    continue block67;
                }
            }
            break;
        }
        v26 = v23.pet;
        v27 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl137
        block68: while (true) {
            v27 = v28 / (3413L ^ -5094277748203248210L);
lbl137:
            // 2 sources

            switch ((int)v27) {
                case -1926379625: {
                    v28 = 18893L ^ -2713764076295122156L;
                    continue block68;
                }
                case 1415186628: {
                    break block68;
                }
                case 1541124514: {
                    v28 = 20036L ^ 6270356671993846710L;
                    continue block68;
                }
                case 1696923950: {
                    v28 = 27723L ^ 5561090391863096374L;
                    continue block68;
                }
            }
            break;
        }
        this.pet = v26;
        while (true) {
            if ((v29 = (cfr_temp_9 = MapCycleModule.\u13e8 - (-2132591587229796008L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
            if (v29 == (19411 ^ -19412)) break;
            v29 = -606246180 >>> "\u0000\u0000".length();
        }
        v30 = main.mapManager;
        v31 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl160
        block70: while (true) {
            v31 = (168140377182945360L >>> "\u0000\u0000".length()) / (20324L ^ -8614539921122325948L);
lbl160:
            // 2 sources

            switch ((int)v31) {
                case 404395543: {
                    continue block70;
                }
                case 1415186628: {
                    break block70;
                }
            }
            break;
        }
        this.mapManager = v30;
        v32 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl170
        block71: while (true) {
            v32 = (31380L ^ -5239447359762777532L) / (5651L ^ -1618374438014350955L);
lbl170:
            // 2 sources

            switch ((int)v32) {
                case -12901429: {
                    continue block71;
                }
                case 1415186628: {
                    break block71;
                }
            }
            break;
        }
        v33 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl179
        block72: while (true) {
            v33 = v34 / (28159L ^ -7588996358287964656L);
lbl179:
            // 2 sources

            switch ((int)v33) {
                case -2080458151: {
                    v34 = 2978L ^ -5186459539737466044L;
                    continue block72;
                }
                case -1295125141: {
                    v34 = 8777L ^ -3629402424182536605L;
                    continue block72;
                }
                case 1415186628: {
                    break block72;
                }
            }
            break;
        }
        v35 = new SafetyFinder(main);
        while (true) {
            if ((v36 = (cfr_temp_10 = MapCycleModule.\u13e8 - (1599L ^ -4590070096946487280L)) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
            if (v36 == (25292 ^ 25293)) break;
            v36 = 12251 ^ -726911519;
        }
        this.safety = v35;
        v37 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl199
        block74: while (true) {
            v37 = v38 / (18396L ^ -699797103986895167L);
lbl199:
            // 2 sources

            switch ((int)v37) {
                case -1895788496: {
                    v38 = 26782L ^ -6033182692573732429L;
                    continue block74;
                }
                case -1029649262: {
                    v38 = 4648360396645237804L >>> "\u0000\u0000".length();
                    continue block74;
                }
                case 1415186628: {
                    break block74;
                }
            }
            break;
        }
        this.destructLogsReader();
        while (true) {
            if ((v39 = (cfr_temp_11 = MapCycleModule.\u13e8 - (13187L ^ -3316257347087526466L)) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
            if (v39 == (27108 ^ 27109)) break;
            v39 = 32586 ^ -213291184;
        }
        this.resetState();
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private void setupUnseenLogsReader() {
        long l = \u13e8;
        boolean bl = true;
        block5: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x648AL ^ 0x79AF1D08B94A8C55L);
            }
            switch ((int)l) {
                case -1995679326: {
                    l2 = 8969743145784107164L >>> "\u0000\u0000".length();
                    continue block5;
                }
                case 107133872: {
                    l2 = 0x1174L ^ 0xB6CFD2BD52DE44F4L;
                    continue block5;
                }
                case 1415186628: {
                    break block5;
                }
            }
            break;
        }
        if (this.unseenLogsReader != null) return;
        while (true) {
            long l3;
            long l4;
            if ((l4 = (l3 = \u13e8 - (-2539819342567208856L >>> "\u0000\u0000".length())) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) continue;
            if (l4 == (0x24FB ^ 0xFFFFDB04)) break;
            l4 = 0x505B ^ 0x26B7C3CE;
        }
        while (true) {
            long l5;
            long l6;
            if ((l6 = (l5 = \u13e8 - (0x7377L ^ 0xE8A6BDC12B3407EBL)) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) continue;
            if (l6 == (0x78CA ^ 0xFFFF8735)) break;
            l6 = 0x12D6 ^ 0xE8AB4D55;
        }
        while (true) {
            long l7;
            long l8;
            if ((l8 = (l7 = \u13e8 - (0x3E69L ^ 0x1941F8B734EFF6F6L)) == 0L ? 0 : (l7 < 0L ? -1 : 1)) == false) continue;
            if (l8 == (0x7EDA ^ 0xFFFF8125)) break;
            l8 = 0x6D91 ^ 0xA59C5ED0;
        }
        FlashLogReader flashLogReader = new FlashLogReader(this.eventBrokerAPI);
        while (true) {
            long l9;
            long l10;
            if ((l10 = (l9 = \u13e8 - (0x7288L ^ 0x2C787B5189020E23L)) == 0L ? 0 : (l9 < 0L ? -1 : 1)) == false) continue;
            if (l10 == (0x352D ^ 0xFFFFCAD2)) break;
            l10 = 0x434A ^ 0x59400A98;
        }
        this.unseenLogsReader = flashLogReader;
        while (true) {
            long l11;
            long l12;
            if ((l12 = (l11 = \u13e8 - (0x2F0FL ^ 0x792DF5402B45BDF1L)) == 0L ? 0 : (l11 < 0L ? -1 : 1)) == false) continue;
            if (l12 == (0x2AB7 ^ 0xFFFFD548)) break;
            l12 = 0x3C1B ^ 0xE7E0C54E;
        }
        while (true) {
            long l13;
            long l14;
            if ((l14 = (l13 = \u13e8 - (0x514L ^ 0xD575289E7A46EF62L)) == 0L ? 0 : (l13 < 0L ? -1 : 1)) == false) continue;
            if (l14 == (0x4679 ^ 0x4678)) {
                this.unseenLogsReader.open();
                return;
            }
            l14 = 0x2DF5 ^ 0xA852DB2F;
        }
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public String getMapName(int mapId) {
        while (true) {
            if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (15909L ^ -5836103506132636708L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v0 = 30853 ^ 1333014201;
        }
        v1 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl10
        block13: while (true) {
            v1 = v2 / (5740L ^ -8437339420393818340L);
lbl10:
            // 2 sources

            switch ((int)v1) {
                case -802553646: {
                    v2 = 3986L ^ 2669983431773728694L;
                    continue block13;
                }
                case 894786565: {
                    v2 = 4431L ^ 7464653776393102216L;
                    continue block13;
                }
                case 1346550408: {
                    v2 = 4592L ^ 7858201550363778959L;
                    continue block13;
                }
                case 1415186628: {
                    break block13;
                }
            }
            break;
        }
        v3 = this.main.starManager;
        while (true) {
            if ((v4 = (cfr_temp_1 = MapCycleModule.\u13e8 - (8080L ^ -7886832994994801552L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v4 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v4 = 23221 ^ -1547795899;
        }
        v5 = v3.byId(mapId);
        v6 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl33
        block15: while (true) {
            v6 = v7 / (23377L ^ 7865976720353788779L);
lbl33:
            // 2 sources

            switch ((int)v6) {
                case -2017908313: {
                    v7 = 5116L ^ -1518705830181806655L;
                    continue block15;
                }
                case 422807290: {
                    v7 = 30588L ^ 7205720515236606860L;
                    continue block15;
                }
                case 863009692: {
                    v7 = 13645L ^ 1180711058666831882L;
                    continue block15;
                }
                case 1415186628: {
                    break block15;
                }
            }
            break;
        }
        return v5.name;
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public Long getAfterNpcKillSecondsPast() {
        while (true) {
            if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (30245L ^ -8546192607963247771L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (3661 ^ 3660)) break;
            v0 = 8146 ^ 1815665263;
        }
        if (this.npcKilledTimeStampMs == null) {
            return null;
        }
        while (true) {
            if ((v1 = (cfr_temp_1 = MapCycleModule.\u13e8 - (-3942204808810615060L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v1 == (13923 ^ -13924)) break;
            v1 = 21969 ^ 1490533203;
        }
        v2 = System.currentTimeMillis();
        v3 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl18
        block12: while (true) {
            v3 = (10055L ^ 5222328351133316823L) / (6336L ^ 9187749371537510851L);
lbl18:
            // 2 sources

            switch ((int)v3) {
                case 1415186628: {
                    break block12;
                }
                case 1773089859: {
                    continue block12;
                }
            }
            break;
        }
        while (true) {
            if ((v4 = (cfr_temp_2 = MapCycleModule.\u13e8 - (2586L ^ -7577779636620870659L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v4 == (24383 ^ 24382)) break;
            v4 = 19863 ^ -494330010;
        }
        v5 = (v2 - this.npcKilledTimeStampMs) / (4000L >>> "\u0000\u0000".length());
        v6 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl33
        block14: while (true) {
            v6 = v7 / (12641L ^ -6359331134703018387L);
lbl33:
            // 2 sources

            switch ((int)v6) {
                case -4219929: {
                    v7 = 14718L ^ 3501122742877309445L;
                    continue block14;
                }
                case 388904084: {
                    v7 = 13590L ^ -2482134356192778854L;
                    continue block14;
                }
                case 1415186628: {
                    break block14;
                }
                case 1749447228: {
                    v7 = -7766621779077910708L >>> "\u0000\u0000".length();
                    continue block14;
                }
            }
            break;
        }
        return v5;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    @Override
    public AfterKillConfig getAfterKillConfig() {
        long l = \u13e8;
        boolean bl = true;
        block5: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x27A0L ^ 0xEA9E5DEC06ED64B8L);
            }
            switch ((int)l) {
                case -819325040: {
                    l2 = 0x609EL ^ 0xBBBE641C5F0B02B1L;
                    continue block5;
                }
                case 467664576: {
                    l2 = 0xFB3L ^ 0x4820813DBA87343L;
                    continue block5;
                }
                case 1415186628: {
                    return this.afterKillConfig;
                }
            }
            break;
        }
        return this.afterKillConfig;
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public Long getKeyFirstLockMsPast() {
        v0 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl5
        block10: while (true) {
            v0 = (18324L ^ 4641882682520899325L) / (27077L ^ -6933417241526730174L);
lbl5:
            // 2 sources

            switch ((int)v0) {
                case -90345967: {
                    continue block10;
                }
                case 1415186628: {
                    break block10;
                }
            }
            break;
        }
        while (true) {
            if ((v1 = (cfr_temp_0 = MapCycleModule.\u13e8 - (7399L ^ -4691660459530732446L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v1 == (18950 ^ 18951)) break;
            v1 = 27409 ^ -1929242746;
        }
        firstLockedNpcTimeStampMs = this.shootingBeheState.getFirstTimeTimeStampMs();
        if (firstLockedNpcTimeStampMs == null) {
            return null;
        }
        while (true) {
            if ((v2 = (cfr_temp_1 = MapCycleModule.\u13e8 - (23953L ^ 5673967577439610244L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v2 == (30631 ^ -30632)) break;
            v2 = 2998 ^ -2040366167;
        }
        v3 = System.currentTimeMillis();
        v4 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl28
        block13: while (true) {
            v4 = v5 / (24024L ^ -8610669502075776355L);
lbl28:
            // 2 sources

            switch ((int)v4) {
                case -1809490737: {
                    v5 = 29946L ^ -2518226612623638862L;
                    continue block13;
                }
                case -1395656240: {
                    v5 = 6551L ^ -8752334982337844100L;
                    continue block13;
                }
                case 1415186628: {
                    break block13;
                }
                case 2132919938: {
                    v5 = 764L ^ -7701732374787594863L;
                    continue block13;
                }
            }
            break;
        }
        v6 = v3 - firstLockedNpcTimeStampMs;
        while (true) {
            if ((v7 = (cfr_temp_2 = MapCycleModule.\u13e8 - (-3706566995353582108L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v7 == (13847 ^ -13848)) break;
            v7 = 26566 ^ -1736798560;
        }
        return v6;
    }

    @Override
    public KeyFirstLockConfig getKeyFirstLockConfig() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x1BBBL ^ 0xBD00B996979F8FC9L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l2 = 0x4A33 ^ 0x82368F36;
        }
        return this.keyFirstLockConfig;
    }

    @Override
    public Boolean getAwaitingRevive() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x2A2BL ^ 0xCEEB82A55A4153ACL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == (0x3C39 ^ 0x3C38)) break;
            l2 = 0x2200 ^ 0x2B43A699;
        }
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = \u13e8 - (0x6FC5L ^ 0xC061A4E5F2440495L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l3 == (0x3116 ^ 0x3117)) break;
            l3 = 0x60A7 ^ 0x9BA41201;
        }
        return this.awaitingRevive;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    @Override
    public com.github.manolo8.darkbot.core.objects.Map getCurrentHeroMap() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x6CCAL ^ 0xF682F131B113C2D5L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == (0x1C75 ^ 0xFFFFE38A)) {
                if (this.hero == null) {
                    return null;
                }
                break;
            }
            l2 = 517528876 >>> "\u0000\u0000".length();
        }
        long l = \u13e8;
        boolean bl = true;
        block7: while (true) {
            long l3;
            if (!bl || (bl = false) || !true) {
                l = l3 / (0x226CL ^ 0xCE5196CD5C78C6AEL);
            }
            switch ((int)l) {
                case -1770183646: {
                    l3 = 0x632EL ^ 0x56163EFA82B5125CL;
                    continue block7;
                }
                case -967517406: {
                    l3 = -785135103250781028L >>> "\u0000\u0000".length();
                    continue block7;
                }
                case 1415186628: {
                    break block7;
                }
                case 1667612413: {
                    l3 = 0x439L ^ 0xEB14514C1DAB55F2L;
                    continue block7;
                }
            }
            break;
        }
        while (true) {
            long l4;
            long l5;
            if ((l5 = (l4 = \u13e8 - (0xC9EL ^ 0x8DB7ED81F3717BFBL)) == 0L ? 0 : (l4 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l5 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                com.github.manolo8.darkbot.core.objects.Map map = this.hero.map;
                return map;
            }
            l5 = 182015952 >>> "\u0000\u0000".length();
        }
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public Integer getGeneralBotWorkingMapId() {
        v0 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl5
        block10: while (true) {
            v0 = (24516L ^ 5053724504269364366L) / (18329L ^ 4536655975596376222L);
lbl5:
            // 2 sources

            switch ((int)v0) {
                case -1927123799: {
                    continue block10;
                }
                case 1415186628: {
                    break block10;
                }
            }
            break;
        }
        while (true) {
            if ((v1 = (cfr_temp_0 = MapCycleModule.\u13e8 - (21185L ^ 6303714781696818330L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v1 == (10420 ^ -10421)) break;
            v1 = 3920 ^ -168125607;
        }
        v2 = this.mainConfig.GENERAL;
        while (true) {
            if ((v3 = (cfr_temp_1 = MapCycleModule.\u13e8 - (11550L ^ 8776573215070445218L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v3 == (17512 ^ -17513)) break;
            v3 = 22813 ^ -574646344;
        }
        v4 = v2.WORKING_MAP;
        v5 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl26
        block13: while (true) {
            v5 = v6 / (10201L ^ -5696613506699532897L);
lbl26:
            // 2 sources

            switch ((int)v5) {
                case -1889992765: {
                    v6 = 27175L ^ -4696088082633834392L;
                    continue block13;
                }
                case -780414048: {
                    v6 = 12324L ^ -7976531202997774957L;
                    continue block13;
                }
                case -185412169: {
                    v6 = 5188L ^ 4975768784881250694L;
                    continue block13;
                }
                case 1415186628: {
                    break block13;
                }
            }
            break;
        }
        return v4;
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public String getFallbackStatusMsg() {
        while (true) {
            if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (1585L ^ 3150607939471562022L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v0 == (5905 ^ -5906)) break;
            v0 = 6121 ^ 528293703;
        }
        v1 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl11
        block7: while (true) {
            v1 = v2 / (15616L ^ -2166146848474461335L);
lbl11:
            // 2 sources

            switch ((int)v1) {
                case 496734430: {
                    v2 = 20950L ^ -5990415674099007143L;
                    continue block7;
                }
                case 524334186: {
                    v2 = 21490L ^ -7666379939782939802L;
                    continue block7;
                }
                case 1415186628: {
                    break block7;
                }
                case 1608528511: {
                    v2 = 19306L ^ -3827942717550488998L;
                    continue block7;
                }
            }
            break;
        }
        return this.twLootNCollectModule.status();
    }

    /*
     * Unable to fully structure code
     */
    private Long getNumberOfBoxesInSight(String subname) {
        block45: {
            block44: {
                if (subname != null) break block44;
                v0 = null;
                break block45;
            }
            v1 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl9
            block35: while (true) {
                v1 = v2 / (28370L ^ -7182110508437972407L);
lbl9:
                // 2 sources

                switch ((int)v1) {
                    case -102194014: {
                        v2 = -4252261305697629508L >>> "\u0000\u0000".length();
                        continue block35;
                    }
                    case 767529728: {
                        v2 = 695L ^ -3807333418784169630L;
                        continue block35;
                    }
                    case 984591015: {
                        v2 = 26785L ^ -7182386613289061020L;
                        continue block35;
                    }
                    case 1415186628: {
                        break block35;
                    }
                }
                break;
            }
            v3 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl25
            block36: while (true) {
                v3 = v4 / (12735L ^ -7742098562006284274L);
lbl25:
                // 2 sources

                switch ((int)v3) {
                    case -1895269656: {
                        v4 = 30593L ^ -7439322509149853249L;
                        continue block36;
                    }
                    case -106823666: {
                        v4 = 8145L ^ -962162836958255793L;
                        continue block36;
                    }
                    case 726587479: {
                        v4 = -1249811646988870308L >>> "\u0000\u0000".length();
                        continue block36;
                    }
                    case 1415186628: {
                        break block36;
                    }
                }
                break;
            }
            v5 = this.main.mapManager;
            v6 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl42
            block37: while (true) {
                v6 = v7 / (3018L ^ -7810202391693791312L);
lbl42:
                // 2 sources

                switch ((int)v6) {
                    case -1293807019: {
                        v7 = 4798L ^ -6920662467384876758L;
                        continue block37;
                    }
                    case -125009373: {
                        v7 = 28443L ^ 309628376073351030L;
                        continue block37;
                    }
                    case 982520094: {
                        v7 = 26683L ^ 6388179350280953530L;
                        continue block37;
                    }
                    case 1415186628: {
                        break block37;
                    }
                }
                break;
            }
            v8 = v5.entities;
            while (true) {
                if ((v9 = (cfr_temp_0 = MapCycleModule.\u13e8 - (10097L ^ -707879690732049288L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v9 == (3707 ^ -3708)) break;
                v9 = 30759 ^ -586750120;
            }
            v10 = v8.boxes;
            while (true) {
                if ((v11 = (cfr_temp_1 = MapCycleModule.\u13e8 - (28063L ^ -7243215000925132002L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v11 == (9259 ^ 9258)) break;
                v11 = 15694 ^ -1685093604;
            }
            v12 = v10.stream();
            while (true) {
                if ((v13 = (cfr_temp_2 = MapCycleModule.\u13e8 - (2694L ^ -5789465127743635186L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v13 == (20407 ^ 20406)) break;
                v13 = -1942154560 >>> "\u0000\u0000".length();
            }
            v14 = (Predicate<Box>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Z, lambda$getNumberOfBoxesInSight$0(java.lang.String com.github.manolo8.darkbot.core.entities.Box ), (Lcom/github/manolo8/darkbot/core/entities/Box;)Z)((MapCycleModule)this, (String)subname);
            v15 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl77
            block41: while (true) {
                v15 = v16 / (21258L ^ -6574962216787397780L);
lbl77:
                // 2 sources

                switch ((int)v15) {
                    case -1235211455: {
                        v16 = 10947L ^ 2147475160247161821L;
                        continue block41;
                    }
                    case -870091295: {
                        v16 = 11175L ^ -3989595461472243996L;
                        continue block41;
                    }
                    case -699065960: {
                        v16 = 9060102388752681312L >>> "\u0000\u0000".length();
                        continue block41;
                    }
                    case 1415186628: {
                        break block41;
                    }
                }
                break;
            }
            v17 = v12.filter(v14);
            v18 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl94
            block42: while (true) {
                v18 = v19 / (5626L ^ 4368938935907668518L);
lbl94:
                // 2 sources

                switch ((int)v18) {
                    case -1541053096: {
                        v19 = 28968L ^ -8551251454711174830L;
                        continue block42;
                    }
                    case 1226677148: {
                        v19 = 6950L ^ -5745958768822871124L;
                        continue block42;
                    }
                    case 1415186628: {
                        break block42;
                    }
                }
                break;
            }
            v20 = v17.count();
            v21 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl108
            block43: while (true) {
                v21 = v22 / (7001L ^ 2382783531694393935L);
lbl108:
                // 2 sources

                switch ((int)v21) {
                    case -392015309: {
                        v22 = 7376L ^ 2690029936730818379L;
                        continue block43;
                    }
                    case -22916891: {
                        v22 = 15087L ^ 8887740403960263372L;
                        continue block43;
                    }
                    case 519152498: {
                        v22 = -105652585555892196L >>> "\u0000\u0000".length();
                        continue block43;
                    }
                    case 1415186628: {
                        break block43;
                    }
                }
                break;
            }
            v0 = v20;
        }
        return v0;
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public Long getNumberOfBoxesInSight() {
        v0 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl5
        block12: while (true) {
            v0 = v1 / (30161L ^ -7119548682957173011L);
lbl5:
            // 2 sources

            switch ((int)v0) {
                case 357042390: {
                    v1 = 28061L ^ 6187927910102170235L;
                    continue block12;
                }
                case 972727882: {
                    v1 = 20073L ^ -4284117897704612892L;
                    continue block12;
                }
                case 1415186628: {
                    break block12;
                }
                case 2103544365: {
                    v1 = 3977L ^ 5598356223995520671L;
                    continue block12;
                }
            }
            break;
        }
        while (true) {
            if ((v2 = (cfr_temp_0 = MapCycleModule.\u13e8 - (16508L ^ -8692353047241606340L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v2 == (8893 ^ 8892)) break;
            v2 = 1839 ^ 278727253;
        }
        v3 = this.miscellaneousConfig.BOX_NAME;
        v4 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl27
        block14: while (true) {
            v4 = v5 / (32640L ^ -974397093912365453L);
lbl27:
            // 2 sources

            switch ((int)v4) {
                case -719850934: {
                    v5 = 8143535816574365700L >>> "\u0000\u0000".length();
                    continue block14;
                }
                case -146200064: {
                    v5 = -3829757766967260528L >>> "\u0000\u0000".length();
                    continue block14;
                }
                case 737019559: {
                    v5 = 18147L ^ -3125257155884295799L;
                    continue block14;
                }
                case 1415186628: {
                    break block14;
                }
            }
            break;
        }
        return this.getNumberOfBoxesInSight(v3);
    }

    public void uninstall() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x3523L ^ 0x7A66EA1357F654C5L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x1E34 ^ 0xFFFFE1CB)) break;
            l2 = 0x8F8 ^ 0x82DEB1DF;
        }
        this.destructLogsReader();
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private void destructLogsReader() {
        long l = \u13e8;
        boolean bl = true;
        block10: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x786FL ^ 0x670FD72788501F28L);
            }
            switch ((int)l) {
                case -1097368304: {
                    l2 = 0x3EA8L ^ 0xA0B92EA6A30DB08BL;
                    continue block10;
                }
                case 774208699: {
                    l2 = 0xE11L ^ 0x7C0AE0F27ADEEB0AL;
                    continue block10;
                }
                case 1380870150: {
                    l2 = 0x7588L ^ 0x9D18F83A1FAEFA3CL;
                    continue block10;
                }
                case 1415186628: {
                    break block10;
                }
            }
            break;
        }
        if (this.unseenLogsReader != null) {
            while (true) {
                long l3;
                long l4;
                if ((l4 = (l3 = \u13e8 - (0x6070L ^ 0xA79A009C5058CE24L)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) continue;
                if (l4 == (0x65CE ^ 0x65CF)) break;
                l4 = 0x54AD ^ 0xA1A76F51;
            }
            while (true) {
                long l5;
                long l6;
                if ((l6 = (l5 = \u13e8 - (8491301667358061572L >>> "\u0000\u0000".length())) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) continue;
                if (l6 == (0x1389 ^ 0xFFFFEC76)) break;
                l6 = 0x4916 ^ 0x14570BED;
            }
            this.unseenLogsReader.close();
            long l7 = \u13e8;
            block13: while (true) {
                switch ((int)l7) {
                    case -1453260565: {
                        l7 = (0x1DDFL ^ 0xE6C768477FE12B39L) / (0x2877L ^ 0x4DE8D64D9E78CE16L);
                        continue block13;
                    }
                    case 1415186628: {
                        break block13;
                    }
                }
                break;
            }
            this.unseenLogsReader = null;
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    @Override
    public String stoppedStatus() {
        long l = \u13e8;
        block10: while (true) {
            switch ((int)l) {
                case -1727743370: {
                    l = (0x6AF4L ^ 0x4145D5E2A42E9914L) / (0x5254L ^ 0x80743079841D79E7L);
                    continue block10;
                }
                case 1415186628: {
                    break block10;
                }
            }
            break;
        }
        long l2 = \u13e8;
        boolean bl = true;
        block11: while (true) {
            long l3;
            if (!bl || (bl = false) || !true) {
                l2 = l3 / (0x64EAL ^ 0x9BDD0FE5BF17EB6EL);
            }
            switch ((int)l2) {
                case -1448555231: {
                    l3 = 0xE92L ^ 0xEA85A8D32FDFABC0L;
                    continue block11;
                }
                case -939954596: {
                    l3 = 0xFB4L ^ 0x69DF894837ECFFA1L;
                    continue block11;
                }
                case 189221950: {
                    l3 = 0x5461L ^ 0xBF901471C6FB4615L;
                    continue block11;
                }
                case 1415186628: {
                    return this.stoppedStatusProvider.getStatusMsg(this);
                }
            }
            break;
        }
        return this.stoppedStatusProvider.getStatusMsg(this);
    }

    @Override
    public String status() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x7623L ^ 0xE20166ED6472A401L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == (0x4034 ^ 0xFFFFBFCB)) break;
            l2 = 0x7C81 ^ 0x9700F905;
        }
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = \u13e8 - (0x2FC2L ^ 0xEBCABA7958BEECEEL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l3 == (0x6F86 ^ 0xFFFF9079)) break;
            l3 = -1894314816 >>> "\u0000\u0000".length();
        }
        return this.statusProvider.getStatusMsg(this);
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private boolean isRefreshableMap(int mapId) {
        long l = \u13e8;
        boolean bl = true;
        block15: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x3F9L ^ 0x41EBD50730F2B67EL);
            }
            switch ((int)l) {
                case -1420937166: {
                    l2 = 5932566751150124296L >>> "\u0000\u0000".length();
                    continue block15;
                }
                case 1058058691: {
                    l2 = 238283992159924784L >>> "\u0000\u0000".length();
                    continue block15;
                }
                case 1415186628: {
                    break block15;
                }
            }
            break;
        }
        List<Integer> list = this.getAllRefreshableMapIds();
        long l3 = \u13e8;
        boolean bl2 = true;
        block16: while (true) {
            long l4;
            if (!bl2 || (bl2 = false) || !true) {
                l3 = l4 / (0x5B53L ^ 0x78A432205DFB3361L);
            }
            switch ((int)l3) {
                case -1780484714: {
                    l4 = -6732945956038557820L >>> "\u0000\u0000".length();
                    continue block16;
                }
                case -1351189787: {
                    l4 = 0x12E6L ^ 0x674488A99686BB31L;
                    continue block16;
                }
                case -546205252: {
                    l4 = 0x79FBL ^ 0x6DC17975082F5CF4L;
                    continue block16;
                }
                case 1415186628: {
                    break block16;
                }
            }
            break;
        }
        Integer n = mapId;
        long l5 = \u13e8;
        block17: while (true) {
            switch ((int)l5) {
                case -83126512: {
                    l5 = (0x67CEL ^ 0x357E65FEEB2A4998L) / (0x1599L ^ 0x30F85F6E546A5B04L);
                    continue block17;
                }
                case 1415186628: {
                    return list.contains(n);
                }
            }
            break;
        }
        return list.contains(n);
    }

    /*
     * Unable to fully structure code
     */
    private List<Integer> getAllRefreshableMapIds() {
        block73: {
            block72: {
                v0 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl5
                block47: while (true) {
                    v0 = v1 / (29437L ^ 6671523192701698149L);
lbl5:
                    // 2 sources

                    switch ((int)v0) {
                        case -1836272284: {
                            v1 = 29094L ^ -938634873663155498L;
                            continue block47;
                        }
                        case -823525140: {
                            v1 = 6411L ^ 6514328852352049285L;
                            continue block47;
                        }
                        case 62306656: {
                            v1 = 26794L ^ -6487982233977104133L;
                            continue block47;
                        }
                        case 1415186628: {
                            break block47;
                        }
                    }
                    break;
                }
                if (this.cachedGetAllRefreshableMapIds == null) break block72;
                while (true) {
                    if ((v2 = (cfr_temp_0 = MapCycleModule.\u13e8 - (6701022272011809260L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                    if (v2 == (23057 ^ -23058)) break;
                    v2 = 32445 ^ -1671761329;
                }
                v3 = System.currentTimeMillis();
                v4 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl28
                block49: while (true) {
                    v4 = v5 / (5402L ^ 5024254575545780624L);
lbl28:
                    // 2 sources

                    switch ((int)v4) {
                        case -1427703263: {
                            v5 = 19932L ^ -886756079509671697L;
                            continue block49;
                        }
                        case -762616875: {
                            v5 = 7451L ^ -3569816998757100317L;
                            continue block49;
                        }
                        case 559306070: {
                            v5 = 4083L ^ 5914446474047745256L;
                            continue block49;
                        }
                        case 1415186628: {
                            break block49;
                        }
                    }
                    break;
                }
                if (v3 - this.cacheExpiresGetAllRefreshableMapIdsStartMilis <= (1580L ^ 5540L)) break block73;
            }
            v6 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl46
            block50: while (true) {
                v6 = (11399L ^ -2685506710776836629L) / (17074L ^ 6658513747280805158L);
lbl46:
                // 2 sources

                switch ((int)v6) {
                    case 991936660: {
                        continue block50;
                    }
                    case 1415186628: {
                        break block50;
                    }
                }
                break;
            }
            v7 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl55
            block51: while (true) {
                v7 = (21711L ^ 7700580947392516600L) / (27980L ^ 7676543447398578023L);
lbl55:
                // 2 sources

                switch ((int)v7) {
                    case 868702998: {
                        continue block51;
                    }
                    case 1415186628: {
                        break block51;
                    }
                }
                break;
            }
            ret = new ArrayList<Integer>();
            v8 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl65
            block52: while (true) {
                v8 = v9 / (2272L ^ 2173563255824492942L);
lbl65:
                // 2 sources

                switch ((int)v8) {
                    case 350930679: {
                        v9 = 13477L ^ 6872148173778299564L;
                        continue block52;
                    }
                    case 577535145: {
                        v9 = 22156L ^ -6077446854035661831L;
                        continue block52;
                    }
                    case 1415186628: {
                        break block52;
                    }
                }
                break;
            }
            while (true) {
                if ((v10 = (cfr_temp_1 = MapCycleModule.\u13e8 - (452L ^ -673503279669044240L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v10 == (1566 ^ -1567)) break;
                v10 = 32114 ^ -903246851;
            }
            mapNameToInfoMap = this.mapCycleConfig.CYCLE_MAP_INFOS;
            while (true) {
                if ((v11 = (cfr_temp_2 = MapCycleModule.\u13e8 - (15956L ^ 7435820773844915714L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v11 == (13669 ^ -13670)) break;
                v11 = 543251860 >>> "\u0000\u0000".length();
            }
            v12 = mapNameToInfoMap.keySet();
            while (true) {
                if ((v13 = (cfr_temp_3 = MapCycleModule.\u13e8 - (24195L ^ -7398434127046084977L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v13 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v13 = 20388 ^ 1374576783;
            }
            var3_3 = v12.iterator();
            block56: while (true) {
                v14 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl97
                block57: while (true) {
                    v14 = (17339L ^ -3043758040374618170L) / (11167L ^ -8737398984608913919L);
lbl97:
                    // 2 sources

                    switch ((int)v14) {
                        case -496790781: {
                            continue block57;
                        }
                        case 1415186628: {
                            break block57;
                        }
                    }
                    break;
                }
                if (!var3_3.hasNext()) break;
                while (true) {
                    if ((v15 = (cfr_temp_4 = MapCycleModule.\u13e8 - (12162L ^ 7635297015095786157L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                    if (v15 == (23154 ^ -23155)) break;
                    v15 = 2368 ^ 1802227430;
                }
                mapName = var3_3.next();
                while (true) {
                    if ((v16 = (cfr_temp_5 = MapCycleModule.\u13e8 - (30300L ^ 78528438156864211L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                    if (v16 == (8317 ^ -8318)) break;
                    v16 = 23973 ^ 1599104372;
                }
                value = mapNameToInfoMap.get(mapName);
                v17 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl119
                block60: while (true) {
                    v17 = (43L ^ -5033369257046064727L) / (25421L ^ 5280136833227817696L);
lbl119:
                    // 2 sources

                    switch ((int)v17) {
                        case 571422857: {
                            continue block60;
                        }
                        case 1415186628: {
                            break block60;
                        }
                    }
                    break;
                }
                if (value.cachedMapId == null) {
                    while (true) {
                        if ((v18 = (cfr_temp_6 = MapCycleModule.\u13e8 - (9707L ^ -4596559992901524393L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                        if (v18 == (339 ^ 338)) {
                            this.cacheWorkMapIdOf(mapName, value);
                            break;
                        }
                        v18 = 22381 ^ -305618330;
                    }
                }
                while (true) {
                    if ((v19 = (cfr_temp_7 = MapCycleModule.\u13e8 - (6105L ^ 1089759061584547320L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                    if (v19 == (11386 ^ -11387)) break;
                    v19 = 14331 ^ -854487797;
                }
                if (!value.isRefreshable) continue;
                v20 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl142
                block63: while (true) {
                    v20 = v21 / (12952L ^ -971041324848623789L);
lbl142:
                    // 2 sources

                    switch ((int)v20) {
                        case -656387109: {
                            v21 = 26076L ^ -8282623719766246394L;
                            continue block63;
                        }
                        case 234822270: {
                            v21 = 6542L ^ -6498359972395186662L;
                            continue block63;
                        }
                        case 1415186628: {
                            break block63;
                        }
                    }
                    break;
                }
                v22 = value.cachedMapId;
                while (true) {
                    if ((v23 = (cfr_temp_8 = MapCycleModule.\u13e8 - (3527279535500834492L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                    if (v23 == (30907 ^ -30908)) {
                        ret.add(v22);
                        continue block56;
                    }
                    v23 = 15269 ^ -1758831705;
                }
                break;
            }
            v24 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl163
            block65: while (true) {
                v24 = v25 / (7341L ^ 5182617432832824175L);
lbl163:
                // 2 sources

                switch ((int)v24) {
                    case 232768451: {
                        v25 = 27020L ^ -1384783225068254628L;
                        continue block65;
                    }
                    case 1213259059: {
                        v25 = 22581L ^ -2694587611007236348L;
                        continue block65;
                    }
                    case 1415186628: {
                        break block65;
                    }
                }
                break;
            }
            this.cachedGetAllRefreshableMapIds = ret;
            v26 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl177
            block66: while (true) {
                v26 = (32129L ^ -1678145460437223679L) / (9067L ^ -2082848455422653020L);
lbl177:
                // 2 sources

                switch ((int)v26) {
                    case 1415186628: {
                        break block66;
                    }
                    case 1698870138: {
                        continue block66;
                    }
                }
                break;
            }
            v27 = System.currentTimeMillis();
            while (true) {
                if ((v28 = (cfr_temp_9 = MapCycleModule.\u13e8 - (6025L ^ -1253423084718091458L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
                if (v28 == (30408 ^ -30409)) break;
                v28 = 555845116 >>> "\u0000\u0000".length();
            }
            this.cacheExpiresGetAllRefreshableMapIdsStartMilis = v27;
            return ret;
        }
        while (true) {
            if ((v29 = (cfr_temp_10 = MapCycleModule.\u13e8 - (22665L ^ -3705598593052631835L)) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
            if (v29 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v29 = 15415 ^ 955359277;
        }
        return this.cachedGetAllRefreshableMapIds;
    }

    private boolean withinBeheKillWaitPeriod() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (-6810366839212215700L >>> "\u0000\u0000".length())) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == (0x625B ^ 0xFFFF9DA4)) break;
            l2 = 0x2895 ^ 0xD392F483;
        }
        return (this.getAfterNpcKillSecondsPast() != null ? "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length() : 0x86B ^ 0x86B) != 0;
    }

    /*
     * Enabled aggressive block sorting
     */
    private boolean tryChangeToRefreshConfig() {
        long l = \u13e8;
        block12: while (true) {
            switch ((int)l) {
                case 1415186628: {
                    break block12;
                }
                case 1719752033: {
                    l = (-2909022785441954992L >>> "\u0000\u0000".length()) / (0xC35L ^ 0xC7E65974579FB761L);
                    continue block12;
                }
            }
            break;
        }
        while (true) {
            long l2;
            long l3;
            if ((l3 = (l2 = \u13e8 - (0x2F1EL ^ 0x45B00B998F70A15FL)) == 0L ? 0 : (l2 < 0L ? -1 : 1)) == false) continue;
            if (l3 == (0x2D9F ^ 0xFFFFD260)) break;
            l3 = 0x1AFB ^ 0x94ED90AE;
        }
        long l4 = \u13e8;
        block14: while (true) {
            switch ((int)l4) {
                case 410982774: {
                    l4 = (0x571DL ^ 0x6A4A90039F736FEEL) / (0x515L ^ 0x4613AB5217D6483DL);
                    continue block14;
                }
                case 1415186628: {
                    break block14;
                }
            }
            break;
        }
        Config.ShipConfig shipConfig = this.mapCycleRefreshConfig.REFRESH_CONFIG;
        long l5 = \u13e8;
        block15: while (true) {
            switch ((int)l5) {
                case -150155889: {
                    l5 = (0xD38L ^ 0x8B2CB375D54B30A5L) / (0x9A8L ^ 0xC9B6A2765847AFC9L);
                    continue block15;
                }
                case 1415186628: {
                    return this.hero.setMode(shipConfig);
                }
            }
            break;
        }
        return this.hero.setMode(shipConfig);
    }

    /*
     * Unable to fully structure code
     */
    public boolean canRefresh() {
        block59: {
            block58: {
                while (true) {
                    if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (29508L ^ 4392539933566578783L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                    if (v0 == (155 ^ -156)) break;
                    v0 = 27914 ^ -300976855;
                }
                if (this.main == null) break block58;
                while (true) {
                    if ((v1 = (cfr_temp_1 = MapCycleModule.\u13e8 - (22777L ^ -5057810231331154322L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                    if (v1 == (31486 ^ 31487)) break;
                    v1 = 23558 ^ 1547502480;
                }
                if (this.mainConfig != null) break block59;
            }
            return "".length() >>> "\u0000\u0000".length();
        }
        v2 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl20
        block32: while (true) {
            v2 = v3 / (19088L ^ 7362283950105826023L);
lbl20:
            // 2 sources

            switch ((int)v2) {
                case -2071514176: {
                    v3 = 17092L ^ 1415540219397860406L;
                    continue block32;
                }
                case 234666718: {
                    v3 = 27055L ^ -5488202094823978740L;
                    continue block32;
                }
                case 1415186628: {
                    break block32;
                }
            }
            break;
        }
        v4 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl33
        block33: while (true) {
            v4 = v5 / (10646L ^ -8284810372852532048L);
lbl33:
            // 2 sources

            switch ((int)v4) {
                case -1471136147: {
                    v5 = 23123L ^ 3066250192982532357L;
                    continue block33;
                }
                case -339194355: {
                    v5 = 6012L ^ -5295202378610516068L;
                    continue block33;
                }
                case 1415186628: {
                    break block33;
                }
            }
            break;
        }
        onlyRefreshDuringWaitPeriodAfterKill = this.mapCycleRefreshConfig.ONLY_REFRESH_DURING_WAIT_PERIOD_AFTER_KILL;
        while (true) {
            if ((v6 = (cfr_temp_2 = MapCycleModule.\u13e8 - (21515L ^ -3641246971452194765L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v6 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v6 = 22031 ^ -583110096;
        }
        withinBeheKillWaitPeriod = this.withinBeheKillWaitPeriod();
        v7 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl53
        block35: while (true) {
            v7 = v8 / (7330L ^ -5487178943597977268L);
lbl53:
            // 2 sources

            switch ((int)v7) {
                case -1719884827: {
                    v8 = 18493L ^ -4560799010158878175L;
                    continue block35;
                }
                case -639797601: {
                    v8 = 26211L ^ 3975850422822567903L;
                    continue block35;
                }
                case 1415186628: {
                    break block35;
                }
            }
            break;
        }
        while (true) {
            if ((v9 = (cfr_temp_3 = MapCycleModule.\u13e8 - (19888L ^ 7426114811568494377L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v9 == (6054 ^ -6055)) break;
            v9 = 14059 ^ -1536194422;
        }
        v10 = this.hero.map;
        while (true) {
            if ((v11 = (cfr_temp_4 = MapCycleModule.\u13e8 - (1377898165741642720L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v11 == (15201 ^ -15202)) break;
            v11 = -406167900 >>> "\u0000\u0000".length();
        }
        currentMapId = v10.id;
        while (true) {
            if ((v12 = (cfr_temp_5 = MapCycleModule.\u13e8 - (569L ^ -7188934888094549262L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
            if (v12 == (19605 ^ 19604)) break;
            v12 = 11309 ^ -1135756853;
        }
        if (!this.isRefreshableMap(currentMapId) || onlyRefreshDuringWaitPeriodAfterKill && !withinBeheKillWaitPeriod) ** GOTO lbl-1000
        v13 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl84
        block39: while (true) {
            v13 = v14 / (3355L ^ -8206915502017758529L);
lbl84:
            // 2 sources

            switch ((int)v13) {
                case 1415186628: {
                    break block39;
                }
                case 1421130751: {
                    v14 = 68L ^ -834934032456892547L;
                    continue block39;
                }
                case 1451903603: {
                    v14 = 28080L ^ 3292524502387505072L;
                    continue block39;
                }
            }
            break;
        }
        while (true) {
            if ((v15 = (cfr_temp_6 = MapCycleModule.\u13e8 - (2755L ^ 3689265693682794263L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
            if (v15 == (6433 ^ -6434)) break;
            v15 = 26468 ^ -31750871;
        }
        if (this.mapCycleRefreshConfig.USE_IN_PLACE_REFRESH) ** GOTO lbl-1000
        v16 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl103
        block41: while (true) {
            v16 = v17 / (21705L ^ -1158432969601186149L);
lbl103:
            // 2 sources

            switch ((int)v16) {
                case 1054685427: {
                    v17 = 6421L ^ -5777346211082095763L;
                    continue block41;
                }
                case 1265521420: {
                    v17 = 4842L ^ 2958939700627639681L;
                    continue block41;
                }
                case 1415186628: {
                    break block41;
                }
            }
            break;
        }
        v18 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl116
        block42: while (true) {
            v18 = v19 / (11869L ^ -8055221590252647317L);
lbl116:
            // 2 sources

            switch ((int)v18) {
                case 283781149: {
                    v19 = 13666L ^ 8472249772841909339L;
                    continue block42;
                }
                case 1247217965: {
                    v19 = 10105L ^ 4584936853367794031L;
                    continue block42;
                }
                case 1415186628: {
                    break block42;
                }
            }
            break;
        }
        if (this.twLootNCollectModule.canRefresh()) lbl-1000:
        // 2 sources

        {
            v20 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        } else lbl-1000:
        // 2 sources

        {
            v20 = ret = 12560 ^ 12560;
        }
        if (ret != 0) {
            while (true) {
                if ((v21 = (cfr_temp_7 = MapCycleModule.\u13e8 - (24805L ^ -9038799437373979420L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                if (v21 == (2875 ^ 2874)) break;
                v21 = 25578 ^ -751095974;
            }
            while (true) {
                if ((v22 = (cfr_temp_8 = MapCycleModule.\u13e8 - (65L ^ 4391491971366668742L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                if (v22 == (500 ^ -501)) break;
                v22 = 21905 ^ -472964486;
            }
            if (this.mapCycleRefreshConfig.ENABLE_REFRESH_CONFIG) {
                while (true) {
                    if ((v23 = (cfr_temp_9 = MapCycleModule.\u13e8 - (6975L ^ 5336710907622190012L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
                    if (v23 == (185 ^ -186)) break;
                    v23 = 879629172 >>> "\u0000\u0000".length();
                }
                ret = (int)this.tryChangeToRefreshConfig();
                v24 = ret == 0 ? 5903 ^ 5902 : 1215 ^ 1215;
                while (true) {
                    if ((v25 = (cfr_temp_10 = MapCycleModule.\u13e8 - (23989L ^ 2482836212566629161L)) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
                    if (v25 == (19529 ^ -19530)) {
                        this.requiresChangeToRefreshConfig = v24;
                        break;
                    }
                    v25 = 19969 ^ -1251793240;
                }
            }
        }
        if (ret != 0) {
            while (true) {
                if ((v26 = (cfr_temp_11 = MapCycleModule.\u13e8 - (3237L ^ -4583950540720465791L)) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
                if (v26 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                    UserLogs.LogRefreshingOnMap(this, currentMapId);
                    break;
                }
                v26 = 525 ^ 1528332841;
            }
        }
        return (boolean)ret;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void markAllLogsAsRead() {
        long l = \u13e8;
        block4: while (true) {
            switch ((int)l) {
                case -1976133679: {
                    l = (0x2E23L ^ 0x9447B0CAE47764C3L) / (2613765664247215484L >>> "\u0000\u0000".length());
                    continue block4;
                }
                case 1415186628: {
                    break block4;
                }
            }
            break;
        }
        this.CheckUnseenLogLines();
    }

    /*
     * Enabled aggressive block sorting
     */
    private void markLatestDeathsKnown() {
        long l = \u13e8;
        block8: while (true) {
            switch ((int)l) {
                case 1415186628: {
                    break block8;
                }
                case 1809426803: {
                    l = (0x52DDL ^ 0x9991DE3461D36666L) / (0x2B2CL ^ 0x4908FC9DB40562D6L);
                    continue block8;
                }
            }
            break;
        }
        while (true) {
            long l2;
            long l3;
            if ((l3 = (l2 = \u13e8 - (0x5EAFL ^ 0xD521A16D005A2B93L)) == 0L ? 0 : (l2 < 0L ? -1 : 1)) == false) continue;
            if (l3 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l3 = 0x3AD4 ^ 0xFB3F441D;
        }
        GuiManager guiManager = this.main.guiManager;
        long l4 = \u13e8;
        block10: while (true) {
            switch ((int)l4) {
                case 1078271298: {
                    l4 = (0x7BB2L ^ 0x65D0E6B195DC2345L) / (0x1EC0L ^ 0xD6E279C78215C725L);
                    continue block10;
                }
                case 1415186628: {
                    break block10;
                }
            }
            break;
        }
        int n = guiManager.deaths;
        while (true) {
            long l5;
            long l6;
            if ((l6 = (l5 = \u13e8 - (0x77FFL ^ 0x780706EC51861270L)) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) continue;
            if (l6 == (0x79A1 ^ 0xFFFF865E)) {
                this.lastKnownDeaths = n;
                return;
            }
            l6 = 0x108C ^ 0xE2C84BFC;
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private boolean hasDied() {
        boolean bl = "".length() >>> "\u0000\u0000".length();
        long l = \u13e8;
        boolean bl2 = true;
        block6: while (true) {
            long l2;
            if (!bl2 || (bl2 = false) || !true) {
                l = l2 / (0x3C07L ^ 0x685B899B9EF2A95BL);
            }
            switch ((int)l) {
                case -429106001: {
                    l2 = 0x4D40L ^ 0xC5925735F0A0C045L;
                    continue block6;
                }
                case -5037974: {
                    l2 = 0x367FL ^ 0xB6827DB64FFB8A08L;
                    continue block6;
                }
                case 221463599: {
                    l2 = 0x56A3L ^ 0xDEDAF78A49877BA4L;
                    continue block6;
                }
                case 1415186628: {
                    return this.hasDied(bl);
                }
            }
            break;
        }
        return this.hasDied(bl);
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private boolean hasDied(boolean silent) {
        boolean died;
        int latestKnownDeaths;
        block23: {
            boolean bl;
            block22: {
                long l = \u13e8;
                boolean bl2 = true;
                block12: while (true) {
                    long l2;
                    if (!bl2 || (bl2 = false) || !true) {
                        l = l2 / (0x502AL ^ 0xB5D3B8FBD6E8CA70L);
                    }
                    switch ((int)l) {
                        case -2088468444: {
                            l2 = 0x589BL ^ 0xFB53668999D3AD6EL;
                            continue block12;
                        }
                        case -231254001: {
                            l2 = 0x3B2L ^ 0xAF26810C1153E2FEL;
                            continue block12;
                        }
                        case 606589987: {
                            l2 = -4635070591924988012L >>> "\u0000\u0000".length();
                            continue block12;
                        }
                        case 1415186628: {
                            break block12;
                        }
                    }
                    break;
                }
                int oldDeathCount = this.lastKnownDeaths;
                while (true) {
                    long l3;
                    long l4;
                    if ((l4 = (l3 = \u13e8 - (-7023779548247120972L >>> "\u0000\u0000".length())) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) continue;
                    if (l4 == (0x2D05 ^ 0xFFFFD2FA)) break;
                    l4 = 0x7C36 ^ 0xE6EA8741;
                }
                while (true) {
                    long l5;
                    long l6;
                    if ((l6 = (l5 = \u13e8 - (0x2147L ^ 0xB5B94CA753C94E1FL)) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) continue;
                    if (l6 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                    l6 = 0x564A ^ 0xA55BE810;
                }
                GuiManager guiManager = this.main.guiManager;
                while (true) {
                    long l7;
                    long l8;
                    if ((l8 = (l7 = \u13e8 - (0x7C24L ^ 0xAA1CDCA07E78F0AL)) == 0L ? 0 : (l7 < 0L ? -1 : 1)) == false) continue;
                    if (l8 == (0x132E ^ 0xFFFFECD1)) {
                        latestKnownDeaths = guiManager.deaths;
                        if (oldDeathCount < latestKnownDeaths) {
                            break;
                        }
                        break block22;
                    }
                    l8 = 0x6D65 ^ 0xEFE90A21;
                }
                bl = 0x2D6 ^ 0x2D7;
                break block23;
            }
            bl = died = "".length() >>> "\u0000\u0000".length();
        }
        if (!silent) {
            long l = \u13e8;
            boolean bl = true;
            block16: while (true) {
                long l9;
                if (!bl || (bl = false) || !true) {
                    l = l9 / (0x19EEL ^ 0x9410B4F375171288L);
                }
                switch ((int)l) {
                    case -1603377512: {
                        l9 = 0x4EFCL ^ 0xFD8164AEABCB76A7L;
                        continue block16;
                    }
                    case -1584714977: {
                        l9 = 0x7DF8L ^ 0x2D34319A90605509L;
                        continue block16;
                    }
                    case -1165759583: {
                        l9 = 311583359862339800L >>> "\u0000\u0000".length();
                        continue block16;
                    }
                    case 1415186628: {
                        break block16;
                    }
                }
                break;
            }
            this.lastKnownDeaths = latestKnownDeaths;
        }
        return died;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private boolean hasRevived() {
        boolean bl;
        long l = \u13e8;
        block14: while (true) {
            switch ((int)l) {
                case -26052161: {
                    l = (3500790849020507068L >>> "\u0000\u0000".length()) / (0x36A5L ^ 0xAAE949D150F451FCL);
                    continue block14;
                }
                case 1415186628: {
                    break block14;
                }
            }
            break;
        }
        long l2 = \u13e8;
        boolean bl2 = true;
        block15: while (true) {
            long l3;
            if (!bl2 || (bl2 = false) || !true) {
                l2 = l3 / (-8314576430849666588L >>> "\u0000\u0000".length());
            }
            switch ((int)l2) {
                case -1009164346: {
                    l3 = 0x3428L ^ 0x5AA91DC1E33E2771L;
                    continue block15;
                }
                case -203635810: {
                    l3 = 0x27F2L ^ 0xD7A9E1E201631899L;
                    continue block15;
                }
                case 214424524: {
                    l3 = 2680341878023589168L >>> "\u0000\u0000".length();
                    continue block15;
                }
                case 1415186628: {
                    break block15;
                }
            }
            break;
        }
        Health health = this.hero.health;
        long l4 = \u13e8;
        block16: while (true) {
            switch ((int)l4) {
                case -1453199460: {
                    l4 = (0x3F2DL ^ 0x7830D4EEF95EF9CDL) / (0x2564L ^ 0x1BD35B3E574ABAB7L);
                    continue block16;
                }
                case 1415186628: {
                    break block16;
                }
            }
            break;
        }
        if (health.getHp() > 0) {
            bl = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
            return bl;
        }
        bl = "".length() >>> "\u0000\u0000".length();
        return bl;
    }

    /*
     * Unable to fully structure code
     */
    private void switchToMap(int currentMapId, Integer nextMapId, String reason) {
        if (nextMapId == null) {
            return;
        }
        v0 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl7
        block35: while (true) {
            v0 = v1 / (4041L ^ -8190930577312743992L);
lbl7:
            // 2 sources

            switch ((int)v0) {
                case -931352582: {
                    v1 = -1962053341432130140L >>> "\u0000\u0000".length();
                    continue block35;
                }
                case 826749504: {
                    v1 = 8739L ^ 99967644417411690L;
                    continue block35;
                }
                case 838444070: {
                    v1 = 18265L ^ -1978968101824510906L;
                    continue block35;
                }
                case 1415186628: {
                    break block35;
                }
            }
            break;
        }
        v2 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl23
        block36: while (true) {
            v2 = (9802L ^ -7892516503136232904L) / (21620L ^ 301566283380234788L);
lbl23:
            // 2 sources

            switch ((int)v2) {
                case -220728380: {
                    continue block36;
                }
                case 1415186628: {
                    break block36;
                }
            }
            break;
        }
        this.shootingBeheState.reset();
        v3 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl33
        block37: while (true) {
            v3 = v4 / (48L ^ 2710547490713732590L);
lbl33:
            // 2 sources

            switch ((int)v3) {
                case -791692731: {
                    v4 = 11222L ^ -8816077123744520392L;
                    continue block37;
                }
                case 300801961: {
                    v4 = 21372L ^ 6912359022779664105L;
                    continue block37;
                }
                case 487337685: {
                    v4 = -7090431894971471728L >>> "\u0000\u0000".length();
                    continue block37;
                }
                case 1415186628: {
                    break block37;
                }
            }
            break;
        }
        v5 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl49
        block38: while (true) {
            v5 = (16012L ^ -4180185690704534090L) / (-8081820530853189964L >>> "\u0000\u0000".length());
lbl49:
            // 2 sources

            switch ((int)v5) {
                case 1415186628: {
                    break block38;
                }
                case 2088498931: {
                    continue block38;
                }
            }
            break;
        }
        v6 = this.mainConfig.GENERAL;
        while (true) {
            if ((v7 = (cfr_temp_0 = MapCycleModule.\u13e8 - (8166L ^ 8555087133754906353L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v7 == (5320 ^ -5321)) break;
            v7 = 1953 ^ -1296171882;
        }
        v8 = nextMapId;
        v9 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl65
        block40: while (true) {
            v9 = (17788L ^ 7480714664798149150L) / (-1180432465192765364L >>> "\u0000\u0000".length());
lbl65:
            // 2 sources

            switch ((int)v9) {
                case -1761310146: {
                    continue block40;
                }
                case 1415186628: {
                    break block40;
                }
            }
            break;
        }
        v6.WORKING_MAP = v8;
        while (true) {
            if ((v10 = (cfr_temp_1 = MapCycleModule.\u13e8 - (18872L ^ -3420962496646048005L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v10 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v10 = 31288 ^ -811630799;
        }
        v11 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl80
        block42: while (true) {
            v11 = v12 / (23257L ^ -7147372036715193489L);
lbl80:
            // 2 sources

            switch ((int)v11) {
                case -2038720118: {
                    v12 = 2099L ^ 6604428065759466806L;
                    continue block42;
                }
                case 1300625728: {
                    v12 = 7412L ^ 2537766330598990537L;
                    continue block42;
                }
                case 1415186628: {
                    break block42;
                }
            }
            break;
        }
        v13 = this.main.starManager;
        while (true) {
            if ((v14 = (cfr_temp_2 = MapCycleModule.\u13e8 - (14016L ^ -3944459339170640785L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v14 == (27948 ^ 27949)) break;
            v14 = 10999 ^ -1266743908;
        }
        v15 = nextMapId;
        v16 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl100
        block44: while (true) {
            v16 = v17 / (-3157832092019075936L >>> "\u0000\u0000".length());
lbl100:
            // 2 sources

            switch ((int)v16) {
                case -1896884483: {
                    v17 = -94812462449596040L >>> "\u0000\u0000".length();
                    continue block44;
                }
                case 396972476: {
                    v17 = 12897L ^ -9220237691249429651L;
                    continue block44;
                }
                case 1415186628: {
                    break block44;
                }
                case 1803717495: {
                    v17 = 2181L ^ -4281251168314269396L;
                    continue block44;
                }
            }
            break;
        }
        v18 = v13.byId(v15);
        while (true) {
            if ((v19 = (cfr_temp_3 = MapCycleModule.\u13e8 - (13726L ^ -5483277432613634855L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v19 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v19 = 1375732968 >>> "\u0000\u0000".length();
        }
        v20 = v18.name;
        while (true) {
            if ((v21 = (cfr_temp_4 = MapCycleModule.\u13e8 - (22499L ^ 8028898668817898383L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v21 == (1194 ^ -1195)) break;
            v21 = 6509 ^ -605932418;
        }
        while (true) {
            if ((v22 = (cfr_temp_5 = MapCycleModule.\u13e8 - (16097L ^ -7633285597345033859L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
            if (v22 == (20288 ^ 20289)) break;
            v22 = 23947 ^ -1457705783;
        }
        v23 = this.main.starManager;
        while (true) {
            if ((v24 = (cfr_temp_6 = MapCycleModule.\u13e8 - (25951L ^ -3059231067711718357L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
            if (v24 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v24 = 32699 ^ 2109933058;
        }
        v25 = v23.byId(currentMapId);
        while (true) {
            if ((v26 = (cfr_temp_7 = MapCycleModule.\u13e8 - (-999999012058645628L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
            if (v26 == (29689 ^ -29690)) break;
            v26 = -1149600756 >>> "\u0000\u0000".length();
        }
        v27 = v25.name;
        while (true) {
            if ((v28 = (cfr_temp_8 = MapCycleModule.\u13e8 - (27934L ^ -3498370701044683518L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
            if (v28 == (24247 ^ 24246)) break;
            v28 = 23064 ^ -543699715;
        }
        UserLogs.LogSwitchingMaps(this, reason, v20, v27);
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private BoxInfo getBoxInfo(String name) {
        long l = \u13e8;
        boolean bl = true;
        block5: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x60D7L ^ 0xBE03006DD583A779L);
            }
            switch ((int)l) {
                case -2043943190: {
                    l2 = 0x2863L ^ 0x20C1C58DB5823858L;
                    continue block5;
                }
                case -1098284409: {
                    l2 = 0x1C3AL ^ 0x46FDF88180B429FCL;
                    continue block5;
                }
                case 1415186628: {
                    break block5;
                }
            }
            break;
        }
        while (true) {
            long l3;
            long l4;
            if ((l4 = (l3 = \u13e8 - (999849867781795264L >>> "\u0000\u0000".length())) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) continue;
            if (l4 == (0x3C98 ^ 0xFFFFC367)) break;
            l4 = 0x267B ^ 0x4F625975;
        }
        Config.Collect collect = this.mainConfig.COLLECT;
        while (true) {
            long l5;
            long l6;
            if ((l6 = (l5 = \u13e8 - (0x4CF0L ^ 0x9F748E21A948D814L)) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) continue;
            if (l6 == (0x170A ^ 0x170B)) break;
            l6 = 0x4567 ^ 0xFE605B81;
        }
        Map map = collect.BOX_INFOS;
        while (true) {
            long l7;
            long l8;
            if ((l8 = (l7 = \u13e8 - (0x1597L ^ 0xCDA2EC78F79AA4BBL)) == 0L ? 0 : (l7 < 0L ? -1 : 1)) == false) continue;
            if (l8 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                return (BoxInfo)map.get(name);
            }
            l8 = 0x2AE6 ^ 0xC8B6AB1B;
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private void EnableCollectBeheBox(boolean enable) {
        long l = \u13e8;
        block10: while (true) {
            switch ((int)l) {
                case 1415186628: {
                    break block10;
                }
                case 1855641928: {
                    l = (0x6A0DL ^ 0xA00DCEF299028A3EL) / (0x1EEBL ^ 0xA96304DA79895635L);
                    continue block10;
                }
            }
            break;
        }
        long l2 = \u13e8;
        boolean bl = true;
        block11: while (true) {
            long l3;
            if (!bl || (bl = false) || !true) {
                l2 = l3 / (0x3AC5L ^ 0x245FA925E6A25346L);
            }
            switch ((int)l2) {
                case -836792809: {
                    l3 = 0x5DDDL ^ 0x69275F9526A87DF1L;
                    continue block11;
                }
                case 1415186628: {
                    break block11;
                }
                case 1438272305: {
                    l3 = 0x61A7L ^ 0x93C4D75E3716D459L;
                    continue block11;
                }
                case 1728781802: {
                    l3 = 0x1B63L ^ 0x265AD93B096BE2C7L;
                    continue block11;
                }
            }
            break;
        }
        BoxInfo beheBoxInto = this.getBoxInfo(this.BEHE_BOX_NAME);
        if (beheBoxInto == null) return;
        while (true) {
            long l4;
            long l5;
            if ((l5 = (l4 = \u13e8 - (0x8A1L ^ 0x6616F9D7FAFDE7D4L)) == 0L ? 0 : (l4 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l5 == (0x39CD ^ 0xFFFFC632)) {
                beheBoxInto.collect = enable;
                return;
            }
            l5 = 0x4C67 ^ 0xBFAAD8AD;
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private void StartServerRestartHandler() {
        long l = \u13e8;
        boolean bl = true;
        block23: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (7574529769443816968L >>> "\u0000\u0000".length());
            }
            switch ((int)l) {
                case -618592407: {
                    l2 = 0x7910L ^ 0xC46CED496CE292F5L;
                    continue block23;
                }
                case 480013212: {
                    l2 = 0x1C2BL ^ 0x78948D1736AB26D0L;
                    continue block23;
                }
                case 1415186628: {
                    break block23;
                }
                case 1488359343: {
                    l2 = 0x5DBAL ^ 0xD209A5F2D8B6075DL;
                    continue block23;
                }
            }
            break;
        }
        while (true) {
            long l3;
            long l4;
            if ((l4 = (l3 = \u13e8 - (0x4CA5L ^ 0x43F699D5C2DAF23FL)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) continue;
            if (l4 == (0x238C ^ 0xFFFFDC73)) break;
            l4 = 0xABB ^ 0xBA6595D1;
        }
        int restartMinsDelay = this.serverRestartHandlerConfig.SERVER_RESTART_MINS_DELAY;
        long l5 = \u13e8;
        block25: while (true) {
            switch ((int)l5) {
                case 470032071: {
                    l5 = (0x207L ^ 0xEB9ACB6408FD7194L) / (0x4EB3L ^ 0xD0CA942225B934FAL);
                    continue block25;
                }
                case 1415186628: {
                    break block25;
                }
            }
            break;
        }
        UserLogs.LogStartedServerRestartHandler(this, restartMinsDelay);
        long serverRestartMS = (240000 >>> "\u0000\u0000".length()) * restartMinsDelay;
        long l6 = \u13e8;
        block26: while (true) {
            switch ((int)l6) {
                case -786224459: {
                    l6 = (0x7F15L ^ 0xD22C5D4FA5AE0006L) / (0x5D15L ^ 0xBFDB65969777DF50L);
                    continue block26;
                }
                case 1415186628: {
                    break block26;
                }
            }
            break;
        }
        long l7 = \u13e8;
        block27: while (true) {
            switch ((int)l7) {
                case 1222542692: {
                    l7 = (0x137FL ^ 0xBCBB908BE4B70BD0L) / (0xD98L ^ 0x6F3B492F8C54197DL);
                    continue block27;
                }
                case 1415186628: {
                    break block27;
                }
            }
            break;
        }
        IAction iAction = () -> {
            while (true) {
                long l;
                long l2;
                if ((l2 = (l = \u13e8 - (0x4E40L ^ 0xFACB8D8B620B00F9L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
                if (l2 == (0x1B66 ^ 0xFFFFE499)) break;
                l2 = 1108144448 >>> "\u0000\u0000".length();
            }
            this.HandleAfterRestart();
        };
        long l8 = \u13e8;
        boolean bl2 = true;
        block28: while (true) {
            long l9;
            if (!bl2 || (bl2 = false) || !true) {
                l8 = l9 / (0x7BFFL ^ 0xDDC0F007819A0034L);
            }
            switch ((int)l8) {
                case -288254575: {
                    l9 = 0x63B7L ^ 0x5561CC7E2C1A9735L;
                    continue block28;
                }
                case 1415186628: {
                    break block28;
                }
                case 1516741497: {
                    l9 = 0x7F23L ^ 0x4F7CD0E2C8DBC2BL;
                    continue block28;
                }
            }
            break;
        }
        this.scheduledActionManager.add(serverRestartMS, iAction);
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private boolean shouldDisableBeheBoxesAfterRestart() {
        long l = \u13e8;
        block10: while (true) {
            switch ((int)l) {
                case 1116252696: {
                    l = (-8161817605388598864L >>> "\u0000\u0000".length()) / (5777860493102046400L >>> "\u0000\u0000".length());
                    continue block10;
                }
                case 1415186628: {
                    break block10;
                }
            }
            break;
        }
        long l2 = \u13e8;
        boolean bl = true;
        block11: while (true) {
            long l3;
            if (!bl || (bl = false) || !true) {
                l2 = l3 / (0x44E9L ^ 0xD2AD8B10A1D7F101L);
            }
            switch ((int)l2) {
                case -1176550855: {
                    l3 = 0x62D7L ^ 0x93E66CCB3A2737F7L;
                    continue block11;
                }
                case 584289035: {
                    l3 = 210143151034977876L >>> "\u0000\u0000".length();
                    continue block11;
                }
                case 1371173927: {
                    l3 = 0x5A9L ^ 0xB16C2CF563F3E43EL;
                    continue block11;
                }
                case 1415186628: {
                    return this.serverRestartHandlerConfig.STOP_COLLECT_BEHE_BOXES_AFTER_SERVER_RESTART;
                }
            }
            break;
        }
        return this.serverRestartHandlerConfig.STOP_COLLECT_BEHE_BOXES_AFTER_SERVER_RESTART;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private void reverseRotation() {
        long l = \u13e8;
        boolean bl = true;
        block28: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x5D90L ^ 0x565DDF1CB005E875L);
            }
            switch ((int)l) {
                case 245557968: {
                    l2 = 0x4D20L ^ 0xC6447778BE686FE6L;
                    continue block28;
                }
                case 1415186628: {
                    break block28;
                }
                case 1665421674: {
                    l2 = 0x4386L ^ 0x2FBCAA9F9F1F9809L;
                    continue block28;
                }
            }
            break;
        }
        long l3 = \u13e8;
        boolean bl2 = true;
        block29: while (true) {
            long l4;
            if (!bl2 || (bl2 = false) || !true) {
                l3 = l4 / (0xB14L ^ 0x8CF84D5DD0E9A325L);
            }
            switch ((int)l3) {
                case -2144631619: {
                    l4 = 0x35A0L ^ 0xE966884EFAF5F101L;
                    continue block29;
                }
                case -347869955: {
                    l4 = 0x1CF0L ^ 0x8658E40B2C13988BL;
                    continue block29;
                }
                case 1415186628: {
                    break block29;
                }
            }
            break;
        }
        Map<String, MapInfo> map = this.mapCycleConfig.CYCLE_MAP_INFOS;
        long l5 = \u13e8;
        boolean bl3 = true;
        block30: while (true) {
            long l6;
            if (!bl3 || (bl3 = false) || !true) {
                l5 = l6 / (-6158914690351826336L >>> "\u0000\u0000".length());
            }
            switch ((int)l5) {
                case -903655839: {
                    l6 = 0x447EL ^ 0x66B04AA5D06166C7L;
                    continue block30;
                }
                case -64419375: {
                    l6 = 0x2E82L ^ 0xD518D20C22A5655FL;
                    continue block30;
                }
                case 1135045667: {
                    l6 = 9013190397777717044L >>> "\u0000\u0000".length();
                    continue block30;
                }
                case 1415186628: {
                    break block30;
                }
            }
            break;
        }
        Collection<MapInfo> collection = map.values();
        while (true) {
            long l7;
            long l8;
            if ((l8 = (l7 = \u13e8 - (-6362382612153804556L >>> "\u0000\u0000".length())) == 0L ? 0 : (l7 < 0L ? -1 : 1)) == false) continue;
            if (l8 == (0x5E5 ^ 0xFFFFFA1A)) break;
            l8 = 0x20B4 ^ 0x3C0AF68D;
        }
        Iterator<MapInfo> iterator = collection.iterator();
        block32: while (true) {
            MapInfo mapInfo;
            long l9;
            long l10;
            if ((l10 = (l9 = \u13e8 - (0x7E4FL ^ 0x8C750F774AAD705EL)) == 0L ? 0 : (l9 < 0L ? -1 : 1)) == false) continue;
            if (l10 == (0xB2C ^ 0xB2D)) {
                if (!iterator.hasNext()) {
                    return;
                }
            } else {
                l10 = 0x2F1A ^ 0xFF073530;
                continue;
            }
            while (true) {
                long l11;
                long l12;
                if ((l12 = (l11 = \u13e8 - (0x183DL ^ 0x328B4320DB7EBACBL)) == 0L ? 0 : (l11 < 0L ? -1 : 1)) == false) continue;
                if (l12 == (0x7B86 ^ 0xFFFF8479)) {
                    mapInfo = iterator.next();
                    if (mapInfo == null) continue block32;
                    break;
                }
                l12 = 582111196 >>> "\u0000\u0000".length();
            }
            long l13 = \u13e8;
            boolean bl4 = true;
            block34: while (true) {
                long l14;
                if (!bl4 || (bl4 = false) || !true) {
                    l13 = l14 / (0x3383L ^ 0xBAD328CAF96F2DDBL);
                }
                switch ((int)l13) {
                    case -65765039: {
                        l14 = 0x7695L ^ 0x8E63FFD758F18E5EL;
                        continue block34;
                    }
                    case 110943004: {
                        l14 = 0x6B36L ^ 0xDBB52A76D54BA673L;
                        continue block34;
                    }
                    case 1415186628: {
                        break block34;
                    }
                    case 1427195652: {
                        l14 = -5665990708580151564L >>> "\u0000\u0000".length();
                        continue block34;
                    }
                }
                break;
            }
            int n = mapInfo.priority * (0x577 ^ 0xFFFFFA88);
            long l15 = \u13e8;
            boolean bl5 = true;
            block35: while (true) {
                long l16;
                if (!bl5 || (bl5 = false) || !true) {
                    l15 = l16 / (0x6FF2L ^ 0x23AF4D59CBA29C6EL);
                }
                switch ((int)l15) {
                    case -1399484032: {
                        l16 = 0x4E5FL ^ 0xB41138B5A071D4BDL;
                        continue block35;
                    }
                    case 505430575: {
                        l16 = 0x5136L ^ 0xDAA906F542CB1118L;
                        continue block35;
                    }
                    case 959105723: {
                        l16 = 0x2212L ^ 0xC628027213100BA2L;
                        continue block35;
                    }
                    case 1415186628: {
                        break block35;
                    }
                }
                break;
            }
            mapInfo.priority = n;
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private void resetState() {
        long l = \u13e8;
        block9: while (true) {
            switch ((int)l) {
                case -771128342: {
                    l = (0x1AA8L ^ 0x1F5A36BF282D6D9L) / (0x73B5L ^ 0xF229B4407F852179L);
                    continue block9;
                }
                case 1415186628: {
                    break block9;
                }
            }
            break;
        }
        this.resetAdaptiveMapIdToTimeSpent();
        long l2 = \u13e8;
        boolean bl = true;
        block10: while (true) {
            long l3;
            if (!bl || (bl = false) || !true) {
                l2 = l3 / (0xFDEL ^ 0xC60B15D06A28D36AL);
            }
            switch ((int)l2) {
                case -2093559640: {
                    l3 = 0x26C8L ^ 0x73B7E6949E3845CDL;
                    continue block10;
                }
                case 1415186628: {
                    break block10;
                }
                case 1953278922: {
                    l3 = 0x7539L ^ 0x7901FD1277823110L;
                    continue block10;
                }
            }
            break;
        }
        while (true) {
            long l4;
            long l5;
            if ((l5 = (l4 = \u13e8 - (0x18CDL ^ 0xC329694BB175699FL)) == 0L ? 0 : (l4 < 0L ? -1 : 1)) == false) continue;
            if (l5 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l5 = 0x4A35 ^ 0x4CDA40C6;
        }
        this.shootingBeheState.reset();
        while (true) {
            long l6;
            long l7;
            if ((l7 = (l6 = \u13e8 - (0x3E34L ^ 0xE9508A4C1E4AC6AAL)) == 0L ? 0 : (l6 < 0L ? -1 : 1)) == false) continue;
            if (l7 == (0xCA8 ^ 0xFFFFF357)) {
                this.markLatestDeathsKnown();
                return;
            }
            l7 = 0x2A2D ^ 0xF863F267;
        }
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private void HandleAfterRestart() {
        block95: {
            block98: {
                block97: {
                    block96: {
                        while (true) {
                            if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (23843L ^ -2600854230930020345L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                            if (v0 == (22731 ^ -22732)) break;
                            v0 = 15726 ^ 2024749779;
                        }
                        UserLogs.LogRestartComplete(this);
                        v1 = "".length() >>> "\u0000\u0000".length();
                        while (true) {
                            if ((v2 = (cfr_temp_1 = MapCycleModule.\u13e8 - (-3821561902790705084L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                            if (v2 == (4202 ^ -4203)) break;
                            v2 = 17491 ^ 1663092687;
                        }
                        this.startedHandlerAfterServerRestart = v1;
                        while (true) {
                            if ((v3 = (cfr_temp_2 = MapCycleModule.\u13e8 - (3267L ^ 8829318591707503597L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                            if (v3 == (9918 ^ -9919)) break;
                            v3 = 19294 ^ -3110856;
                        }
                        if (this.oldPredictNpcSpawnMapChangeCondConfigEnableState == null) break block96;
                        while (true) {
                            if ((v4 = (cfr_temp_3 = MapCycleModule.\u13e8 - (25414L ^ -3043202747929105906L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                            if (v4 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                            v4 = 26826 ^ -864513270;
                        }
                        while (true) {
                            if ((v5 = (cfr_temp_4 = MapCycleModule.\u13e8 - (14302L ^ -7313896074302650444L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                            if (v5 == (20502 ^ 20503)) break;
                            v5 = 23172 ^ -1594754246;
                        }
                        v6 = this.predictNpcSpawnConfig.MAP_CHANGE_COND_CONFIG;
                        v7 = MapCycleModule.\u13e8;
                        if (true) ** GOTO lbl35
                        block70: while (true) {
                            v7 = (32424L ^ 6996866217393461247L) / (28179L ^ -6262769711749034856L);
lbl35:
                            // 2 sources

                            switch ((int)v7) {
                                case 1415186628: {
                                    break block70;
                                }
                                case 1564548908: {
                                    continue block70;
                                }
                            }
                            break;
                        }
                        v8 = MapCycleModule.\u13e8;
                        if (true) ** GOTO lbl44
                        block71: while (true) {
                            v8 = v9 / (23032L ^ -1578336215900163235L);
lbl44:
                            // 2 sources

                            switch ((int)v8) {
                                case -1641593773: {
                                    v9 = 4263008601795741572L >>> "\u0000\u0000".length();
                                    continue block71;
                                }
                                case 1415186628: {
                                    break block71;
                                }
                                case 1511711641: {
                                    v9 = 5160L ^ -1692954670379060309L;
                                    continue block71;
                                }
                                case 1636566502: {
                                    v9 = 17462L ^ -5851743876106414094L;
                                    continue block71;
                                }
                            }
                            break;
                        }
                        v10 = this.oldPredictNpcSpawnMapChangeCondConfigEnableState;
                        v11 = MapCycleModule.\u13e8;
                        if (true) ** GOTO lbl61
                        block72: while (true) {
                            v11 = v12 / (32129L ^ 7916053360320326244L);
lbl61:
                            // 2 sources

                            switch ((int)v11) {
                                case -1213786266: {
                                    v12 = 9707L ^ -1082705156584868682L;
                                    continue block72;
                                }
                                case 3665498: {
                                    v12 = 9224L ^ -7562819492164812098L;
                                    continue block72;
                                }
                                case 1415186628: {
                                    break block72;
                                }
                            }
                            break;
                        }
                        v6.ENABLE = v10;
                    }
                    v13 = MapCycleModule.\u13e8;
                    if (true) ** GOTO lbl76
                    block73: while (true) {
                        v13 = (7073L ^ 1067498301586438515L) / (-8685445943366962280L >>> "\u0000\u0000".length());
lbl76:
                        // 2 sources

                        switch ((int)v13) {
                            case -1389328823: {
                                continue block73;
                            }
                            case 1415186628: {
                                break block73;
                            }
                        }
                        break;
                    }
                    v14 = MapCycleModule.\u13e8;
                    if (true) ** GOTO lbl85
                    block74: while (true) {
                        v14 = (-6369175487427077792L >>> "\u0000\u0000".length()) / (4007L ^ 5370474565173053968L);
lbl85:
                        // 2 sources

                        switch ((int)v14) {
                            case -1969405713: {
                                continue block74;
                            }
                            case 1415186628: {
                                break block74;
                            }
                        }
                        break;
                    }
                    if (!this.serverRestartHandlerConfig.REVERSE_ROTATION_ON_SERVER_RESTART) break block97;
                    v15 = MapCycleModule.\u13e8;
                    if (true) ** GOTO lbl95
                    block75: while (true) {
                        v15 = v16 / (5104L ^ -5736957504350437921L);
lbl95:
                        // 2 sources

                        switch ((int)v15) {
                            case -1708693866: {
                                v16 = 15018L ^ 5876333485747998048L;
                                continue block75;
                            }
                            case -1131860481: {
                                v16 = 19694L ^ -363938403950279363L;
                                continue block75;
                            }
                            case 90119263: {
                                v16 = 25910L ^ -7704939395687249045L;
                                continue block75;
                            }
                            case 1415186628: {
                                break block75;
                            }
                        }
                        break;
                    }
                    this.reverseRotation();
                }
                while (true) {
                    if ((v17 = (cfr_temp_5 = MapCycleModule.\u13e8 - (13210L ^ 6932709598396656964L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                    if (v17 == (27329 ^ -27330)) break;
                    v17 = 8988 ^ -176207738;
                }
                this.resetState();
                v18 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl119
                block77: while (true) {
                    v18 = v19 / (31566L ^ 5850412536696310544L);
lbl119:
                    // 2 sources

                    switch ((int)v18) {
                        case -1747301712: {
                            v19 = 3401895653571375332L >>> "\u0000\u0000".length();
                            continue block77;
                        }
                        case 1250078597: {
                            v19 = 10731L ^ 5298157693461623528L;
                            continue block77;
                        }
                        case 1402798601: {
                            v19 = 8169L ^ -1574779905087492117L;
                            continue block77;
                        }
                        case 1415186628: {
                            break block77;
                        }
                    }
                    break;
                }
                if (this.shouldDisableBeheBoxesAfterRestart()) {
                    v20 = "".length() >>> "\u0000\u0000".length();
                    while (true) {
                        if ((v21 = (cfr_temp_6 = MapCycleModule.\u13e8 - (7911L ^ 2204380480181800592L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                        if (v21 == (8965 ^ -8966)) {
                            this.EnableCollectBeheBox(v20);
                            break;
                        }
                        v21 = 31443 ^ -712593905;
                    }
                }
                v22 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl144
                block79: while (true) {
                    v22 = v23 / (8395591794036291760L >>> "\u0000\u0000".length());
lbl144:
                    // 2 sources

                    switch ((int)v22) {
                        case 392902502: {
                            v23 = 4118L ^ -889205107129492303L;
                            continue block79;
                        }
                        case 1362798441: {
                            v23 = -8162834607637117620L >>> "\u0000\u0000".length();
                            continue block79;
                        }
                        case 1415186628: {
                            break block79;
                        }
                    }
                    break;
                }
                v24 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl157
                block80: while (true) {
                    v24 = v25 / (2492L ^ 3766146488099427037L);
lbl157:
                    // 2 sources

                    switch ((int)v24) {
                        case -71590273: {
                            v25 = 304L ^ 4989837121608460267L;
                            continue block80;
                        }
                        case 448586381: {
                            v25 = 4044734876849739052L >>> "\u0000\u0000".length();
                            continue block80;
                        }
                        case 1415186628: {
                            break block80;
                        }
                    }
                    break;
                }
                extraWaitSeconds = this.tempExtraWaitSecondsConfig.TEMP_EXTRA_WAIT_SECONDS;
                if (extraWaitSeconds <= 0) break block98;
                v26 = 240000 >>> "\u0000\u0000".length();
                while (true) {
                    if ((v27 = (cfr_temp_7 = MapCycleModule.\u13e8 - (6329L ^ 5697010570761141171L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                    if (v27 == (22155 ^ -22156)) break;
                    v27 = 15138 ^ -132279504;
                }
                v28 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl178
                block82: while (true) {
                    v28 = v29 / (21133L ^ 2662376087635119799L);
lbl178:
                    // 2 sources

                    switch ((int)v28) {
                        case 1415186628: {
                            break block82;
                        }
                        case 1419319333: {
                            v29 = 2016L ^ 4975054342260265871L;
                            continue block82;
                        }
                        case 1451453956: {
                            v29 = 30511L ^ -4864948742250287298L;
                            continue block82;
                        }
                    }
                    break;
                }
                extraWaitSecondsExpiresDurationMs = v26 * this.tempExtraWaitSecondsConfig.TEMP_EXTRA_WAIT_DURATION_AFTER_RESTART;
                v30 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl192
                block83: while (true) {
                    v30 = (14969L ^ -6176543670484560636L) / (6126L ^ 4982977296029001535L);
lbl192:
                    // 2 sources

                    switch ((int)v30) {
                        case -1661070785: {
                            continue block83;
                        }
                        case 1415186628: {
                            break block83;
                        }
                    }
                    break;
                }
                v31 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl201
                block84: while (true) {
                    v31 = v32 / (10463L ^ -7863225983444390835L);
lbl201:
                    // 2 sources

                    switch ((int)v31) {
                        case 1415186628: {
                            break block84;
                        }
                        case 1732651665: {
                            v32 = 23741L ^ -3322628368362979024L;
                            continue block84;
                        }
                        case 1735561966: {
                            v32 = 23494L ^ 712882184714608313L;
                            continue block84;
                        }
                    }
                    break;
                }
                v33 = this.afterKillConfig.WAIT_SECONDS_AFTER_KILL + extraWaitSeconds;
                v34 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl215
                block85: while (true) {
                    v34 = v35 / (10485L ^ -4826644179715829565L);
lbl215:
                    // 2 sources

                    switch ((int)v34) {
                        case 139063954: {
                            v35 = 3125L ^ -8681396435939057897L;
                            continue block85;
                        }
                        case 567738078: {
                            v35 = 32659L ^ 3253897632344313790L;
                            continue block85;
                        }
                        case 736493236: {
                            v35 = 30435L ^ 4903690702444965705L;
                            continue block85;
                        }
                        case 1415186628: {
                            break block85;
                        }
                    }
                    break;
                }
                this.afterKillConfig.WAIT_SECONDS_AFTER_KILL = v33;
                while (true) {
                    if ((v36 = (cfr_temp_8 = MapCycleModule.\u13e8 - (950L ^ 7982093422997056499L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                    if (v36 == (22373 ^ -22374)) break;
                    v36 = 820608076 >>> "\u0000\u0000".length();
                }
                UserLogs.LogExtraWaitTicksAdded(this);
                while (true) {
                    if ((v37 = (cfr_temp_9 = MapCycleModule.\u13e8 - (9920L ^ 6145847590432835928L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
                    if (v37 == (21582 ^ -21583)) break;
                    v37 = 12603 ^ 1888595732;
                }
                while (true) {
                    if ((v38 = (cfr_temp_10 = MapCycleModule.\u13e8 - (30571L ^ 5516768123910982153L)) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
                    if (v38 == (30903 ^ -30904)) break;
                    v38 = 584 ^ -1876855426;
                }
                v39 = (IAction)LambdaMetafactory.metafactory(null, null, null, ()V, lambda$HandleAfterRestart$2(), ()V)((MapCycleModule)this);
                while (true) {
                    if ((v40 = (cfr_temp_11 = MapCycleModule.\u13e8 - (2789L ^ -8885387751767724720L)) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
                    if (v40 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                        this.scheduledActionManager.add(extraWaitSecondsExpiresDurationMs, v39);
                        break block95;
                    }
                    v40 = 3834 ^ -487600077;
                }
            }
            while (true) {
                if ((v41 = (cfr_temp_12 = MapCycleModule.\u13e8 - (19646L ^ 6329014709718471807L)) == 0L ? 0 : (cfr_temp_12 < 0L ? -1 : 1)) == false) continue;
                if (v41 == (14104 ^ -14105)) {
                    UserLogs.LogNoExtraWaitTicksAdded(this);
                    break;
                }
                v41 = 18247 ^ -1809866922;
            }
        }
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private void OnServerRestart() {
        block60: {
            block59: {
                v0 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl5
                block43: while (true) {
                    v0 = (8674695736810729016L >>> "\u0000\u0000".length()) / (22628L ^ -4170511670108278775L);
lbl5:
                    // 2 sources

                    switch ((int)v0) {
                        case 306399986: {
                            continue block43;
                        }
                        case 1415186628: {
                            break block43;
                        }
                    }
                    break;
                }
                if (!this.startedHandlerAfterServerRestart) break block59;
                v1 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl15
                block44: while (true) {
                    v1 = (25602L ^ -6177580779081369263L) / (19871L ^ -16595458600499873L);
lbl15:
                    // 2 sources

                    switch ((int)v1) {
                        case -1036957798: {
                            continue block44;
                        }
                        case 1415186628: {
                            break block44;
                        }
                    }
                    break;
                }
                UserLogs.LogRestartAlreadySeen(this);
                return;
            }
            while (true) {
                if ((v2 = (cfr_temp_0 = MapCycleModule.\u13e8 - (32733L ^ -3123076175383183615L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v2 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v2 = 17047 ^ -670143756;
            }
            this.startedHandlerAfterServerRestart = 26745 ^ 26744;
            v3 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl33
            block46: while (true) {
                v3 = v4 / (23973L ^ -1333748610591209157L);
lbl33:
                // 2 sources

                switch ((int)v3) {
                    case -923126991: {
                        v4 = 2837L ^ -3396095644487525525L;
                        continue block46;
                    }
                    case 1324162453: {
                        v4 = -6801381506386984780L >>> "\u0000\u0000".length();
                        continue block46;
                    }
                    case 1415186628: {
                        break block46;
                    }
                }
                break;
            }
            UserLogs.LogRestartInProgress(this);
            while (true) {
                if ((v5 = (cfr_temp_1 = MapCycleModule.\u13e8 - (29218L ^ 8185256616270412095L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v5 == (17587 ^ -17588)) break;
                v5 = 12414 ^ -580526505;
            }
            while (true) {
                if ((v6 = (cfr_temp_2 = MapCycleModule.\u13e8 - (29450L ^ 6542309194467321829L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v6 == (14589 ^ -14590)) break;
                v6 = 21955 ^ -1174069419;
            }
            if (!this.serverRestartHandlerConfig.COLLECT_BEHE_BOXES_ON_GAME_SERVER_RESTART) break block60;
            v7 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
            v8 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl59
            block49: while (true) {
                v8 = v9 / (13857L ^ -7624653485414205467L);
lbl59:
                // 2 sources

                switch ((int)v8) {
                    case -1131510122: {
                        v9 = 32326L ^ -5445207132268312872L;
                        continue block49;
                    }
                    case 844620546: {
                        v9 = 7769L ^ -6222982377127279225L;
                        continue block49;
                    }
                    case 1415186628: {
                        break block49;
                    }
                }
                break;
            }
            this.EnableCollectBeheBox(v7);
        }
        while (true) {
            if ((v10 = (cfr_temp_3 = MapCycleModule.\u13e8 - (14888L ^ -873457949460875333L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v10 == (3608 ^ -3609)) break;
            v10 = 2139284660 >>> "\u0000\u0000".length();
        }
        v11 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl79
        block51: while (true) {
            v11 = v12 / (6074L ^ -1477902074259874016L);
lbl79:
            // 2 sources

            switch ((int)v11) {
                case -1857387518: {
                    v12 = 21280L ^ -3597562479551816392L;
                    continue block51;
                }
                case -1014846342: {
                    v12 = 4454L ^ -2676579801258667254L;
                    continue block51;
                }
                case 1415186628: {
                    break block51;
                }
                case 1849130962: {
                    v12 = 4264L ^ -3651356292723438165L;
                    continue block51;
                }
            }
            break;
        }
        v13 = this.predictNpcSpawnConfig.MAP_CHANGE_COND_CONFIG;
        while (true) {
            if ((v14 = (cfr_temp_4 = MapCycleModule.\u13e8 - (8555L ^ 9121765807627042952L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v14 == (3817 ^ -3818)) break;
            v14 = 30855 ^ -1395364216;
        }
        v15 = v13.ENABLE;
        v16 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl102
        block53: while (true) {
            v16 = (13444L ^ -1709944191716194977L) / (2861L ^ 4060541635384371924L);
lbl102:
            // 2 sources

            switch ((int)v16) {
                case 1415186628: {
                    break block53;
                }
                case 2112924612: {
                    continue block53;
                }
            }
            break;
        }
        v17 = v15;
        v18 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl112
        block54: while (true) {
            v18 = v19 / (2702L ^ 5222960519763165211L);
lbl112:
            // 2 sources

            switch ((int)v18) {
                case -172121998: {
                    v19 = 6230L ^ -6917235609814606671L;
                    continue block54;
                }
                case 1060589005: {
                    v19 = 7668L ^ -2945244660079327727L;
                    continue block54;
                }
                case 1415186628: {
                    break block54;
                }
            }
            break;
        }
        this.oldPredictNpcSpawnMapChangeCondConfigEnableState = v17;
        while (true) {
            if ((v20 = (cfr_temp_5 = MapCycleModule.\u13e8 - (16807L ^ 3675622310715881749L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
            if (v20 == (2577 ^ -2578)) break;
            v20 = 11641 ^ 1000570175;
        }
        v21 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl131
        block56: while (true) {
            v21 = v22 / (648L ^ -8494699598115204453L);
lbl131:
            // 2 sources

            switch ((int)v21) {
                case -1898972795: {
                    v22 = 20373L ^ -8189333471335693610L;
                    continue block56;
                }
                case -1565508438: {
                    v22 = 6219L ^ 4699628746998293659L;
                    continue block56;
                }
                case 1415186628: {
                    break block56;
                }
            }
            break;
        }
        v23 = this.predictNpcSpawnConfig.MAP_CHANGE_COND_CONFIG;
        v24 = "".length() >>> "\u0000\u0000".length();
        while (true) {
            if ((v25 = (cfr_temp_6 = MapCycleModule.\u13e8 - (29079L ^ -5901686541754575679L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
            if (v25 == (30569 ^ 30568)) break;
            v25 = 21580 ^ 274998909;
        }
        v23.ENABLE = v24;
        v26 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl152
        block58: while (true) {
            v26 = v27 / (19306L ^ -3713889817567655879L);
lbl152:
            // 2 sources

            switch ((int)v26) {
                case -10142467: {
                    v27 = 25726L ^ 8070530322069633103L;
                    continue block58;
                }
                case 507298430: {
                    v27 = 5987L ^ -3021123224595620047L;
                    continue block58;
                }
                case 1415186628: {
                    break block58;
                }
            }
            break;
        }
        this.StartServerRestartHandler();
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private void CheckSingleUnseenLogLine(String unseenLogLine) {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x181L ^ 0xBFF4FEBA54BEABF0L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == (0x3A9D ^ 0x3A9C)) break;
            l2 = 0x7EF0 ^ 0xDC5EFA2F;
        }
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = \u13e8 - (0x54C4L ^ 0x6EFC0D6264819222L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l3 == (0x957 ^ 0xFFFFF6A8)) {
                if (!this.serverRestartHandlerConfig.ENABLE_CHECK_SERVER_RESTART) return;
                break;
            }
            l3 = 0x1F99 ^ 0xE002850B;
        }
        byte[] byArray = new byte["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
        byArray[0x2DCD ^ 0x2DDE] = 0x7D15 ^ 0x7D46;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x3612 ^ 0x3661;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0xE0 ^ 0x9B;
        byArray[0xCEE ^ 0xCEB] = 460 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 128 >>> "\u0000\u0000".length();
        byArray[0x4503 ^ 0x4513] = 0x271D ^ 0x273D;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0xA4D ^ 0xA3F;
        byArray[0x4397 ^ 0x4382] = 388 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x3088 ^ 0x30FA;
        byArray[0x3B7E ^ 0x3B64] = 0x2110 ^ 0x217E;
        byArray[0x60F3 ^ 0x60EA] = 0x1840 ^ 0x1829;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 464 >>> "\u0000\u0000".length();
        byArray[0x43C3 ^ 0x43C3] = 0x751D ^ 0x755A;
        byArray[0x266A ^ 0x266C] = 0x7F5C ^ 0x7F39;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x4C0D ^ 0x4C79;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 472 >>> "\u0000\u0000".length();
        byArray[0x39B5 ^ 0x39AE] = 0x1969 ^ 0x1949;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x1A04 ^ 0x1A76;
        byArray[0x3716 ^ 0x371B] = 420 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 404 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 404 >>> "\u0000\u0000".length();
        byArray[0x4183 ^ 0x4195] = 0x676C ^ 0x671E;
        byArray[0x2764 ^ 0x2765] = 388 >>> "\u0000\u0000".length();
        byArray[0x118D ^ 0x118F] = 0x73AE ^ 0x73C3;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0xBE3 ^ 0xBC3;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x4709 ^ 0x476C;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 128 >>> "\u0000\u0000".length();
        byArray[0xEF3 ^ 0xEFC] = 0x4198 ^ 0x41F4;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x5237 ^ 0x5240;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x5570 ^ 0x551C;
        String string = new String(byArray);
        while (true) {
            long l;
            long l4;
            if ((l4 = (l = \u13e8 - (0xB9DL ^ 0xEA0E99FB22993DDBL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l4 == (0x2FF0 ^ 0xFFFFD00F)) {
                if (!unseenLogLine.contains(string)) return;
                break;
            }
            l4 = 0x7CC6 ^ 0xED6B5DFB;
        }
        long l = \u13e8;
        boolean bl = true;
        block8: while (true) {
            long l5;
            if (!bl || (bl = false) || !true) {
                l = l5 / (0x7861L ^ 0x61C5923735D383EEL);
            }
            switch ((int)l) {
                case -1472008297: {
                    l5 = 0x1336L ^ 0x97FBBF753F9440E2L;
                    continue block8;
                }
                case 1196657175: {
                    l5 = 0x2DFFL ^ 0x53EBD7F3F38A75F0L;
                    continue block8;
                }
                case 1415186628: {
                    break block8;
                }
            }
            break;
        }
        this.OnServerRestart();
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private void CheckUnseenLogLines(List<String> newLogLines) {
        if (newLogLines == null) {
            return;
        }
        long l = \u13e8;
        boolean bl = true;
        block10: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x2D1CL ^ 0x990BCE76978C74EEL);
            }
            switch ((int)l) {
                case -2129872821: {
                    l2 = 0x22A4L ^ 0x3232B419BB243A2FL;
                    continue block10;
                }
                case 592564779: {
                    l2 = 0x25EEL ^ 0x6C76C88252E33368L;
                    continue block10;
                }
                case 1118181803: {
                    l2 = 0x420DL ^ 0xCC89AC1FF9C94DA2L;
                    continue block10;
                }
                case 1415186628: {
                    break block10;
                }
            }
            break;
        }
        Consumer<String> consumer = this::CheckSingleUnseenLogLine;
        long l3 = \u13e8;
        block11: while (true) {
            switch ((int)l3) {
                case 1415186628: {
                    break block11;
                }
                case 1955703881: {
                    l3 = (0x6DD2L ^ 0xA51BC488AAC36427L) / (0x6689L ^ 0xC79BD3F97C3B1101L);
                    continue block11;
                }
            }
            break;
        }
        newLogLines.forEach(consumer);
    }

    /*
     * Unable to fully structure code
     */
    private void CheckUnseenLogLines() {
        v0 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl5
        block10: while (true) {
            v0 = v1 / (32284L ^ -765520948488348467L);
lbl5:
            // 2 sources

            switch ((int)v0) {
                case 739200245: {
                    v1 = 12895L ^ -8942359760291000916L;
                    continue block10;
                }
                case 855837286: {
                    v1 = 32043L ^ 5752332515569147969L;
                    continue block10;
                }
                case 1415186628: {
                    break block10;
                }
            }
            break;
        }
        if (this.unseenLogsReader == null) {
            return;
        }
        while (true) {
            if ((v2 = (cfr_temp_0 = MapCycleModule.\u13e8 - (1620L ^ 6796747315865907579L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v2 == (32388 ^ -32389)) break;
            v2 = 16776 ^ -205132800;
        }
        while (true) {
            if ((v3 = (cfr_temp_1 = MapCycleModule.\u13e8 - (16232L ^ -4827077690409390432L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v3 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v3 = 20665 ^ 2052432490;
        }
        v4 = this.unseenLogsReader.getUnseenLogs();
        v5 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl31
        block13: while (true) {
            v5 = v6 / (13416L ^ 6434751011658445981L);
lbl31:
            // 2 sources

            switch ((int)v5) {
                case -572774892: {
                    v6 = 24456L ^ -8407870530273654630L;
                    continue block13;
                }
                case 1415186628: {
                    break block13;
                }
                case 2011983097: {
                    v6 = 25997L ^ -2613397078417778711L;
                    continue block13;
                }
            }
            break;
        }
        this.CheckUnseenLogLines(v4);
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private boolean tryDetermineNpcKilledFromUnseenLogs() {
        block37: {
            String logLineSubString;
            while (true) {
                long l;
                long l2;
                if ((l2 = (l = \u13e8 - (0x7D9DL ^ 0x8F8B19F1D31FEBDFL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
                if (l2 == (0x64EE ^ 0x64EF)) break;
                l2 = -114140972 >>> "\u0000\u0000".length();
            }
            long l = \u13e8;
            block15: while (true) {
                switch ((int)l) {
                    case 1306334999: {
                        l = (0x4FA0L ^ 0x1C217A6FBFBC9874L) / (2026901911385826456L >>> "\u0000\u0000".length());
                        continue block15;
                    }
                    case 1415186628: {
                        break block15;
                    }
                }
                break;
            }
            List<String> unseenLogs = this.unseenLogsReader.getUnseenLogs();
            if (unseenLogs == null) {
                return (0x155B ^ 0x155B) != 0;
            }
            while (true) {
                long l3;
                long l4;
                if ((l4 = (l3 = \u13e8 - (0x1A2AL ^ 0xFB1443C0AC513A57L)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) continue;
                if (l4 == (0x58EE ^ 0xFFFFA711)) break;
                l4 = 0x19A ^ 0xBA458A8F;
            }
            this.CheckUnseenLogLines(unseenLogs);
            long l5 = \u13e8;
            block17: while (true) {
                switch ((int)l5) {
                    case -1538220083: {
                        l5 = (0x18D4L ^ 0xB7798AD9176E2D54L) / (0x7E6DL ^ 0xE5429F7974C06627L);
                        continue block17;
                    }
                    case 1415186628: {
                        break block17;
                    }
                }
                break;
            }
            while (true) {
                long l6;
                long l7;
                if ((l7 = (l6 = \u13e8 - (0x764AL ^ 0x9F6F54352E0E4F83L)) == 0L ? 0 : (l6 < 0L ? -1 : 1)) == false) continue;
                if (l7 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                    logLineSubString = this.loglineSubstringConditionConfig.LOG_LINE_SUBSTRING;
                    if (logLineSubString != null) {
                        break;
                    }
                    break block37;
                }
                l7 = 0x723C ^ 0xB147EF0A;
            }
            while (true) {
                long l8;
                long l9;
                if ((l9 = (l8 = \u13e8 - (0x2B58L ^ 0x1243A204B77CEF27L)) == 0L ? 0 : (l8 < 0L ? -1 : 1)) == false) continue;
                if (l9 == (0x38C7 ^ 0xFFFFC738)) {
                    if (logLineSubString.length() > 0) {
                        break;
                    }
                    break block37;
                }
                l9 = 0x3748 ^ 0xCD46B98B;
            }
            long l10 = \u13e8;
            boolean bl = true;
            block20: while (true) {
                long l11;
                if (!bl || (bl = false) || !true) {
                    l10 = l11 / (0x2245L ^ 0xB921980E0A6E3BBBL);
                }
                switch ((int)l10) {
                    case -1713350399: {
                        l11 = 0x2CEL ^ 0x78084901348A8292L;
                        continue block20;
                    }
                    case -1614128282: {
                        l11 = 0x3F5FL ^ 0x5945401B40EFCB59L;
                        continue block20;
                    }
                    case -233374461: {
                        l11 = 0x5EE3L ^ 0xD426886D79755342L;
                        continue block20;
                    }
                    case 1415186628: {
                        break block20;
                    }
                }
                break;
            }
            while (true) {
                long l12;
                long l13;
                if ((l13 = (l12 = \u13e8 - (0x120DL ^ 0xD2A6247E1518222BL)) == 0L ? 0 : (l12 < 0L ? -1 : 1)) == false) continue;
                if (l13 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                    if (this.loglineSubstringConditionConfig.USE_LOG_LINE_SUBSTRING) {
                        break;
                    }
                    break block37;
                }
                l13 = 0x333B ^ 0x9E3FA12E;
            }
            while (true) {
                long l14;
                long l15;
                if ((l15 = (l14 = \u13e8 - (0x6FCDL ^ 0xFF3DE02355A6FAD9L)) == 0L ? 0 : (l14 < 0L ? -1 : 1)) == false) continue;
                if (l15 == (0x7DD4 ^ 0xFFFF822B)) break;
                l15 = 0x4ACF ^ 0x2F2E93DE;
            }
            Stream stream = unseenLogs.stream();
            while (true) {
                long l16;
                long l17;
                if ((l17 = (l16 = \u13e8 - (0x1D3BL ^ 0x751967B863AF7B31L)) == 0L ? 0 : (l16 < 0L ? -1 : 1)) == false) continue;
                if (l17 == (0x9AE ^ 0xFFFFF651)) break;
                l17 = 0x2659 ^ 0x5E74C147;
            }
            Predicate<String> predicate = unseenLog -> {
                while (true) {
                    long l;
                    long l2;
                    if ((l2 = (l = \u13e8 - (0x2CDDL ^ 0x6BA9F0265EB36F6EL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                        continue;
                    }
                    if (l2 == (0x1A1D ^ 0xFFFFE5E2)) break;
                    l2 = -1134393420 >>> "\u0000\u0000".length();
                }
                return unseenLog.contains(logLineSubString);
            };
            while (true) {
                long l18;
                long l19;
                if ((l19 = (l18 = \u13e8 - (-6294663154814357264L >>> "\u0000\u0000".length())) == 0L ? 0 : (l18 < 0L ? -1 : 1)) == false) continue;
                if (l19 == (0x50CB ^ 0xFFFFAF34)) {
                    if (!stream.anyMatch(predicate)) return "".length() >>> "\u0000\u0000".length();
                    return (0x2A9D ^ 0x2A9C) != 0;
                }
                l19 = 0x2A31 ^ 0x960B0455;
            }
        }
        while (true) {
            long l;
            long l20;
            if ((l20 = (l = \u13e8 - (0x36F5L ^ 0x6C6E298D67F33251L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l20 == (0x4899 ^ 0xFFFFB766)) break;
            l20 = 0x696 ^ 0x67516C58;
        }
        int n = "".length() >>> "\u0000\u0000".length();
        while (true) {
            long l;
            long l21;
            if ((l21 = (l = \u13e8 - (0x1645L ^ 0x5DFECDD4BDB34ABBL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l21 == (0x86B ^ 0xFFFFF794)) {
                this.loglineSubstringConditionConfig.USE_LOG_LINE_SUBSTRING = n;
                return "".length() >>> "\u0000\u0000".length() != 0;
            }
            l21 = 0x57C8 ^ 0x63F6B816;
        }
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public Integer getExcessSecondsMax() {
        while (true) {
            if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (-5582843126675145564L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (25367 ^ -25368)) break;
            v0 = 13168 ^ 656446876;
        }
        v1 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl10
        block11: while (true) {
            v1 = (4586L ^ -3375601923991915219L) / (27340L ^ 32182080862790618L);
lbl10:
            // 2 sources

            switch ((int)v1) {
                case 1147391874: {
                    continue block11;
                }
                case 1415186628: {
                    break block11;
                }
            }
            break;
        }
        v2 = this.predictNpcSpawnConfig.MAP_CHANGE_COND_CONFIG;
        while (true) {
            if ((v3 = (cfr_temp_1 = MapCycleModule.\u13e8 - (2219L ^ 8565056972319980415L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v3 == (16190 ^ -16191)) break;
            v3 = 21745 ^ -190067220;
        }
        if (!v2.ENABLE) {
            return null;
        }
        while (true) {
            if ((v4 = (cfr_temp_2 = MapCycleModule.\u13e8 - (10924L ^ 3070234069919644186L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v4 == (29990 ^ -29991)) break;
            v4 = 30648 ^ 107401308;
        }
        while (true) {
            if ((v5 = (cfr_temp_3 = MapCycleModule.\u13e8 - (28912L ^ -3778984479901473533L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v5 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v5 = 19732 ^ -964135860;
        }
        v6 = this.predictNpcSpawnConfig.MAP_CHANGE_COND_CONFIG;
        while (true) {
            if ((v7 = (cfr_temp_4 = MapCycleModule.\u13e8 - (15042L ^ 5743719131619491881L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v7 == (19154 ^ -19155)) break;
            v7 = 30496 ^ 1628504374;
        }
        v8 = v6.PREDICTION_TOLERANCE_SECONDS;
        v9 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl44
        block16: while (true) {
            v9 = v10 / (15372L ^ -7391584427315174283L);
lbl44:
            // 2 sources

            switch ((int)v9) {
                case 240281479: {
                    v10 = 22851L ^ -6886020556535781961L;
                    continue block16;
                }
                case 349093604: {
                    v10 = 17229L ^ 8383548522489268086L;
                    continue block16;
                }
                case 1415186628: {
                    break block16;
                }
                case 2020706829: {
                    v10 = 1762L ^ -4137794639139119785L;
                    continue block16;
                }
            }
            break;
        }
        return v8;
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public Integer getExcessSecondsAfterPredictedSpawn() {
        while (true) {
            if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (10330L ^ -8322400912744139005L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v0 == (9281 ^ 9280)) break;
            v0 = 11943 ^ 129006727;
        }
        v1 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl11
        block25: while (true) {
            v1 = v2 / (29676L ^ 436099557561194661L);
lbl11:
            // 2 sources

            switch ((int)v1) {
                case -1125742007: {
                    v2 = 10099L ^ 2126960601409719781L;
                    continue block25;
                }
                case -216415215: {
                    v2 = 31458L ^ -5242914491879569792L;
                    continue block25;
                }
                case 1415186628: {
                    break block25;
                }
            }
            break;
        }
        v3 = this.predictNpcSpawnConfig.MAP_CHANGE_COND_CONFIG;
        while (true) {
            if ((v4 = (cfr_temp_1 = MapCycleModule.\u13e8 - (25231L ^ -2295358026440323054L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v4 == (14838 ^ -14839)) break;
            v4 = 15385 ^ -1556604573;
        }
        if (!v3.ENABLE) {
            return null;
        }
        while (true) {
            if ((v5 = (cfr_temp_2 = MapCycleModule.\u13e8 - (3848L ^ -6568291574709821783L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v5 == (26462 ^ 26463)) break;
            v5 = 29902 ^ 326751237;
        }
        msTillWithinPredictedSpawn = this.getMsTillWithinNPCSpawnPeriod();
        if (msTillWithinPredictedSpawn == null) {
            return null;
        }
        v6 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl42
        block28: while (true) {
            v6 = v7 / (-1865313725164643172L >>> "\u0000\u0000".length());
lbl42:
            // 2 sources

            switch ((int)v6) {
                case -1628373480: {
                    v7 = 11108L ^ -1008473420096319547L;
                    continue block28;
                }
                case 208857086: {
                    v7 = 851L ^ 8416511749111683874L;
                    continue block28;
                }
                case 1415186628: {
                    break block28;
                }
            }
            break;
        }
        v8 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl55
        block29: while (true) {
            v8 = v9 / (25141L ^ -3244662093511751690L);
lbl55:
            // 2 sources

            switch ((int)v8) {
                case 534575722: {
                    v9 = 22177L ^ 3988071025583285101L;
                    continue block29;
                }
                case 663302828: {
                    v9 = 19540L ^ 3588223989195125172L;
                    continue block29;
                }
                case 1415186628: {
                    break block29;
                }
            }
            break;
        }
        offsetSeconds = this.predictNpcSpawnConfig.PREPARE_FOR_SPAWN_PERIOD_SECONDS;
        while (true) {
            if ((v10 = (cfr_temp_3 = MapCycleModule.\u13e8 - (281L ^ -968738349099977386L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v10 == ("\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() ^ -9)) break;
            v10 = 32715 ^ -1474585973;
        }
        v11 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl75
        block31: while (true) {
            v11 = (22727L ^ -2532966303955139900L) / (4943066851005836988L >>> "\u0000\u0000".length());
lbl75:
            // 2 sources

            switch ((int)v11) {
                case 681632726: {
                    continue block31;
                }
                case 1415186628: {
                    break block31;
                }
            }
            break;
        }
        v12 = msTillWithinPredictedSpawn;
        while (true) {
            if ((v13 = (cfr_temp_4 = MapCycleModule.\u13e8 - (28551L ^ 5764683557036969221L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v13 == (16654 ^ -16655)) break;
            v13 = 31871 ^ 1972785831;
        }
        secondsAfterPredictedSpawn = TimeUnit.MILLISECONDS.toSeconds(v12) + offsetSeconds;
        if (secondsAfterPredictedSpawn >= 0L >>> "\u0000\u0000".length()) {
            return null;
        }
        v14 = -secondsAfterPredictedSpawn;
        v15 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl95
        block33: while (true) {
            v15 = v16 / (-7554542957735735560L >>> "\u0000\u0000".length());
lbl95:
            // 2 sources

            switch ((int)v15) {
                case -1594233047: {
                    v16 = 8015L ^ 2653975429324656094L;
                    continue block33;
                }
                case 323307056: {
                    v16 = 18740L ^ -3430007778571795086L;
                    continue block33;
                }
                case 1415186628: {
                    break block33;
                }
            }
            break;
        }
        v17 = Math.toIntExact(v14);
        while (true) {
            if ((v18 = (cfr_temp_5 = MapCycleModule.\u13e8 - (21899L ^ 5605821726510983524L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v18 == (2692 ^ -2693)) break;
            v18 = 141190572 >>> "\u0000\u0000".length();
        }
        return v17;
    }

    /*
     * Unable to fully structure code
     */
    private boolean tryDetermineNpcDeadInPast() {
        while (true) {
            if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (1688L ^ -6591107245835096345L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (11610 ^ 11611)) break;
            v0 = 2565 ^ 84844681;
        }
        excessSeconds = this.getExcessSecondsAfterPredictedSpawn();
        if (excessSeconds == null) {
            return "".length() >>> "\u0000\u0000".length();
        }
        while (true) {
            if ((v1 = (cfr_temp_1 = MapCycleModule.\u13e8 - (32351L ^ 177156445088106863L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v1 == (2219 ^ -2220)) break;
            v1 = 10717 ^ -956711906;
        }
        v2 = excessSeconds;
        v3 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl19
        block7: while (true) {
            v3 = v4 / (5149L ^ -2892184119626006621L);
lbl19:
            // 2 sources

            switch ((int)v3) {
                case -1139054388: {
                    v4 = 29999L ^ 4560099533069821402L;
                    continue block7;
                }
                case -677464281: {
                    v4 = 14292L ^ -8594752474484050670L;
                    continue block7;
                }
                case 1415186628: {
                    break block7;
                }
            }
            break;
        }
        v5 = this.getExcessSecondsMax();
        while (true) {
            if ((v6 = (cfr_temp_2 = MapCycleModule.\u13e8 - (289L ^ -2542996173433721055L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v6 == (17077 ^ -17078)) break;
            v6 = 12659 ^ -860665576;
        }
        return v2 >= v5 ? "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length() : "".length() >>> "\u0000\u0000".length();
    }

    /*
     * Unable to fully structure code
     */
    private boolean tryDetermineNpcKilledFromSight() {
        v0 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl5
        block11: while (true) {
            v0 = v1 / (17877L ^ -8263800561906917460L);
lbl5:
            // 2 sources

            switch ((int)v0) {
                case 274875212: {
                    v1 = 11830L ^ -5467171762419328088L;
                    continue block11;
                }
                case 781639110: {
                    v1 = 2214L ^ -8097804683549986640L;
                    continue block11;
                }
                case 1415186628: {
                    break block11;
                }
            }
            break;
        }
        npcInSight = this.npcSubnameInSight();
        while (true) {
            if ((v2 = (cfr_temp_0 = MapCycleModule.\u13e8 - (8194L ^ 5936437558051874740L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v2 == (11095 ^ -11096)) break;
            v2 = "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() ^ 1786982676;
        }
        v3 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl25
        block13: while (true) {
            v3 = v4 / (22390L ^ -167901641117180940L);
lbl25:
            // 2 sources

            switch ((int)v3) {
                case -2018653140: {
                    v4 = 17833L ^ 9104876509323980231L;
                    continue block13;
                }
                case 968382856: {
                    v4 = 30396L ^ -1294936090584765930L;
                    continue block13;
                }
                case 1415186628: {
                    break block13;
                }
                case 1793944560: {
                    v4 = 15773L ^ -6740508602884049088L;
                    continue block13;
                }
            }
            break;
        }
        npcWasInSight = this.shootingBeheState.isStillShooting();
        return (boolean)(npcInSight == false && npcWasInSight != false ? "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length() : 13536 ^ 13536);
    }

    /*
     * Unable to fully structure code
     */
    private void pressKeyFirstLockTick() {
        block25: {
            while (true) {
                if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (8829L ^ -4700377528313529813L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v0 == (9756 ^ 9757)) break;
                v0 = 32689 ^ 1837962561;
            }
            firstLockedTimePastMs = this.getKeyFirstLockMsPast();
            if (firstLockedTimePastMs == null) break block25;
            v1 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl12
            block18: while (true) {
                v1 = v2 / (6586L ^ 8684931128122399539L);
lbl12:
                // 2 sources

                switch ((int)v1) {
                    case -1906086448: {
                        v2 = 11477L ^ 7944915078628201067L;
                        continue block18;
                    }
                    case -1328680226: {
                        v2 = 2399L ^ -6093613200160010700L;
                        continue block18;
                    }
                    case -920993157: {
                        v2 = 32702L ^ -5249945603838936722L;
                        continue block18;
                    }
                    case 1415186628: {
                        break block18;
                    }
                }
                break;
            }
            v3 = firstLockedTimePastMs;
            while (true) {
                if ((v4 = (cfr_temp_1 = MapCycleModule.\u13e8 - (9057L ^ -7203692566627946312L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v4 == (1415 ^ 1414)) break;
                v4 = 15358 ^ 2022928813;
            }
            v5 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl34
            block20: while (true) {
                v5 = v6 / (20442L ^ 6006981539509461931L);
lbl34:
                // 2 sources

                switch ((int)v5) {
                    case -1407582436: {
                        v6 = 21915L ^ -7164744779082764051L;
                        continue block20;
                    }
                    case -142620840: {
                        v6 = 6679L ^ 5328511063318384751L;
                        continue block20;
                    }
                    case 654625493: {
                        v6 = 11388L ^ -2377886982797507693L;
                        continue block20;
                    }
                    case 1415186628: {
                        break block20;
                    }
                }
                break;
            }
            if (v3 < (long)this.keyFirstLockConfig.WAIT_MS_AFTER_FIRST_LOCK) break block25;
            while (true) {
                if ((v7 = (cfr_temp_2 = MapCycleModule.\u13e8 - (21589L ^ 7679446392634421817L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v7 == (25701 ^ -25702)) break;
                v7 = -1232923716 >>> "\u0000\u0000".length();
            }
            UserLogs.LogPressKeyFirstLock(this);
            while (true) {
                if ((v8 = (cfr_temp_3 = MapCycleModule.\u13e8 - (29271L ^ 6684673912857936874L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v8 == (26145 ^ -26146)) break;
                v8 = -1505657164 >>> "\u0000\u0000".length();
            }
            this.pressKeyOnFirstLock();
            while (true) {
                if ((v9 = (cfr_temp_4 = MapCycleModule.\u13e8 - (23081L ^ -8277857680990114515L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v9 == (13508 ^ 13509)) break;
                v9 = 4736 ^ 985692055;
            }
            v10 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl68
            block24: while (true) {
                v10 = v11 / (21939L ^ -5274309145317224010L);
lbl68:
                // 2 sources

                switch ((int)v10) {
                    case -303450879: {
                        v11 = 25422L ^ 4525201668509645676L;
                        continue block24;
                    }
                    case 1415186628: {
                        break block24;
                    }
                    case 1652282329: {
                        v11 = 31569L ^ 79313557019394812L;
                        continue block24;
                    }
                }
                break;
            }
            this.shootingBeheState.consumeFirstTimeTimeStampMs();
        }
    }

    /*
     * Unable to fully structure code
     */
    private boolean npcSubnameInSight() {
        block43: {
            block42: {
                while (true) {
                    if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (12260L ^ 3261796282375512409L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                        continue;
                    }
                    if (v0 == (2190 ^ -2191)) break;
                    v0 = -1405216400 >>> "\u0000\u0000".length();
                }
                v1 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl11
                block27: while (true) {
                    v1 = (499L ^ 8755125936147838081L) / (20272L ^ -5772774030626836773L);
lbl11:
                    // 2 sources

                    switch ((int)v1) {
                        case -226263344: {
                            continue block27;
                        }
                        case 1415186628: {
                            break block27;
                        }
                    }
                    break;
                }
                if (this.mapCycleConfig.NPC_SUBNAME == null) break block42;
                v2 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl21
                block28: while (true) {
                    v2 = v3 / (2351L ^ 2136998241688206573L);
lbl21:
                    // 2 sources

                    switch ((int)v2) {
                        case -1921643353: {
                            v3 = 25324L ^ 4466677211429025008L;
                            continue block28;
                        }
                        case 1415186628: {
                            break block28;
                        }
                        case 1449081986: {
                            v3 = 23140L ^ -8570495737698951799L;
                            continue block28;
                        }
                        case 2098926800: {
                            v3 = 26572L ^ -2456550924542096842L;
                            continue block28;
                        }
                    }
                    break;
                }
                v4 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl37
                block29: while (true) {
                    v4 = v5 / (4558L ^ 6975895284234327460L);
lbl37:
                    // 2 sources

                    switch ((int)v4) {
                        case -1674219879: {
                            v5 = 9462L ^ 5343162546471173807L;
                            continue block29;
                        }
                        case -186631402: {
                            v5 = 28943L ^ -5438656799269092522L;
                            continue block29;
                        }
                        case 1018133652: {
                            v5 = -5073345359064355620L >>> "\u0000\u0000".length();
                            continue block29;
                        }
                        case 1415186628: {
                            break block29;
                        }
                    }
                    break;
                }
                v6 = this.mapCycleConfig.NPC_SUBNAME;
                while (true) {
                    if ((v7 = (cfr_temp_1 = MapCycleModule.\u13e8 - (18268L ^ 6284870871632673869L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) {
                        continue;
                    }
                    if (v7 == (14439 ^ -14440)) break;
                    v7 = 1693468152 >>> "\u0000\u0000".length();
                }
                if (v6.length() != 0) break block43;
            }
            return "".length() >>> "\u0000\u0000".length();
        }
        while (true) {
            if ((v8 = (cfr_temp_2 = MapCycleModule.\u13e8 - (20391L ^ -8110315984717567833L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v8 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v8 = 19673 ^ -878475946;
        }
        v9 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl70
        block32: while (true) {
            v9 = v10 / (6452L ^ 5597834161171340995L);
lbl70:
            // 2 sources

            switch ((int)v9) {
                case -2077109948: {
                    v10 = 9388L ^ -948099634228685004L;
                    continue block32;
                }
                case 1415186628: {
                    break block32;
                }
                case 1580590280: {
                    v10 = 6335L ^ 8221153913922493493L;
                    continue block32;
                }
                case 1979645364: {
                    v10 = 3967L ^ -4386783925047016545L;
                    continue block32;
                }
            }
            break;
        }
        v11 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl86
        block33: while (true) {
            v11 = (18438L ^ 4223894570562492617L) / (25873L ^ 4769867884438774982L);
lbl86:
            // 2 sources

            switch ((int)v11) {
                case -556862884: {
                    continue block33;
                }
                case 1415186628: {
                    break block33;
                }
            }
            break;
        }
        v12 = this.mapCycleConfig.NPC_SUBNAME;
        while (true) {
            if ((v13 = (cfr_temp_3 = MapCycleModule.\u13e8 - (8310301181994552676L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v13 == (4338 ^ -4339)) break;
            v13 = -907990020 >>> "\u0000\u0000".length();
        }
        return this.lootModule.npcSubnameInSight(v12);
    }

    /*
     * Exception decompiling
     */
    private void updatePetTick() {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 106[SWITCH]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private boolean petGearIsGuardMode(int mode) {
        int n;
        long l = \u13e8;
        boolean bl = true;
        block14: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0xB02L ^ 0x8C43957CB85077B0L);
            }
            switch ((int)l) {
                case -1224075809: {
                    l2 = 0x5D03L ^ 0x929CE696789A1824L;
                    continue block14;
                }
                case 511358729: {
                    l2 = 0x7776L ^ 0xEFF6566CD906E476L;
                    continue block14;
                }
                case 1415186628: {
                    break block14;
                }
            }
            break;
        }
        long l3 = \u13e8;
        block15: while (true) {
            switch ((int)l3) {
                case 1415186628: {
                    break block15;
                }
                case 2075712852: {
                    l3 = (0x4D04L ^ 0x809A0AE58787F6B4L) / (0xEC2L ^ 0x1495E15DEC2A43F8L);
                    continue block15;
                }
            }
            break;
        }
        if (mode != PetGearSupplier.Gears.GUARD.getId()) {
            long l4 = \u13e8;
            boolean bl2 = true;
            block16: while (true) {
                long l5;
                if (!bl2 || (bl2 = false) || !true) {
                    l4 = l5 / (0x2CD1L ^ 0x2AF6B5AF4644B62CL);
                }
                switch ((int)l4) {
                    case -1501313006: {
                        l5 = 0x22C0L ^ 0x96FE00FC7179EABEL;
                        continue block16;
                    }
                    case 1415186628: {
                        break block16;
                    }
                    case 1519171741: {
                        l5 = 0x55CFL ^ 0x96EBA02673345901L;
                        continue block16;
                    }
                }
                break;
            }
            if (!this.petGearExtendsGuardMode(mode)) {
                n = 0x7E67 ^ 0x7E67;
                return n != 0;
            }
        }
        n = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        return n != 0;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private boolean petGearExtendsGuardMode(int mode) {
        int n;
        block32: {
            while (true) {
                long l;
                long l2;
                if ((l2 = (l = \u13e8 - (0x351CL ^ 0x7901586C04C3BC36L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
                if (l2 == (0x7603 ^ 0xFFFF89FC)) break;
                l2 = 0x72CA ^ 0x781D6ECD;
            }
            while (true) {
                long l;
                long l3;
                if ((l3 = (l = \u13e8 - (0x307L ^ 0x653052B1A6300574L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
                if (l3 == (0x377D ^ 0xFFFFC882)) {
                    if (mode != PetGearSupplier.Gears.HP_LINK.getId()) {
                        break;
                    }
                    break block32;
                }
                l3 = 0x7C08 ^ 0x604B4E8D;
            }
            long l = \u13e8;
            boolean bl = true;
            block18: while (true) {
                long l4;
                if (!bl || (bl = false) || !true) {
                    l = l4 / (0xA52L ^ 0xAC5ECA1FFCEFFAABL);
                }
                switch ((int)l) {
                    case -1050535206: {
                        l4 = 0x71B7L ^ 0xA73051CA6D89F7E2L;
                        continue block18;
                    }
                    case 9082896: {
                        l4 = 0x5A28L ^ 0x46F50E5652F8F9D2L;
                        continue block18;
                    }
                    case 1415186628: {
                        break block18;
                    }
                    case 1503342761: {
                        l4 = 0x36A0L ^ 0xB3F49AEB10CC51D1L;
                        continue block18;
                    }
                }
                break;
            }
            long l5 = \u13e8;
            boolean bl2 = true;
            block19: while (true) {
                long l6;
                if (!bl2 || (bl2 = false) || !true) {
                    l5 = l6 / (0x60L ^ 0xF81B4764CBA4EE01L);
                }
                switch ((int)l5) {
                    case -940636391: {
                        l6 = 0x2835L ^ 0x9CC6F44A94EE10EAL;
                        continue block19;
                    }
                    case -879845711: {
                        l6 = 0x33F1L ^ 0xA6C140D9093FF2CEL;
                        continue block19;
                    }
                    case 85788649: {
                        l6 = 0x28C5L ^ 0x14EFC20E2A1BD011L;
                        continue block19;
                    }
                    case 1415186628: {
                        break block19;
                    }
                }
                break;
            }
            if (mode != PetGearSupplier.Gears.ENEMY_LOCATOR.getId()) {
                while (true) {
                    long l7;
                    long l8;
                    if ((l8 = (l7 = \u13e8 - (0x44B9L ^ 0xD4A6013397740BBL)) == 0L ? 0 : (l7 < 0L ? -1 : 1)) == false) continue;
                    if (l8 == (0x26EA ^ 0xFFFFD915)) break;
                    l8 = 0x2278 ^ 0x908931BE;
                }
                while (true) {
                    long l9;
                    long l10;
                    if ((l10 = (l9 = \u13e8 - (1628769028422124564L >>> "\u0000\u0000".length())) == 0L ? 0 : (l9 < 0L ? -1 : 1)) == false) continue;
                    if (l10 == (0x2EDD ^ 0xFFFFD122)) {
                        if (mode != PetGearSupplier.Gears.COMBO_GUARD.getId()) {
                            break;
                        }
                        break block32;
                    }
                    l10 = 0x531D ^ 0x966615E0;
                }
                while (true) {
                    long l11;
                    long l12;
                    if ((l12 = (l11 = \u13e8 - (0x579BL ^ 0x4BD381132178AEB0L)) == 0L ? 0 : (l11 < 0L ? -1 : 1)) == false) continue;
                    if (l12 == (0x5739 ^ 0xFFFFA8C6)) break;
                    l12 = 0x3547 ^ 0xE22ED328;
                }
                long l13 = \u13e8;
                block23: while (true) {
                    switch ((int)l13) {
                        case 9320976: {
                            l13 = (0x6C38L ^ 0x769EE064CEB7ED26L) / (0x298L ^ 0xCFA343F89B9F3554L);
                            continue block23;
                        }
                        case 1415186628: {
                            break block23;
                        }
                    }
                    break;
                }
                if (mode != PetGearSupplier.Gears.COMBO_REPAIR.getId()) {
                    n = "".length() >>> "\u0000\u0000".length();
                    return n != 0;
                }
            }
        }
        n = 0x5502 ^ 0x5503;
        return n != 0;
    }

    /*
     * Exception decompiling
     */
    private boolean repairPetWhileWaiting() {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 24[SWITCH]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private boolean containsNPCSubname(String word) {
        String npcSubname;
        if (word == null) {
            return "".length() >>> "\u0000\u0000".length();
        }
        long l = \u13e8;
        boolean bl = true;
        block20: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x679EL ^ 0xD0003F1AE9F4CFB8L);
            }
            switch ((int)l) {
                case -1127096456: {
                    l2 = 0x56E7L ^ 0xBCA2790856A922C7L;
                    continue block20;
                }
                case 1042914058: {
                    l2 = 0x1649L ^ 0x7690A7463F0CB29CL;
                    continue block20;
                }
                case 1415186628: {
                    break block20;
                }
                case 1980317917: {
                    l2 = 0x2862L ^ 0x32C558B9FCFF5000L;
                    continue block20;
                }
            }
            break;
        }
        while (true) {
            long l3;
            long l4;
            if ((l4 = (l3 = \u13e8 - (0xFDL ^ 0x1A61942A6D2CAFECL)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) continue;
            if (l4 == (0x365D ^ 0xFFFFC9A2)) {
                npcSubname = this.mapCycleConfig.NPC_SUBNAME;
                if (npcSubname == null) {
                    return (0x68E2 ^ 0x68E2) != 0;
                }
                break;
            }
            l4 = 0x63E0 ^ 0xF9A121AF;
        }
        while (true) {
            long l5;
            long l6;
            if ((l6 = (l5 = \u13e8 - (0x54BAL ^ 0xFE0F4EEA5EFA32AAL)) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) continue;
            if (l6 == (0x586 ^ 0xFFFFFA79)) break;
            l6 = 0xED3 ^ 0x199FB12;
        }
        npcSubname = npcSubname.toLowerCase();
        while (true) {
            long l7;
            long l8;
            if ((l8 = (l7 = \u13e8 - (0x4C78L ^ 0xCF9D4257B1210BFBL)) == 0L ? 0 : (l7 < 0L ? -1 : 1)) == false) continue;
            if (l8 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l8 = 0x2F24 ^ 0x89FCCB19;
        }
        long l9 = \u13e8;
        block24: while (true) {
            switch ((int)l9) {
                case -654536515: {
                    l9 = (0x6396L ^ 0x404A6D73D71D44D0L) / (0x69B0L ^ 0x5920F295AADCEDBCL);
                    continue block24;
                }
                case 1415186628: {
                    break block24;
                }
            }
            break;
        }
        this.mapCycleConfig.NPC_SUBNAME = npcSubname;
        long l10 = \u13e8;
        boolean bl2 = true;
        block25: while (true) {
            long l11;
            if (!bl2 || (bl2 = false) || !true) {
                l10 = l11 / (0x5408L ^ 0x679AE453F6683B2DL);
            }
            switch ((int)l10) {
                case -1140749996: {
                    l11 = 0x4AB4L ^ 0x4CD9E498C4FE8FBDL;
                    continue block25;
                }
                case 164280888: {
                    l11 = 0x37BAL ^ 0x9CBBF2481418A1B6L;
                    continue block25;
                }
                case 1415186628: {
                    break block25;
                }
            }
            break;
        }
        if (npcSubname.length() == 0) {
            return "".length() >>> "\u0000\u0000".length();
        }
        long l12 = \u13e8;
        boolean bl3 = true;
        block26: while (true) {
            long l13;
            if (!bl3 || (bl3 = false) || !true) {
                l12 = l13 / (0x6865L ^ 0x644E74FB242EEF02L);
            }
            switch ((int)l12) {
                case -1128529607: {
                    l13 = 0x7BB6L ^ 0xAC64934BA354EC15L;
                    continue block26;
                }
                case -489131302: {
                    l13 = 0x1A33L ^ 0x23E9196BE90CB9ADL;
                    continue block26;
                }
                case 1415186628: {
                    break block26;
                }
            }
            break;
        }
        String string = word.toLowerCase();
        while (true) {
            long l14;
            long l15;
            if ((l15 = (l14 = \u13e8 - (0x395FL ^ 0xDCDDD7522235CF31L)) == 0L ? 0 : (l14 < 0L ? -1 : 1)) == false) continue;
            if (l15 == (0x3785 ^ 0xFFFFC87A)) {
                return string.contains(npcSubname);
            }
            l15 = 0x1D9A ^ 0xCDC09D41;
        }
    }

    /*
     * Unable to fully structure code
     */
    private void MoveToHeroTargetPosition() {
        block19: {
            while (true) {
                if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (-1426601439094532524L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v0 == (9178 ^ -9179)) break;
                v0 = 7088 ^ -866240125;
            }
            while (true) {
                if ((v1 = (cfr_temp_1 = MapCycleModule.\u13e8 - (8716L ^ -6756493998421593124L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v1 == (948 ^ 949)) break;
                v1 = -895108776 >>> "\u0000\u0000".length();
            }
            if (!this.hero.hasTarget()) break block19;
            v2 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl16
            block14: while (true) {
                v2 = v3 / (19259L ^ 6633784216580425688L);
lbl16:
                // 2 sources

                switch ((int)v2) {
                    case -1987330828: {
                        v3 = 215039815924461016L >>> "\u0000\u0000".length();
                        continue block14;
                    }
                    case -1416730470: {
                        v3 = 1565L ^ -5711620869310339348L;
                        continue block14;
                    }
                    case -479766317: {
                        v3 = 8123L ^ 3584420372408906126L;
                        continue block14;
                    }
                    case 1415186628: {
                        break block14;
                    }
                }
                break;
            }
            v4 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl32
            block15: while (true) {
                v4 = v5 / (17001L ^ 1551749730206050892L);
lbl32:
                // 2 sources

                switch ((int)v4) {
                    case -2001006750: {
                        v5 = -3907881164107189384L >>> "\u0000\u0000".length();
                        continue block15;
                    }
                    case 1156246228: {
                        v5 = 25940L ^ 3097570762385935018L;
                        continue block15;
                    }
                    case 1415186628: {
                        break block15;
                    }
                    case 1596396137: {
                        v5 = 16137L ^ 8773489749052209161L;
                        continue block15;
                    }
                }
                break;
            }
            while (true) {
                if ((v6 = (cfr_temp_2 = MapCycleModule.\u13e8 - (8572L ^ 3526417791232597030L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v6 == (1943 ^ -1944)) break;
                v6 = 20621 ^ 1566077200;
            }
            v7 = this.hero.target;
            while (true) {
                if ((v8 = (cfr_temp_3 = MapCycleModule.\u13e8 - (22821L ^ 1597136079442916783L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v8 == (15367 ^ -15368)) {
                    this.drive.move((Entity)v7);
                    break;
                }
                v8 = 18471 ^ -1813576663;
            }
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private void cacheWorkMapIdOf(String mapName, MapInfo mapInfo) {
        long l = \u13e8;
        boolean bl = true;
        block10: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x64DDL ^ 0xDA31252ABB406791L);
            }
            switch ((int)l) {
                case -1308344345: {
                    l2 = 0x634CL ^ 0x470AE0217AAA1265L;
                    continue block10;
                }
                case -1222148325: {
                    l2 = -1454490783618193156L >>> "\u0000\u0000".length();
                    continue block10;
                }
                case -1049317170: {
                    l2 = 0x4AAEL ^ 0x9260EFA97D06FB95L;
                    continue block10;
                }
                case 1415186628: {
                    break block10;
                }
            }
            break;
        }
        while (true) {
            long l3;
            long l4;
            if ((l4 = (l3 = \u13e8 - (0x9C8L ^ 0xD7A29DBC0CBAF709L)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) continue;
            if (l4 == (0x73B4 ^ 0xFFFF8C4B)) break;
            l4 = 0x537F ^ 0x4990E68E;
        }
        StarManager starManager = this.main.starManager;
        long l5 = \u13e8;
        block12: while (true) {
            switch ((int)l5) {
                case -4588069: {
                    l5 = (0x7736L ^ 0xA8B378DDF47821A5L) / (0x387FL ^ 0xF529C9AC29C75234L);
                    continue block12;
                }
                case 1415186628: {
                    break block12;
                }
            }
            break;
        }
        com.github.manolo8.darkbot.core.objects.Map map = starManager.byName(mapName);
        while (true) {
            long l6;
            long l7;
            if ((l7 = (l6 = \u13e8 - (0x9CDL ^ 0x5ED89B4912DBB773L)) == 0L ? 0 : (l6 < 0L ? -1 : 1)) == false) continue;
            if (l7 == (0x3FCD ^ 0xFFFFC032)) break;
            l7 = 0x634B ^ 0x550EFA00;
        }
        int n = map.id;
        while (true) {
            long l8;
            long l9;
            if ((l9 = (l8 = \u13e8 - (0x7CD8L ^ 0x762D6E4274E5B963L)) == 0L ? 0 : (l8 < 0L ? -1 : 1)) == false) continue;
            if (l9 == (0x61B2 ^ 0xFFFF9E4D)) break;
            l9 = 0x383A ^ 0xD7259607;
        }
        Integer n2 = n;
        while (true) {
            long l10;
            long l11;
            if ((l11 = (l10 = \u13e8 - (0x2A24L ^ 0x406521F27A205279L)) == 0L ? 0 : (l10 < 0L ? -1 : 1)) == false) continue;
            if (l11 == (0x2EE7 ^ 0xFFFFD118)) {
                mapInfo.cachedMapId = n2;
                return;
            }
            l11 = 0x749A ^ 0x9D25224E;
        }
    }

    /*
     * Unable to fully structure code
     */
    private List<Integer> getPrioritySortedCycleWorkMapIds() {
        block96: {
            block95: {
                while (true) {
                    if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (15173L ^ -6025367590759075788L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                    if (v0 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                    v0 = 16111 ^ 1750016351;
                }
                if (this.cachedPrioritySortedCycleWorkMapIds == null) break block95;
                while (true) {
                    if ((v1 = (cfr_temp_1 = MapCycleModule.\u13e8 - (5795L ^ 8468591690558249256L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                    if (v1 == (14132 ^ -14133)) break;
                    v1 = 28991 ^ -1103659437;
                }
                v2 = System.currentTimeMillis();
                v3 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl17
                block64: while (true) {
                    v3 = v4 / (23005L ^ 5125258744499423706L);
lbl17:
                    // 2 sources

                    switch ((int)v3) {
                        case -1640260648: {
                            v4 = 10370L ^ -620270446616714478L;
                            continue block64;
                        }
                        case -951329104: {
                            v4 = 18405L ^ 1674619591679065777L;
                            continue block64;
                        }
                        case 78355884: {
                            v4 = 513L ^ -4302718338162319797L;
                            continue block64;
                        }
                        case 1415186628: {
                            break block64;
                        }
                    }
                    break;
                }
                if (v2 - this.cachedPrioritySortedCycleWorkMapIdsStartMS <= (524L ^ 4484L)) break block96;
            }
            while (true) {
                if ((v5 = (cfr_temp_2 = MapCycleModule.\u13e8 - (15729L ^ -3801385721915390250L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v5 == (7906 ^ 7907)) break;
                v5 = 20474 ^ 633426392;
            }
            while (true) {
                if ((v6 = (cfr_temp_3 = MapCycleModule.\u13e8 - (15526L ^ -2570198132795581306L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v6 == (17719 ^ -17720)) break;
                v6 = 1294 ^ 2057669354;
            }
            cycleWorkMapInfos = new ArrayList<MapInfo>();
            while (true) {
                if ((v7 = (cfr_temp_4 = MapCycleModule.\u13e8 - (-8419214197318730824L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v7 == (21410 ^ -21411)) break;
                v7 = 26178 ^ 2098241305;
            }
            while (true) {
                if ((v8 = (cfr_temp_5 = MapCycleModule.\u13e8 - (15870L ^ -6899193890784314393L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                if (v8 == (3927 ^ 3926)) break;
                v8 = 9528 ^ 406865918;
            }
            configCycleMapInfosMap = this.mapCycleConfig.CYCLE_MAP_INFOS;
            while (true) {
                if ((v9 = (cfr_temp_6 = MapCycleModule.\u13e8 - (16338L ^ -500558982513917031L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                if (v9 == (16003 ^ -16004)) break;
                v9 = 13280 ^ -1453633958;
            }
            while (true) {
                if ((v10 = (cfr_temp_7 = MapCycleModule.\u13e8 - (106741566770866900L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                if (v10 == (3878 ^ -3879)) break;
                v10 = 26259 ^ 311590218;
            }
            v11 = configCycleMapInfosMap.keySet();
            v12 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl68
            block71: while (true) {
                v12 = v13 / (11193L ^ 6450819945870706263L);
lbl68:
                // 2 sources

                switch ((int)v12) {
                    case -1476422152: {
                        v13 = 25477L ^ 7702112409265407588L;
                        continue block71;
                    }
                    case -1341152884: {
                        v13 = 890L ^ 1247770834125566199L;
                        continue block71;
                    }
                    case 1415186628: {
                        break block71;
                    }
                    case 2097177981: {
                        v13 = 24231L ^ -4271059127390199977L;
                        continue block71;
                    }
                }
                break;
            }
            cycleMapNames = new HashSet<String>(v11);
            while (true) {
                if ((v14 = (cfr_temp_8 = MapCycleModule.\u13e8 - (13369L ^ 2447004349479886207L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                if (v14 == (291 ^ -292)) break;
                v14 = 31806 ^ -487627991;
            }
            var4_4 = cycleMapNames.iterator();
            while (true) {
                block97: {
                    v15 = MapCycleModule.\u13e8;
                    if (true) ** GOTO lbl92
                    block74: while (true) {
                        v15 = (2161L ^ -2503380564590728813L) / (15870L ^ 8724576445189033749L);
lbl92:
                        // 2 sources

                        switch ((int)v15) {
                            case -1053745113: {
                                continue block74;
                            }
                            case 1415186628: {
                                break block74;
                            }
                        }
                        break;
                    }
                    if (!var4_4.hasNext()) break;
                    while (true) {
                        if ((v16 = (cfr_temp_9 = MapCycleModule.\u13e8 - (26053L ^ 2723732219443819504L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
                        if (v16 == (834 ^ -835)) break;
                        v16 = 25247 ^ -332678335;
                    }
                    cycleWorkMapName = (String)var4_4.next();
                    v17 = MapCycleModule.\u13e8;
                    if (true) ** GOTO lbl108
                    block76: while (true) {
                        v17 = (6058L ^ 5317615911569393475L) / (5705470131386454024L >>> "\u0000\u0000".length());
lbl108:
                        // 2 sources

                        switch ((int)v17) {
                            case -1379797884: {
                                continue block76;
                            }
                            case 1415186628: {
                                break block76;
                            }
                        }
                        break;
                    }
                    cycleWorkMapInfo = configCycleMapInfosMap.get(cycleWorkMapName);
                    while (true) {
                        if ((v18 = (cfr_temp_10 = MapCycleModule.\u13e8 - (29882L ^ 4410282130319269381L)) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
                        if (v18 == (8945 ^ -8946)) break;
                        v18 = 27709 ^ -193688698;
                    }
                    if (!cycleWorkMapInfo.isPartOfCycle) continue;
                    v19 = MapCycleModule.\u13e8;
                    if (true) ** GOTO lbl124
                    block78: while (true) {
                        v19 = (9393L ^ 4875513932127647043L) / (-2930096123885180524L >>> "\u0000\u0000".length());
lbl124:
                        // 2 sources

                        switch ((int)v19) {
                            case 1415186628: {
                                break block78;
                            }
                            case 1825002582: {
                                continue block78;
                            }
                        }
                        break;
                    }
                    if (cycleWorkMapInfo.cachedMapId != null) break block97;
                    v20 = MapCycleModule.\u13e8;
                    if (true) ** GOTO lbl134
                    block79: while (true) {
                        v20 = v21 / (-3522603497082078140L >>> "\u0000\u0000".length());
lbl134:
                        // 2 sources

                        switch ((int)v20) {
                            case -691903362: {
                                v21 = 19145L ^ 1112036299541413028L;
                                continue block79;
                            }
                            case 182255032: {
                                v21 = 28673L ^ 5587562236931675211L;
                                continue block79;
                            }
                            case 843087999: {
                                v21 = 3933L ^ -2243194186713225398L;
                                continue block79;
                            }
                            case 1415186628: {
                                break block79;
                            }
                        }
                        break;
                    }
                    this.cacheWorkMapIdOf(cycleWorkMapName, cycleWorkMapInfo);
                }
                while (true) {
                    if ((v22 = (cfr_temp_11 = MapCycleModule.\u13e8 - (4609L ^ 4358744882072029063L)) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
                    if (v22 == (3547 ^ -3548)) break;
                    v22 = 11931 ^ -1031565674;
                }
                v23 = cycleWorkMapInfo.cachedMapId;
                while (true) {
                    if ((v24 = (cfr_temp_12 = MapCycleModule.\u13e8 - (3617764278335846020L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_12 < 0L ? -1 : 1)) == false) continue;
                    if (v24 == (10970 ^ -10971)) break;
                    v24 = 19107 ^ -1145097659;
                }
                if (v23 < 0) continue;
                v25 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl164
                block82: while (true) {
                    v25 = v26 / (19721L ^ -2359688794009148805L);
lbl164:
                    // 2 sources

                    switch ((int)v25) {
                        case -792393209: {
                            v26 = 6698L ^ 1440174724230999329L;
                            continue block82;
                        }
                        case 373135207: {
                            v26 = 6183L ^ -5035973459276774012L;
                            continue block82;
                        }
                        case 1098950309: {
                            v26 = -1206094278035365404L >>> "\u0000\u0000".length();
                            continue block82;
                        }
                        case 1415186628: {
                            break block82;
                        }
                    }
                    break;
                }
                cycleWorkMapInfos.add(cycleWorkMapInfo);
            }
            while (true) {
                if ((v27 = (cfr_temp_13 = MapCycleModule.\u13e8 - (7941L ^ 4272062162021397415L)) == 0L ? 0 : (cfr_temp_13 < 0L ? -1 : 1)) == false) continue;
                if (v27 == (20603 ^ -20604)) break;
                v27 = 1023988404 >>> "\u0000\u0000".length();
            }
            v28 = (Function<MapInfo, Integer>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, lambda$getPrioritySortedCycleWorkMapIds$5(com.tawaret.tawaplugin.features.mapcyclemodule.models.MapInfo ), (Lcom/tawaret/tawaplugin/features/mapcyclemodule/models/MapInfo;)Ljava/lang/Integer;)();
            while (true) {
                if ((v29 = (cfr_temp_14 = MapCycleModule.\u13e8 - (6759L ^ -1079130365767759558L)) == 0L ? 0 : (cfr_temp_14 < 0L ? -1 : 1)) == false) continue;
                if (v29 == (23007 ^ -23008)) break;
                v29 = 29078 ^ -900554821;
            }
            v30 = Comparator.comparing(v28);
            v31 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl195
            block85: while (true) {
                v31 = v32 / (30487L ^ -8442857180299380753L);
lbl195:
                // 2 sources

                switch ((int)v31) {
                    case -285038340: {
                        v32 = 32731L ^ -5044673519980739184L;
                        continue block85;
                    }
                    case 1415186628: {
                        break block85;
                    }
                    case 1777099237: {
                        v32 = 29200L ^ -8853927437309411943L;
                        continue block85;
                    }
                }
                break;
            }
            cycleWorkMapInfos.sort(v30);
            while (true) {
                if ((v33 = (cfr_temp_15 = MapCycleModule.\u13e8 - (32759L ^ -2939107967386840425L)) == 0L ? 0 : (cfr_temp_15 < 0L ? -1 : 1)) == false) continue;
                if (v33 == (24486 ^ -24487)) break;
                v33 = 862599852 >>> "\u0000\u0000".length();
            }
            v34 = cycleWorkMapInfos.stream();
            while (true) {
                if ((v35 = (cfr_temp_16 = MapCycleModule.\u13e8 - (5181L ^ -899974616889109357L)) == 0L ? 0 : (cfr_temp_16 < 0L ? -1 : 1)) == false) continue;
                if (v35 == (9352 ^ -9353)) break;
                v35 = 28232 ^ 1764081852;
            }
            v36 = (Function<MapInfo, Integer>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, lambda$getPrioritySortedCycleWorkMapIds$6(com.tawaret.tawaplugin.features.mapcyclemodule.models.MapInfo ), (Lcom/tawaret/tawaplugin/features/mapcyclemodule/models/MapInfo;)Ljava/lang/Integer;)();
            while (true) {
                if ((v37 = (cfr_temp_17 = MapCycleModule.\u13e8 - (7266L ^ -4949868224585973502L)) == 0L ? 0 : (cfr_temp_17 < 0L ? -1 : 1)) == false) continue;
                if (v37 == (27265 ^ 27264)) break;
                v37 = 32016 ^ 2126057536;
            }
            v38 = v34.map(v36);
            while (true) {
                if ((v39 = (cfr_temp_18 = MapCycleModule.\u13e8 - (3825L ^ -8462540734569549802L)) == 0L ? 0 : (cfr_temp_18 < 0L ? -1 : 1)) == false) continue;
                if (v39 == (29512 ^ 29513)) break;
                v39 = 26291 ^ -428230178;
            }
            v40 = Collectors.toList();
            v41 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl233
            block90: while (true) {
                v41 = v42 / (1883L ^ -8821798301875767513L);
lbl233:
                // 2 sources

                switch ((int)v41) {
                    case -883023191: {
                        v42 = 31414L ^ 2181196487081697383L;
                        continue block90;
                    }
                    case 5003702: {
                        v42 = 26169L ^ -4015051151160929920L;
                        continue block90;
                    }
                    case 1415186628: {
                        break block90;
                    }
                }
                break;
            }
            v43 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl246
            block91: while (true) {
                v43 = v44 / (12209L ^ 5501207402709717666L);
lbl246:
                // 2 sources

                switch ((int)v43) {
                    case -1727890032: {
                        v44 = 24669L ^ 3183932035522815559L;
                        continue block91;
                    }
                    case 1400669244: {
                        v44 = 1755L ^ -9114716462982747785L;
                        continue block91;
                    }
                    case 1415186628: {
                        break block91;
                    }
                }
                break;
            }
            this.cachedPrioritySortedCycleWorkMapIds = v38.collect(v40);
            while (true) {
                if ((v45 = (cfr_temp_19 = MapCycleModule.\u13e8 - (31116L ^ 7233195132695079874L)) == 0L ? 0 : (cfr_temp_19 < 0L ? -1 : 1)) == false) continue;
                if (v45 == (20533 ^ -20534)) break;
                v45 = 4582 ^ -1603571397;
            }
            v46 = System.currentTimeMillis();
            v47 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl266
            block93: while (true) {
                v47 = v48 / (9103L ^ 4771911123253785868L);
lbl266:
                // 2 sources

                switch ((int)v47) {
                    case -1612350298: {
                        v48 = 4706L ^ -7874389850898067360L;
                        continue block93;
                    }
                    case -334128987: {
                        v48 = 7962L ^ -520457631518957892L;
                        continue block93;
                    }
                    case 1415186628: {
                        break block93;
                    }
                }
                break;
            }
            this.cachedPrioritySortedCycleWorkMapIdsStartMS = v46;
        }
        v49 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl281
        block94: while (true) {
            v49 = v50 / (5163L ^ 5058155690700568605L);
lbl281:
            // 2 sources

            switch ((int)v49) {
                case -1445372195: {
                    v50 = 18935L ^ -1120491214667868670L;
                    continue block94;
                }
                case 832159996: {
                    v50 = 28784L ^ 8738681304416951978L;
                    continue block94;
                }
                case 1165689051: {
                    v50 = 17435L ^ 2625432601396675304L;
                    continue block94;
                }
                case 1415186628: {
                    break block94;
                }
            }
            break;
        }
        return this.cachedPrioritySortedCycleWorkMapIds;
    }

    /*
     * Enabled aggressive block sorting
     */
    private boolean isOnLoadingPage() {
        int n;
        long l = \u13e8;
        block4: while (true) {
            switch ((int)l) {
                case 1415186628: {
                    break block4;
                }
                case 1567060479: {
                    l = (0x7EA6L ^ 0xF9973561F803DF5AL) / (0x4422L ^ 0xF98D9A57AB14FE06L);
                    continue block4;
                }
            }
            break;
        }
        while (true) {
            long l2;
            long l3;
            if ((l3 = (l2 = \u13e8 - (0x3E9AL ^ 0x9C720546921527DL)) == 0L ? 0 : (l2 < 0L ? -1 : 1)) == false) continue;
            if (l3 == (0x4D68 ^ 0xFFFFB297)) break;
            l3 = 0x11D0 ^ 0xCCD27C6B;
        }
        com.github.manolo8.darkbot.core.objects.Map map = this.hero.map;
        while (true) {
            long l4;
            long l5;
            if ((l5 = (l4 = \u13e8 - (0x1EC6L ^ 0xB7C2D6181F80FA6FL)) == 0L ? 0 : (l4 < 0L ? -1 : 1)) == false) continue;
            if (l5 == (0x5C93 ^ 0x5C92)) {
                if (map.id == (0x39B3 ^ 0xFFFFC64C)) break;
                n = "".length() >>> "\u0000\u0000".length();
                return n != 0;
            }
            l5 = 0x5088 ^ 0xE6121E0F;
        }
        n = 0x58B5 ^ 0x58B4;
        return n != 0;
    }

    public void tick() {
    }

    /*
     * Unable to fully structure code
     */
    public void tickStopped() {
        v0 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl5
        block33: while (true) {
            v0 = (29183L ^ -9004881531347731584L) / (10473L ^ -7179445605879842389L);
lbl5:
            // 2 sources

            switch ((int)v0) {
                case -499837476: {
                    continue block33;
                }
                case 1415186628: {
                    break block33;
                }
            }
            break;
        }
        v1 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl14
        block34: while (true) {
            v1 = v2 / (8960L ^ -4024031209910277771L);
lbl14:
            // 2 sources

            switch ((int)v1) {
                case -335641312: {
                    v2 = 28833L ^ 4792074509587974181L;
                    continue block34;
                }
                case 437749451: {
                    v2 = 12942L ^ -2556884187033870160L;
                    continue block34;
                }
                case 908421020: {
                    v2 = 9969L ^ -326517504263091253L;
                    continue block34;
                }
                case 1415186628: {
                    break block34;
                }
            }
            break;
        }
        this.twLootNCollectModule.tickStopped();
        v3 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl31
        block35: while (true) {
            v3 = v4 / (-1423094784218785724L >>> "\u0000\u0000".length());
lbl31:
            // 2 sources

            switch ((int)v3) {
                case 1415186628: {
                    break block35;
                }
                case 1702846645: {
                    v4 = 15846L ^ 7521575560238470881L;
                    continue block35;
                }
                case 1789965846: {
                    v4 = -2455072873833004228L >>> "\u0000\u0000".length();
                    continue block35;
                }
            }
            break;
        }
        if (this.isOnLoadingPage()) {
            return;
        }
        while (true) {
            if ((v5 = (cfr_temp_0 = MapCycleModule.\u13e8 - (9518L ^ -4293763901490486173L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v5 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v5 = -360740880 >>> "\u0000\u0000".length();
        }
        this.markAllLogsAsRead();
        while (true) {
            if ((v6 = (cfr_temp_1 = MapCycleModule.\u13e8 - (11911L ^ 2564737170948743534L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v6 == (13945 ^ -13946)) break;
            v6 = 8397 ^ 458076017;
        }
        v7 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl57
        block38: while (true) {
            v7 = v8 / (21176L ^ -466477438329287490L);
lbl57:
            // 2 sources

            switch ((int)v7) {
                case -1896378787: {
                    v8 = 12209L ^ -7834977211145678187L;
                    continue block38;
                }
                case -786655297: {
                    v8 = 16160L ^ -5267323128718081588L;
                    continue block38;
                }
                case 476750885: {
                    v8 = 31026L ^ -8108746681201015261L;
                    continue block38;
                }
                case 1415186628: {
                    break block38;
                }
            }
            break;
        }
        v9 = this.main.hero;
        while (true) {
            if ((v10 = (cfr_temp_2 = MapCycleModule.\u13e8 - (27219L ^ -3149286940590965252L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v10 == (29637 ^ 29636)) break;
            v10 = 15314 ^ -1466210540;
        }
        v11 = v9.map;
        v12 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl80
        block40: while (true) {
            v12 = v13 / (32681L ^ -538196957276449978L);
lbl80:
            // 2 sources

            switch ((int)v12) {
                case -1432214275: {
                    v13 = 1645L ^ 4830760123837741485L;
                    continue block40;
                }
                case 594987101: {
                    v13 = 25913L ^ -834684796408400843L;
                    continue block40;
                }
                case 815950031: {
                    v13 = 24988L ^ -7105512425292357887L;
                    continue block40;
                }
                case 1415186628: {
                    break block40;
                }
            }
            break;
        }
        v14 = v11.id;
        v15 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl97
        block41: while (true) {
            v15 = v16 / (958L ^ 3150720048323387750L);
lbl97:
            // 2 sources

            switch ((int)v15) {
                case -1915068517: {
                    v16 = 1395L ^ -610826536053721078L;
                    continue block41;
                }
                case 470268144: {
                    v16 = 28161L ^ 5698125822890724629L;
                    continue block41;
                }
                case 1190201630: {
                    v16 = -2516487604427768264L >>> "\u0000\u0000".length();
                    continue block41;
                }
                case 1415186628: {
                    break block41;
                }
            }
            break;
        }
        this.progressAfterKillSeconds(v14);
    }

    /*
     * Unable to fully structure code
     */
    private Long getSecondsTillSpawnOnNextMap() {
        v0 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl5
        block19: while (true) {
            v0 = (24012L ^ -5161971694332383608L) / (17594L ^ -6029122560147095043L);
lbl5:
            // 2 sources

            switch ((int)v0) {
                case 601582847: {
                    continue block19;
                }
                case 1415186628: {
                    break block19;
                }
            }
            break;
        }
        while (true) {
            if ((v1 = (cfr_temp_0 = MapCycleModule.\u13e8 - (3527L ^ 8062996143809320983L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v1 == (5160 ^ -5161)) break;
            v1 = 18815 ^ 1767286264;
        }
        msOnNextMap = this.getMsTillWithinNPCSpawnPeriod(this.cachedNextWorkMapId);
        if (msOnNextMap == null) {
            return null;
        }
        while (true) {
            if ((v2 = (cfr_temp_1 = MapCycleModule.\u13e8 - (20903L ^ -3728985064705664122L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v2 == (22448 ^ 22449)) break;
            v2 = 15818 ^ -159739590;
        }
        v3 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl29
        block22: while (true) {
            v3 = v4 / (8568L ^ -5147292675224526036L);
lbl29:
            // 2 sources

            switch ((int)v3) {
                case 643273636: {
                    v4 = 11331L ^ -3468642262972533491L;
                    continue block22;
                }
                case 881956609: {
                    v4 = 17440L ^ -8436084328082371357L;
                    continue block22;
                }
                case 1415186628: {
                    break block22;
                }
            }
            break;
        }
        v5 = msOnNextMap;
        v6 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl43
        block23: while (true) {
            v6 = (19580L ^ 178280486012796150L) / (6668962703669730140L >>> "\u0000\u0000".length());
lbl43:
            // 2 sources

            switch ((int)v6) {
                case 1415186628: {
                    break block23;
                }
                case 2069335911: {
                    continue block23;
                }
            }
            break;
        }
        v7 = TimeUnit.MILLISECONDS.toSeconds(v5);
        v8 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl53
        block24: while (true) {
            v8 = v9 / (17082L ^ 6795994517910059355L);
lbl53:
            // 2 sources

            switch ((int)v8) {
                case 369627967: {
                    v9 = 30077L ^ -1221540325279868397L;
                    continue block24;
                }
                case 885872048: {
                    v9 = 2184L ^ -7207193562000172513L;
                    continue block24;
                }
                case 1350573455: {
                    v9 = 18475L ^ -5679762014117934611L;
                    continue block24;
                }
                case 1415186628: {
                    break block24;
                }
            }
            break;
        }
        return v7;
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public int getWaitSecondsAfterKill() {
        long l = \u13e8;
        block4: while (true) {
            switch ((int)l) {
                case 909125197: {
                    l = (0x912L ^ 0x93A9792E62DE5A18L) / (0x2611L ^ 0xFDE310D89A3765C4L);
                    continue block4;
                }
                case 1415186628: {
                    break block4;
                }
            }
            break;
        }
        while (true) {
            long l2;
            long l3;
            if ((l3 = (l2 = \u13e8 - (0x7871L ^ 0xA34F123CD75235DDL)) == 0L ? 0 : (l2 < 0L ? -1 : 1)) == false) continue;
            if (l3 == (0xC9 ^ 0xC8)) break;
            l3 = -1940328736 >>> "\u0000\u0000".length();
        }
        com.github.manolo8.darkbot.core.objects.Map map = this.hero.map;
        while (true) {
            long l4;
            long l5;
            if ((l5 = (l4 = \u13e8 - (0x3CBCL ^ 0x78937BEF5716EBF2L)) == 0L ? 0 : (l4 < 0L ? -1 : 1)) == false) continue;
            if (l5 == (0x66B7 ^ 0xFFFF9948)) break;
            l5 = 0x7C52 ^ 0x37D62921;
        }
        int n = map.id;
        while (true) {
            long l6;
            long l7;
            if ((l7 = (l6 = \u13e8 - (0x63A2L ^ 0x5A8051CFF4063CD1L)) == 0L ? 0 : (l6 < 0L ? -1 : 1)) == false) continue;
            if (l7 == (0x278B ^ 0xFFFFD874)) {
                return this.getWaitSecondsAfterKill(n);
            }
            l7 = 0x7A7C ^ 0x72FDB9E2;
        }
    }

    /*
     * Unable to fully structure code
     */
    private int getWaitSecondsAfterKill(int currentMapId) {
        block86: {
            block85: {
                block84: {
                    v0 = MapCycleModule.\u13e8;
                    if (true) ** GOTO lbl5
                    block53: while (true) {
                        v0 = v1 / (27086L ^ -6740677851836852889L);
lbl5:
                        // 2 sources

                        switch ((int)v0) {
                            case -630835466: {
                                v1 = 32618L ^ -1557375530125498328L;
                                continue block53;
                            }
                            case 1415186628: {
                                break block53;
                            }
                            case 2056302391: {
                                v1 = 3306L ^ -2379869576171632308L;
                                continue block53;
                            }
                        }
                        break;
                    }
                    while (true) {
                        if ((v2 = (cfr_temp_0 = MapCycleModule.\u13e8 - (6669L ^ -4335823670770258041L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                            continue;
                        }
                        if (v2 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                        v2 = 19630 ^ -500590032;
                    }
                    stayTillNextMapThresholdSeconds = this.predictNpcSpawnConfig.STAY_TILL_NEXT_MAP_PREDICTED_SPAWN_THRESHOLD;
                    minSecondsToWait = 18820 ^ 18820;
                    if (stayTillNextMapThresholdSeconds < 0) break block84;
                    while (true) {
                        if ((v3 = (cfr_temp_1 = MapCycleModule.\u13e8 - (15444L ^ 2458373665978528050L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) {
                            continue;
                        }
                        if (v3 == (25471 ^ -25472)) break;
                        v3 = 26382 ^ -2109783015;
                    }
                    secondsTillSpawnOnNextMap = this.getSecondsTillSpawnOnNextMap();
                    v4 = MapCycleModule.\u13e8;
                    if (true) ** GOTO lbl34
                    block56: while (true) {
                        v4 = v5 / (7677L ^ 122431214966795517L);
lbl34:
                        // 2 sources

                        switch ((int)v4) {
                            case -1553889010: {
                                v5 = 32756L ^ -6865249409499147467L;
                                continue block56;
                            }
                            case -1290789549: {
                                v5 = 7756L ^ 1002545075562194176L;
                                continue block56;
                            }
                            case 198261571: {
                                v5 = 6073141377067794008L >>> "\u0000\u0000".length();
                                continue block56;
                            }
                            case 1415186628: {
                                break block56;
                            }
                        }
                        break;
                    }
                    afterNpcKillSecondsPastNullable = this.getAfterNpcKillSecondsPast();
                    if (secondsTillSpawnOnNextMap == null) break block84;
                    while (true) {
                        if ((v6 = (cfr_temp_2 = MapCycleModule.\u13e8 - (2268L ^ 8296472755657584091L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) {
                            continue;
                        }
                        if (v6 == (869 ^ -870)) break;
                        v6 = -1331975804 >>> "\u0000\u0000".length();
                    }
                    if (secondsTillSpawnOnNextMap < (long)stayTillNextMapThresholdSeconds) break block84;
                    if (afterNpcKillSecondsPastNullable == null) {
                        v7 = 16753L ^ 16753L;
                    } else {
                        while (true) {
                            if ((v8 = (cfr_temp_3 = MapCycleModule.\u13e8 - (1979L ^ -6718153975485968619L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) {
                                continue;
                            }
                            if (v8 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                                v7 = afterNpcKillSecondsPastNullable;
                                break;
                            }
                            v8 = 1413545616 >>> "\u0000\u0000".length();
                        }
                    }
                    afterNpcKillSecondsPast = v7;
                    while (true) {
                        if ((v9 = (cfr_temp_4 = MapCycleModule.\u13e8 - (3216L ^ 8887150449998338082L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) {
                            continue;
                        }
                        if (v9 == (19535 ^ -19536)) break;
                        v9 = 14209 ^ 2135990797;
                    }
                    v10 = secondsTillSpawnOnNextMap - (long)stayTillNextMapThresholdSeconds + afterNpcKillSecondsPast;
                    v11 = MapCycleModule.\u13e8;
                    if (true) ** GOTO lbl78
                    block60: while (true) {
                        v11 = v12 / (2408L ^ -3389371505665679786L);
lbl78:
                        // 2 sources

                        switch ((int)v11) {
                            case -2132137266: {
                                v12 = 2787L ^ 7827787208481726344L;
                                continue block60;
                            }
                            case 1415186628: {
                                break block60;
                            }
                            case 1941335224: {
                                v12 = 7561L ^ 3254881961204772467L;
                                continue block60;
                            }
                        }
                        break;
                    }
                    minSecondsToWait = Math.toIntExact(v10);
                }
                while (true) {
                    if ((v13 = (cfr_temp_5 = MapCycleModule.\u13e8 - (28675L ^ 8352836849326973336L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) {
                        continue;
                    }
                    if (v13 == (7846 ^ -7847)) break;
                    v13 = 26503 ^ -1029903757;
                }
                if (!this.solarClashIsWaitable()) break block85;
                v14 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl100
                block62: while (true) {
                    v14 = v15 / (4340L ^ 3582537514328444657L);
lbl100:
                    // 2 sources

                    switch ((int)v14) {
                        case -638378182: {
                            v15 = 15782L ^ -6644017127401746971L;
                            continue block62;
                        }
                        case -130512723: {
                            v15 = 12990L ^ 8594876743911046249L;
                            continue block62;
                        }
                        case 1415186628: {
                            break block62;
                        }
                        case 1530177103: {
                            v15 = 12646L ^ -7142315702829957594L;
                            continue block62;
                        }
                    }
                    break;
                }
                minSecondsToWait = Math.max(minSecondsToWait, 8503 ^ 8501);
            }
            v16 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl118
            block63: while (true) {
                v16 = (25266L ^ -9024868679421014783L) / (27114L ^ -3739931228141990479L);
lbl118:
                // 2 sources

                switch ((int)v16) {
                    case -1957648359: {
                        continue block63;
                    }
                    case 1415186628: {
                        break block63;
                    }
                }
                break;
            }
            while (true) {
                if ((v17 = (cfr_temp_6 = MapCycleModule.\u13e8 - (30771L ^ -2832055695769249871L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (v17 == (4514 ^ -4515)) break;
                v17 = 24468 ^ -1021439814;
            }
            normalWaitSecondsAfterKill = this.afterKillConfig.WAIT_SECONDS_AFTER_KILL;
            v18 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl134
            block65: while (true) {
                v18 = v19 / (25254L ^ -3880203004386623466L);
lbl134:
                // 2 sources

                switch ((int)v18) {
                    case -1071999835: {
                        v19 = 17181L ^ 5979528841462295802L;
                        continue block65;
                    }
                    case 1415186628: {
                        break block65;
                    }
                    case 1573840878: {
                        v19 = 6489L ^ -9084484188859096728L;
                        continue block65;
                    }
                }
                break;
            }
            if (!this.preventTimeSpentUpdates) break block86;
            while (true) {
                if ((v20 = (cfr_temp_7 = MapCycleModule.\u13e8 - (23608L ^ -2886802334520244580L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (v20 == (11691 ^ -11692)) break;
                v20 = 19066 ^ 1974657637;
            }
            v21 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl154
            block67: while (true) {
                v21 = v22 / (-6394714745424456888L >>> "\u0000\u0000".length());
lbl154:
                // 2 sources

                switch ((int)v21) {
                    case -473851310: {
                        v22 = 27877L ^ -1175888071926453805L;
                        continue block67;
                    }
                    case -261614149: {
                        v22 = 6998L ^ -6484839343195243252L;
                        continue block67;
                    }
                    case 1415186628: {
                        break block67;
                    }
                    case 1761224050: {
                        v22 = 158L ^ 113193309387382756L;
                        continue block67;
                    }
                }
                break;
            }
            if (!this.extraSecondsOnRefreshableMapsConfig.USE_EXTRA_REFRESH_SECONDS) break block86;
            v23 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl171
            block68: while (true) {
                v23 = v24 / (30080L ^ 8097568887657891806L);
lbl171:
                // 2 sources

                switch ((int)v23) {
                    case -702120303: {
                        v24 = 2336449697767117588L >>> "\u0000\u0000".length();
                        continue block68;
                    }
                    case 1415186628: {
                        break block68;
                    }
                    case 1584267526: {
                        v24 = -4992758389827158752L >>> "\u0000\u0000".length();
                        continue block68;
                    }
                }
                break;
            }
            if (!this.isRefreshableMap(currentMapId)) break block86;
            v25 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl185
            block69: while (true) {
                v25 = v26 / (4135L ^ -1085298832669468307L);
lbl185:
                // 2 sources

                switch ((int)v25) {
                    case -669376551: {
                        v26 = 6145L ^ -4131222330826398894L;
                        continue block69;
                    }
                    case -481182484: {
                        v26 = 21212L ^ 4815257472443334274L;
                        continue block69;
                    }
                    case -459731598: {
                        v26 = 159L ^ 8510451208243080686L;
                        continue block69;
                    }
                    case 1415186628: {
                        break block69;
                    }
                }
                break;
            }
            v27 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl201
            block70: while (true) {
                v27 = v28 / (17107L ^ -9174998985704852712L);
lbl201:
                // 2 sources

                switch ((int)v27) {
                    case 310760535: {
                        v28 = 29177L ^ 7997422869606397261L;
                        continue block70;
                    }
                    case 1415186628: {
                        break block70;
                    }
                    case 1813646411: {
                        v28 = 25358L ^ -4414856384072910502L;
                        continue block70;
                    }
                }
                break;
            }
            normalWaitSecondsAfterKill += this.extraSecondsOnRefreshableMapsConfig.EXTRA_REFRESH_MAP_SECONDS;
        }
        while (true) {
            if ((v29 = (cfr_temp_8 = MapCycleModule.\u13e8 - (20560L ^ -1574663920379887151L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v29 == (19676 ^ -19677)) break;
            v29 = 10680 ^ 427118267;
        }
        return Math.max(minSecondsToWait, normalWaitSecondsAfterKill);
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean canLeavePreferredRegion() {
        int n;
        block8: {
            while (true) {
                long l;
                long l2;
                if ((l2 = (l = \u13e8 - (0x6A5BL ^ 0xF66F632641966EL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (l2 == (0x1B98 ^ 0xFFFFE467)) {
                    if (!this.areAttendsInPreferredRegion()) {
                        break;
                    }
                    break block8;
                }
                l2 = 339864164 >>> "\u0000\u0000".length();
            }
            while (true) {
                long l;
                long l3;
                if ((l3 = (l = \u13e8 - (0x4E9FL ^ 0xA24B35D3ED8422C5L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (l3 == (0x3589 ^ 0x3588)) {
                    if (!this.areSolarClashesInPreferredRegion()) {
                        break;
                    }
                    break block8;
                }
                l3 = 0x2E5B ^ 0x8FB3976E;
            }
            n = 0x5B0E ^ 0x5B0F;
            return n != 0;
        }
        n = "".length() >>> "\u0000\u0000".length();
        return n != 0;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public boolean isWaitingAfterKill() {
        boolean bl;
        long l = \u13e8;
        block15: while (true) {
            switch ((int)l) {
                case -698830501: {
                    l = (0x1554L ^ 0x3240E88EBE708227L) / (3149986278254103192L >>> "\u0000\u0000".length());
                    continue block15;
                }
                case 1415186628: {
                    break block15;
                }
            }
            break;
        }
        Long afterNpcKillSecondsPast = this.getAfterNpcKillSecondsPast();
        if (afterNpcKillSecondsPast == null) {
            return (0x52C7 ^ 0x52C7) != 0;
        }
        long l2 = \u13e8;
        boolean bl2 = true;
        block16: while (true) {
            long l3;
            if (!bl2 || (bl2 = false) || !true) {
                l2 = l3 / (0xFFBL ^ 0xBC57937808927E6EL);
            }
            switch ((int)l2) {
                case -1835529429: {
                    l3 = 9051791290523783900L >>> "\u0000\u0000".length();
                    continue block16;
                }
                case -860269537: {
                    l3 = 0x2E77L ^ 0x8A714DB5F44D4D65L;
                    continue block16;
                }
                case 183943886: {
                    l3 = 0x3B22L ^ 0x769CC3347874F967L;
                    continue block16;
                }
                case 1415186628: {
                    break block16;
                }
            }
            break;
        }
        long l4 = this.getWaitSecondsAfterKill();
        long l5 = \u13e8;
        boolean bl3 = true;
        block17: while (true) {
            long l6;
            if (!bl3 || (bl3 = false) || !true) {
                l5 = l6 / (4292682894310826008L >>> "\u0000\u0000".length());
            }
            switch ((int)l5) {
                case -1617293224: {
                    l6 = 0x3776L ^ 0x4C2511C934F329C9L;
                    continue block17;
                }
                case -229790542: {
                    l6 = 0x7F04L ^ 0xD4BC60F6138BCA2EL;
                    continue block17;
                }
                case 1415186628: {
                    break block17;
                }
            }
            break;
        }
        if (l4 > afterNpcKillSecondsPast) {
            bl = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
            return bl;
        }
        bl = "".length() >>> "\u0000\u0000".length();
        return bl;
    }

    /*
     * Unable to fully structure code
     */
    private boolean progressAfterKillSeconds(int currentMapId) {
        block35: {
            block36: {
                while (true) {
                    if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (-6840609193264233744L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                    if (v0 == (17928 ^ -17929)) break;
                    v0 = 1354 ^ -1726775477;
                }
                afterNpcKillSecondsPast = this.getAfterNpcKillSecondsPast();
                if (afterNpcKillSecondsPast == null) break block35;
                while (true) {
                    if ((v1 = (cfr_temp_1 = MapCycleModule.\u13e8 - (18656L ^ -4239782304119029731L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                    if (v1 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                    v1 = 23929 ^ -1905926701;
                }
                this.markAllLogsAsRead();
                while (true) {
                    if ((v2 = (cfr_temp_2 = MapCycleModule.\u13e8 - (9901L ^ 629915490228573220L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                    if (v2 == (31898 ^ -31899)) break;
                    v2 = 1965 ^ 1580099630;
                }
                this.markLatestDeathsKnown();
                v3 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl24
                block29: while (true) {
                    v3 = v4 / (24668L ^ -3153019310677846992L);
lbl24:
                    // 2 sources

                    switch ((int)v3) {
                        case -1151690433: {
                            v4 = 29397L ^ -6515198654830951333L;
                            continue block29;
                        }
                        case 96433289: {
                            v4 = 16499L ^ 2608241566048452657L;
                            continue block29;
                        }
                        case 1243649033: {
                            v4 = -179879737285501076L >>> "\u0000\u0000".length();
                            continue block29;
                        }
                        case 1415186628: {
                            break block29;
                        }
                    }
                    break;
                }
                waitSecondsAfterKill = this.getWaitSecondsAfterKill(currentMapId);
                v5 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl41
                block30: while (true) {
                    v5 = (781L ^ -8199547821230688375L) / (5488L ^ -6527037614138297360L);
lbl41:
                    // 2 sources

                    switch ((int)v5) {
                        case 1415186628: {
                            break block30;
                        }
                        case 1713283684: {
                            continue block30;
                        }
                    }
                    break;
                }
                v6 = afterKillPeriodExpired = afterNpcKillSecondsPast >= (long)waitSecondsAfterKill ? "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length() : "".length() >>> "\u0000\u0000".length();
                if (afterKillPeriodExpired == 0) break block36;
                v7 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl52
                block31: while (true) {
                    v7 = v8 / (-308114654113671564L >>> "\u0000\u0000".length());
lbl52:
                    // 2 sources

                    switch ((int)v7) {
                        case 969179663: {
                            v8 = 508L ^ 6414834451139684021L;
                            continue block31;
                        }
                        case 1415186628: {
                            break block31;
                        }
                        case 1637878431: {
                            v8 = 6003L ^ -5451333771062686397L;
                            continue block31;
                        }
                    }
                    break;
                }
                if (!this.canLeavePreferredRegion()) break block36;
                while (true) {
                    if ((v9 = (cfr_temp_3 = MapCycleModule.\u13e8 - (31194L ^ -7712924608848580490L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                    if (v9 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                    v9 = 5445 ^ 1419858339;
                }
                this.npcKilledTimeStampMs = null;
                v10 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl72
                block33: while (true) {
                    v10 = v11 / (18891L ^ -939093558669192620L);
lbl72:
                    // 2 sources

                    switch ((int)v10) {
                        case -1960736432: {
                            v11 = 13109L ^ 2840792494742089687L;
                            continue block33;
                        }
                        case -1942809072: {
                            v11 = -3334271479114007708L >>> "\u0000\u0000".length();
                            continue block33;
                        }
                        case 1415186628: {
                            break block33;
                        }
                        case 1558164599: {
                            v11 = 18809L ^ 8235178451482909927L;
                            continue block33;
                        }
                    }
                    break;
                }
                var6_5 = new byte[9524 ^ 9510];
                var6_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 2905 ^ -2898;
                var6_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 23809 ^ 23922;
                var6_5[30934 ^ 30930] = 27111 ^ 27027;
                var6_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 404 >>> "\u0000\u0000".length();
                var6_5[23743 ^ 23732] = 4003 ^ 4047;
                var6_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 27242 ^ 27162;
                var6_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 27638 ^ 27551;
                var6_5[18282 ^ 18283] = 448 >>> "\u0000\u0000".length();
                var6_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 17356 ^ 17388;
                var6_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 3630 ^ 3661;
                var6_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 396 >>> "\u0000\u0000".length();
                var6_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 3745 ^ 3713;
                var6_5[22045 ^ 22033] = 27766 ^ 27671;
                var6_5["".length() >>> "\u0000\u0000".length()] = 9248 ^ 9294;
                var6_5[2770 ^ 2754] = 25635 ^ 25671;
                var6_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 10298 ^ 10321;
                var6_5[18134 ^ 18142] = 5761 ^ 5874;
                var6_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 5456 ^ 5429;
                var6_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() ^ "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length()] = 184 >>> "\u0000\u0000".length();
                v12 = new String(var6_5);
                v13 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl109
                block34: while (true) {
                    v13 = v14 / (5168L ^ -2501941948590174933L);
lbl109:
                    // 2 sources

                    switch ((int)v13) {
                        case -1180483349: {
                            v14 = 10679L ^ -9169321503489529193L;
                            continue block34;
                        }
                        case 195436375: {
                            v14 = 19000L ^ -4220692365868199674L;
                            continue block34;
                        }
                        case 1415186628: {
                            break block34;
                        }
                    }
                    break;
                }
                this.switchToMap(currentMapId, this.nextMapIdAfterWaitKillPeriod, v12);
            }
            return "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        }
        return (boolean)(11290 ^ 11290);
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private boolean solarClashIsWaitable() {
        long l = \u13e8;
        block23: while (true) {
            switch ((int)l) {
                case 1415186628: {
                    break block23;
                }
                case 1663833621: {
                    l = (-7553683893451262568L >>> "\u0000\u0000".length()) / (0x645DL ^ 0x8AE48D59CD131A7EL);
                    continue block23;
                }
            }
            break;
        }
        long l2 = \u13e8;
        boolean bl = true;
        block24: while (true) {
            long l3;
            if (!bl || (bl = false) || !true) {
                l2 = l3 / (0x3C93L ^ 0x5E2D082FEB45B71CL);
            }
            switch ((int)l2) {
                case 190692276: {
                    l3 = 0x1D70L ^ 0x64ED51852B8A72ACL;
                    continue block24;
                }
                case 422301046: {
                    l3 = 0x452EL ^ 0xF68F40A76361AEA2L;
                    continue block24;
                }
                case 1415186628: {
                    break block24;
                }
                case 2020154782: {
                    l3 = 0x1A8DL ^ 0x536B41EBE78DCCA8L;
                    continue block24;
                }
            }
            break;
        }
        if (!this.afterKillConfig.SHOULD_WAIT_UNTIL_SOLAR_CLASH_GONE) {
            return (0x6F11 ^ 0x6F11) != 0;
        }
        while (true) {
            long l4;
            long l5;
            if ((l5 = (l4 = \u13e8 - (0x56B4L ^ 0x9757CC20084AF760L)) == 0L ? 0 : (l4 < 0L ? -1 : 1)) == false) continue;
            if (l5 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l5 = 0x427E ^ 0xAB64C590;
        }
        long l6 = \u13e8;
        block26: while (true) {
            switch ((int)l6) {
                case 1415186628: {
                    break block26;
                }
                case 1473893313: {
                    l6 = (0x387FL ^ 0x8DC19FCD468D50AEL) / (0x6D56L ^ 0xC44157B0F24112D2L);
                    continue block26;
                }
            }
            break;
        }
        String boxName = this.miscellaneousConfig.BOX_NAME;
        while (true) {
            long l7;
            long l8;
            if ((l8 = (l7 = \u13e8 - (0x11FCL ^ 0xB65C2B7060EB89FDL)) == 0L ? 0 : (l7 < 0L ? -1 : 1)) == false) continue;
            if (l8 == (0x51FE ^ 0x51FF)) {
                if (boxName.length() == 0) {
                    return "".length() >>> "\u0000\u0000".length() != 0;
                }
                break;
            }
            l8 = 0x6DAB ^ 0xCF854AF9;
        }
        long l9 = \u13e8;
        block28: while (true) {
            switch ((int)l9) {
                case 1415186628: {
                    break block28;
                }
                case 1785108184: {
                    l9 = (0xE16L ^ 0xF7EAC1BCB058C2D4L) / (0x6CFBL ^ 0x8E3497218D1648A3L);
                    continue block28;
                }
            }
            break;
        }
        BoxInfo boxInfo = this.getBoxInfo(boxName);
        if (boxInfo == null) {
            return "".length() >>> "\u0000\u0000".length();
        }
        long l10 = \u13e8;
        boolean bl2 = true;
        block29: while (true) {
            long l11;
            if (!bl2 || (bl2 = false) || !true) {
                l10 = l11 / (0x4674L ^ 0xBF277587D50BF2L);
            }
            switch ((int)l10) {
                case -1564889936: {
                    l11 = 4859894106643242248L >>> "\u0000\u0000".length();
                    continue block29;
                }
                case 1415186628: {
                    return boxInfo.collect;
                }
                case 1456020172: {
                    l11 = 0x6717L ^ 0xF119D94A979198F5L;
                    continue block29;
                }
            }
            break;
        }
        return boxInfo.collect;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private boolean areSolarClashesInPreferredRegion() {
        int n;
        block25: {
            long l = \u13e8;
            boolean bl = true;
            block15: while (true) {
                long l2;
                if (!bl || (bl = false) || !true) {
                    l = l2 / (-3383529783249817728L >>> "\u0000\u0000".length());
                }
                switch ((int)l) {
                    case -933929729: {
                        l2 = 0x2110L ^ 0x23EA3257BFB716B3L;
                        continue block15;
                    }
                    case 198230455: {
                        l2 = 0x146CL ^ 0x17A55C0C4995849EL;
                        continue block15;
                    }
                    case 1415186628: {
                        break block15;
                    }
                    case 1572622210: {
                        l2 = 0x6785L ^ 0x41B94242CF21DA3AL;
                        continue block15;
                    }
                }
                break;
            }
            if (this.solarClashIsWaitable()) {
                long l3 = \u13e8;
                block16: while (true) {
                    switch ((int)l3) {
                        case -170903847: {
                            l3 = (0x7185L ^ 0xC4317841B1F52BA2L) / (0x7DE1L ^ 0xF237D8230C0D21A9L);
                            continue block16;
                        }
                        case 1415186628: {
                            break block16;
                        }
                    }
                    break;
                }
                long l4 = \u13e8;
                boolean bl2 = true;
                block17: while (true) {
                    long l5;
                    if (!bl2 || (bl2 = false) || !true) {
                        l4 = l5 / (0x4752L ^ 0xFA7870F85A6B9CC3L);
                    }
                    switch ((int)l4) {
                        case 1415186628: {
                            break block17;
                        }
                        case 1780850465: {
                            l5 = 0x2B05L ^ 0x50E8C305F19AEB33L;
                            continue block17;
                        }
                        case 1977160914: {
                            l5 = 0x1A4CL ^ 0x31E5F626B2A5A16BL;
                            continue block17;
                        }
                    }
                    break;
                }
                String string = this.miscellaneousConfig.BOX_NAME;
                while (true) {
                    long l6;
                    long l7;
                    if ((l7 = (l6 = \u13e8 - (0x623DL ^ 0x3E6B5468D23F8C8FL)) == 0L ? 0 : (l6 < 0L ? -1 : 1)) == false) continue;
                    if (l7 == (0x13CA ^ 0xFFFFEC35)) break;
                    l7 = 0x88C ^ 0x302B0060;
                }
                Long l8 = this.getNumberOfBoxesInSight(string);
                while (true) {
                    long l9;
                    long l10;
                    if ((l10 = (l9 = \u13e8 - (5045435188737723524L >>> "\u0000\u0000".length())) == 0L ? 0 : (l9 < 0L ? -1 : 1)) == false) continue;
                    if (l10 == (0x6459 ^ 0xFFFF9BA6)) {
                        if (l8 > (0x4555L ^ 0x4555L)) {
                            break;
                        }
                        break block25;
                    }
                    l10 = -424636900 >>> "\u0000\u0000".length();
                }
                n = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
                return n != 0;
            }
        }
        n = 0x2BB3 ^ 0x2BB3;
        return n != 0;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private boolean areAttendsInPreferredRegion() {
        int n;
        block25: {
            long l = \u13e8;
            boolean bl = true;
            block13: while (true) {
                long l2;
                if (!bl || (bl = false) || !true) {
                    l = l2 / (0x5329L ^ 0xA7038546462ACB18L);
                }
                switch ((int)l) {
                    case 118623541: {
                        l2 = 0x7826L ^ 0x73879A30A4874BBEL;
                        continue block13;
                    }
                    case 1415186628: {
                        break block13;
                    }
                    case 1493064314: {
                        l2 = 0x40C6L ^ 0xAA89C3C35D5D4968L;
                        continue block13;
                    }
                }
                break;
            }
            while (true) {
                long l3;
                long l4;
                if ((l4 = (l3 = \u13e8 - (-3753944002838228444L >>> "\u0000\u0000".length())) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) continue;
                if (l4 == (0x3197 ^ 0xFFFFCE68)) break;
                l4 = 0xD5C ^ 0x38642E08;
            }
            String string = this.afterKillConfig.ATTEND_SUBNAME;
            while (true) {
                long l5;
                long l6;
                if ((l6 = (l5 = \u13e8 - (0x79EFL ^ 0x4F221B796FFA037DL)) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) continue;
                if (l6 == (0x3DCD ^ 0xFFFFC232)) {
                    if (string.length() != 0) {
                        break;
                    }
                    break block25;
                }
                l6 = 129397012 >>> "\u0000\u0000".length();
            }
            while (true) {
                long l7;
                long l8;
                if ((l8 = (l7 = \u13e8 - (0x204AL ^ 0xE2E8DD342E0A9AD0L)) == 0L ? 0 : (l7 < 0L ? -1 : 1)) == false) continue;
                if (l8 == (0x4B3C ^ 0xFFFFB4C3)) break;
                l8 = 0x585B ^ 0xE1B63587;
            }
            while (true) {
                long l9;
                long l10;
                if ((l10 = (l9 = \u13e8 - (-2111782613081243324L >>> "\u0000\u0000".length())) == 0L ? 0 : (l9 < 0L ? -1 : 1)) == false) continue;
                if (l10 == (0x539 ^ 0xFFFFFAC6)) break;
                l10 = 0x6B2E ^ 0x8CEFA739;
            }
            TwLootModule twLootModule = this.twLootNCollectModule.lootModule;
            long l11 = \u13e8;
            block18: while (true) {
                switch ((int)l11) {
                    case -437360426: {
                        l11 = (0x28AAL ^ 0xA0DA36511C3765DCL) / (0x599CL ^ 0xE9F6B03F7801394EL);
                        continue block18;
                    }
                    case 1415186628: {
                        break block18;
                    }
                }
                break;
            }
            while (true) {
                long l12;
                long l13;
                if ((l13 = (l12 = \u13e8 - (0x60FFL ^ 0x70F1211AA3D79ACBL)) == 0L ? 0 : (l12 < 0L ? -1 : 1)) == false) continue;
                if (l13 == (0xCBB ^ 0xFFFFF344)) break;
                l13 = 0x1171 ^ 0xCC785108;
            }
            String string2 = this.afterKillConfig.ATTEND_SUBNAME;
            long l14 = \u13e8;
            block20: while (true) {
                switch ((int)l14) {
                    case -2104490186: {
                        l14 = (0x2BFCL ^ 0x7DDE38C6F8668014L) / (0x4B38L ^ 0xF295216810F3048DL);
                        continue block20;
                    }
                    case 1415186628: {
                        break block20;
                    }
                }
                break;
            }
            if (twLootModule.npcSubnameInPreferredRegion(string2)) {
                n = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
                return n != 0;
            }
        }
        n = 0x3CF0 ^ 0x3CF0;
        return n != 0;
    }

    /*
     * Unable to fully structure code
     */
    private void switchToPreferredRegionTravelConfig() {
        block60: {
            block59: {
                while (true) {
                    if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (30782L ^ -839980426897112985L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                    if (v0 == (4152 ^ -4153)) break;
                    v0 = 32344 ^ -1981967584;
                }
                while (true) {
                    if ((v1 = (cfr_temp_1 = MapCycleModule.\u13e8 - (-4212122306993261412L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                    if (v1 == (19150 ^ -19151)) break;
                    v1 = 8912 ^ 1443820431;
                }
                v2 = this.hero.health;
                v3 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl16
                block38: while (true) {
                    v3 = v4 / (25283L ^ 356365255307777493L);
lbl16:
                    // 2 sources

                    switch ((int)v3) {
                        case -674061709: {
                            v4 = 4060L ^ 8670738563939046652L;
                            continue block38;
                        }
                        case 243750885: {
                            v4 = -487131675432747284L >>> "\u0000\u0000".length();
                            continue block38;
                        }
                        case 1415186628: {
                            break block38;
                        }
                        case 1586271531: {
                            v4 = 6041L ^ 5200992781481917426L;
                            continue block38;
                        }
                    }
                    break;
                }
                if (!(v2.hpPercent() * 100.0 < 70.0)) break block59;
                while (true) {
                    if ((v5 = (cfr_temp_2 = MapCycleModule.\u13e8 - (17063L ^ 5241089231455776777L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                    if (v5 == (27853 ^ -27854)) break;
                    v5 = 18616 ^ 1359753891;
                }
                while (true) {
                    if ((v6 = (cfr_temp_3 = MapCycleModule.\u13e8 - (7310L ^ -8111383070791452039L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                    if (v6 == (17337 ^ 17336)) break;
                    v6 = 7222 ^ -1296012870;
                }
                v7 = this.hero.health;
                v8 = 8000 >>> "\u0000\u0000".length();
                v9 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl45
                block41: while (true) {
                    v9 = v10 / (24748L ^ -4103116828601577940L);
lbl45:
                    // 2 sources

                    switch ((int)v9) {
                        case -804944497: {
                            v10 = 17572L ^ -8336029676074989837L;
                            continue block41;
                        }
                        case 809532869: {
                            v10 = 5859L ^ -3859474630283437832L;
                            continue block41;
                        }
                        case 1415186628: {
                            break block41;
                        }
                    }
                    break;
                }
                if (v7.hpIncreasedIn(v8)) {
                    while (true) {
                        if ((v11 = (cfr_temp_4 = MapCycleModule.\u13e8 - (7217L ^ -3321393654409343937L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                        if (v11 == (27530 ^ 27531)) break;
                        v11 = 26662 ^ 1704118108;
                    }
                    this.inDiamondMode = 22200 ^ 22200;
                    while (true) {
                        if ((v12 = (cfr_temp_5 = MapCycleModule.\u13e8 - (21861L ^ -8513139006857286596L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                        if (v12 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                        v12 = 13951 ^ 181607876;
                    }
                    this.setNormalTravelConfig();
                    return;
                }
                while (true) {
                    if ((v13 = (cfr_temp_6 = MapCycleModule.\u13e8 - (22090L ^ -525804789540469429L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                    if (v13 == (12950 ^ -12951)) break;
                    v13 = 27992 ^ 833467277;
                }
                while (true) {
                    if ((v14 = (cfr_temp_7 = MapCycleModule.\u13e8 - (2814L ^ -3285477830830118427L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                    if (v14 == (21834 ^ 21835)) break;
                    v14 = 5252 ^ 1943305246;
                }
                v15 = this.hero.health;
                while (true) {
                    if ((v16 = (cfr_temp_8 = MapCycleModule.\u13e8 - (18932L ^ -1205311912450249231L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                    if (v16 == (12975 ^ -12976)) break;
                    v16 = 6268 ^ 133719310;
                }
                if (!v15.hpDecreasedIn(20664 ^ 22376)) break block59;
                v17 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
                v18 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl90
                block47: while (true) {
                    v18 = v19 / (8859L ^ -1609807410771715970L);
lbl90:
                    // 2 sources

                    switch ((int)v18) {
                        case -2037188513: {
                            v19 = 22374L ^ -6191592240758572251L;
                            continue block47;
                        }
                        case -1389003135: {
                            v19 = 9684L ^ 8694810539811266360L;
                            continue block47;
                        }
                        case -1367971756: {
                            v19 = 10849L ^ -3177927590126763043L;
                            continue block47;
                        }
                        case 1415186628: {
                            break block47;
                        }
                    }
                    break;
                }
                this.inDiamondMode = v17;
                v20 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl107
                block48: while (true) {
                    v20 = v21 / (29192L ^ 4704568572300799742L);
lbl107:
                    // 2 sources

                    switch ((int)v20) {
                        case 842147058: {
                            v21 = 31514L ^ -6398368376765230560L;
                            continue block48;
                        }
                        case 1415186628: {
                            break block48;
                        }
                        case 1754369537: {
                            v21 = 14317L ^ -4044392851541642083L;
                            continue block48;
                        }
                    }
                    break;
                }
                this.setDiamondMode();
                return;
            }
            while (true) {
                if ((v22 = (cfr_temp_9 = MapCycleModule.\u13e8 - (-6319076035505047412L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
                if (v22 == (8577 ^ -8578)) break;
                v22 = 27026 ^ -566294701;
            }
            if (!this.inDiamondMode) break block60;
            v23 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl129
            block50: while (true) {
                v23 = v24 / (1950L ^ -7645808098329284114L);
lbl129:
                // 2 sources

                switch ((int)v23) {
                    case -1455480937: {
                        v24 = 13031L ^ 7748939813366805146L;
                        continue block50;
                    }
                    case -248270283: {
                        v24 = 19983L ^ -4391334133419813939L;
                        continue block50;
                    }
                    case 1187917106: {
                        v24 = 32743L ^ 8469355840429879862L;
                        continue block50;
                    }
                    case 1415186628: {
                        break block50;
                    }
                }
                break;
            }
            v25 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl145
            block51: while (true) {
                v25 = (85714276921159292L >>> "\u0000\u0000".length()) / (19882L ^ -8666306549300214142L);
lbl145:
                // 2 sources

                switch ((int)v25) {
                    case 753006246: {
                        continue block51;
                    }
                    case 1415186628: {
                        break block51;
                    }
                }
                break;
            }
            v26 = this.hero.health;
            while (true) {
                if ((v27 = (cfr_temp_10 = MapCycleModule.\u13e8 - (6868L ^ 7611637043713836579L)) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
                if (v27 == (15511 ^ -15512)) break;
                v27 = 31636 ^ -1503183873;
            }
            if (v26.hpDecreasedIn(17971 ^ 16867)) {
                while (true) {
                    if ((v28 = (cfr_temp_11 = MapCycleModule.\u13e8 - (1403L ^ -3186542302867243743L)) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
                    if (v28 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                    v28 = 1395291840 >>> "\u0000\u0000".length();
                }
                this.setDiamondMode();
                return;
            }
            while (true) {
                if ((v29 = (cfr_temp_12 = MapCycleModule.\u13e8 - (28436L ^ -4959476520205064893L)) == 0L ? 0 : (cfr_temp_12 < 0L ? -1 : 1)) == false) continue;
                if (v29 == (4611 ^ 4610)) {
                    this.inDiamondMode = 9409 ^ 9409;
                    break;
                }
                v29 = 13444 ^ -998721903;
            }
        }
        v30 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl176
        block55: while (true) {
            v30 = (22936L ^ -893243749111440366L) / (23108L ^ 8567948298646867790L);
lbl176:
            // 2 sources

            switch ((int)v30) {
                case -791852605: {
                    continue block55;
                }
                case 1415186628: {
                    break block55;
                }
            }
            break;
        }
        this.setNormalTravelConfig();
    }

    private void setNormalTravelConfig() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0xC87L ^ 0x5B7FCDFBE37A6432L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x5B04 ^ 0xFFFFA4FB)) break;
            l2 = 0x6787 ^ 0x9346AE9F;
        }
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = \u13e8 - (0x5B30L ^ 0x28050E4067B4A215L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l3 == (0x5560 ^ 0xFFFFAA9F)) break;
            l3 = 0x59B7 ^ 0x494DE9C9;
        }
        while (true) {
            long l;
            long l4;
            if ((l4 = (l = \u13e8 - (0x6CC5L ^ 0x531743E5BD99C55FL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l4 == (0x2603 ^ 0xFFFFD9FC)) break;
            l4 = 0x5711 ^ 0x4E6045B3;
        }
        Config.ShipConfig shipConfig = this.mapCycleConfig.PREFERRED_REGION_TRAVEL_CONFIG;
        while (true) {
            long l;
            long l5;
            if ((l5 = (l = \u13e8 - (0x74FL ^ 0xAB4FF3FFE203D00FL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l5 == (0x5C86 ^ 0x5C87)) break;
            l5 = -74697244 >>> "\u0000\u0000".length();
        }
        this.hero.setMode(shipConfig);
    }

    /*
     * Unable to fully structure code
     */
    private void setDiamondMode() {
        while (true) {
            if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (2118L ^ -123631370890827304L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (5868 ^ -5869)) break;
            v0 = 7244 ^ -741892552;
        }
        while (true) {
            if ((v1 = (cfr_temp_1 = MapCycleModule.\u13e8 - (16719L ^ -7371885410061539706L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v1 == (7641 ^ 7640)) break;
            v1 = 5092 ^ -1923597077;
        }
        while (true) {
            if ((v2 = (cfr_temp_2 = MapCycleModule.\u13e8 - (1571L ^ -4805011614884625932L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v2 == (12025 ^ 12024)) break;
            v2 = 21657 ^ -227029644;
        }
        v3 = this.mapCycleConfig.LOW_HP_PREFERRED_REGION_TRAVEL_CONFIG;
        v4 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl21
        block9: while (true) {
            v4 = v5 / (30578L ^ 5201221027825441044L);
lbl21:
            // 2 sources

            switch ((int)v4) {
                case -1008642615: {
                    v5 = 1125L ^ -6392528616812288533L;
                    continue block9;
                }
                case -97954521: {
                    v5 = 2563L ^ -8153125292779749586L;
                    continue block9;
                }
                case 1415186628: {
                    break block9;
                }
                case 1893401932: {
                    v5 = 19859L ^ 8453150287223394968L;
                    continue block9;
                }
            }
            break;
        }
        this.hero.setMode(v3);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void switchToNPCRewardConfig() {
        long l = \u13e8;
        block12: while (true) {
            switch ((int)l) {
                case 187147578: {
                    l = (0x7FA5L ^ 0x77B1430BA756CC37L) / (0x4216L ^ 0xCD3E3FBF424D8C3CL);
                    continue block12;
                }
                case 1415186628: {
                    break block12;
                }
            }
            break;
        }
        long l2 = \u13e8;
        block13: while (true) {
            switch ((int)l2) {
                case -450518013: {
                    l2 = (0x788L ^ 0x34E02507BB7ABE08L) / (0x5A96L ^ 0x3D095C2DBB589D5FL);
                    continue block13;
                }
                case 1415186628: {
                    break block13;
                }
            }
            break;
        }
        long l3 = \u13e8;
        block14: while (true) {
            switch ((int)l3) {
                case 277428437: {
                    l3 = (0x191FL ^ 0x6779D0C0EA77548L) / (0x357DL ^ 0xFC3ED4B2DA6FFEB9L);
                    continue block14;
                }
                case 1415186628: {
                    break block14;
                }
            }
            break;
        }
        Config.ShipConfig shipConfig = this.npcRewardConfig.NPC_REWARD_CONFIG;
        while (true) {
            long l4;
            long l5;
            if ((l5 = (l4 = \u13e8 - (0x1108L ^ 0xA093966986920C7CL)) == 0L ? 0 : (l4 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l5 == (0x729C ^ 0x729D)) {
                this.hero.setMode(shipConfig);
                return;
            }
            l5 = 0x6115 ^ 0x4779A43F;
        }
    }

    /*
     * Unable to fully structure code
     */
    private void switchToCollectConfig() {
        block85: {
            block86: {
                v0 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl5
                block62: while (true) {
                    v0 = v1 / (24606L ^ 4732163541239132897L);
lbl5:
                    // 2 sources

                    switch ((int)v0) {
                        case -2077959691: {
                            v1 = 27271L ^ 7571615610103007654L;
                            continue block62;
                        }
                        case 46863110: {
                            v1 = 1633L ^ -6441357141622281134L;
                            continue block62;
                        }
                        case 1415186628: {
                            break block62;
                        }
                        case 1488636792: {
                            v1 = 26552L ^ -1045532143717886344L;
                            continue block62;
                        }
                    }
                    break;
                }
                v2 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl21
                block63: while (true) {
                    v2 = (29431L ^ -3190804098458881956L) / (11981L ^ 2501688192480193186L);
lbl21:
                    // 2 sources

                    switch ((int)v2) {
                        case -211812014: {
                            continue block63;
                        }
                        case 1415186628: {
                            break block63;
                        }
                    }
                    break;
                }
                if (!this.mapCycleBoxCollectConfig.ENABLE_COLLECT_CONFIG) break block86;
                v3 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl31
                block64: while (true) {
                    v3 = v4 / (23287L ^ 2689234938608372759L);
lbl31:
                    // 2 sources

                    switch ((int)v3) {
                        case 1415186628: {
                            break block64;
                        }
                        case 1450485493: {
                            v4 = 18355L ^ -1820734660478965847L;
                            continue block64;
                        }
                        case 1948327125: {
                            v4 = 29986L ^ -381057181163264559L;
                            continue block64;
                        }
                    }
                    break;
                }
                v5 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl44
                block65: while (true) {
                    v5 = v6 / (28784L ^ 512991121909548350L);
lbl44:
                    // 2 sources

                    switch ((int)v5) {
                        case -85323961: {
                            v6 = 5077L ^ 2840177114309615911L;
                            continue block65;
                        }
                        case 1074307435: {
                            v6 = 1750L ^ 5292687878568592708L;
                            continue block65;
                        }
                        case 1415186628: {
                            break block65;
                        }
                    }
                    break;
                }
                if (HeroExtensions.IsInRadiationZone(this.hero)) break block86;
                while (true) {
                    if ((v7 = (cfr_temp_0 = MapCycleModule.\u13e8 - (10935L ^ 8424487273592467731L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                    if (v7 == (24867 ^ -24868)) break;
                    v7 = 16735 ^ -886752865;
                }
                while (true) {
                    if ((v8 = (cfr_temp_1 = MapCycleModule.\u13e8 - (1079L ^ 9033700632136855557L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                    if (v8 == (6838 ^ -6839)) break;
                    v8 = 22646 ^ -269813911;
                }
                while (true) {
                    if ((v9 = (cfr_temp_2 = MapCycleModule.\u13e8 - (15473L ^ 8367757440929491565L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                    if (v9 == (23009 ^ -23010)) break;
                    v9 = -1910779780 >>> "\u0000\u0000".length();
                }
                v10 = this.mapCycleBoxCollectConfig.COLLECT_BOX;
                v11 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl74
                block69: while (true) {
                    v11 = v12 / (5035429300930551432L >>> "\u0000\u0000".length());
lbl74:
                    // 2 sources

                    switch ((int)v11) {
                        case -256347336: {
                            v12 = 29866L ^ -6035536025085199575L;
                            continue block69;
                        }
                        case -16450302: {
                            v12 = 25975L ^ 5882132761446739175L;
                            continue block69;
                        }
                        case 1415186628: {
                            break block69;
                        }
                    }
                    break;
                }
                this.hero.setMode(v10);
                v13 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl89
                block70: while (true) {
                    v13 = v14 / (10415L ^ 1981907893528693678L);
lbl89:
                    // 2 sources

                    switch ((int)v13) {
                        case -60483324: {
                            v14 = 27744L ^ -2612187918888579262L;
                            continue block70;
                        }
                        case 141551421: {
                            v14 = 23151L ^ 7876605158598101132L;
                            continue block70;
                        }
                        case 1415186628: {
                            break block70;
                        }
                        case 2031989259: {
                            v14 = 7875L ^ 6609891189202451567L;
                            continue block70;
                        }
                    }
                    break;
                }
                v15 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl105
                block71: while (true) {
                    v15 = (-7995325581471050608L >>> "\u0000\u0000".length()) / (24794L ^ 1044100362110086626L);
lbl105:
                    // 2 sources

                    switch ((int)v15) {
                        case 227796857: {
                            continue block71;
                        }
                        case 1415186628: {
                            break block71;
                        }
                    }
                    break;
                }
                x = this.mapCycleBoxCollectConfig.PRESS_COLLECT_FORMATION_KEY_SECONDS;
                if (x <= 0) break block85;
                while (true) {
                    if ((v16 = (cfr_temp_3 = MapCycleModule.\u13e8 - (17718L ^ -4351177565870018244L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                    if (v16 == (7943 ^ 7942)) break;
                    v16 = 19642 ^ -406383901;
                }
                v17 = System.currentTimeMillis();
                v18 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl122
                block73: while (true) {
                    v18 = v19 / (6749L ^ 6536517326310091705L);
lbl122:
                    // 2 sources

                    switch ((int)v18) {
                        case -803387182: {
                            v19 = 22554L ^ -2484121860737371928L;
                            continue block73;
                        }
                        case 1037453116: {
                            v19 = 12953L ^ -2861270659605378783L;
                            continue block73;
                        }
                        case 1415186628: {
                            break block73;
                        }
                        case 1951701921: {
                            v19 = 2923L ^ -7520283445508137369L;
                            continue block73;
                        }
                    }
                    break;
                }
                v20 = v17 - this.collectorConfigFormationKeyPressMs;
                v21 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl139
                block74: while (true) {
                    v21 = v22 / (31250L ^ 2262391204317758654L);
lbl139:
                    // 2 sources

                    switch ((int)v21) {
                        case -1329569410: {
                            v22 = 8386L ^ 1650278207748093356L;
                            continue block74;
                        }
                        case -330101554: {
                            v22 = -48982101722797440L >>> "\u0000\u0000".length();
                            continue block74;
                        }
                        case 1415186628: {
                            break block74;
                        }
                    }
                    break;
                }
                v23 = x;
                v24 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl153
                block75: while (true) {
                    v24 = v25 / (5377L ^ -4081646774222596243L);
lbl153:
                    // 2 sources

                    switch ((int)v24) {
                        case -2115724449: {
                            v25 = 6993L ^ 1511046491516048884L;
                            continue block75;
                        }
                        case -1672110322: {
                            v25 = 20563L ^ -780589471166741520L;
                            continue block75;
                        }
                        case -896548475: {
                            v25 = 25414L ^ 6210646629185420360L;
                            continue block75;
                        }
                        case 1415186628: {
                            break block75;
                        }
                    }
                    break;
                }
                if (v20 < TimeUnit.SECONDS.toMillis(v23)) break block85;
                v26 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl170
                block76: while (true) {
                    v26 = v27 / (24320L ^ 4896042395197444628L);
lbl170:
                    // 2 sources

                    switch ((int)v26) {
                        case -733663781: {
                            v27 = 8908L ^ 690248167834323799L;
                            continue block76;
                        }
                        case 984964801: {
                            v27 = 16538L ^ -7044737650786838663L;
                            continue block76;
                        }
                        case 1415186628: {
                            break block76;
                        }
                        case 1887043454: {
                            v27 = 19946L ^ 964051781643386552L;
                            continue block76;
                        }
                    }
                    break;
                }
                v28 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl186
                block77: while (true) {
                    v28 = (-3773522164566437348L >>> "\u0000\u0000".length()) / (8693L ^ -7295401725106341589L);
lbl186:
                    // 2 sources

                    switch ((int)v28) {
                        case -1310419274: {
                            continue block77;
                        }
                        case 1415186628: {
                            break block77;
                        }
                    }
                    break;
                }
                v29 = this.mapCycleBoxCollectConfig.COLLECT_BOX;
                while (true) {
                    if ((v30 = (cfr_temp_4 = MapCycleModule.\u13e8 - (20831L ^ 8199072839505061298L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                    if (v30 == (8642 ^ -8643)) break;
                    v30 = 12020 ^ 199516542;
                }
                v31 = v29.FORMATION;
                while (true) {
                    if ((v32 = (cfr_temp_5 = MapCycleModule.\u13e8 - (39L ^ 6270826925090514436L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                    if (v32 == (4881 ^ -4882)) break;
                    v32 = 28324 ^ 1764444738;
                }
                ApiExtensions.keyboardClick(v31);
                while (true) {
                    if ((v33 = (cfr_temp_6 = MapCycleModule.\u13e8 - (6823174994103570384L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                    if (v33 == (28165 ^ -28166)) break;
                    v33 = 6275 ^ 1277448613;
                }
                v34 = System.currentTimeMillis();
                while (true) {
                    if ((v35 = (cfr_temp_7 = MapCycleModule.\u13e8 - (20116L ^ 8175658752899006497L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                    if (v35 == (32660 ^ -32661)) {
                        this.collectorConfigFormationKeyPressMs = v34;
                        break block85;
                    }
                    v35 = 21350 ^ 1215951968;
                }
            }
            while (true) {
                if ((v36 = (cfr_temp_8 = MapCycleModule.\u13e8 - (1312L ^ 2425627424520241403L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                if (v36 == (29579 ^ -29580)) {
                    this.switchToPreferredRegionTravelConfig();
                    break;
                }
                v36 = 14269 ^ 953044164;
            }
        }
    }

    private boolean inWaitTicksPeriod() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x1825L ^ 0x5D2271057CDD0EE7L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == (0x498A ^ 0xFFFFB675)) break;
            l2 = 0x29E0 ^ 0x4FF50BAC;
        }
        return this.npcKilledTimeStampMs != null ? "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length() : "".length() >>> "\u0000\u0000".length();
    }

    /*
     * Enabled aggressive block sorting
     */
    private boolean shipIsInPreferredRegion() {
        long l = \u13e8;
        block4: while (true) {
            switch ((int)l) {
                case 13504830: {
                    l = (-9206897071834410392L >>> "\u0000\u0000".length()) / (0x1C90L ^ 0x7790EBCB2C5A3ADDL);
                    continue block4;
                }
                case 1415186628: {
                    break block4;
                }
            }
            break;
        }
        while (true) {
            long l2;
            long l3;
            if ((l3 = (l2 = \u13e8 - (0x6242L ^ 0xBEDA97C6CE514E68L)) == 0L ? 0 : (l2 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l3 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                return this.EntityIsInPreferredRegion((Entity)this.hero);
            }
            l3 = 0x7B7C ^ 0xAED41B34;
        }
    }

    /*
     * Unable to fully structure code
     */
    private boolean EntityIsInPreferredRegion(Entity entity) {
        v0 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl5
        block12: while (true) {
            v0 = v1 / (18248L ^ -3252014510362706096L);
lbl5:
            // 2 sources

            switch ((int)v0) {
                case -1883693508: {
                    v1 = 15470L ^ 2858741309724045138L;
                    continue block12;
                }
                case 920922946: {
                    v1 = 10049L ^ -4690519616249189718L;
                    continue block12;
                }
                case 1415186628: {
                    break block12;
                }
                case 1960904160: {
                    v1 = 26005L ^ 8921265665780722764L;
                    continue block12;
                }
            }
            break;
        }
        while (true) {
            if ((v2 = (cfr_temp_0 = MapCycleModule.\u13e8 - (28392L ^ -6275645943121923966L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v2 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v2 = 8066 ^ 1002581412;
        }
        v3 = this.main.mapManager;
        v4 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl27
        block14: while (true) {
            v4 = v5 / (19488L ^ 1908048793889469168L);
lbl27:
            // 2 sources

            switch ((int)v4) {
                case -2107283722: {
                    v5 = 32552L ^ 113140741565305458L;
                    continue block14;
                }
                case -1030500893: {
                    v5 = 26654L ^ 5319880004164623058L;
                    continue block14;
                }
                case 292650366: {
                    v5 = 32566L ^ -2271805764994644467L;
                    continue block14;
                }
                case 1415186628: {
                    break block14;
                }
            }
            break;
        }
        return MapManagerExtensions.isInPreferredRegion(v3, entity);
    }

    /*
     * Unable to fully structure code
     */
    private void PressSafetyKey() {
        block23: {
            while (true) {
                if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (12227L ^ -1998579251979494725L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v0 == (11360 ^ -11361)) break;
                v0 = 1641100824 >>> "\u0000\u0000".length();
            }
            if (!this.CanPressSafetyKey()) break block23;
            v1 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl11
            block18: while (true) {
                v1 = v2 / (926951140290610064L >>> "\u0000\u0000".length());
lbl11:
                // 2 sources

                switch ((int)v1) {
                    case -765390104: {
                        v2 = 25224L ^ -8088792686045157044L;
                        continue block18;
                    }
                    case -377019276: {
                        v2 = 28504L ^ 2161824277943919460L;
                        continue block18;
                    }
                    case 1088896898: {
                        v2 = 30865L ^ -8700103797055453858L;
                        continue block18;
                    }
                    case 1415186628: {
                        break block18;
                    }
                }
                break;
            }
            while (true) {
                if ((v3 = (cfr_temp_1 = MapCycleModule.\u13e8 - (2735L ^ -457398115784852483L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v3 == (10808 ^ -10809)) break;
                v3 = 27750 ^ 597804151;
            }
            v4 = this.mapCycleSafetyConfig.SAFE_ABILITY_KEY;
            while (true) {
                if ((v5 = (cfr_temp_2 = MapCycleModule.\u13e8 - (10182L ^ -2445926322381765776L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v5 == (22443 ^ -22444)) break;
                v5 = 18688 ^ 1853646189;
            }
            ApiExtensions.keyboardClick(v4);
            v6 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl39
            block21: while (true) {
                v6 = v7 / (17676L ^ 9164914818913693790L);
lbl39:
                // 2 sources

                switch ((int)v6) {
                    case -609027212: {
                        v7 = 620276990440150288L >>> "\u0000\u0000".length();
                        continue block21;
                    }
                    case 1415186628: {
                        break block21;
                    }
                    case 1575654971: {
                        v7 = 5340L ^ -3406302800626665619L;
                        continue block21;
                    }
                }
                break;
            }
            v8 = System.currentTimeMillis();
            v9 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl53
            block22: while (true) {
                v9 = v10 / (23850L ^ -1431577937363423189L);
lbl53:
                // 2 sources

                switch ((int)v9) {
                    case -1060615579: {
                        v10 = 28450L ^ -1969168426647358697L;
                        continue block22;
                    }
                    case 463965263: {
                        v10 = 7043L ^ -4756885921708556894L;
                        continue block22;
                    }
                    case 1415186628: {
                        break block22;
                    }
                    case 1544175327: {
                        v10 = 19058L ^ 4319215421809942935L;
                        continue block22;
                    }
                }
                break;
            }
            this.safetyKeyStartMS = v8;
        }
    }

    /*
     * Unable to fully structure code
     */
    private void pressInstaShieldKey() {
        block12: {
            while (true) {
                if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (6174L ^ 8630217870935202303L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v0 == (26862 ^ -26863)) break;
                v0 = 10476 ^ 1159684545;
            }
            if (!this.canPressInstaShieldKey()) break block12;
            while (true) {
                if ((v1 = (cfr_temp_1 = MapCycleModule.\u13e8 - (29306L ^ -5947309547452716945L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v1 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v1 = 21315 ^ -1944445552;
            }
            while (true) {
                if ((v2 = (cfr_temp_2 = MapCycleModule.\u13e8 - (3784L ^ -1456988710025439389L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v2 == (7351 ^ -7352)) break;
                v2 = 31956 ^ 749343607;
            }
            v3 = this.mapCycleSafetyConfig.INSTA_SHIELD_KEY;
            v4 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl22
            block8: while (true) {
                v4 = v5 / (17322L ^ -6357755799453533045L);
lbl22:
                // 2 sources

                switch ((int)v4) {
                    case -1008340284: {
                        v5 = 20878L ^ -8339258733195092278L;
                        continue block8;
                    }
                    case 53340364: {
                        v5 = 13214L ^ 8640963976252300933L;
                        continue block8;
                    }
                    case 1415186628: {
                        break block8;
                    }
                }
                break;
            }
            ApiExtensions.keyboardClick(v3);
            while (true) {
                if ((v6 = (cfr_temp_3 = MapCycleModule.\u13e8 - (13798L ^ 3737830995122009109L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v6 == (11483 ^ -11484)) break;
                v6 = 77556844 >>> "\u0000\u0000".length();
            }
            v7 = System.currentTimeMillis();
            while (true) {
                if ((v8 = (cfr_temp_4 = MapCycleModule.\u13e8 - (-3249551185991787796L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v8 == (15479 ^ -15480)) {
                    this.instaShieldKeyStartMs = v7;
                    break;
                }
                v8 = 23345 ^ -47476711;
            }
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private boolean isWaitingForSafetyCloak() {
        int n;
        long l = \u13e8;
        boolean bl = true;
        block6: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x7097L ^ 0xC3BBE2DDE3880FE6L);
            }
            switch ((int)l) {
                case -1866806533: {
                    l2 = 0x2A10L ^ 0x685DE8897F7DB38L;
                    continue block6;
                }
                case -1677179397: {
                    l2 = 0x2A4CL ^ 0x7701D45E6FF44831L;
                    continue block6;
                }
                case 886983146: {
                    l2 = 0x7974L ^ 0x2B4A277839ED9AE8L;
                    continue block6;
                }
                case 1415186628: {
                    break block6;
                }
            }
            break;
        }
        while (true) {
            long l3;
            long l4;
            if ((l4 = (l3 = \u13e8 - (0x49E9L ^ 0xA01CA35E0A5E8DF2L)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) continue;
            if (l4 == (0x5198 ^ 0x5199)) {
                if (this.hero.isInvisible()) {
                    return "".length() >>> "\u0000\u0000".length() != 0;
                }
                break;
            }
            l4 = 668890980 >>> "\u0000\u0000".length();
        }
        while (true) {
            long l5;
            long l6;
            if ((l6 = (l5 = \u13e8 - (0x371DL ^ 0xE7398BD42A538488L)) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) continue;
            if (l6 == (0x56F6 ^ 0xFFFFA909)) break;
            l6 = 1888828872 >>> "\u0000\u0000".length();
        }
        long l7 = System.currentTimeMillis();
        while (true) {
            long l8;
            long l9;
            if ((l9 = (l8 = \u13e8 - (0x7032L ^ 0x48519711F5D59470L)) == 0L ? 0 : (l8 < 0L ? -1 : 1)) == false) continue;
            if (l9 == (0x1550 ^ 0xFFFFEAAF)) {
                if (l7 - this.waitingForSafetyCloakStartMs <= 20000L >>> "\u0000\u0000".length()) break;
                n = "".length() >>> "\u0000\u0000".length();
                return n != 0;
            }
            l9 = -699890448 >>> "\u0000\u0000".length();
        }
        n = 0x3F84 ^ 0x3F85;
        return n != 0;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private boolean canPressInstaShieldKey() {
        boolean bl;
        long l = \u13e8;
        boolean bl2 = true;
        block10: while (true) {
            long l2;
            if (!bl2 || (bl2 = false) || !true) {
                l = l2 / (0x4CDL ^ 0xEB65263B3FB4929DL);
            }
            switch ((int)l) {
                case -1665395103: {
                    l2 = 0x5DACL ^ 0xEB58F46C61A5DE68L;
                    continue block10;
                }
                case -1307759463: {
                    l2 = 0x299FL ^ 0xCC8C4326389120B8L;
                    continue block10;
                }
                case 1415186628: {
                    break block10;
                }
            }
            break;
        }
        long l3 = System.currentTimeMillis();
        long l4 = \u13e8;
        boolean bl3 = true;
        block11: while (true) {
            long l5;
            if (!bl3 || (bl3 = false) || !true) {
                l4 = l5 / (-431010553008047244L >>> "\u0000\u0000".length());
            }
            switch ((int)l4) {
                case -488367746: {
                    l5 = 0x7BF7L ^ 0xC86E5B938985294L;
                    continue block11;
                }
                case 1157363014: {
                    l5 = 0x6C1FL ^ 0x4F08ACE6A25C5834L;
                    continue block11;
                }
                case 1415186628: {
                    break block11;
                }
            }
            break;
        }
        if (l3 - this.instaShieldKeyStartMs > (0x678L ^ 0x15F0L)) {
            bl = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
            return bl;
        }
        bl = "".length() >>> "\u0000\u0000".length();
        return bl;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private boolean CanPressSafetyKey() {
        boolean bl;
        long l = \u13e8;
        boolean bl2 = true;
        block10: while (true) {
            long l2;
            if (!bl2 || (bl2 = false) || !true) {
                l = l2 / (0x1609L ^ 0x5DD609B22D6F7A03L);
            }
            switch ((int)l) {
                case -2126648733: {
                    l2 = 0x5456L ^ 0x4C0A526338C62DFDL;
                    continue block10;
                }
                case -1122223083: {
                    l2 = 0x2D0CL ^ 0xEF9A2D59D61D7BB3L;
                    continue block10;
                }
                case 1415186628: {
                    break block10;
                }
                case 1439964636: {
                    l2 = 0x551AL ^ 0xA49FF6BB1759F667L;
                    continue block10;
                }
            }
            break;
        }
        long l3 = System.currentTimeMillis();
        long l4 = \u13e8;
        block11: while (true) {
            switch ((int)l4) {
                case 1278240805: {
                    l4 = (0x5F1EL ^ 0xB24821A426348023L) / (0x61F8L ^ 0xBCD36D57873706E4L);
                    continue block11;
                }
                case 1415186628: {
                    break block11;
                }
            }
            break;
        }
        if (l3 - this.safetyKeyStartMS > (0x100DL ^ 0x385L)) {
            bl = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
            return bl;
        }
        bl = "".length() >>> "\u0000\u0000".length();
        return bl;
    }

    /*
     * Unable to fully structure code
     */
    private boolean isUnsafe() {
        block42: {
            block41: {
                block40: {
                    while (true) {
                        if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (31602L ^ -1647704377078331877L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                        if (v0 == (22174 ^ -22175)) break;
                        v0 = 3953 ^ -1172840841;
                    }
                    v1 = System.currentTimeMillis();
                    while (true) {
                        if ((v2 = (cfr_temp_1 = MapCycleModule.\u13e8 - (288L ^ -230056859282792195L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                        if (v2 == (12249 ^ -12250)) break;
                        v2 = -1536206332 >>> "\u0000\u0000".length();
                    }
                    if (v1 - this.lastIsUnsafeCheckMs <= (18585L ^ 18797L)) break block40;
                    v3 = MapCycleModule.\u13e8;
                    if (true) ** GOTO lbl17
                    block27: while (true) {
                        v3 = v4 / (20729L ^ 922302559508963059L);
lbl17:
                        // 2 sources

                        switch ((int)v3) {
                            case -877562210: {
                                v4 = 17330L ^ -5991218466518667373L;
                                continue block27;
                            }
                            case 1415186628: {
                                break block27;
                            }
                            case 1840486975: {
                                v4 = 4461L ^ 8492951392331053907L;
                                continue block27;
                            }
                        }
                        break;
                    }
                    v5 = System.currentTimeMillis();
                    v6 = MapCycleModule.\u13e8;
                    if (true) ** GOTO lbl31
                    block28: while (true) {
                        v6 = v7 / (25847L ^ -3144638824058635637L);
lbl31:
                        // 2 sources

                        switch ((int)v6) {
                            case -1117252212: {
                                v7 = 3671L ^ 6403041312256785837L;
                                continue block28;
                            }
                            case -766719358: {
                                v7 = 19100L ^ -6280022967470295616L;
                                continue block28;
                            }
                            case 1415186628: {
                                break block28;
                            }
                        }
                        break;
                    }
                    break block41;
                }
                while (true) {
                    if ((v8 = (cfr_temp_2 = MapCycleModule.\u13e8 - (3102347919666947408L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                    if (v8 == (1442 ^ -1443)) break;
                    v8 = 32295 ^ -829079476;
                }
                return this.cachedIsUnsafe;
            }
            this.lastIsUnsafeCheckMs = v5;
            var3_1 = new byte[445 ^ 445];
            unsafeNpcSubname = new String(var3_1);
            while (true) {
                if ((v9 = (cfr_temp_3 = MapCycleModule.\u13e8 - (32220L ^ -8253398709755200299L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v9 == (3897 ^ 3896)) break;
                v9 = 564 ^ -917000060;
            }
            while (true) {
                if ((v10 = (cfr_temp_4 = MapCycleModule.\u13e8 - (24359L ^ -2238178390911330861L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v10 == (28168 ^ -28169)) break;
                v10 = 1759 ^ -738743230;
            }
            if (!this.mapCycleSafetyConfig.ONLY_COUNT_NPC_SUBNAME_GONE) break block42;
            v11 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl67
            block32: while (true) {
                v11 = v12 / (15213L ^ 4798802314013567428L);
lbl67:
                // 2 sources

                switch ((int)v11) {
                    case 29973176: {
                        v12 = -5926009658877808188L >>> "\u0000\u0000".length();
                        continue block32;
                    }
                    case 495317951: {
                        v12 = 2595L ^ -1179401768645222272L;
                        continue block32;
                    }
                    case 1415186628: {
                        break block32;
                    }
                }
                break;
            }
            v13 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl80
            block33: while (true) {
                v13 = (-1999016969710320356L >>> "\u0000\u0000".length()) / (11100L ^ 3137643059557892372L);
lbl80:
                // 2 sources

                switch ((int)v13) {
                    case 357382212: {
                        continue block33;
                    }
                    case 1415186628: {
                        break block33;
                    }
                }
                break;
            }
            unsafeNpcSubname = this.afterKillConfig.ATTEND_SUBNAME;
        }
        while (true) {
            if ((v14 = (cfr_temp_5 = MapCycleModule.\u13e8 - (22842L ^ -3868405156976417184L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
            if (v14 == (5967 ^ 5966)) break;
            v14 = 23131 ^ 1369511770;
        }
        while (true) {
            if ((v15 = (cfr_temp_6 = MapCycleModule.\u13e8 - (5469L ^ -6300955859416413031L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
            if (v15 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v15 = -587309300 >>> "\u0000\u0000".length();
        }
        v16 = this.lootModule.getNumNpcsInRange(unsafeNpcSubname);
        v17 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl102
        block36: while (true) {
            v17 = v18 / (13697L ^ -21490681583279335L);
lbl102:
            // 2 sources

            switch ((int)v17) {
                case -1900789730: {
                    v18 = 8963L ^ 5037884806342718926L;
                    continue block36;
                }
                case 506636752: {
                    v18 = 19380L ^ -1380192606688022988L;
                    continue block36;
                }
                case 1339153145: {
                    v18 = 12266L ^ 2912896602088507092L;
                    continue block36;
                }
                case 1415186628: {
                    break block36;
                }
            }
            break;
        }
        while (true) {
            if ((v19 = (cfr_temp_7 = MapCycleModule.\u13e8 - (26706L ^ -7173083953105098577L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
            if (v19 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v19 = 8252 ^ -1452107516;
        }
        v20 = v16 >= this.mapCycleSafetyConfig.MIN_NUM_NPCS_UNSAFE ? "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length() : "".length() >>> "\u0000\u0000".length();
        while (true) {
            if ((v21 = (cfr_temp_8 = MapCycleModule.\u13e8 - (24954L ^ -4087236008540159247L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
            if (v21 == (7880 ^ 7881)) break;
            v21 = -1862957932 >>> "\u0000\u0000".length();
        }
        this.cachedIsUnsafe = v20;
        while (true) {
            if ((v22 = (cfr_temp_9 = MapCycleModule.\u13e8 - (23266L ^ -6483285127904735720L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
            if (v22 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v22 = 29672 ^ 2000805623;
        }
        return this.cachedIsUnsafe;
    }

    /*
     * Unable to fully structure code
     */
    private boolean heroCanBuyCloak() {
        v0 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl5
        block22: while (true) {
            v0 = v1 / (2561983533835586380L >>> "\u0000\u0000".length());
lbl5:
            // 2 sources

            switch ((int)v0) {
                case -1259546845: {
                    v1 = 630L ^ 593673709121396381L;
                    continue block22;
                }
                case -128318892: {
                    v1 = 18226L ^ -2065258860035321340L;
                    continue block22;
                }
                case 1415186628: {
                    break block22;
                }
            }
            break;
        }
        v2 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl18
        block23: while (true) {
            v2 = v3 / (9045908096135790764L >>> "\u0000\u0000".length());
lbl18:
            // 2 sources

            switch ((int)v2) {
                case -362916682: {
                    v3 = 27502L ^ 8514666643754368997L;
                    continue block23;
                }
                case -132669727: {
                    v3 = 14524L ^ 2440635751876113747L;
                    continue block23;
                }
                case 1415186628: {
                    break block23;
                }
            }
            break;
        }
        if (this.hero.isInvisible()) ** GOTO lbl-1000
        while (true) {
            if ((v4 = (cfr_temp_0 = MapCycleModule.\u13e8 - (18096L ^ 1810424716834161912L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v4 == (28731 ^ -28732)) break;
            v4 = 29829 ^ 1508242078;
        }
        if (this.heroIsAttacking()) ** GOTO lbl-1000
        while (true) {
            if ((v5 = (cfr_temp_1 = MapCycleModule.\u13e8 - (7329L ^ -204193535161969371L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v5 == (21823 ^ -21824)) break;
            v5 = 24077 ^ 898184613;
        }
        v6 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl45
        block26: while (true) {
            v6 = v7 / (58785457217424792L >>> "\u0000\u0000".length());
lbl45:
            // 2 sources

            switch ((int)v6) {
                case -1716052385: {
                    v7 = 18240L ^ -9082822184577771100L;
                    continue block26;
                }
                case -1149249522: {
                    v7 = 29022L ^ -4748168275314999593L;
                    continue block26;
                }
                case 1415186628: {
                    break block26;
                }
                case 1699659725: {
                    v7 = 23681L ^ 1726031721780566958L;
                    continue block26;
                }
            }
            break;
        }
        if (this.mapCycleSafetyConfig.ALLOW_BUY_CLOAK_WITHIN_WAIT_AFTER_KILL_PERIOD) ** GOTO lbl-1000
        v8 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl62
        block27: while (true) {
            v8 = v9 / (30535L ^ -5448187272940728602L);
lbl62:
            // 2 sources

            switch ((int)v8) {
                case -412667498: {
                    v9 = 1926L ^ -7401626459897039045L;
                    continue block27;
                }
                case 936035076: {
                    v9 = 9538L ^ -2743412373557689241L;
                    continue block27;
                }
                case 1414568220: {
                    v9 = 12959L ^ 5777722674756587334L;
                    continue block27;
                }
                case 1415186628: {
                    break block27;
                }
            }
            break;
        }
        if (!this.withinBeheKillWaitPeriod()) lbl-1000:
        // 2 sources

        {
            v10 = 29758 ^ 29759;
        } else lbl-1000:
        // 3 sources

        {
            v10 = "".length() >>> "\u0000\u0000".length();
        }
        return (boolean)v10;
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private void checkSafenessOfArea() {
        block84: {
            block86: {
                block83: {
                    block85: {
                        while (true) {
                            if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (11304L ^ 5663834671892875586L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                            if (v0 == (15165 ^ -15166)) break;
                            v0 = 26357 ^ -1153385182;
                        }
                        v1 = System.currentTimeMillis();
                        while (true) {
                            if ((v2 = (cfr_temp_1 = MapCycleModule.\u13e8 - (20359L ^ 6615014277382374168L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                            if (v2 == (13811 ^ -13812)) break;
                            v2 = 998545776 >>> "\u0000\u0000".length();
                        }
                        if (v1 - this.safenessOfAreaCheckStartMs <= 4000L >>> "\u0000\u0000".length()) break block85;
                        v3 = MapCycleModule.\u13e8;
                        if (true) ** GOTO lbl17
                        block61: while (true) {
                            v3 = (17611L ^ 7826149521817956146L) / (20189L ^ 6566213611707852320L);
lbl17:
                            // 2 sources

                            switch ((int)v3) {
                                case -1036507387: {
                                    continue block61;
                                }
                                case 1415186628: {
                                    break block61;
                                }
                            }
                            break;
                        }
                        v4 = System.currentTimeMillis();
                        while (true) {
                            if ((v5 = (cfr_temp_2 = MapCycleModule.\u13e8 - (31237L ^ -1215838337073358674L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                            if (v5 != (276 ^ -277)) {
                                v5 = 14546 ^ -1769237386;
                                continue;
                            }
                            break block83;
                            break;
                        }
                    }
                    return;
                }
                this.safenessOfAreaCheckStartMs = v4;
                v6 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl37
                block63: while (true) {
                    v6 = v7 / (8412L ^ -7884556224887104344L);
lbl37:
                    // 2 sources

                    switch ((int)v6) {
                        case -514844068: {
                            v7 = -5814780570448351912L >>> "\u0000\u0000".length();
                            continue block63;
                        }
                        case -32080488: {
                            v7 = 1383652561493780988L >>> "\u0000\u0000".length();
                            continue block63;
                        }
                        case 1415186628: {
                            break block63;
                        }
                        case 1590829564: {
                            v7 = 10852L ^ 7493424621127886759L;
                            continue block63;
                        }
                    }
                    break;
                }
                isUnsafe = this.isUnsafe();
                if (!isUnsafe) break block86;
                v8 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl55
                block64: while (true) {
                    v8 = v9 / (19191L ^ 6078723102902124560L);
lbl55:
                    // 2 sources

                    switch ((int)v8) {
                        case -404603591: {
                            v9 = 22340L ^ -9066555605589290176L;
                            continue block64;
                        }
                        case 79948272: {
                            v9 = 26782L ^ -4238317848302483069L;
                            continue block64;
                        }
                        case 1415186628: {
                            break block64;
                        }
                        case 1705430417: {
                            v9 = 10852L ^ 3119741456586650724L;
                            continue block64;
                        }
                    }
                    break;
                }
                if (!this.heroCanBuyCloak()) break block86;
                v10 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl72
                block65: while (true) {
                    v10 = (1267L ^ -1253444721444348250L) / (242L ^ -4676397880859501955L);
lbl72:
                    // 2 sources

                    switch ((int)v10) {
                        case 482516512: {
                            continue block65;
                        }
                        case 1415186628: {
                            break block65;
                        }
                    }
                    break;
                }
                if (this.npcSubnameInSight()) break block86;
                v11 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl82
                block66: while (true) {
                    v11 = (11776L ^ -1302173386399255873L) / (11742L ^ -3807864524152930357L);
lbl82:
                    // 2 sources

                    switch ((int)v11) {
                        case -1399234236: {
                            continue block66;
                        }
                        case 1415186628: {
                            break block66;
                        }
                    }
                    break;
                }
                v12 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl91
                block67: while (true) {
                    v12 = v13 / (-7904275354842141288L >>> "\u0000\u0000".length());
lbl91:
                    // 2 sources

                    switch ((int)v12) {
                        case -1259754997: {
                            v13 = 7381738698418451352L >>> "\u0000\u0000".length();
                            continue block67;
                        }
                        case 1415186628: {
                            break block67;
                        }
                        case 1461222026: {
                            v13 = 12627L ^ 7867251226342900046L;
                            continue block67;
                        }
                    }
                    break;
                }
                if (!this.mapCycleSafetyConfig.BUY_CLOAK_IF_UNSAFE) break block86;
                v14 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl105
                block68: while (true) {
                    v14 = v15 / (31010L ^ -2347337801419601850L);
lbl105:
                    // 2 sources

                    switch ((int)v14) {
                        case -1828773594: {
                            v15 = 16419L ^ 8610955707145008465L;
                            continue block68;
                        }
                        case -1038055504: {
                            v15 = 22426L ^ 5567020932141651023L;
                            continue block68;
                        }
                        case 949038175: {
                            v15 = 11345L ^ -6098460730697461805L;
                            continue block68;
                        }
                        case 1415186628: {
                            break block68;
                        }
                    }
                    break;
                }
                if (this.isWaitingForSafetyCloak()) {
                    return;
                }
                v16 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
                while (true) {
                    if ((v17 = (cfr_temp_3 = MapCycleModule.\u13e8 - (31601L ^ 8623350724079340106L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                    if (v17 == (6590 ^ -6591)) break;
                    v17 = 21385 ^ 1449684764;
                }
                this.tryBuyCloakCPU(v16);
                while (true) {
                    if ((v18 = (cfr_temp_4 = MapCycleModule.\u13e8 - (5643L ^ -4003369169677196755L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                    if (v18 == (7057 ^ 7056)) break;
                    v18 = 16663 ^ -918466762;
                }
                v19 = System.currentTimeMillis();
                v20 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl136
                block71: while (true) {
                    v20 = v21 / (20037L ^ -760937582779645524L);
lbl136:
                    // 2 sources

                    switch ((int)v20) {
                        case -425152990: {
                            v21 = 18672L ^ -383638137710072790L;
                            continue block71;
                        }
                        case 1351528906: {
                            v21 = 11488L ^ -2235548351010625967L;
                            continue block71;
                        }
                        case 1415186628: {
                            break block71;
                        }
                    }
                    break;
                }
                this.waitingForSafetyCloakStartMs = v19;
                return;
            }
            while (true) {
                if ((v22 = (cfr_temp_5 = MapCycleModule.\u13e8 - (15244L ^ -2963518143261208555L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                if (v22 == (31747 ^ -31748)) break;
                v22 = 2071734036 >>> "\u0000\u0000".length();
            }
            if (!this.CanPressSafetyKey()) break block84;
            while (true) {
                if ((v23 = (cfr_temp_6 = MapCycleModule.\u13e8 - (24299L ^ 1085085915246558793L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                if (v23 == (3191 ^ -3192)) break;
                v23 = 5739 ^ -1380885345;
            }
            if (!this.shipIsInPreferredRegion() || !isUnsafe) break block84;
            v24 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl164
            block74: while (true) {
                v24 = v25 / (16397L ^ 7150917334085956883L);
lbl164:
                // 2 sources

                switch ((int)v24) {
                    case -120970545: {
                        v25 = 15074L ^ -3423878282581546394L;
                        continue block74;
                    }
                    case 581452077: {
                        v25 = 5943L ^ 5377874110613490334L;
                        continue block74;
                    }
                    case 1415186628: {
                        break block74;
                    }
                }
                break;
            }
            v26 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl177
            block75: while (true) {
                v26 = v27 / (11236L ^ -6384863822866477451L);
lbl177:
                // 2 sources

                switch ((int)v26) {
                    case -79461404: {
                        v27 = 9707L ^ -4139244996495318133L;
                        continue block75;
                    }
                    case 1408503687: {
                        v27 = 13915L ^ 6992752405932880831L;
                        continue block75;
                    }
                    case 1415186628: {
                        break block75;
                    }
                }
                break;
            }
            if (this.hero.isInvisible()) break block84;
            v28 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl191
            block76: while (true) {
                v28 = (15365L ^ 549765727117736111L) / (26711L ^ 3509820716884864411L);
lbl191:
                // 2 sources

                switch ((int)v28) {
                    case 252498900: {
                        continue block76;
                    }
                    case 1415186628: {
                        break block76;
                    }
                }
                break;
            }
            if (this.canPressInstaShieldKey()) {
                while (true) {
                    if ((v29 = (cfr_temp_7 = MapCycleModule.\u13e8 - (2971936124748071532L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                    if (v29 == (7537 ^ -7538)) {
                        this.pressInstaShieldKey();
                        break block84;
                    }
                    v29 = 26672 ^ -1043071557;
                }
            }
            v30 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl208
            block78: while (true) {
                v30 = v31 / (31300L ^ -550916667355589017L);
lbl208:
                // 2 sources

                switch ((int)v30) {
                    case -418564825: {
                        v31 = 3979L ^ 1471205832904105905L;
                        continue block78;
                    }
                    case 1368083244: {
                        v31 = 22789L ^ -1427140808278219940L;
                        continue block78;
                    }
                    case 1415186628: {
                        break block78;
                    }
                }
                break;
            }
            this.PressSafetyKey();
        }
    }

    /*
     * Unable to fully structure code
     */
    private boolean heroIsAttacking() {
        while (true) {
            if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (11748L ^ -7818979606187098497L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (20014 ^ 20015)) break;
            v0 = 8237 ^ -496415198;
        }
        v1 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl10
        block15: while (true) {
            v1 = v2 / (7409064977352543236L >>> "\u0000\u0000".length());
lbl10:
            // 2 sources

            switch ((int)v1) {
                case -613718280: {
                    v2 = 17459L ^ -6962161427523773007L;
                    continue block15;
                }
                case 1415186628: {
                    break block15;
                }
                case 1630892220: {
                    v2 = 18945L ^ 8311687217200866455L;
                    continue block15;
                }
            }
            break;
        }
        if (this.hero.target == null) ** GOTO lbl-1000
        v3 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl24
        block16: while (true) {
            v3 = (19905L ^ -3895248881063020212L) / (29984L ^ 7432577439990601182L);
lbl24:
            // 2 sources

            switch ((int)v3) {
                case -56342155: {
                    continue block16;
                }
                case 1415186628: {
                    break block16;
                }
            }
            break;
        }
        while (true) {
            if ((v4 = (cfr_temp_1 = MapCycleModule.\u13e8 - (16106L ^ -7522366533948985936L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v4 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v4 = 20278 ^ 1617375311;
        }
        while (true) {
            if ((v5 = (cfr_temp_2 = MapCycleModule.\u13e8 - (31952L ^ 8337529828782790491L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v5 == (888 ^ -889)) break;
            v5 = 10930 ^ -1578498997;
        }
        v6 = this.hero.target;
        v7 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl44
        block19: while (true) {
            v7 = v8 / (10492L ^ 8232925702225868586L);
lbl44:
            // 2 sources

            switch ((int)v7) {
                case 820867191: {
                    v8 = 15230L ^ -7288471443192679590L;
                    continue block19;
                }
                case 1415186628: {
                    break block19;
                }
                case 1480512911: {
                    v8 = 13124L ^ -2561956455762164718L;
                    continue block19;
                }
            }
            break;
        }
        if (this.hero.isAttacking(v6)) {
            v9 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        } else lbl-1000:
        // 2 sources

        {
            v9 = "".length() >>> "\u0000\u0000".length();
        }
        return (boolean)v9;
    }

    /*
     * Unable to fully structure code
     */
    private void HandleIsWithinPredictedSpawnPeriod() {
        block80: {
            block79: {
                v0 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl5
                block53: while (true) {
                    v0 = v1 / (5826L ^ -3372432966884132035L);
lbl5:
                    // 2 sources

                    switch ((int)v0) {
                        case -1423905542: {
                            v1 = 5845L ^ -5902545444726946901L;
                            continue block53;
                        }
                        case -146895114: {
                            v1 = 26838L ^ 8822514786675245545L;
                            continue block53;
                        }
                        case 1415186628: {
                            break block53;
                        }
                        case 2016131705: {
                            v1 = 10275L ^ -4973280041297365958L;
                            continue block53;
                        }
                    }
                    break;
                }
                v2 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl21
                block54: while (true) {
                    v2 = v3 / (-2932457105677020400L >>> "\u0000\u0000".length());
lbl21:
                    // 2 sources

                    switch ((int)v2) {
                        case -1411139292: {
                            v3 = 8638L ^ 6310499669372177454L;
                            continue block54;
                        }
                        case -1374304069: {
                            v3 = 10814L ^ -6823680266899198068L;
                            continue block54;
                        }
                        case 675253913: {
                            v3 = 32650L ^ -1017600703314386876L;
                            continue block54;
                        }
                        case 1415186628: {
                            break block54;
                        }
                    }
                    break;
                }
                if (!this.predictNpcSpawnConfig.ENABLE_TRACK_NPC_SPAWN_TIME) {
                    return;
                }
                v4 = new Character["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
                v5 = "".length() >>> "\u0000\u0000".length();
                while (true) {
                    if ((v6 = (cfr_temp_0 = MapCycleModule.\u13e8 - (18894L ^ 4699515147885381578L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                    if (v6 == (1721 ^ -1722)) break;
                    v6 = 18200 ^ -238115800;
                }
                while (true) {
                    if ((v7 = (cfr_temp_1 = MapCycleModule.\u13e8 - (6624L ^ -6269055802511657415L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                    if (v7 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                    v7 = 21731 ^ -1936706555;
                }
                v4[v5] = this.predictNpcSpawnConfig.KEY_ON_PREDICTED_SPAWN_PERIOD_START;
                v8 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl52
                block57: while (true) {
                    v8 = v9 / (17446L ^ 1261398653107458540L);
lbl52:
                    // 2 sources

                    switch ((int)v8) {
                        case -310339969: {
                            v9 = -6473253532149222152L >>> "\u0000\u0000".length();
                            continue block57;
                        }
                        case 779974136: {
                            v9 = 16963L ^ 4781486130075616040L;
                            continue block57;
                        }
                        case 1415186628: {
                            break block57;
                        }
                        case 2066798203: {
                            v9 = 22348L ^ -8703077883286239967L;
                            continue block57;
                        }
                    }
                    break;
                }
                while (true) {
                    if ((v10 = (cfr_temp_2 = MapCycleModule.\u13e8 - (6508L ^ 436733216178455091L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                    if (v10 == (32076 ^ -32077)) break;
                    v10 = 11236 ^ -1004605818;
                }
                v4[11294 ^ 11295] = this.predictNpcSpawnConfig.KEY_ON_PREDICTED_SPAWN_PERIOD_START_2;
                while (true) {
                    if ((v11 = (cfr_temp_3 = MapCycleModule.\u13e8 - (969L ^ -6958908688139743725L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                    if (v11 == (16411 ^ 16410)) break;
                    v11 = 15508 ^ -825614070;
                }
                v12 = Arrays.stream(v4);
                v13 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl80
                block60: while (true) {
                    v13 = (14410L ^ -6626793598336776095L) / (1108072731006900700L >>> "\u0000\u0000".length());
lbl80:
                    // 2 sources

                    switch ((int)v13) {
                        case -1193757037: {
                            continue block60;
                        }
                        case 1415186628: {
                            break block60;
                        }
                    }
                    break;
                }
                v14 = (Predicate<Character>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Z, nonNull(java.lang.Object ), (Ljava/lang/Character;)Z)();
                while (true) {
                    if ((v15 = (cfr_temp_4 = MapCycleModule.\u13e8 - (13867L ^ -7020855746828785219L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                    if (v15 == (17000 ^ 17001)) break;
                    v15 = 5249 ^ -1792488622;
                }
                v16 = v12.filter(v14);
                while (true) {
                    if ((v17 = (cfr_temp_5 = MapCycleModule.\u13e8 - (7106489440551921024L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                    if (v17 == (2119 ^ -2120)) break;
                    v17 = 13025 ^ 1618796384;
                }
                v18 = Collectors.toList();
                v19 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl102
                block63: while (true) {
                    v19 = (15760L ^ 6309728398224837232L) / (23654L ^ -4394638669428145542L);
lbl102:
                    // 2 sources

                    switch ((int)v19) {
                        case -1071253256: {
                            continue block63;
                        }
                        case 1415186628: {
                            break block63;
                        }
                    }
                    break;
                }
                validKeys = v16.collect(v18);
                while (true) {
                    if ((v20 = (cfr_temp_6 = MapCycleModule.\u13e8 - (2172L ^ -806680347709853960L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                    if (v20 == (29219 ^ -29220)) break;
                    v20 = 8249 ^ -67258282;
                }
                if (validKeys.isEmpty()) {
                    return;
                }
                while (true) {
                    if ((v21 = (cfr_temp_7 = MapCycleModule.\u13e8 - (22833L ^ -8051893199087051971L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                    if (v21 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                    v21 = 9634 ^ -1123320952;
                }
                while (true) {
                    if ((v22 = (cfr_temp_8 = MapCycleModule.\u13e8 - (23983L ^ -1617669017263336283L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                    if (v22 == (15403 ^ -15404)) break;
                    v22 = 8593 ^ -1298599423;
                }
                v23 = this.predictNpcSpawnConfig.KEY_PREPARE_DEPTH_MS;
                v24 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl130
                block67: while (true) {
                    v24 = (840L ^ 6734999037191995348L) / (31160L ^ -1960875821351177606L);
lbl130:
                    // 2 sources

                    switch ((int)v24) {
                        case -909367443: {
                            continue block67;
                        }
                        case 1415186628: {
                            break block67;
                        }
                    }
                    break;
                }
                if (!this.withinPrepareForNPCSpawnPeriod(v23)) break block79;
                v25 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl140
                block68: while (true) {
                    v25 = (26466L ^ -6736546950626968324L) / (20414L ^ -602530654389753916L);
lbl140:
                    // 2 sources

                    switch ((int)v25) {
                        case 583483092: {
                            continue block68;
                        }
                        case 1415186628: {
                            break block68;
                        }
                    }
                    break;
                }
                if (this.pressedKeyOnPredictedSpawnPeriodStart) {
                    return;
                }
                v26 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl151
                block69: while (true) {
                    v26 = (-2299926282756172812L >>> "\u0000\u0000".length()) / (-7837083763432432752L >>> "\u0000\u0000".length());
lbl151:
                    // 2 sources

                    switch ((int)v26) {
                        case -1078684879: {
                            continue block69;
                        }
                        case 1415186628: {
                            break block69;
                        }
                    }
                    break;
                }
                v27 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl160
                block70: while (true) {
                    v27 = v28 / (4278L ^ -7025347804763541516L);
lbl160:
                    // 2 sources

                    switch ((int)v27) {
                        case -2076506307: {
                            v28 = 9107409048948084316L >>> "\u0000\u0000".length();
                            continue block70;
                        }
                        case 692424136: {
                            v28 = 8636L ^ -8849409939574207325L;
                            continue block70;
                        }
                        case 1415186628: {
                            break block70;
                        }
                    }
                    break;
                }
                if (this.drive.isMoving()) break block80;
                v29 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl174
                block71: while (true) {
                    v29 = v30 / (23511L ^ -3817161205713563107L);
lbl174:
                    // 2 sources

                    switch ((int)v29) {
                        case -1015397877: {
                            v30 = 3453L ^ -5909761500674058199L;
                            continue block71;
                        }
                        case 1415186628: {
                            break block71;
                        }
                        case 1912216757: {
                            v30 = 5352L ^ -1531517467098814894L;
                            continue block71;
                        }
                    }
                    break;
                }
                this.pressedKeyOnPredictedSpawnPeriodStart = 14214 ^ 14215;
                while (true) {
                    if ((v31 = (cfr_temp_9 = MapCycleModule.\u13e8 - (21977L ^ -2340789015268670585L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
                    if (v31 == (17446 ^ -17447)) break;
                    v31 = 1552423028 >>> "\u0000\u0000".length();
                }
                v32 = (Consumer<Character>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)V, keyboardClick(java.lang.Character ), (Ljava/lang/Character;)V)();
                v33 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl194
                block73: while (true) {
                    v33 = v34 / (4940267170288572300L >>> "\u0000\u0000".length());
lbl194:
                    // 2 sources

                    switch ((int)v33) {
                        case -1305890921: {
                            v34 = 22585L ^ 1936612871961674308L;
                            continue block73;
                        }
                        case 460744450: {
                            v34 = 139L ^ 5971937554036697721L;
                            continue block73;
                        }
                        case 1415186628: {
                            break block73;
                        }
                    }
                    break;
                }
                validKeys.forEach(v32);
                break block80;
            }
            while (true) {
                if ((v35 = (cfr_temp_10 = MapCycleModule.\u13e8 - (24157L ^ -2574484888157839259L)) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
                if (v35 == (12112 ^ -12113)) {
                    this.pressedKeyOnPredictedSpawnPeriodStart = 7063 ^ 7063;
                    break;
                }
                v35 = 19800 ^ -767705675;
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private void MoveToNpcSubnameTick() {
        block36: {
            while (true) {
                if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (25051L ^ 3161331339713659913L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v0 == (32361 ^ -32362)) break;
                v0 = 25196 ^ -418241524;
            }
            v1 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl10
            block26: while (true) {
                v1 = v2 / (18184L ^ -1069860992637204455L);
lbl10:
                // 2 sources

                switch ((int)v1) {
                    case -1763507725: {
                        v2 = 13112L ^ -2493399652089629065L;
                        continue block26;
                    }
                    case -545139256: {
                        v2 = 6704L ^ 8557692600049421766L;
                        continue block26;
                    }
                    case 527707428: {
                        v2 = 24314L ^ 3777610076013904851L;
                        continue block26;
                    }
                    case 1415186628: {
                        break block26;
                    }
                }
                break;
            }
            if (!this.npcSubnameConditionConfig.MOVE_TO_NPC_SUBNAME) break block36;
            v3 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl27
            block27: while (true) {
                v3 = (17723L ^ 8357307226987381259L) / (27756L ^ -4689027141206343983L);
lbl27:
                // 2 sources

                switch ((int)v3) {
                    case -241992619: {
                        continue block27;
                    }
                    case 1415186628: {
                        break block27;
                    }
                }
                break;
            }
            v4 = System.currentTimeMillis();
            v5 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl37
            block28: while (true) {
                v5 = v6 / (11809L ^ -959742751715855524L);
lbl37:
                // 2 sources

                switch ((int)v5) {
                    case -586675196: {
                        v6 = 20156L ^ -669460045179769102L;
                        continue block28;
                    }
                    case 531309482: {
                        v6 = 20040L ^ 4531638650671097879L;
                        continue block28;
                    }
                    case 1415186628: {
                        break block28;
                    }
                }
                break;
            }
            v7 = v4 - this.moveToNpcSubnameStartMs;
            v8 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl51
            block29: while (true) {
                v8 = (22858L ^ 8715089074347300214L) / (23821L ^ 4954380577217011556L);
lbl51:
                // 2 sources

                switch ((int)v8) {
                    case 1415186628: {
                        break block29;
                    }
                    case 2081451290: {
                        continue block29;
                    }
                }
                break;
            }
            v9 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl60
            block30: while (true) {
                v9 = v10 / (14064L ^ -6073373765648216118L);
lbl60:
                // 2 sources

                switch ((int)v9) {
                    case -1579016074: {
                        v10 = 28191L ^ -7285395798995639952L;
                        continue block30;
                    }
                    case -867659573: {
                        v10 = 19574L ^ 6374545959627582685L;
                        continue block30;
                    }
                    case -829687955: {
                        v10 = 3750L ^ -2574688044734305705L;
                        continue block30;
                    }
                    case 1415186628: {
                        break block30;
                    }
                }
                break;
            }
            if (v7 >= (long)this.npcSubnameConditionConfig.MOVE_TO_NPC_SUBNAME_PERIOD_MS) {
                while (true) {
                    if ((v11 = (cfr_temp_1 = MapCycleModule.\u13e8 - (16918L ^ -737236429275735280L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                    if (v11 == (4851 ^ -4852)) break;
                    v11 = 26558 ^ 1927140868;
                }
                v12 = System.currentTimeMillis();
                while (true) {
                    if ((v13 = (cfr_temp_2 = MapCycleModule.\u13e8 - (2255L ^ 1340488811098666815L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                    if (v13 == (20523 ^ -20524)) break;
                    v13 = 1146 ^ 1175494684;
                }
                this.moveToNpcSubnameStartMs = v12;
                while (true) {
                    if ((v14 = (cfr_temp_3 = MapCycleModule.\u13e8 - (13280L ^ -4926450248357486585L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                    if (v14 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                        this.MoveToHeroTargetPosition();
                        break;
                    }
                    v14 = 7752 ^ -328426941;
                }
            }
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private void PressKeyNpcBelowHp() {
        long l = \u13e8;
        block21: while (true) {
            switch ((int)l) {
                case 518514305: {
                    l = (0x6AABL ^ 0xBC634511722081E8L) / (0x491FL ^ 0x4510A3A353C0FA4DL);
                    continue block21;
                }
                case 1415186628: {
                    break block21;
                }
            }
            break;
        }
        if (this.pressedKeyNpcBelowHp) {
            return;
        }
        long l2 = \u13e8;
        boolean bl = true;
        block22: while (true) {
            long l3;
            if (!bl || (bl = false) || !true) {
                l2 = l3 / (3944790772394846644L >>> "\u0000\u0000".length());
            }
            switch ((int)l2) {
                case -87480184: {
                    l3 = 0xE4L ^ 0xAF80EEA90647DFA3L;
                    continue block22;
                }
                case 834382206: {
                    l3 = 0x48ACL ^ 0x124ECD59A89CB737L;
                    continue block22;
                }
                case 1415186628: {
                    break block22;
                }
                case 1793429634: {
                    l3 = 0x48D6L ^ 0xB50589EAD137A0B1L;
                    continue block22;
                }
            }
            break;
        }
        this.pressedKeyNpcBelowHp = 0x432 ^ 0x433;
        long l4 = \u13e8;
        boolean bl2 = true;
        block23: while (true) {
            long l5;
            if (!bl2 || (bl2 = false) || !true) {
                l4 = l5 / (0x5CB1L ^ 0x233231B64EDBA47BL);
            }
            switch ((int)l4) {
                case -15764558: {
                    l5 = 0x9DFL ^ 0x72D135A9728069A2L;
                    continue block23;
                }
                case 1356446367: {
                    l5 = 0x5CF6L ^ 0x46FFA05C9DBC34C3L;
                    continue block23;
                }
                case 1415186628: {
                    break block23;
                }
            }
            break;
        }
        long l6 = \u13e8;
        boolean bl3 = true;
        block24: while (true) {
            long l7;
            if (!bl3 || (bl3 = false) || !true) {
                l6 = l7 / (0x1722L ^ 0x9A70C11C8D397731L);
            }
            switch ((int)l6) {
                case -800943255: {
                    l7 = 0x1256L ^ 0xEEA65BD07304C4D0L;
                    continue block24;
                }
                case 516623699: {
                    l7 = 0x3328L ^ 0x1B1DBDF61F469C6CL;
                    continue block24;
                }
                case 1415186628: {
                    break block24;
                }
                case 1774466376: {
                    l7 = -5981982816929823404L >>> "\u0000\u0000".length();
                    continue block24;
                }
            }
            break;
        }
        Character c = this.npcRewardConfig.KEY_ON_NPC_BELOW_HP;
        while (true) {
            long l8;
            long l9;
            if ((l9 = (l8 = \u13e8 - (0x2469L ^ 0x2A75304E0DDF6BF9L)) == 0L ? 0 : (l8 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l9 == (0x5E7D ^ 0xFFFFA182)) {
                ApiExtensions.keyboardClick(c);
                return;
            }
            l9 = 0x45F4 ^ 0xF33CC92D;
        }
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private boolean HandleShootingBeheTick() {
        block184: {
            block183: {
                block180: {
                    block181: {
                        block182: {
                            v0 = MapCycleModule.\u13e8;
                            if (true) ** GOTO lbl5
                            block130: while (true) {
                                v0 = v1 / (8571340329594398300L >>> "\u0000\u0000".length());
lbl5:
                                // 2 sources

                                switch ((int)v0) {
                                    case -892014481: {
                                        v1 = 4652L ^ -2673135051803003298L;
                                        continue block130;
                                    }
                                    case 665413811: {
                                        v1 = -2756922946862769168L >>> "\u0000\u0000".length();
                                        continue block130;
                                    }
                                    case 1415186628: {
                                        break block130;
                                    }
                                    case 1603420942: {
                                        v1 = 1289L ^ 2272106129275053255L;
                                        continue block130;
                                    }
                                }
                                break;
                            }
                            v2 = MapCycleModule.\u13e8;
                            if (true) ** GOTO lbl21
                            block131: while (true) {
                                v2 = v3 / (17942L ^ -2714109273621482069L);
lbl21:
                                // 2 sources

                                switch ((int)v2) {
                                    case -1520237032: {
                                        v3 = 22060L ^ -7610047128539576328L;
                                        continue block131;
                                    }
                                    case -1067935519: {
                                        v3 = 25317L ^ 9184865643105714042L;
                                        continue block131;
                                    }
                                    case 1415186628: {
                                        break block131;
                                    }
                                }
                                break;
                            }
                            this.shootingBeheState.advance();
                            v4 = MapCycleModule.\u13e8;
                            if (true) ** GOTO lbl35
                            block132: while (true) {
                                v4 = (8481L ^ 8132189153942540243L) / (13739L ^ 5008920864336498389L);
lbl35:
                                // 2 sources

                                switch ((int)v4) {
                                    case -117574959: {
                                        continue block132;
                                    }
                                    case 1415186628: {
                                        break block132;
                                    }
                                }
                                break;
                            }
                            this.pressKeyFirstLockTick();
                            changedConfig = "".length() >>> "\u0000\u0000".length();
                            while (true) {
                                if ((v5 = (cfr_temp_0 = MapCycleModule.\u13e8 - (13803L ^ -2703744550770355329L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                                if (v5 == (28110 ^ -28111)) break;
                                v5 = 1576059208 >>> "\u0000\u0000".length();
                            }
                            v6 = MapCycleModule.\u13e8;
                            if (true) ** GOTO lbl51
                            block134: while (true) {
                                v6 = v7 / (14731L ^ 7311459421842006235L);
lbl51:
                                // 2 sources

                                switch ((int)v6) {
                                    case -12498485: {
                                        v7 = 8903L ^ -8781845885507299982L;
                                        continue block134;
                                    }
                                    case 537075951: {
                                        v7 = 63L ^ -4299846141184045742L;
                                        continue block134;
                                    }
                                    case 1415186628: {
                                        break block134;
                                    }
                                }
                                break;
                            }
                            if (this.npcRewardConfig.ENABLE_NPC_REWARD_CONFIG) ** GOTO lbl-1000
                            while (true) {
                                if ((v8 = (cfr_temp_1 = MapCycleModule.\u13e8 - (11894L ^ 2147328435740263931L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                                if (v8 == (31972 ^ -31973)) break;
                                v8 = 13094 ^ -1514257178;
                            }
                            v9 = MapCycleModule.\u13e8;
                            if (true) ** GOTO lbl70
                            block136: while (true) {
                                v9 = v10 / (18027L ^ 2308050415883220001L);
lbl70:
                                // 2 sources

                                switch ((int)v9) {
                                    case -1735494642: {
                                        v10 = -392497239761432168L >>> "\u0000\u0000".length();
                                        continue block136;
                                    }
                                    case -1135629176: {
                                        v10 = 29261L ^ -899035203205437399L;
                                        continue block136;
                                    }
                                    case 1415186628: {
                                        break block136;
                                    }
                                }
                                break;
                            }
                            if (this.npcRewardConfig.KEY_ON_NPC_BELOW_HP != null) lbl-1000:
                            // 2 sources

                            {
                                v11 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
                            } else {
                                v11 = checkNpcHp = 31764 ^ 31764;
                            }
                            if (checkNpcHp == 0) break block180;
                            while (true) {
                                if ((v12 = (cfr_temp_2 = MapCycleModule.\u13e8 - (22014L ^ 4836630331784381742L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                                if (v12 == (692 ^ -693)) break;
                                v12 = -845587996 >>> "\u0000\u0000".length();
                            }
                            v13 = MapCycleModule.\u13e8;
                            if (true) ** GOTO lbl93
                            block138: while (true) {
                                v13 = (25660L ^ -6456055733673578376L) / (6586L ^ -805026211085327434L);
lbl93:
                                // 2 sources

                                switch ((int)v13) {
                                    case -1065123663: {
                                        continue block138;
                                    }
                                    case 1415186628: {
                                        break block138;
                                    }
                                }
                                break;
                            }
                            if (!this.hero.hasTarget()) ** GOTO lbl-1000
                            v14 = MapCycleModule.\u13e8;
                            if (true) ** GOTO lbl103
                            block139: while (true) {
                                v14 = v15 / (8900967137210559800L >>> "\u0000\u0000".length());
lbl103:
                                // 2 sources

                                switch ((int)v14) {
                                    case 612433780: {
                                        v15 = 8788930794894826800L >>> "\u0000\u0000".length();
                                        continue block139;
                                    }
                                    case 1233498725: {
                                        v15 = 8855750639031221784L >>> "\u0000\u0000".length();
                                        continue block139;
                                    }
                                    case 1415186628: {
                                        break block139;
                                    }
                                }
                                break;
                            }
                            v16 = MapCycleModule.\u13e8;
                            if (true) ** GOTO lbl116
                            block140: while (true) {
                                v16 = v17 / (26908L ^ -3662463089100535902L);
lbl116:
                                // 2 sources

                                switch ((int)v16) {
                                    case -1357057188: {
                                        v17 = 16168L ^ -8535612674673058515L;
                                        continue block140;
                                    }
                                    case -592106885: {
                                        v17 = 27922L ^ 6329205289180314150L;
                                        continue block140;
                                    }
                                    case 1415186628: {
                                        break block140;
                                    }
                                }
                                break;
                            }
                            v18 = this.hero.target;
                            v19 = MapCycleModule.\u13e8;
                            if (true) ** GOTO lbl130
                            block141: while (true) {
                                v19 = (8613474651322679404L >>> "\u0000\u0000".length()) / (2097L ^ -6382183614242218006L);
lbl130:
                                // 2 sources

                                switch ((int)v19) {
                                    case -1312812243: {
                                        continue block141;
                                    }
                                    case 1415186628: {
                                        break block141;
                                    }
                                }
                                break;
                            }
                            v20 = v18.health;
                            while (true) {
                                if ((v21 = (cfr_temp_3 = MapCycleModule.\u13e8 - (3950L ^ -2246781056911397981L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                                if (v21 == (31846 ^ -31847)) break;
                                v21 = 25897 ^ -1740502006;
                            }
                            v22 = v20.hp;
                            v23 = MapCycleModule.\u13e8;
                            if (true) ** GOTO lbl146
                            block143: while (true) {
                                v23 = v24 / (5735L ^ -6698698096059161423L);
lbl146:
                                // 2 sources

                                switch ((int)v23) {
                                    case -569941965: {
                                        v24 = 26378L ^ -5747016598073846805L;
                                        continue block143;
                                    }
                                    case 933337336: {
                                        v24 = 26658L ^ -4442787491811955281L;
                                        continue block143;
                                    }
                                    case 1415186628: {
                                        break block143;
                                    }
                                }
                                break;
                            }
                            v25 = MapCycleModule.\u13e8;
                            if (true) ** GOTO lbl159
                            block144: while (true) {
                                v25 = (8008L ^ 2476972784378441308L) / (30291L ^ -6784967392414112556L);
lbl159:
                                // 2 sources

                                switch ((int)v25) {
                                    case 1415186628: {
                                        break block144;
                                    }
                                    case 1776223143: {
                                        continue block144;
                                    }
                                }
                                break;
                            }
                            if (v22 > this.npcRewardConfig.NPC_REWARD_HP_THRESH) ** GOTO lbl-1000
                            while (true) {
                                if ((v26 = (cfr_temp_4 = MapCycleModule.\u13e8 - (29196L ^ 5996422596895317391L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                                if (v26 == (18257 ^ -18258)) break;
                                v26 = 12877 ^ 2035175516;
                            }
                            v27 = MapCycleModule.\u13e8;
                            if (true) ** GOTO lbl174
                            block146: while (true) {
                                v27 = v28 / (9405L ^ 5255086813361931596L);
lbl174:
                                // 2 sources

                                switch ((int)v27) {
                                    case -2030768902: {
                                        v28 = 14685L ^ -2340583900126083089L;
                                        continue block146;
                                    }
                                    case 1415186628: {
                                        break block146;
                                    }
                                    case 1953232846: {
                                        v28 = 28711L ^ 1824725865616965208L;
                                        continue block146;
                                    }
                                }
                                break;
                            }
                            v29 = this.hero.target;
                            v30 = MapCycleModule.\u13e8;
                            if (true) ** GOTO lbl188
                            block147: while (true) {
                                v30 = v31 / (5824L ^ 819272086589817874L);
lbl188:
                                // 2 sources

                                switch ((int)v30) {
                                    case -1660541973: {
                                        v31 = 5282271798106582308L >>> "\u0000\u0000".length();
                                        continue block147;
                                    }
                                    case -1154114637: {
                                        v31 = 20461L ^ -6844915872372492776L;
                                        continue block147;
                                    }
                                    case 421186058: {
                                        v31 = 18418L ^ -6758497763245910096L;
                                        continue block147;
                                    }
                                    case 1415186628: {
                                        break block147;
                                    }
                                }
                                break;
                            }
                            v32 = v29.health;
                            v33 = MapCycleModule.\u13e8;
                            if (true) ** GOTO lbl205
                            block148: while (true) {
                                v33 = v34 / (5816L ^ -8504886094902368731L);
lbl205:
                                // 2 sources

                                switch ((int)v33) {
                                    case -1796209225: {
                                        v34 = 23101L ^ 6191622824275414484L;
                                        continue block148;
                                    }
                                    case -841398382: {
                                        v34 = 20340L ^ -3307026098865814081L;
                                        continue block148;
                                    }
                                    case -101439914: {
                                        v34 = 26724L ^ -3702746020126168328L;
                                        continue block148;
                                    }
                                    case 1415186628: {
                                        break block148;
                                    }
                                }
                                break;
                            }
                            if (v32.hp > 0) {
                                v35 = 9452 ^ 9453;
                            } else lbl-1000:
                            // 3 sources

                            {
                                v35 = npcBelowHp = "".length() >>> "\u0000\u0000".length();
                            }
                            if (npcBelowHp == 0) break block181;
                            while (true) {
                                if ((v36 = (cfr_temp_5 = MapCycleModule.\u13e8 - (32032L ^ -8837813251307963214L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                                if (v36 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                                v36 = 21619 ^ 1215881452;
                            }
                            v37 = MapCycleModule.\u13e8;
                            if (true) ** GOTO lbl231
                            block150: while (true) {
                                v37 = v38 / (24791L ^ 5657627326533041445L);
lbl231:
                                // 2 sources

                                switch ((int)v37) {
                                    case -159609426: {
                                        v38 = 15102L ^ -4521358632265407955L;
                                        continue block150;
                                    }
                                    case 592639425: {
                                        v38 = 9859L ^ 7606184975741955775L;
                                        continue block150;
                                    }
                                    case 1415186628: {
                                        break block150;
                                    }
                                }
                                break;
                            }
                            if (!this.npcRewardConfig.ENABLE_NPC_REWARD_CONFIG) break block182;
                            v39 = MapCycleModule.\u13e8;
                            if (true) ** GOTO lbl245
                            block151: while (true) {
                                v39 = (17300L ^ -3360924303269989613L) / (14497L ^ 8155535741069259972L);
lbl245:
                                // 2 sources

                                switch ((int)v39) {
                                    case -307614797: {
                                        continue block151;
                                    }
                                    case 1415186628: {
                                        break block151;
                                    }
                                }
                                break;
                            }
                            this.switchToNPCRewardConfig();
                            changedConfig = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
                        }
                        v40 = MapCycleModule.\u13e8;
                        if (true) ** GOTO lbl257
                        block152: while (true) {
                            v40 = v41 / (18543L ^ -4749300493056557873L);
lbl257:
                            // 2 sources

                            switch ((int)v40) {
                                case -873099950: {
                                    v41 = 500L ^ 4738130394826938112L;
                                    continue block152;
                                }
                                case 1415186628: {
                                    break block152;
                                }
                                case 1701102131: {
                                    v41 = 8564L ^ -7507503810059475644L;
                                    continue block152;
                                }
                            }
                            break;
                        }
                        v42 = MapCycleModule.\u13e8;
                        if (true) ** GOTO lbl270
                        block153: while (true) {
                            v42 = v43 / (17602L ^ 7572630991508674688L);
lbl270:
                            // 2 sources

                            switch ((int)v42) {
                                case -1548025283: {
                                    v43 = 17676L ^ -8216990585898354361L;
                                    continue block153;
                                }
                                case 190912965: {
                                    v43 = 11296L ^ -1634653597258372906L;
                                    continue block153;
                                }
                                case 513814662: {
                                    v43 = 30174L ^ -5992243121001905350L;
                                    continue block153;
                                }
                                case 1415186628: {
                                    break block153;
                                }
                            }
                            break;
                        }
                        if (this.npcRewardConfig.KEY_ON_NPC_BELOW_HP == null) break block180;
                        v44 = MapCycleModule.\u13e8;
                        if (true) ** GOTO lbl287
                        block154: while (true) {
                            v44 = v45 / (15825L ^ -2632377636599016406L);
lbl287:
                            // 2 sources

                            switch ((int)v44) {
                                case 508539837: {
                                    v45 = 18507L ^ 8224382270765471350L;
                                    continue block154;
                                }
                                case 607771516: {
                                    v45 = 9148894557037780924L >>> "\u0000\u0000".length();
                                    continue block154;
                                }
                                case 904628208: {
                                    v45 = -9095630628098858308L >>> "\u0000\u0000".length();
                                    continue block154;
                                }
                                case 1415186628: {
                                    break block154;
                                }
                            }
                            break;
                        }
                        this.PressKeyNpcBelowHp();
                        break block180;
                    }
                    while (true) {
                        if ((v46 = (cfr_temp_6 = MapCycleModule.\u13e8 - (3165L ^ 8296796112980087691L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                        if (v46 == (8333 ^ -8334)) {
                            this.pressedKeyNpcBelowHp = 26066 ^ 26066;
                            break;
                        }
                        v46 = 15612 ^ 1302960939;
                    }
                }
                while (true) {
                    if ((v47 = (cfr_temp_7 = MapCycleModule.\u13e8 - (13450L ^ -5109803017641508480L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                    if (v47 == (28259 ^ 28258)) break;
                    v47 = 932280536 >>> "\u0000\u0000".length();
                }
                while (true) {
                    if ((v48 = (cfr_temp_8 = MapCycleModule.\u13e8 - (15628L ^ 4609298098129879945L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                    if (v48 == (17177 ^ -17178)) break;
                    v48 = 590 ^ 1708731661;
                }
                v49 = this.hero.health;
                v50 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl325
                block158: while (true) {
                    v50 = v51 / (11675L ^ -4187784895262412015L);
lbl325:
                    // 2 sources

                    switch ((int)v50) {
                        case -1748166909: {
                            v51 = 6670L ^ 1779826141747014609L;
                            continue block158;
                        }
                        case -1619339453: {
                            v51 = 13931L ^ -7732315262178588701L;
                            continue block158;
                        }
                        case 906823730: {
                            v51 = 5172112608090971576L >>> "\u0000\u0000".length();
                            continue block158;
                        }
                        case 1415186628: {
                            break block158;
                        }
                    }
                    break;
                }
                v52 = v49.hpPercent() * 100.0;
                while (true) {
                    if ((v53 = (cfr_temp_9 = MapCycleModule.\u13e8 - (19805L ^ 5992177281976335504L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
                    if (v53 == (23158 ^ -23159)) break;
                    v53 = 10928 ^ 1222687569;
                }
                v54 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl347
                block160: while (true) {
                    v54 = (7392L ^ 5589179782256653563L) / (12730L ^ -465984167705497771L);
lbl347:
                    // 2 sources

                    switch ((int)v54) {
                        case -334384340: {
                            continue block160;
                        }
                        case 1415186628: {
                            break block160;
                        }
                    }
                    break;
                }
                considerSafetyKeyPress = v52 < (double)this.mapCycleSafetyConfig.SAFTEY_HP_THRESHOLD ? "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length() : 25041 ^ 25041;
                while (true) {
                    if ((v55 = (cfr_temp_10 = MapCycleModule.\u13e8 - (18767L ^ -1668337811185218739L)) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
                    if (v55 == (3417 ^ -3418)) break;
                    v55 = 10847 ^ 1931688581;
                }
                while (true) {
                    if ((v56 = (cfr_temp_11 = MapCycleModule.\u13e8 - (6648L ^ -3083876844043476128L)) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
                    if (v56 == (23925 ^ 23924)) break;
                    v56 = 5929 ^ 1158467592;
                }
                v57 = this.hero.health;
                while (true) {
                    if ((v58 = (cfr_temp_12 = MapCycleModule.\u13e8 - (8699L ^ 7957616176053446914L)) == 0L ? 0 : (cfr_temp_12 < 0L ? -1 : 1)) == false) continue;
                    if (v58 == (11910 ^ -11911)) break;
                    v58 = 4025 ^ -294936894;
                }
                v59 = v57.hpPercent() * 100.0;
                while (true) {
                    if ((v60 = (cfr_temp_13 = MapCycleModule.\u13e8 - (21414L ^ -439816522909770696L)) == 0L ? 0 : (cfr_temp_13 < 0L ? -1 : 1)) == false) continue;
                    if (v60 == (30718 ^ -30719)) break;
                    v60 = 11694 ^ 1673130902;
                }
                while (true) {
                    if ((v61 = (cfr_temp_14 = MapCycleModule.\u13e8 - (-83387318649951196L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_14 < 0L ? -1 : 1)) == false) continue;
                    if (v61 == (1322 ^ -1323)) break;
                    v61 = 9537 ^ -274193121;
                }
                v62 = considerInstaShieldKeyPress = v59 < (double)this.mapCycleSafetyConfig.INSTA_SHIELD_HP_THRESHOLD ? 24675 ^ 24674 : 25789 ^ 25789;
                if (considerSafetyKeyPress == 0) break block183;
                v63 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl386
                block166: while (true) {
                    v63 = v64 / (11950L ^ 7225213520078598465L);
lbl386:
                    // 2 sources

                    switch ((int)v63) {
                        case -824621874: {
                            v64 = 2357L ^ 8438352760162960255L;
                            continue block166;
                        }
                        case 669595128: {
                            v64 = 5834L ^ 1949487003209421168L;
                            continue block166;
                        }
                        case 1415186628: {
                            break block166;
                        }
                    }
                    break;
                }
                if (!this.CanPressSafetyKey()) break block183;
                v65 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl400
                block167: while (true) {
                    v65 = (12276L ^ -4184363472690362937L) / (-3224100182334297088L >>> "\u0000\u0000".length());
lbl400:
                    // 2 sources

                    switch ((int)v65) {
                        case 1415186628: {
                            break block167;
                        }
                        case 1506513309: {
                            continue block167;
                        }
                    }
                    break;
                }
                v66 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl409
                block168: while (true) {
                    v66 = (7385L ^ -7137395870505476773L) / (26687L ^ 3066002733493673343L);
lbl409:
                    // 2 sources

                    switch ((int)v66) {
                        case -910055444: {
                            continue block168;
                        }
                        case 1415186628: {
                            break block168;
                        }
                    }
                    break;
                }
                if (!this.mapCycleSafetyConfig.USE_SAFETY_KEY_WHEN_BELOW_HP_SAFETY) break block183;
                v67 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl419
                block169: while (true) {
                    v67 = v68 / (11908L ^ 3467494270395788260L);
lbl419:
                    // 2 sources

                    switch ((int)v67) {
                        case -1601198448: {
                            v68 = 26364L ^ 8883973017163382479L;
                            continue block169;
                        }
                        case -720090966: {
                            v68 = 3812L ^ 2224565367056019010L;
                            continue block169;
                        }
                        case 1276742320: {
                            v68 = 11254L ^ 7139329951097460043L;
                            continue block169;
                        }
                        case 1415186628: {
                            break block169;
                        }
                    }
                    break;
                }
                this.PressSafetyKey();
            }
            if (considerInstaShieldKeyPress == 0) break block184;
            v69 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl438
            block170: while (true) {
                v69 = v70 / (11217L ^ 2205365880289432746L);
lbl438:
                // 2 sources

                switch ((int)v69) {
                    case -1001392803: {
                        v70 = 1090127560596406212L >>> "\u0000\u0000".length();
                        continue block170;
                    }
                    case -576192471: {
                        v70 = 9907L ^ -3041893663520815598L;
                        continue block170;
                    }
                    case 658794619: {
                        v70 = -4542787495161873824L >>> "\u0000\u0000".length();
                        continue block170;
                    }
                    case 1415186628: {
                        break block170;
                    }
                }
                break;
            }
            if (this.canPressInstaShieldKey()) {
                while (true) {
                    if ((v71 = (cfr_temp_15 = MapCycleModule.\u13e8 - (878L ^ 2314739512768260652L)) == 0L ? 0 : (cfr_temp_15 < 0L ? -1 : 1)) == false) continue;
                    if (v71 == (1858 ^ -1859)) {
                        this.pressInstaShieldKey();
                        break;
                    }
                    v71 = 2117257376 >>> "\u0000\u0000".length();
                }
            }
        }
        while (true) {
            if ((v72 = (cfr_temp_16 = MapCycleModule.\u13e8 - (1529L ^ -5352574100643268622L)) == 0L ? 0 : (cfr_temp_16 < 0L ? -1 : 1)) == false) continue;
            if (v72 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v72 = 3990 ^ -1491191281;
        }
        this.MoveToNpcSubnameTick();
        return changedConfig;
    }

    /*
     * Unable to fully structure code
     */
    private boolean sateftyTick() {
        block102: {
            block100: {
                block101: {
                    v0 = MapCycleModule.\u13e8;
                    if (true) ** GOTO lbl5
                    block56: while (true) {
                        v0 = (27110L ^ -7235468223802581989L) / (10175L ^ 4533328541103711149L);
lbl5:
                        // 2 sources

                        switch ((int)v0) {
                            case -1461533644: {
                                continue block56;
                            }
                            case 1415186628: {
                                break block56;
                            }
                        }
                        break;
                    }
                    while (true) {
                        if ((v1 = (cfr_temp_0 = MapCycleModule.\u13e8 - (25799L ^ -3406516833630563193L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                        if (v1 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                        v1 = 28294 ^ -1000088286;
                    }
                    v2 = this.mainConfig.GENERAL;
                    while (true) {
                        if ((v3 = (cfr_temp_1 = MapCycleModule.\u13e8 - (30169L ^ 3684988208501362302L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                        if (v3 == (10898 ^ -10899)) break;
                        v3 = 5958 ^ -1721322769;
                    }
                    v4 = v2.WORKING_MAP;
                    while (true) {
                        if ((v5 = (cfr_temp_2 = MapCycleModule.\u13e8 - (21296L ^ 5640595664444606765L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                        if (v5 == (29672 ^ -29673)) break;
                        v5 = 6312 ^ -1994209141;
                    }
                    while (true) {
                        if ((v6 = (cfr_temp_3 = MapCycleModule.\u13e8 - (30700L ^ -3275278573554720974L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                        if (v6 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                        v6 = 22997 ^ 1413277336;
                    }
                    v7 = this.hero.map;
                    while (true) {
                        if ((v8 = (cfr_temp_4 = MapCycleModule.\u13e8 - (1250L ^ 8848924379238902435L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                        if (v8 == (3678 ^ -3679)) break;
                        v8 = 15432 ^ 1572200141;
                    }
                    if (v4 != v7.id) {
                        return (boolean)(31319 ^ 31319);
                    }
                    while (true) {
                        if ((v9 = (cfr_temp_5 = MapCycleModule.\u13e8 - (11243L ^ -8254457910940808989L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                        if (v9 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                        v9 = -104496748 >>> "\u0000\u0000".length();
                    }
                    while (true) {
                        if ((v10 = (cfr_temp_6 = MapCycleModule.\u13e8 - (3134L ^ -235712932002522192L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                        if (v10 == (7080 ^ -7081)) break;
                        v10 = 4414 ^ -49707121;
                    }
                    atLeastGroupMembersCount = this.groupConfig.WAIT_FOR_GROUP_MEMBER_COUNT;
                    if (atLeastGroupMembersCount <= 0) break block100;
                    while (true) {
                        if ((v11 = (cfr_temp_7 = MapCycleModule.\u13e8 - (21315L ^ 6935457895940217233L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                        if (v11 == (20339 ^ -20340)) break;
                        v11 = 25737 ^ -311126257;
                    }
                    v12 = MapCycleModule.\u13e8;
                    if (true) ** GOTO lbl61
                    block65: while (true) {
                        v12 = (28302L ^ 1051329514616093867L) / (-1060920662025805280L >>> "\u0000\u0000".length());
lbl61:
                        // 2 sources

                        switch ((int)v12) {
                            case 262916999: {
                                continue block65;
                            }
                            case 1415186628: {
                                break block65;
                            }
                        }
                        break;
                    }
                    while (true) {
                        if ((v13 = (cfr_temp_8 = MapCycleModule.\u13e8 - (31050L ^ 10291295594940145L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                        if (v13 == (17174 ^ -17175)) break;
                        v13 = 27384 ^ 1090334014;
                    }
                    v14 = this.hero.map;
                    while (true) {
                        if ((v15 = (cfr_temp_9 = MapCycleModule.\u13e8 - (21729L ^ -7148924910096884412L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
                        if (v15 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                        v15 = 23333 ^ 2061385161;
                    }
                    v16 = v14.id;
                    v17 = atLeastGroupMembersCount;
                    while (true) {
                        if ((v18 = (cfr_temp_10 = MapCycleModule.\u13e8 - (206L ^ -1234177159366858314L)) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
                        if (v18 == (23020 ^ -23021)) break;
                        v18 = 22961 ^ -1980071563;
                    }
                    if (!GroupManagerExtensions.LessThanCountOnMap(this.groupManager, v16, v17)) break block101;
                    v19 = MapCycleModule.\u13e8;
                    if (true) ** GOTO lbl89
                    block69: while (true) {
                        v19 = v20 / (8484L ^ -3640975487687994925L);
lbl89:
                        // 2 sources

                        switch ((int)v19) {
                            case -1178833087: {
                                v20 = 17936L ^ -8283944996745786210L;
                                continue block69;
                            }
                            case 1381138378: {
                                v20 = 6611L ^ -1649090160484329750L;
                                continue block69;
                            }
                            case 1415186628: {
                                break block69;
                            }
                            case 1816760399: {
                                v20 = 9537L ^ -689720859844146240L;
                                continue block69;
                            }
                        }
                        break;
                    }
                    this.flyToSafety();
                    return (boolean)(31084 ^ 31085);
                }
                while (true) {
                    if ((v21 = (cfr_temp_11 = MapCycleModule.\u13e8 - (-5280964687659700484L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
                    if (v21 == (5703 ^ -5704)) break;
                    v21 = 30368 ^ 1963554522;
                }
                v22 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl113
                block71: while (true) {
                    v22 = v23 / (9286L ^ -2817769378163720405L);
lbl113:
                    // 2 sources

                    switch ((int)v22) {
                        case -1942242417: {
                            v23 = 21671L ^ -6789674918412860514L;
                            continue block71;
                        }
                        case 1415186628: {
                            break block71;
                        }
                        case 1661388118: {
                            v23 = 3726L ^ -3108358873683568205L;
                            continue block71;
                        }
                    }
                    break;
                }
                if (!GroupManagerExtensions.HasGroup(this.groupManager)) {
                    while (true) {
                        if ((v24 = (cfr_temp_12 = MapCycleModule.\u13e8 - (30834L ^ 4407248553672711096L)) == 0L ? 0 : (cfr_temp_12 < 0L ? -1 : 1)) == false) continue;
                        if (v24 == (11882 ^ -11883)) break;
                        v24 = 11091 ^ 2127535070;
                    }
                    while (true) {
                        if ((v25 = (cfr_temp_13 = MapCycleModule.\u13e8 - (30808L ^ -7374223155569821134L)) == 0L ? 0 : (cfr_temp_13 < 0L ? -1 : 1)) == false) continue;
                        if (v25 == (4819 ^ 4818)) break;
                        v25 = 23694 ^ -1373293133;
                    }
                    if (this.groupConfig.WAIT_TO_BE_IN_GROUP) {
                        while (true) {
                            if ((v26 = (cfr_temp_14 = MapCycleModule.\u13e8 - (27435L ^ 3966198355537176424L)) == 0L ? 0 : (cfr_temp_14 < 0L ? -1 : 1)) == false) continue;
                            if (v26 == (11852 ^ -11853)) break;
                            v26 = 21041 ^ 1170777817;
                        }
                        this.flyToSafety();
                        return (boolean)(17274 ^ 17275);
                    }
                }
            }
            v27 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl146
            block75: while (true) {
                v27 = v28 / (11044L ^ -6783353673816487627L);
lbl146:
                // 2 sources

                switch ((int)v27) {
                    case -1907528715: {
                        v28 = 11425L ^ 1809567442319734586L;
                        continue block75;
                    }
                    case -1168435367: {
                        v28 = 6440954138508561608L >>> "\u0000\u0000".length();
                        continue block75;
                    }
                    case 1415186628: {
                        break block75;
                    }
                }
                break;
            }
            if (this.withinBeheKillWaitPeriod()) {
                return "".length() >>> "\u0000\u0000".length();
            }
            v29 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl161
            block76: while (true) {
                v29 = v30 / (20629L ^ -4268692149447584122L);
lbl161:
                // 2 sources

                switch ((int)v29) {
                    case -1072345899: {
                        v30 = 23008L ^ 4884394721261455631L;
                        continue block76;
                    }
                    case 1415186628: {
                        break block76;
                    }
                    case 1915697573: {
                        v30 = 2447848020350068720L >>> "\u0000\u0000".length();
                        continue block76;
                    }
                }
                break;
            }
            while (true) {
                if ((v31 = (cfr_temp_15 = MapCycleModule.\u13e8 - (16165L ^ 8623055016179539416L)) == 0L ? 0 : (cfr_temp_15 < 0L ? -1 : 1)) == false) continue;
                if (v31 == (18882 ^ -18883)) break;
                v31 = 2791 ^ 1230173765;
            }
            waitInSafetyTillUnderSeconds = this.predictNpcSpawnConfig.WAIT_IN_SAFETY_UNTIL_UNDER_SECONDS;
            if (waitInSafetyTillUnderSeconds < 0) {
                return (boolean)(22325 ^ 22325);
            }
            while (true) {
                if ((v32 = (cfr_temp_16 = MapCycleModule.\u13e8 - (30859L ^ 5009454019842898307L)) == 0L ? 0 : (cfr_temp_16 < 0L ? -1 : 1)) == false) continue;
                if (v32 == (32290 ^ -32291)) break;
                v32 = 871992684 >>> "\u0000\u0000".length();
            }
            msTillSpawnPeriod = this.getMsTillWithinNPCSpawnPeriod();
            if (msTillSpawnPeriod == null) {
                return "".length() >>> "\u0000\u0000".length();
            }
            v33 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl190
            block79: while (true) {
                v33 = (-1959951724480447016L >>> "\u0000\u0000".length()) / (2772L ^ -2237122217978987047L);
lbl190:
                // 2 sources

                switch ((int)v33) {
                    case -653461857: {
                        continue block79;
                    }
                    case 1415186628: {
                        break block79;
                    }
                }
                break;
            }
            v34 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl199
            block80: while (true) {
                v34 = v35 / (11806L ^ -4913106021704802442L);
lbl199:
                // 2 sources

                switch ((int)v34) {
                    case -353407818: {
                        v35 = 17779L ^ -7372871155733789704L;
                        continue block80;
                    }
                    case -302734392: {
                        v35 = 443L ^ -603407391382483514L;
                        continue block80;
                    }
                    case 1415186628: {
                        break block80;
                    }
                }
                break;
            }
            v36 = msTillSpawnPeriod;
            while (true) {
                if ((v37 = (cfr_temp_17 = MapCycleModule.\u13e8 - (16291L ^ -219714265244091717L)) == 0L ? 0 : (cfr_temp_17 < 0L ? -1 : 1)) == false) continue;
                if (v37 == (28809 ^ -28810)) break;
                v37 = 19686 ^ -1235959984;
            }
            secondsTillSpawnPeriod = TimeUnit.MILLISECONDS.toSeconds(v36);
            if (secondsTillSpawnPeriod <= (long)waitInSafetyTillUnderSeconds) {
                return (boolean)(5663 ^ 5663);
            }
            v38 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl221
            block82: while (true) {
                v38 = v39 / (18388L ^ 529529020594392777L);
lbl221:
                // 2 sources

                switch ((int)v38) {
                    case -1640947547: {
                        v39 = 22174L ^ -5111839684366964907L;
                        continue block82;
                    }
                    case -512403279: {
                        v39 = 13319L ^ -4396870098561543767L;
                        continue block82;
                    }
                    case 1415186628: {
                        break block82;
                    }
                }
                break;
            }
            while (true) {
                if ((v40 = (cfr_temp_18 = MapCycleModule.\u13e8 - (32123L ^ 5676196765909333932L)) == 0L ? 0 : (cfr_temp_18 < 0L ? -1 : 1)) == false) continue;
                if (v40 == (26001 ^ -26002)) break;
                v40 = 5538 ^ 249612514;
            }
            if (!this.predictNpcSpawnConfig.LOGOUT_WHILE_WAITING_IN_SAFETY) break block102;
            while (true) {
                if ((v41 = (cfr_temp_19 = MapCycleModule.\u13e8 - (8732L ^ 3997414026746334925L)) == 0L ? 0 : (cfr_temp_19 < 0L ? -1 : 1)) == false) continue;
                if (v41 == (5455 ^ -5456)) break;
                v41 = -1792427632 >>> "\u0000\u0000".length();
            }
            v42 = msTillSpawnPeriod;
            while (true) {
                if ((v43 = (cfr_temp_20 = MapCycleModule.\u13e8 - (24967L ^ -2050350910371699563L)) == 0L ? 0 : (cfr_temp_20 < 0L ? -1 : 1)) == false) continue;
                if (v43 == (31556 ^ -31557)) break;
                v43 = 1831 ^ 157636889;
            }
            v44 = waitInSafetyTillUnderSeconds;
            while (true) {
                if ((v45 = (cfr_temp_21 = MapCycleModule.\u13e8 - (4372L ^ 8228731342518058866L)) == 0L ? 0 : (cfr_temp_21 < 0L ? -1 : 1)) == false) continue;
                if (v45 == (16992 ^ -16993)) break;
                v45 = 4740 ^ 971217023;
            }
            disconnectSpawnTimeMs = v42 - TimeUnit.SECONDS.toMillis(v44);
            if (disconnectSpawnTimeMs <= 0L >>> "\u0000\u0000".length()) break block102;
            while (true) {
                if ((v46 = (cfr_temp_22 = MapCycleModule.\u13e8 - (16580L ^ 983173757183996764L)) == 0L ? 0 : (cfr_temp_22 < 0L ? -1 : 1)) == false) continue;
                if (v46 == (21091 ^ -21092)) break;
                v46 = 19584 ^ -930448375;
            }
            v47 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl264
            block88: while (true) {
                v47 = (6956L ^ -6864062845953360868L) / (13837L ^ 2586694779835235472L);
lbl264:
                // 2 sources

                switch ((int)v47) {
                    case 1415186628: {
                        break block88;
                    }
                    case 2113627334: {
                        continue block88;
                    }
                }
                break;
            }
            while (true) {
                if ((v48 = (cfr_temp_23 = MapCycleModule.\u13e8 - (8568L ^ -3099662130032944093L)) == 0L ? 0 : (cfr_temp_23 < 0L ? -1 : 1)) == false) continue;
                if (v48 == (7298 ^ 7299)) break;
                v48 = 4755 ^ -2078680944;
            }
            v49 = disconnectSpawnTimeMs;
            var9_6 = new byte[12751 ^ 12761];
            var9_6[19924 ^ 19905] = "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
            var9_6[31696 ^ 31685] = 12942 ^ 13053;
            var9_6[25844 ^ 25850] = 396 >>> "\u0000\u0000".length();
            var9_6["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 440 >>> "\u0000\u0000".length();
            var9_6["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 25544 ^ 25519;
            var9_6[30348 ^ 30367] = 27605 ^ 27554;
            var9_6[12407 ^ 12407] = 738 ^ 686;
            var9_6[32294 ^ 32288] = 30351 ^ 30383;
            var9_6["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 10804 ^ 10823;
            var9_6["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 25646 ^ 25664;
            var9_6["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 3305 ^ 3225;
            var9_6[31337 ^ 31329] = 420 >>> "\u0000\u0000".length();
            var9_6[14470 ^ 14466] = 468 >>> "\u0000\u0000".length();
            var9_6[6915 ^ 6930] = 13152 ^ 13072;
            var9_6["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 5665 ^ 5709;
            var9_6[15886 ^ 15883] = 1849 ^ 1869;
            var9_6[18474 ^ 18467] = 432 >>> "\u0000\u0000".length();
            var9_6["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 21026 ^ 21059;
            var9_6[8747 ^ 8744] = 444 >>> "\u0000\u0000".length();
            var9_6[28870 ^ 28871] = 12887 ^ 12856;
            var9_6["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 464 >>> "\u0000\u0000".length();
            var9_6["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 128 >>> "\u0000\u0000".length();
            var9_6[20642 ^ 20649] = 28808 ^ 28840;
            v50 = new String(var9_6);
            while (true) {
                if ((v51 = (cfr_temp_24 = MapCycleModule.\u13e8 - (14789L ^ -6781183311082567759L)) == 0L ? 0 : (cfr_temp_24 < 0L ? -1 : 1)) == false) continue;
                if (v51 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v51 = 4467 ^ -1842164235;
            }
            v52 = new DisconnectModule(v49, v50);
            v53 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl310
            block91: while (true) {
                v53 = v54 / (26015L ^ 1515186905877929324L);
lbl310:
                // 2 sources

                switch ((int)v53) {
                    case 472955205: {
                        v54 = 20993L ^ -58062606968587316L;
                        continue block91;
                    }
                    case 1415186628: {
                        break block91;
                    }
                    case 1456199108: {
                        v54 = 24553L ^ 5276293315271028111L;
                        continue block91;
                    }
                }
                break;
            }
            this.main.setModule((Module)v52);
            return (boolean)(15325 ^ 15324);
        }
        v55 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl327
        block92: while (true) {
            v55 = (26193L ^ -490212617518604631L) / (26805L ^ -8368781141746018201L);
lbl327:
            // 2 sources

            switch ((int)v55) {
                case -2053026140: {
                    continue block92;
                }
                case 1415186628: {
                    break block92;
                }
            }
            break;
        }
        this.flyToSafety();
        return "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private void stopFlyToSafety() {
        while (true) {
            if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (-2146292591736713204L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v0 == (8926 ^ -8927)) break;
            v0 = 1993035032 >>> "\u0000\u0000".length();
        }
        v1 = "".length() >>> "\u0000\u0000".length();
        v2 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl12
        block7: while (true) {
            v2 = v3 / (6715543986152508632L >>> "\u0000\u0000".length());
lbl12:
            // 2 sources

            switch ((int)v2) {
                case -144419490: {
                    v3 = 25638L ^ -5722285630931783826L;
                    continue block7;
                }
                case 16096708: {
                    v3 = 1205L ^ 5463555627316352318L;
                    continue block7;
                }
                case 359862893: {
                    v3 = 25461L ^ 3197342048721461003L;
                    continue block7;
                }
                case 1415186628: {
                    break block7;
                }
            }
            break;
        }
        this.safety.setRefreshing(v1);
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private void flyToSafety() {
        while (true) {
            if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (15063L ^ 7171477299131477399L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (18354 ^ -18355)) break;
            v0 = 17485 ^ -586356356;
        }
        while (true) {
            if ((v1 = (cfr_temp_1 = MapCycleModule.\u13e8 - (6046L ^ -3071123419656436210L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v1 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v1 = 3511 ^ -1926734715;
        }
        v2 = this.main.guiManager;
        v3 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl16
        block25: while (true) {
            v3 = v4 / (9230L ^ -808645052646470597L);
lbl16:
            // 2 sources

            switch ((int)v3) {
                case -1760672890: {
                    v4 = 14562L ^ -6064516910544486699L;
                    continue block25;
                }
                case 1050577197: {
                    v4 = 17176L ^ 3200740038821439684L;
                    continue block25;
                }
                case 1415186628: {
                    break block25;
                }
            }
            break;
        }
        v5 = v2.pet;
        v6 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl30
        block26: while (true) {
            v6 = (24746L ^ 6626093637437379234L) / (32660L ^ -5580932915888941901L);
lbl30:
            // 2 sources

            switch ((int)v6) {
                case -2016959076: {
                    continue block26;
                }
                case 1415186628: {
                    break block26;
                }
            }
            break;
        }
        while (true) {
            if ((v7 = (cfr_temp_2 = MapCycleModule.\u13e8 - (30323L ^ -5087947354133456097L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v7 == (25205 ^ 25204)) break;
            v7 = 3081 ^ -1389026204;
        }
        v8 = this.betterLootModuleConfig.MAP_TRAVELLER_CONFIG;
        while (true) {
            if ((v9 = (cfr_temp_3 = MapCycleModule.\u13e8 - (12370L ^ -6833802098705673495L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v9 == (24379 ^ 24378)) break;
            v9 = 22167 ^ -66447435;
        }
        v10 = v8.PET_OUT_WHILE_TRAVELLING;
        v11 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl51
        block29: while (true) {
            v11 = v12 / (18850L ^ -5130973870702272464L);
lbl51:
            // 2 sources

            switch ((int)v11) {
                case -2013893216: {
                    v12 = -1513542074960740136L >>> "\u0000\u0000".length();
                    continue block29;
                }
                case -1105496682: {
                    v12 = 5638L ^ -5591138980962620927L;
                    continue block29;
                }
                case 1415186628: {
                    break block29;
                }
                case 1639556444: {
                    v12 = 14617L ^ -2376369806333926192L;
                    continue block29;
                }
            }
            break;
        }
        v5.setEnabled(v10);
        while (true) {
            if ((v13 = (cfr_temp_4 = MapCycleModule.\u13e8 - (-6169955481087363416L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v13 == (23097 ^ -23098)) break;
            v13 = 28642 ^ -1699895901;
        }
        v14 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        v15 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl74
        block31: while (true) {
            v15 = (9012L ^ 8501617337348499837L) / (4383L ^ -3224352531739631067L);
lbl74:
            // 2 sources

            switch ((int)v15) {
                case -1489879865: {
                    continue block31;
                }
                case 1415186628: {
                    break block31;
                }
            }
            break;
        }
        this.safety.setRefreshing(v14);
        while (true) {
            if ((v16 = (cfr_temp_5 = MapCycleModule.\u13e8 - (3476L ^ -3286142357545500893L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
            if (v16 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v16 = 13067 ^ 1827369314;
        }
        v17 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl89
        block33: while (true) {
            v17 = (17979L ^ -6281410658321241897L) / (10010L ^ -133873838734170471L);
lbl89:
            // 2 sources

            switch ((int)v17) {
                case -384651840: {
                    continue block33;
                }
                case 1415186628: {
                    break block33;
                }
            }
            break;
        }
        this.safety.tick();
        while (true) {
            if ((v18 = (cfr_temp_6 = MapCycleModule.\u13e8 - (14838L ^ -9213883041131145875L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
            if (v18 == (24801 ^ 24800)) break;
            v18 = 25995 ^ -211788875;
        }
        this.switchToPreferredRegionTravelConfig();
    }

    /*
     * Enabled aggressive block sorting
     */
    private boolean shouldCollectBox(Box box) {
        int n;
        block13: {
            if (box == null) {
                return "".length() >>> "\u0000\u0000".length();
            }
            long l = \u13e8;
            block4: while (true) {
                switch ((int)l) {
                    case -1651602930: {
                        l = (0x1DFCL ^ 0x13AF0EBC2C334D44L) / (0x3861L ^ 0xF5E9C62F57654816L);
                        continue block4;
                    }
                    case 1415186628: {
                        break block4;
                    }
                }
                break;
            }
            while (true) {
                long l2;
                long l3;
                if ((l3 = (l2 = \u13e8 - (0x3EDEL ^ 0xF6E73190560EF93DL)) == 0L ? 0 : (l2 < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (l3 == (0x6B69 ^ 0xFFFF9496)) {
                    if (this.mapCycleBoxCollectConfig.ONLY_COLLECT_BOXES_IN_PREFERRED_REGION) {
                        break;
                    }
                    break block13;
                }
                l3 = 0x5DBF ^ 0xEA51917B;
            }
            while (true) {
                long l4;
                long l5;
                if ((l5 = (l4 = \u13e8 - (0x227DL ^ 0xA308A5A415DE3FA9L)) == 0L ? 0 : (l4 < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (l5 == (0x122 ^ 0x123)) {
                    if (this.EntityIsInPreferredRegion((Entity)box)) break;
                    n = 0x6FE8 ^ 0x6FE8;
                    return n != 0;
                }
                l5 = 0x6B15 ^ 0x678A9671;
            }
        }
        n = 0xADB ^ 0xADA;
        return n != 0;
    }

    /*
     * Unable to fully structure code
     */
    private boolean lootNCollect() {
        block262: {
            block263: {
                block271: {
                    block272: {
                        block261: {
                            block270: {
                                block269: {
                                    block267: {
                                        block268: {
                                            block266: {
                                                block264: {
                                                    block265: {
                                                        v0 = MapCycleModule.\u13e8;
                                                        if (true) ** GOTO lbl5
                                                        block164: while (true) {
                                                            v0 = (14993L ^ -3868460768779704957L) / (3448L ^ 5973771032781067297L);
lbl5:
                                                            // 2 sources

                                                            switch ((int)v0) {
                                                                case -375141289: {
                                                                    continue block164;
                                                                }
                                                                case 1415186628: {
                                                                    break block164;
                                                                }
                                                            }
                                                            break;
                                                        }
                                                        if (this.sateftyTick()) {
                                                            return "".length() >>> "\u0000\u0000".length();
                                                        }
                                                        while (true) {
                                                            if ((v1 = (cfr_temp_0 = MapCycleModule.\u13e8 - (29994L ^ -3498216160816855372L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                                                            if (v1 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                                                            v1 = 11113 ^ -956265028;
                                                        }
                                                        this.checkMapSwitch();
                                                        v2 = MapCycleModule.\u13e8;
                                                        if (true) ** GOTO lbl22
                                                        block166: while (true) {
                                                            v2 = v3 / (30442L ^ -6542848564093558535L);
lbl22:
                                                            // 2 sources

                                                            switch ((int)v2) {
                                                                case -1339256024: {
                                                                    v3 = -3326108193897012392L >>> "\u0000\u0000".length();
                                                                    continue block166;
                                                                }
                                                                case -473100241: {
                                                                    v3 = 15750L ^ -4862584197013951820L;
                                                                    continue block166;
                                                                }
                                                                case 1415186628: {
                                                                    break block166;
                                                                }
                                                                case 2007666154: {
                                                                    v3 = 6740L ^ -6221960688647240795L;
                                                                    continue block166;
                                                                }
                                                            }
                                                            break;
                                                        }
                                                        this.checkSafenessOfArea();
                                                        v4 = MapCycleModule.\u13e8;
                                                        if (true) ** GOTO lbl39
                                                        block167: while (true) {
                                                            v4 = v5 / (23447L ^ 5054813489268786278L);
lbl39:
                                                            // 2 sources

                                                            switch ((int)v4) {
                                                                case -443897191: {
                                                                    v5 = 27582L ^ 4151658601403611631L;
                                                                    continue block167;
                                                                }
                                                                case 373961249: {
                                                                    v5 = 2311024616265541844L >>> "\u0000\u0000".length();
                                                                    continue block167;
                                                                }
                                                                case 1361802620: {
                                                                    v5 = 6875L ^ 6319799908579448459L;
                                                                    continue block167;
                                                                }
                                                                case 1415186628: {
                                                                    break block167;
                                                                }
                                                            }
                                                            break;
                                                        }
                                                        while (true) {
                                                            if ((v6 = (cfr_temp_1 = MapCycleModule.\u13e8 - (-4930115527548046276L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                                                            if (v6 == (13539 ^ -13540)) break;
                                                            v6 = 30695 ^ -1482476832;
                                                        }
                                                        if (!this.collectorModule.isNotWaiting()) break block262;
                                                        v7 = MapCycleModule.\u13e8;
                                                        if (true) ** GOTO lbl61
                                                        block169: while (true) {
                                                            v7 = v8 / (7504L ^ -9002088258125605819L);
lbl61:
                                                            // 2 sources

                                                            switch ((int)v7) {
                                                                case -1913346092: {
                                                                    v8 = 9280L ^ 3691358563027723144L;
                                                                    continue block169;
                                                                }
                                                                case -290229370: {
                                                                    v8 = 29181L ^ -6666264360724820090L;
                                                                    continue block169;
                                                                }
                                                                case 1005331050: {
                                                                    v8 = 12762L ^ 4895606276078008124L;
                                                                    continue block169;
                                                                }
                                                                case 1415186628: {
                                                                    break block169;
                                                                }
                                                            }
                                                            break;
                                                        }
                                                        v9 = MapCycleModule.\u13e8;
                                                        if (true) ** GOTO lbl77
                                                        block170: while (true) {
                                                            v9 = v10 / (16268L ^ -1182019173427859575L);
lbl77:
                                                            // 2 sources

                                                            switch ((int)v9) {
                                                                case -1184883824: {
                                                                    v10 = 11690L ^ -3830153075211176283L;
                                                                    continue block170;
                                                                }
                                                                case 1415186628: {
                                                                    break block170;
                                                                }
                                                                case 2040504820: {
                                                                    v10 = 15949L ^ -5294117412408979602L;
                                                                    continue block170;
                                                                }
                                                            }
                                                            break;
                                                        }
                                                        v11 = (BooleanSupplier)LambdaMetafactory.metafactory(null, null, null, ()Z, canRefresh(), ()Z)((MapCycleModule)this);
                                                        while (true) {
                                                            if ((v12 = (cfr_temp_2 = MapCycleModule.\u13e8 - (4153466122757587648L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                                                            if (v12 == (10063 ^ -10064)) break;
                                                            v12 = 8375 ^ 480061673;
                                                        }
                                                        if (!this.lootModule.checkDangerousAndCurrentMapPub(v11)) break block262;
                                                        while (true) {
                                                            if ((v13 = (cfr_temp_3 = MapCycleModule.\u13e8 - (5450L ^ 3778280996737718472L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                                                            if (v13 == (14075 ^ -14076)) break;
                                                            v13 = 30477 ^ 395206391;
                                                        }
                                                        this.updatePetTick();
                                                        while (true) {
                                                            if ((v14 = (cfr_temp_4 = MapCycleModule.\u13e8 - (31240L ^ -1174145725701529762L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                                                            if (v14 == (1606 ^ -1607)) break;
                                                            v14 = 22369 ^ -1603810456;
                                                        }
                                                        this.HandleIsWithinPredictedSpawnPeriod();
                                                        while (true) {
                                                            if ((v15 = (cfr_temp_5 = MapCycleModule.\u13e8 - (27950L ^ 3134685369053305850L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                                                            if (v15 == (32140 ^ -32141)) break;
                                                            v15 = 23715 ^ -144445290;
                                                        }
                                                        this.KeepShipInPreferredRegion();
                                                        while (true) {
                                                            if ((v16 = (cfr_temp_6 = MapCycleModule.\u13e8 - (32761L ^ -6590410403439220941L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                                                            if (v16 == (353 ^ 352)) break;
                                                            v16 = 32659 ^ -117081467;
                                                        }
                                                        while (true) {
                                                            if ((v17 = (cfr_temp_7 = MapCycleModule.\u13e8 - (26575L ^ -5876715760242637167L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                                                            if (v17 == (31780 ^ 31781)) break;
                                                            v17 = 1742826976 >>> "\u0000\u0000".length();
                                                        }
                                                        if (!this.lootModule.findTargetPub()) break block263;
                                                        v18 = MapCycleModule.\u13e8;
                                                        if (true) ** GOTO lbl126
                                                        block177: while (true) {
                                                            v18 = v19 / (8299L ^ -2939316869389957052L);
lbl126:
                                                            // 2 sources

                                                            switch ((int)v18) {
                                                                case -953767053: {
                                                                    v19 = 31855L ^ -2358812920714093591L;
                                                                    continue block177;
                                                                }
                                                                case 76961321: {
                                                                    v19 = 7524L ^ -2494955022254092058L;
                                                                    continue block177;
                                                                }
                                                                case 935549067: {
                                                                    v19 = 19204L ^ -7674184439872847079L;
                                                                    continue block177;
                                                                }
                                                                case 1415186628: {
                                                                    break block177;
                                                                }
                                                            }
                                                            break;
                                                        }
                                                        while (true) {
                                                            if ((v20 = (cfr_temp_8 = MapCycleModule.\u13e8 - (9244L ^ 8184129957844440596L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                                                            if (v20 == (23378 ^ -23379)) break;
                                                            v20 = 30143 ^ -418981586;
                                                        }
                                                        this.collectorModule.findBox();
                                                        while (true) {
                                                            if ((v21 = (cfr_temp_9 = MapCycleModule.\u13e8 - (9116243852080245256L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
                                                            if (v21 == (10519 ^ -10520)) break;
                                                            v21 = 25569 ^ -351282251;
                                                        }
                                                        while (true) {
                                                            if ((v22 = (cfr_temp_10 = MapCycleModule.\u13e8 - (18627L ^ -3292595636841493336L)) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
                                                            if (v22 == (26560 ^ 26561)) break;
                                                            v22 = 10128 ^ 605377482;
                                                        }
                                                        box = this.collectorModule.current;
                                                        v23 = MapCycleModule.\u13e8;
                                                        if (true) ** GOTO lbl159
                                                        block181: while (true) {
                                                            v23 = v24 / (10314L ^ -6374505530907764535L);
lbl159:
                                                            // 2 sources

                                                            switch ((int)v23) {
                                                                case -1942429362: {
                                                                    v24 = 238L ^ -433775367878482934L;
                                                                    continue block181;
                                                                }
                                                                case 117581654: {
                                                                    v24 = 4863L ^ 3777311962170196369L;
                                                                    continue block181;
                                                                }
                                                                case 215260686: {
                                                                    v24 = 29729L ^ -3283023351931698905L;
                                                                    continue block181;
                                                                }
                                                                case 1415186628: {
                                                                    break block181;
                                                                }
                                                            }
                                                            break;
                                                        }
                                                        v25 = MapCycleModule.\u13e8;
                                                        if (true) ** GOTO lbl175
                                                        block182: while (true) {
                                                            v25 = v26 / (11228L ^ -5534314404891524358L);
lbl175:
                                                            // 2 sources

                                                            switch ((int)v25) {
                                                                case -985900831: {
                                                                    v26 = 11913L ^ 7708502768517445530L;
                                                                    continue block182;
                                                                }
                                                                case -185396095: {
                                                                    v26 = -3734545553471716888L >>> "\u0000\u0000".length();
                                                                    continue block182;
                                                                }
                                                                case 643479980: {
                                                                    v26 = 13416L ^ 8356096335882741576L;
                                                                    continue block182;
                                                                }
                                                                case 1415186628: {
                                                                    break block182;
                                                                }
                                                            }
                                                            break;
                                                        }
                                                        npc = this.lootModule.getAttackTarget();
                                                        if (box == null) break block264;
                                                        while (true) {
                                                            if ((v27 = (cfr_temp_11 = MapCycleModule.\u13e8 - (12136L ^ 2490819337054004325L)) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
                                                            if (v27 == (24446 ^ -24447)) break;
                                                            v27 = 21950 ^ -1927011325;
                                                        }
                                                        if (box.removed) break block264;
                                                        while (true) {
                                                            if ((v28 = (cfr_temp_12 = MapCycleModule.\u13e8 - (16275L ^ 7297654640950067156L)) == 0L ? 0 : (cfr_temp_12 < 0L ? -1 : 1)) == false) continue;
                                                            if (v28 == (25512 ^ -25513)) break;
                                                            v28 = -1783133912 >>> "\u0000\u0000".length();
                                                        }
                                                        v29 = box.locationInfo;
                                                        while (true) {
                                                            if ((v30 = (cfr_temp_13 = MapCycleModule.\u13e8 - (10310L ^ 6246684278606725855L)) == 0L ? 0 : (cfr_temp_13 < 0L ? -1 : 1)) == false) continue;
                                                            if (v30 == (30626 ^ -30627)) break;
                                                            v30 = 2649 ^ 387170117;
                                                        }
                                                        v31 = MapCycleModule.\u13e8;
                                                        if (true) ** GOTO lbl210
                                                        block186: while (true) {
                                                            v31 = (-7605106102701398572L >>> "\u0000\u0000".length()) / (11480L ^ 7290779972920072536L);
lbl210:
                                                            // 2 sources

                                                            switch ((int)v31) {
                                                                case 477060617: {
                                                                    continue block186;
                                                                }
                                                                case 1415186628: {
                                                                    break block186;
                                                                }
                                                            }
                                                            break;
                                                        }
                                                        v32 = v29.distance((Entity)this.hero);
                                                        v33 = MapCycleModule.\u13e8;
                                                        if (true) ** GOTO lbl220
                                                        block187: while (true) {
                                                            v33 = (22612L ^ 7842738177234426178L) / (31988L ^ -5599562383468981848L);
lbl220:
                                                            // 2 sources

                                                            switch ((int)v33) {
                                                                case -621292748: {
                                                                    continue block187;
                                                                }
                                                                case 1415186628: {
                                                                    break block187;
                                                                }
                                                            }
                                                            break;
                                                        }
                                                        while (true) {
                                                            if ((v34 = (cfr_temp_14 = MapCycleModule.\u13e8 - (10450L ^ -1493038063225873253L)) == 0L ? 0 : (cfr_temp_14 < 0L ? -1 : 1)) == false) continue;
                                                            if (v34 == (6061 ^ -6062)) break;
                                                            v34 = 16918 ^ 2130812977;
                                                        }
                                                        v35 = this.mainConfig.COLLECT;
                                                        while (true) {
                                                            if ((v36 = (cfr_temp_15 = MapCycleModule.\u13e8 - (-2711457793336903000L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_15 < 0L ? -1 : 1)) == false) continue;
                                                            if (v36 == (32610 ^ -32611)) break;
                                                            v36 = 10539 ^ -1200759848;
                                                        }
                                                        if (v32 > (double)v35.RADIUS) break block264;
                                                        while (true) {
                                                            if ((v37 = (cfr_temp_16 = MapCycleModule.\u13e8 - (5289L ^ 1107646675473201834L)) == 0L ? 0 : (cfr_temp_16 < 0L ? -1 : 1)) == false) continue;
                                                            if (v37 == (15135 ^ -15136)) break;
                                                            v37 = 7403 ^ -1819721769;
                                                        }
                                                        v38 = npc.npcInfo;
                                                        while (true) {
                                                            if ((v39 = (cfr_temp_17 = MapCycleModule.\u13e8 - (8479L ^ -7310485014102659920L)) == 0L ? 0 : (cfr_temp_17 < 0L ? -1 : 1)) == false) continue;
                                                            if (v39 == (28476 ^ 28477)) break;
                                                            v39 = 4511 ^ -661046728;
                                                        }
                                                        v40 = v38.extra;
                                                        while (true) {
                                                            if ((v41 = (cfr_temp_18 = MapCycleModule.\u13e8 - (-1341493712470020264L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_18 < 0L ? -1 : 1)) == false) continue;
                                                            if (v41 == (8736 ^ -8737)) break;
                                                            v41 = 146 ^ -1847342873;
                                                        }
                                                        v42 = MapCycleModule.\u13e8;
                                                        if (true) ** GOTO lbl258
                                                        block193: while (true) {
                                                            v42 = (26019L ^ -2102732833585424907L) / (24441L ^ -7458395664145421586L);
lbl258:
                                                            // 2 sources

                                                            switch ((int)v42) {
                                                                case 143434670: {
                                                                    continue block193;
                                                                }
                                                                case 1415186628: {
                                                                    break block193;
                                                                }
                                                            }
                                                            break;
                                                        }
                                                        if (!v40.has((NpcExtraFlag)NpcExtra.IGNORE_BOXES)) break block265;
                                                        while (true) {
                                                            if ((v43 = (cfr_temp_19 = MapCycleModule.\u13e8 - (28286L ^ -6152386798938162138L)) == 0L ? 0 : (cfr_temp_19 < 0L ? -1 : 1)) == false) continue;
                                                            if (v43 == (9885 ^ 9884)) break;
                                                            v43 = 5440 ^ -1912944771;
                                                        }
                                                        v44 = npc.locationInfo;
                                                        while (true) {
                                                            if ((v45 = (cfr_temp_20 = MapCycleModule.\u13e8 - (1840L ^ -5550399270820291802L)) == 0L ? 0 : (cfr_temp_20 < 0L ? -1 : 1)) == false) continue;
                                                            if (v45 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                                                            v45 = 32562 ^ -1118666622;
                                                        }
                                                        v46 = v44.distance((Entity)box);
                                                        v47 = MapCycleModule.\u13e8;
                                                        if (true) ** GOTO lbl280
                                                        block196: while (true) {
                                                            v47 = v48 / (26451L ^ 8577444367783918586L);
lbl280:
                                                            // 2 sources

                                                            switch ((int)v47) {
                                                                case -359851015: {
                                                                    v48 = 20753L ^ 5955291643399761130L;
                                                                    continue block196;
                                                                }
                                                                case 591721548: {
                                                                    v48 = 26587L ^ -9049721978373467779L;
                                                                    continue block196;
                                                                }
                                                                case 1415186628: {
                                                                    break block196;
                                                                }
                                                            }
                                                            break;
                                                        }
                                                        v49 = npc.npcInfo;
                                                        while (true) {
                                                            if ((v50 = (cfr_temp_21 = MapCycleModule.\u13e8 - (17966L ^ 145596476405214831L)) == 0L ? 0 : (cfr_temp_21 < 0L ? -1 : 1)) == false) continue;
                                                            if (v50 == (3552 ^ -3553)) break;
                                                            v50 = 32298 ^ -480971733;
                                                        }
                                                        v51 = v49.radius * 2.0;
                                                        while (true) {
                                                            if ((v52 = (cfr_temp_22 = MapCycleModule.\u13e8 - (24590L ^ 6801649283694148688L)) == 0L ? 0 : (cfr_temp_22 < 0L ? -1 : 1)) == false) continue;
                                                            if (v52 == (20068 ^ -20069)) break;
                                                            v52 = 5544 ^ 1966036915;
                                                        }
                                                        if (v46 > Math.min(800.0, v51)) break block264;
                                                    }
                                                    v53 = MapCycleModule.\u13e8;
                                                    if (true) ** GOTO lbl307
                                                    block199: while (true) {
                                                        v53 = (27517L ^ 8278856463031979283L) / (26071L ^ 9211910681926392428L);
lbl307:
                                                        // 2 sources

                                                        switch ((int)v53) {
                                                            case -1719981932: {
                                                                continue block199;
                                                            }
                                                            case 1415186628: {
                                                                break block199;
                                                            }
                                                        }
                                                        break;
                                                    }
                                                    while (true) {
                                                        if ((v54 = (cfr_temp_23 = MapCycleModule.\u13e8 - (32111L ^ -1410279237026465704L)) == 0L ? 0 : (cfr_temp_23 < 0L ? -1 : 1)) == false) continue;
                                                        if (v54 == (20394 ^ -20395)) break;
                                                        v54 = 1687193960 >>> "\u0000\u0000".length();
                                                    }
                                                    v55 = this.lootModule.getAttackTarget();
                                                    v56 = MapCycleModule.\u13e8;
                                                    if (true) ** GOTO lbl322
                                                    block201: while (true) {
                                                        v56 = (10058L ^ 5230884480053972152L) / (13847L ^ -5262769583887695665L);
lbl322:
                                                        // 2 sources

                                                        switch ((int)v56) {
                                                            case 167646471: {
                                                                continue block201;
                                                            }
                                                            case 1415186628: {
                                                                break block201;
                                                            }
                                                        }
                                                        break;
                                                    }
                                                    v57 = v55.health;
                                                    v58 = MapCycleModule.\u13e8;
                                                    if (true) ** GOTO lbl332
                                                    block202: while (true) {
                                                        v58 = (16557L ^ 6067917602689640710L) / (15881L ^ -1519690613753458127L);
lbl332:
                                                        // 2 sources

                                                        switch ((int)v58) {
                                                            case -570681910: {
                                                                continue block202;
                                                            }
                                                            case 1415186628: {
                                                                break block202;
                                                            }
                                                        }
                                                        break;
                                                    }
                                                    if (v57.hpPercent() < 0.25) break block264;
                                                    v59 = MapCycleModule.\u13e8;
                                                    if (true) ** GOTO lbl342
                                                    block203: while (true) {
                                                        v59 = v60 / (22666L ^ -655765457410227411L);
lbl342:
                                                        // 2 sources

                                                        switch ((int)v59) {
                                                            case -683593972: {
                                                                v60 = 26930L ^ -5606866033205026658L;
                                                                continue block203;
                                                            }
                                                            case 120520050: {
                                                                v60 = 5062L ^ -2952879874113698131L;
                                                                continue block203;
                                                            }
                                                            case 1415186628: {
                                                                break block203;
                                                            }
                                                        }
                                                        break;
                                                    }
                                                    if (this.shouldCollectBox(box)) break block266;
                                                }
                                                box = null;
                                            }
                                            while (true) {
                                                if ((v61 = (cfr_temp_24 = MapCycleModule.\u13e8 - (3122L ^ -7053890296066302711L)) == 0L ? 0 : (cfr_temp_24 < 0L ? -1 : 1)) == false) continue;
                                                if (v61 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                                                v61 = 8796 ^ 1511510381;
                                            }
                                            v62 = npc.playerInfo;
                                            v63 = MapCycleModule.\u13e8;
                                            if (true) ** GOTO lbl365
                                            block205: while (true) {
                                                v63 = (28665L ^ 9139364718048463556L) / (11266L ^ -6660752568715761578L);
lbl365:
                                                // 2 sources

                                                switch ((int)v63) {
                                                    case -97967677: {
                                                        continue block205;
                                                    }
                                                    case 1415186628: {
                                                        break block205;
                                                    }
                                                }
                                                break;
                                            }
                                            npcName = v62.username;
                                            while (true) {
                                                if ((v64 = (cfr_temp_25 = MapCycleModule.\u13e8 - (-2109849546144242244L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_25 < 0L ? -1 : 1)) == false) continue;
                                                if (v64 == (4738 ^ -4739)) break;
                                                v64 = -465399256 >>> "\u0000\u0000".length();
                                            }
                                            npcIsBehe = this.containsNPCSubname(npcName);
                                            while (true) {
                                                if ((v65 = (cfr_temp_26 = MapCycleModule.\u13e8 - (27059L ^ 4616847273565687723L)) == 0L ? 0 : (cfr_temp_26 < 0L ? -1 : 1)) == false) continue;
                                                if (v65 == (23209 ^ -23210)) break;
                                                v65 = 16844 ^ -1721761335;
                                            }
                                            if (this.heroIsAttacking()) break block267;
                                            v66 = MapCycleModule.\u13e8;
                                            if (true) ** GOTO lbl387
                                            block208: while (true) {
                                                v66 = v67 / (2454L ^ 7351521403140252835L);
lbl387:
                                                // 2 sources

                                                switch ((int)v66) {
                                                    case -1132880851: {
                                                        v67 = 19908L ^ 588130023821709377L;
                                                        continue block208;
                                                    }
                                                    case 1020981584: {
                                                        v67 = 204L ^ 5747848676105303295L;
                                                        continue block208;
                                                    }
                                                    case 1415186628: {
                                                        break block208;
                                                    }
                                                }
                                                break;
                                            }
                                            if (!this.onlyShootDuringWaitPeriod()) break block267;
                                            while (true) {
                                                if ((v68 = (cfr_temp_27 = MapCycleModule.\u13e8 - (28213L ^ -4688407808102404851L)) == 0L ? 0 : (cfr_temp_27 < 0L ? -1 : 1)) == false) continue;
                                                if (v68 == (14845 ^ 14844)) break;
                                                v68 = 10706 ^ -69075759;
                                            }
                                            if (!this.inWaitTicksPeriod()) break block268;
                                            v69 = MapCycleModule.\u13e8;
                                            if (true) ** GOTO lbl407
                                            block210: while (true) {
                                                v69 = (24404L ^ 3808756423652169821L) / (13654L ^ 2634891413550095880L);
lbl407:
                                                // 2 sources

                                                switch ((int)v69) {
                                                    case -739269748: {
                                                        continue block210;
                                                    }
                                                    case 1415186628: {
                                                        break block210;
                                                    }
                                                }
                                                break;
                                            }
                                            if (this.shootDuringWaitPeriod()) break block267;
                                        }
                                        if (!npcIsBehe) ** GOTO lbl-1000
                                    }
                                    v70 = MapCycleModule.\u13e8;
                                    if (true) ** GOTO lbl420
                                    block211: while (true) {
                                        v70 = (13589L ^ -4106025269519569861L) / (9922L ^ 1213203838819447529L);
lbl420:
                                        // 2 sources

                                        switch ((int)v70) {
                                            case -399030881: {
                                                continue block211;
                                            }
                                            case 1415186628: {
                                                break block211;
                                            }
                                        }
                                        break;
                                    }
                                    while (true) {
                                        if ((v71 = (cfr_temp_28 = MapCycleModule.\u13e8 - (25236L ^ 8063376363836882771L)) == 0L ? 0 : (cfr_temp_28 < 0L ? -1 : 1)) == false) continue;
                                        if (v71 == (30825 ^ -30826)) break;
                                        v71 = 9486 ^ -785446348;
                                    }
                                    v72 = this.main.config;
                                    v73 = MapCycleModule.\u13e8;
                                    if (true) ** GOTO lbl435
                                    block213: while (true) {
                                        v73 = (13414L ^ 5642331437588962752L) / (30487L ^ -1213739542955272096L);
lbl435:
                                        // 2 sources

                                        switch ((int)v73) {
                                            case 1415186628: {
                                                break block213;
                                            }
                                            case 1912358273: {
                                                continue block213;
                                            }
                                        }
                                        break;
                                    }
                                    v74 = v72.GENERAL;
                                    while (true) {
                                        if ((v75 = (cfr_temp_29 = MapCycleModule.\u13e8 - (9181L ^ -4537415196874698214L)) == 0L ? 0 : (cfr_temp_29 < 0L ? -1 : 1)) == false) continue;
                                        if (v75 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                                        v75 = 3010 ^ 595303576;
                                    }
                                    v76 = v74.ROAMING;
                                    while (true) {
                                        if ((v77 = (cfr_temp_30 = MapCycleModule.\u13e8 - (8004L ^ -372755570958459623L)) == 0L ? 0 : (cfr_temp_30 < 0L ? -1 : 1)) == false) continue;
                                        if (v77 == (8405 ^ -8406)) break;
                                        v77 = 3442 ^ -425251886;
                                    }
                                    if (!v76.ONLY_KILL_PREFERRED) ** GOTO lbl-1000
                                    while (true) {
                                        if ((v78 = (cfr_temp_31 = MapCycleModule.\u13e8 - (-8848591974204044768L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_31 < 0L ? -1 : 1)) == false) continue;
                                        if (v78 == (28158 ^ -28159)) break;
                                        v78 = 15144 ^ -1705165467;
                                    }
                                    if (this.EntityIsInPreferredRegion((Entity)npc)) lbl-1000:
                                    // 2 sources

                                    {
                                        v79 = 13882 ^ 13883;
                                    } else lbl-1000:
                                    // 2 sources

                                    {
                                        v79 = 10780 ^ 10780;
                                    }
                                    shootNPC = v79;
                                    forceBoxCollection = box != null ? "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length() : 11882 ^ 11882;
                                    allowChangeToFightConfig = "".length() >>> "\u0000\u0000".length();
                                    boxCollectTravel = 17977 ^ 17977;
                                    v80 = ignoreBoxAndShootNpc = box == null ? 25853 ^ 25852 : 22216 ^ 22216;
                                    if (ignoreBoxAndShootNpc == 0) break block269;
                                    if (shootNPC != 0) {
                                        while (true) {
                                            if ((v81 = (cfr_temp_32 = MapCycleModule.\u13e8 - (16418L ^ -3462621982951406483L)) == 0L ? 0 : (cfr_temp_32 < 0L ? -1 : 1)) == false) continue;
                                            if (v81 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                                            v81 = 11382 ^ -1446116933;
                                        }
                                        while (true) {
                                            if ((v82 = (cfr_temp_33 = MapCycleModule.\u13e8 - (7770L ^ 7904903966842658211L)) == 0L ? 0 : (cfr_temp_33 < 0L ? -1 : 1)) == false) continue;
                                            if (v82 == (23549 ^ -23550)) {
                                                this.lootModule.moveToSafePosition();
                                                break block261;
                                            }
                                            v82 = 15342 ^ -283090595;
                                        }
                                    }
                                    break block261;
                                }
                                v83 = MapCycleModule.\u13e8;
                                if (true) ** GOTO lbl487
                                block219: while (true) {
                                    v83 = v84 / (16821L ^ 8334493606874333143L);
lbl487:
                                    // 2 sources

                                    switch ((int)v83) {
                                        case -385348261: {
                                            v84 = 10228L ^ -4104794892676135513L;
                                            continue block219;
                                        }
                                        case -357342316: {
                                            v84 = 21388L ^ -621359366844859225L;
                                            continue block219;
                                        }
                                        case 1415186628: {
                                            break block219;
                                        }
                                    }
                                    break;
                                }
                                while (true) {
                                    if ((v85 = (cfr_temp_34 = MapCycleModule.\u13e8 - (533L ^ 3502437277707159935L)) == 0L ? 0 : (cfr_temp_34 < 0L ? -1 : 1)) == false) continue;
                                    if (v85 == (8954 ^ -8955)) break;
                                    v85 = 19676 ^ 1150702830;
                                }
                                boxCollectTravel = (int)this.collectorModule.tryCollectNearestBox();
                                if (boxCollectTravel == 0) break block270;
                                v86 = MapCycleModule.\u13e8;
                                if (true) ** GOTO lbl507
                                block221: while (true) {
                                    v86 = (6008556486819244012L >>> "\u0000\u0000".length()) / (31774L ^ -6193849231403076671L);
lbl507:
                                    // 2 sources

                                    switch ((int)v86) {
                                        case -1013143171: {
                                            continue block221;
                                        }
                                        case 1415186628: {
                                            break block221;
                                        }
                                    }
                                    break;
                                }
                                this.switchToCollectConfig();
                                break block261;
                            }
                            allowChangeToFightConfig = 26876 ^ 26877;
                        }
                        if (forceBoxCollection != 0) break block271;
                        v87 = MapCycleModule.\u13e8;
                        if (true) ** GOTO lbl522
                        block222: while (true) {
                            v87 = v88 / (31693L ^ 9185812901930296580L);
lbl522:
                            // 2 sources

                            switch ((int)v87) {
                                case -1867963801: {
                                    v88 = 1095833344806225300L >>> "\u0000\u0000".length();
                                    continue block222;
                                }
                                case 85400729: {
                                    v88 = 4871L ^ 8994209318053490537L;
                                    continue block222;
                                }
                                case 1415186628: {
                                    break block222;
                                }
                            }
                            break;
                        }
                        v89 = MapCycleModule.\u13e8;
                        if (true) ** GOTO lbl535
                        block223: while (true) {
                            v89 = v90 / (8778L ^ -3459939639514843477L);
lbl535:
                            // 2 sources

                            switch ((int)v89) {
                                case -1416235096: {
                                    v90 = 3726L ^ 2053070899951733813L;
                                    continue block223;
                                }
                                case 1415186628: {
                                    break block223;
                                }
                                case 1733455997: {
                                    v90 = 25561L ^ -5685451605618394021L;
                                    continue block223;
                                }
                            }
                            break;
                        }
                        this.lootModule.ignoreTarget();
                        if (shootNPC == 0) break block272;
                        v91 = MapCycleModule.\u13e8;
                        if (true) ** GOTO lbl550
                        block224: while (true) {
                            v91 = v92 / (4452L ^ -4259389951564986230L);
lbl550:
                            // 2 sources

                            switch ((int)v91) {
                                case -1163972398: {
                                    v92 = 26882L ^ 3779128193320023813L;
                                    continue block224;
                                }
                                case 158756179: {
                                    v92 = 24704L ^ -8427538042642026166L;
                                    continue block224;
                                }
                                case 1415186628: {
                                    break block224;
                                }
                                case 1673978516: {
                                    v92 = 30157L ^ 3545150189502643470L;
                                    continue block224;
                                }
                            }
                            break;
                        }
                        v93 = MapCycleModule.\u13e8;
                        if (true) ** GOTO lbl566
                        block225: while (true) {
                            v93 = v94 / (26283L ^ -8565449662962472951L);
lbl566:
                            // 2 sources

                            switch ((int)v93) {
                                case -903970016: {
                                    v94 = 26926L ^ -6977730692190092002L;
                                    continue block225;
                                }
                                case -690479606: {
                                    v94 = 291L ^ 6375361261839502103L;
                                    continue block225;
                                }
                                case 1415186628: {
                                    break block225;
                                }
                                case 2035807525: {
                                    v94 = 21686L ^ 5992896271458515939L;
                                    continue block225;
                                }
                            }
                            break;
                        }
                        this.lootModule.doAttackKillTargetTick();
                        if (!npcIsBehe) break block271;
                        while (true) {
                            if ((v95 = (cfr_temp_35 = MapCycleModule.\u13e8 - (5951368982482543912L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_35 < 0L ? -1 : 1)) == false) continue;
                            if (v95 == (2513 ^ -2514)) break;
                            v95 = 895 ^ -1674012133;
                        }
                        allowChangeToFightConfig = this.HandleShootingBeheTick() == false ? "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length() : 32610 ^ 32610;
                        while (true) {
                            if ((v96 = (cfr_temp_36 = MapCycleModule.\u13e8 - (25335L ^ 2569635628644050297L)) == 0L ? 0 : (cfr_temp_36 < 0L ? -1 : 1)) == false) continue;
                            if (v96 == (5939 ^ -5940)) break;
                            v96 = -1554804500 >>> "\u0000\u0000".length();
                        }
                        while (true) {
                            if ((v97 = (cfr_temp_37 = MapCycleModule.\u13e8 - (17111L ^ 2081632882872720392L)) == 0L ? 0 : (cfr_temp_37 < 0L ? -1 : 1)) == false) continue;
                            if (v97 == (22709 ^ -22710)) break;
                            v97 = 20687 ^ -56113931;
                        }
                        v98 = this.hero.map;
                        while (true) {
                            if ((v99 = (cfr_temp_38 = MapCycleModule.\u13e8 - (2895L ^ -1322401105869975473L)) == 0L ? 0 : (cfr_temp_38 < 0L ? -1 : 1)) == false) continue;
                            if (v99 == (27413 ^ -27414)) break;
                            v99 = 24423 ^ -1056942046;
                        }
                        v100 = v98.id;
                        v101 = MapCycleModule.\u13e8;
                        if (true) ** GOTO lbl607
                        block230: while (true) {
                            v101 = v102 / (20151L ^ 318186243618411990L);
lbl607:
                            // 2 sources

                            switch ((int)v101) {
                                case -1578389329: {
                                    v102 = 23032L ^ 3170681702436840130L;
                                    continue block230;
                                }
                                case -648955885: {
                                    v102 = 13206L ^ -8705871994638320375L;
                                    continue block230;
                                }
                                case 1394724910: {
                                    v102 = 20961L ^ -5918486708689814929L;
                                    continue block230;
                                }
                                case 1415186628: {
                                    break block230;
                                }
                            }
                            break;
                        }
                        this.timestampSubnameKill(v100, null);
                        break block271;
                    }
                    if (boxCollectTravel == 0) {
                        while (true) {
                            if ((v103 = (cfr_temp_39 = MapCycleModule.\u13e8 - (7067947665632954092L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_39 < 0L ? -1 : 1)) == false) continue;
                            if (v103 == (14288 ^ -14289)) break;
                            v103 = 14583 ^ 1518633377;
                        }
                        this.handleLootModuleNoFoundTarget();
                        return (boolean)(14333 ^ 14332);
                    }
                }
                if (allowChangeToFightConfig == 0 || forceBoxCollection != 0) break block262;
                v104 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl636
                block232: while (true) {
                    v104 = v105 / (23525L ^ 5800896081166139391L);
lbl636:
                    // 2 sources

                    switch ((int)v104) {
                        case -1483429458: {
                            v105 = 19598L ^ -1570891191507663743L;
                            continue block232;
                        }
                        case 793945274: {
                            v105 = 8910L ^ 2166628814017734752L;
                            continue block232;
                        }
                        case 1415186628: {
                            break block232;
                        }
                    }
                    break;
                }
                while (true) {
                    if ((v106 = (cfr_temp_40 = MapCycleModule.\u13e8 - (10620L ^ -5237446777420384018L)) == 0L ? 0 : (cfr_temp_40 < 0L ? -1 : 1)) == false) continue;
                    if (v106 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                    v106 = 13868 ^ 985412340;
                }
                while (true) {
                    if ((v107 = (cfr_temp_41 = MapCycleModule.\u13e8 - (17860L ^ 5882151048533211091L)) == 0L ? 0 : (cfr_temp_41 < 0L ? -1 : 1)) == false) continue;
                    if (v107 == (28564 ^ -28565)) break;
                    v107 = 6725 ^ -1291136213;
                }
                v108 = this.mainConfig.GENERAL;
                while (true) {
                    if ((v109 = (cfr_temp_42 = MapCycleModule.\u13e8 - (18626L ^ -8775952455078586507L)) == 0L ? 0 : (cfr_temp_42 < 0L ? -1 : 1)) == false) continue;
                    if (v109 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                    v109 = 30919 ^ 1645212396;
                }
                v110 = v108.OFFENSIVE;
                v111 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl666
                block236: while (true) {
                    v111 = v112 / (-8597824296844906916L >>> "\u0000\u0000".length());
lbl666:
                    // 2 sources

                    switch ((int)v111) {
                        case 424456146: {
                            v112 = 28462L ^ -7632270444195414185L;
                            continue block236;
                        }
                        case 1415186628: {
                            break block236;
                        }
                        case 1531958401: {
                            v112 = 3391L ^ -685517528238779509L;
                            continue block236;
                        }
                    }
                    break;
                }
                this.hero.setMode(v110);
                break block262;
            }
            while (true) {
                if ((v113 = (cfr_temp_43 = MapCycleModule.\u13e8 - (8460050035380399960L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_43 < 0L ? -1 : 1)) == false) continue;
                if (v113 == (5465 ^ -5466)) break;
                v113 = 25524 ^ 1339012200;
            }
            while (true) {
                if ((v114 = (cfr_temp_44 = MapCycleModule.\u13e8 - (2225L ^ -599776043783755945L)) == 0L ? 0 : (cfr_temp_44 < 0L ? -1 : 1)) == false) continue;
                if (v114 == (14697 ^ -14698)) break;
                v114 = 16730 ^ -1490500300;
            }
            this.collectorModule.findBox();
            while (true) {
                if ((v115 = (cfr_temp_45 = MapCycleModule.\u13e8 - (27390L ^ 6803240311907227954L)) == 0L ? 0 : (cfr_temp_45 < 0L ? -1 : 1)) == false) continue;
                if (v115 == (21968 ^ -21969)) break;
                v115 = 11603 ^ 1343081164;
            }
            while (true) {
                if ((v116 = (cfr_temp_46 = MapCycleModule.\u13e8 - (19613L ^ -7976370375115096502L)) == 0L ? 0 : (cfr_temp_46 < 0L ? -1 : 1)) == false) continue;
                if (v116 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v116 = 24852 ^ -261990119;
            }
            box = this.collectorModule.current;
            v117 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl705
            block241: while (true) {
                v117 = v118 / (28285L ^ -2667119994396631196L);
lbl705:
                // 2 sources

                switch ((int)v117) {
                    case -1401814683: {
                        v118 = 2822L ^ -2305024731487645933L;
                        continue block241;
                    }
                    case 1415186628: {
                        break block241;
                    }
                    case 1982548610: {
                        v118 = 8828L ^ -8889704440856821944L;
                        continue block241;
                    }
                }
                break;
            }
            if (!this.shouldCollectBox(box)) ** GOTO lbl-1000
            while (true) {
                if ((v119 = (cfr_temp_47 = MapCycleModule.\u13e8 - (6412L ^ -4102038889710434232L)) == 0L ? 0 : (cfr_temp_47 < 0L ? -1 : 1)) == false) continue;
                if (v119 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v119 = -888954436 >>> "\u0000\u0000".length();
            }
            v120 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl724
            block243: while (true) {
                v120 = v121 / (30059L ^ -5595520725727456631L);
lbl724:
                // 2 sources

                switch ((int)v120) {
                    case -2100740182: {
                        v121 = 26658L ^ -4008725389173416454L;
                        continue block243;
                    }
                    case -374635832: {
                        v121 = 13495L ^ 5040106840397612894L;
                        continue block243;
                    }
                    case 1415186628: {
                        break block243;
                    }
                    case 2038870169: {
                        v121 = 25602L ^ 6337217117400828774L;
                        continue block243;
                    }
                }
                break;
            }
            if (this.collectorModule.tryCollectNearestBox()) {
                v122 = 15844 ^ 15845;
            } else lbl-1000:
            // 2 sources

            {
                v122 = collectedNearestBox = "".length() >>> "\u0000\u0000".length();
            }
            if (collectedNearestBox != 0) {
                while (true) {
                    if ((v123 = (cfr_temp_48 = MapCycleModule.\u13e8 - (15513L ^ -4702718875426116819L)) == 0L ? 0 : (cfr_temp_48 < 0L ? -1 : 1)) == false) continue;
                    if (v123 == (28587 ^ 28586)) {
                        this.switchToCollectConfig();
                        break block262;
                    }
                    v123 = 26427 ^ -748007156;
                }
            }
            v124 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl752
            block245: while (true) {
                v124 = v125 / (7854L ^ 5310672535060857978L);
lbl752:
                // 2 sources

                switch ((int)v124) {
                    case -1588314856: {
                        v125 = 364770458747931856L >>> "\u0000\u0000".length();
                        continue block245;
                    }
                    case 1027867169: {
                        v125 = 20130L ^ -7685549509652933237L;
                        continue block245;
                    }
                    case 1415186628: {
                        break block245;
                    }
                    case 1939778159: {
                        v125 = 21389L ^ -8401523979303855461L;
                        continue block245;
                    }
                }
                break;
            }
            this.handleLootModuleNoFoundTarget();
        }
        return "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private void handleLootModuleNoFoundTarget() {
        block75: {
            block77: {
                block78: {
                    block76: {
                        block74: {
                            v0 = MapCycleModule.\u13e8;
                            if (true) ** GOTO lbl5
                            block43: while (true) {
                                v0 = (2574L ^ 1857985472233981501L) / (6621L ^ 1425653189726194623L);
lbl5:
                                // 2 sources

                                switch ((int)v0) {
                                    case 430728906: {
                                        continue block43;
                                    }
                                    case 1415186628: {
                                        break block43;
                                    }
                                }
                                break;
                            }
                            shipIsInPreferredRegion = this.shipIsInPreferredRegion();
                            if (shipIsInPreferredRegion) {
                                while (true) {
                                    if ((v1 = (cfr_temp_0 = MapCycleModule.\u13e8 - (1976L ^ 7932256459747109869L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                                        continue;
                                    }
                                    if (v1 == (14433 ^ -14434)) break;
                                    v1 = 12413 ^ -2062464586;
                                }
                                while (true) {
                                    if ((v2 = (cfr_temp_1 = MapCycleModule.\u13e8 - (25749L ^ 3290301975874975178L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) {
                                        continue;
                                    }
                                    if (v2 == (31378 ^ -31379)) {
                                        this.hero.roamMode();
                                        break block74;
                                    }
                                    v2 = 11086 ^ 1240746868;
                                }
                            }
                            v3 = MapCycleModule.\u13e8;
                            if (true) ** GOTO lbl30
                            block46: while (true) {
                                v3 = v4 / (27503L ^ 8440105173263855386L);
lbl30:
                                // 2 sources

                                switch ((int)v3) {
                                    case -2117047720: {
                                        v4 = 2993L ^ -3733951411645862481L;
                                        continue block46;
                                    }
                                    case -1013944492: {
                                        v4 = 11828L ^ -6460525876785594955L;
                                        continue block46;
                                    }
                                    case 1415186628: {
                                        break block46;
                                    }
                                }
                                break;
                            }
                            this.switchToPreferredRegionTravelConfig();
                        }
                        while (true) {
                            if ((v5 = (cfr_temp_2 = MapCycleModule.\u13e8 - (15883L ^ -1715238192098027359L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) {
                                continue;
                            }
                            if (v5 == (1829 ^ -1830)) break;
                            v5 = 32407 ^ 1193269797;
                        }
                        while (true) {
                            if ((v6 = (cfr_temp_3 = MapCycleModule.\u13e8 - (830L ^ -9203221185478182997L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) {
                                continue;
                            }
                            if (v6 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                            v6 = 2654 ^ -1097744422;
                        }
                        if (this.drive.isMoving()) break block75;
                        v7 = MapCycleModule.\u13e8;
                        if (true) ** GOTO lbl58
                        block49: while (true) {
                            v7 = v8 / (27751L ^ 2222410213308900856L);
lbl58:
                            // 2 sources

                            switch ((int)v7) {
                                case -1884846669: {
                                    v8 = 21496L ^ 8876106020222017139L;
                                    continue block49;
                                }
                                case 1032096006: {
                                    v8 = 13088L ^ 4210321443961025442L;
                                    continue block49;
                                }
                                case 1415186628: {
                                    break block49;
                                }
                                case 1602087722: {
                                    v8 = 737L ^ -1285418042243455065L;
                                    continue block49;
                                }
                            }
                            break;
                        }
                        v9 = MapCycleModule.\u13e8;
                        if (true) ** GOTO lbl74
                        block50: while (true) {
                            v9 = v10 / (13711L ^ 8102411056297345622L);
lbl74:
                            // 2 sources

                            switch ((int)v9) {
                                case -869189833: {
                                    v10 = 6258L ^ -6343850863722515894L;
                                    continue block50;
                                }
                                case -641895013: {
                                    v10 = 16075L ^ 2770470232545200161L;
                                    continue block50;
                                }
                                case 1170309521: {
                                    v10 = 17766L ^ -4422073350121531495L;
                                    continue block50;
                                }
                                case 1415186628: {
                                    break block50;
                                }
                            }
                            break;
                        }
                        v11 = this.hero.health;
                        v12 = MapCycleModule.\u13e8;
                        if (true) ** GOTO lbl91
                        block51: while (true) {
                            v12 = v13 / (31879L ^ 4973671046540069399L);
lbl91:
                            // 2 sources

                            switch ((int)v12) {
                                case -1795046766: {
                                    v13 = 31097L ^ -1597979409103134152L;
                                    continue block51;
                                }
                                case -1088730861: {
                                    v13 = 4825L ^ 7291641167440149225L;
                                    continue block51;
                                }
                                case 72456739: {
                                    v13 = 28318L ^ 8691030072624123800L;
                                    continue block51;
                                }
                                case 1415186628: {
                                    break block51;
                                }
                            }
                            break;
                        }
                        heroIsUnderAttack = v11.hpDecreasedIn(16907 ^ 16867);
                        if (!heroIsUnderAttack) break block76;
                        while (true) {
                            if ((v14 = (cfr_temp_4 = MapCycleModule.\u13e8 - (20282L ^ -2975994797768987855L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) {
                                continue;
                            }
                            if (v14 == (5299 ^ -5300)) break;
                            v14 = 2090 ^ -1355352421;
                        }
                        while (true) {
                            if ((v15 = (cfr_temp_5 = MapCycleModule.\u13e8 - (22097L ^ -3372154191679174078L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) {
                                continue;
                            }
                            if (v15 == (17886 ^ 17887)) break;
                            v15 = 15342 ^ 944054710;
                        }
                        if (this.mapCycleConfig.MOVE_IF_UNDER_ATTACK) {
                            while (true) {
                                if ((v16 = (cfr_temp_6 = MapCycleModule.\u13e8 - (-1316722380686165748L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) {
                                    continue;
                                }
                                if (v16 == (28498 ^ -28499)) break;
                                v16 = 26661 ^ -345794957;
                            }
                            if (!this.withinPrepareForNPCSpawnPeriod()) {
                                v17 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
                                while (true) {
                                    if ((v18 = (cfr_temp_7 = MapCycleModule.\u13e8 - (12363L ^ -2006202427425911262L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) {
                                        continue;
                                    }
                                    if (v18 == (11170 ^ -11171)) {
                                        this.DriveToMapAnchor(v17);
                                        break block75;
                                    }
                                    v18 = 5783 ^ -1835949860;
                                }
                            }
                        }
                        break block75;
                    }
                    if (!shipIsInPreferredRegion) break block77;
                    v19 = MapCycleModule.\u13e8;
                    if (true) ** GOTO lbl141
                    block56: while (true) {
                        v19 = (19699L ^ -4012923379969850577L) / (2295646325230560900L >>> "\u0000\u0000".length());
lbl141:
                        // 2 sources

                        switch ((int)v19) {
                            case 1058021152: {
                                continue block56;
                            }
                            case 1415186628: {
                                break block56;
                            }
                        }
                        break;
                    }
                    if (this.HeroIsOutsideAnchorRadius()) break block78;
                    while (true) {
                        if ((v20 = (cfr_temp_8 = MapCycleModule.\u13e8 - (7373L ^ -5915025806449053231L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) {
                            continue;
                        }
                        if (v20 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                        v20 = 12161 ^ -1141929693;
                    }
                    if (!this.shouldStationaryRandomRoam()) break block75;
                }
                v21 = "".length() >>> "\u0000\u0000".length();
                v22 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl160
                block58: while (true) {
                    v22 = v23 / (8044L ^ -8082437643820652574L);
lbl160:
                    // 2 sources

                    switch ((int)v22) {
                        case -737055332: {
                            v23 = 17762L ^ 4977487189485190115L;
                            continue block58;
                        }
                        case -633567691: {
                            v23 = 3862597522685991308L >>> "\u0000\u0000".length();
                            continue block58;
                        }
                        case 1415186628: {
                            break block58;
                        }
                        case 1633739748: {
                            v23 = 24412L ^ -4607414787222289150L;
                            continue block58;
                        }
                    }
                    break;
                }
                this.DriveToMapAnchor(v21);
                break block75;
            }
            v24 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl179
            block59: while (true) {
                v24 = v25 / (7092L ^ -1707267183146563485L);
lbl179:
                // 2 sources

                switch ((int)v24) {
                    case -1187273901: {
                        v25 = -4659605600861413964L >>> "\u0000\u0000".length();
                        continue block59;
                    }
                    case -986092977: {
                        v25 = 23457L ^ 7324335654275945577L;
                        continue block59;
                    }
                    case 1415186628: {
                        break block59;
                    }
                    case 1464956389: {
                        v25 = 27345L ^ -7387238100558599267L;
                        continue block59;
                    }
                }
                break;
            }
            this.DriveToMapAnchor((boolean)(26718 ^ 26719));
        }
    }

    /*
     * Unable to fully structure code
     */
    private boolean shouldStationaryRandomRoam() {
        while (true) {
            if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (3967L ^ -5204580797142412300L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (32646 ^ 32647)) break;
            v0 = 11273 ^ -972700390;
        }
        v1 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl10
        block17: while (true) {
            v1 = v2 / (29860L ^ 1927680610681032726L);
lbl10:
            // 2 sources

            switch ((int)v1) {
                case -930231099: {
                    v2 = -3364705366239732616L >>> "\u0000\u0000".length();
                    continue block17;
                }
                case -365714536: {
                    v2 = 30417L ^ -7542739178864026141L;
                    continue block17;
                }
                case 1233385916: {
                    v2 = 18063L ^ -3136988229599532753L;
                    continue block17;
                }
                case 1415186628: {
                    break block17;
                }
            }
            break;
        }
        stationaryRoamSeconds = this.mapCycleConfig.STATIONARY_RANDOM_ROAM_SECONDS;
        if (stationaryRoamSeconds == 0) {
            return (boolean)(30262 ^ 30262);
        }
        v3 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl29
        block18: while (true) {
            v3 = v4 / (20464L ^ -1858085059110987871L);
lbl29:
            // 2 sources

            switch ((int)v3) {
                case -1776577376: {
                    v4 = 4242L ^ 5414991985174800637L;
                    continue block18;
                }
                case 376763507: {
                    v4 = 26376L ^ 5599605613377889476L;
                    continue block18;
                }
                case 1415186628: {
                    break block18;
                }
            }
            break;
        }
        v5 = System.currentTimeMillis();
        while (true) {
            if ((v6 = (cfr_temp_1 = MapCycleModule.\u13e8 - (686L ^ -9087321058028857708L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v6 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v6 = 30112 ^ -958709590;
        }
        v7 = v5 - this.lastStationaryRandomRoamMs;
        v8 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl49
        block20: while (true) {
            v8 = v9 / (18235L ^ 4819461761203843561L);
lbl49:
            // 2 sources

            switch ((int)v8) {
                case -1756921809: {
                    v9 = -8304783278364720048L >>> "\u0000\u0000".length();
                    continue block20;
                }
                case 1263304902: {
                    v9 = 337009872737099240L >>> "\u0000\u0000".length();
                    continue block20;
                }
                case 1415186628: {
                    break block20;
                }
            }
            break;
        }
        v10 = stationaryRoamSeconds;
        while (true) {
            if ((v11 = (cfr_temp_2 = MapCycleModule.\u13e8 - (12866L ^ 9168456867831280743L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v11 == (20222 ^ -20223)) break;
            v11 = 21701 ^ 1179064743;
        }
        if (v7 >= TimeUnit.SECONDS.toMillis(v10)) {
            while (true) {
                if ((v12 = (cfr_temp_3 = MapCycleModule.\u13e8 - (31259L ^ 4547850728055393022L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v12 == (23019 ^ -23020)) break;
                v12 = 22394 ^ -1555416065;
            }
            v13 = System.currentTimeMillis();
            while (true) {
                if ((v14 = (cfr_temp_4 = MapCycleModule.\u13e8 - (27603L ^ -4774110254117124269L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v14 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v14 = 18610 ^ 1151575384;
            }
            this.lastStationaryRandomRoamMs = v13;
            return (boolean)(27934 ^ 27935);
        }
        return (boolean)(31753 ^ 31753);
    }

    /*
     * Unable to fully structure code
     */
    private boolean HeroIsOutsideAnchorRadius() {
        block54: {
            v0 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl5
            block39: while (true) {
                v0 = (-2824667415655349952L >>> "\u0000\u0000".length()) / (5596L ^ 7104569618795370339L);
lbl5:
                // 2 sources

                switch ((int)v0) {
                    case -2098398765: {
                        continue block39;
                    }
                    case 1415186628: {
                        break block39;
                    }
                }
                break;
            }
            v1 = System.currentTimeMillis();
            while (true) {
                if ((v2 = (cfr_temp_0 = MapCycleModule.\u13e8 - (229L ^ 8990639586439249818L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v2 == (568 ^ -569)) break;
                v2 = 27074 ^ 1308123165;
            }
            if (v1 - this.outsideAnchorCheckStartMilis <= (11905L ^ 15625L)) break block54;
            v3 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl21
            block41: while (true) {
                v3 = v4 / (30396L ^ 2187776039903680426L);
lbl21:
                // 2 sources

                switch ((int)v3) {
                    case -1405172637: {
                        v4 = 19929L ^ -3638297026319595627L;
                        continue block41;
                    }
                    case 1415186628: {
                        break block41;
                    }
                    case 2130105396: {
                        v4 = 21408L ^ -5203020888894010703L;
                        continue block41;
                    }
                }
                break;
            }
            v5 = System.currentTimeMillis();
            while (true) {
                if ((v6 = (cfr_temp_1 = MapCycleModule.\u13e8 - (2054L ^ 7861638497581813679L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v6 == (30926 ^ -30927)) break;
                v6 = 30763 ^ -914306052;
            }
            this.outsideAnchorCheckStartMilis = v5;
            while (true) {
                if ((v7 = (cfr_temp_2 = MapCycleModule.\u13e8 - (14327L ^ -2242935476069384036L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v7 == (31633 ^ -31634)) break;
                v7 = 8990 ^ 1389306275;
            }
            v8 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl46
            block44: while (true) {
                v8 = (19070L ^ -1887616727113937478L) / (7208L ^ 3516461609010795576L);
lbl46:
                // 2 sources

                switch ((int)v8) {
                    case -223996619: {
                        continue block44;
                    }
                    case 1415186628: {
                        break block44;
                    }
                }
                break;
            }
            v9 = this.hero.map;
            v10 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl56
            block45: while (true) {
                v10 = (30446L ^ 706886511504489389L) / (8744L ^ 737393419395303214L);
lbl56:
                // 2 sources

                switch ((int)v10) {
                    case -263207488: {
                        continue block45;
                    }
                    case 1415186628: {
                        break block45;
                    }
                }
                break;
            }
            v11 = v9.id;
            v12 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl66
            block46: while (true) {
                v12 = (18591L ^ -1338974175396310299L) / (26023L ^ 5527745093630975390L);
lbl66:
                // 2 sources

                switch ((int)v12) {
                    case -1484265138: {
                        continue block46;
                    }
                    case 1415186628: {
                        break block46;
                    }
                }
                break;
            }
            anchor = this.GetAnchorLocationForMap(v11);
            if (anchor == null) {
                return "".length() >>> "\u0000\u0000".length();
            }
            v13 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl78
            block47: while (true) {
                v13 = (7454L ^ -545897842799122396L) / (30219L ^ 8123570737466391037L);
lbl78:
                // 2 sources

                switch ((int)v13) {
                    case 1102790234: {
                        continue block47;
                    }
                    case 1415186628: {
                        break block47;
                    }
                }
                break;
            }
            v14 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl87
            block48: while (true) {
                v14 = (28088L ^ 301256432843037139L) / (1010303156172179820L >>> "\u0000\u0000".length());
lbl87:
                // 2 sources

                switch ((int)v14) {
                    case -1541424131: {
                        continue block48;
                    }
                    case 1415186628: {
                        break block48;
                    }
                }
                break;
            }
            v15 = this.hero.locationInfo;
            while (true) {
                if ((v16 = (cfr_temp_3 = MapCycleModule.\u13e8 - (32514L ^ -6302037499198015623L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v16 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v16 = 6729 ^ 1738384247;
            }
            v17 = v15.now;
            v18 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl103
            block50: while (true) {
                v18 = (18047L ^ -5960577211287046033L) / (17905L ^ 4499810435393531886L);
lbl103:
                // 2 sources

                switch ((int)v18) {
                    case -955686914: {
                        continue block50;
                    }
                    case 1415186628: {
                        break block50;
                    }
                }
                break;
            }
            distToAnchor = v17.distance(anchor);
            while (true) {
                if ((v19 = (cfr_temp_4 = MapCycleModule.\u13e8 - (21390L ^ -7606627672074659114L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v19 == (27566 ^ 27567)) break;
                v19 = 14514 ^ -482195085;
            }
            v20 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl118
            block52: while (true) {
                v20 = v21 / (3288L ^ -1209144668841880900L);
lbl118:
                // 2 sources

                switch ((int)v20) {
                    case -2079089918: {
                        v21 = 9813L ^ -6373846960835658792L;
                        continue block52;
                    }
                    case -463640000: {
                        v21 = -3736247241751542740L >>> "\u0000\u0000".length();
                        continue block52;
                    }
                    case 474437725: {
                        v21 = 991L ^ -8969603868975051278L;
                        continue block52;
                    }
                    case 1415186628: {
                        break block52;
                    }
                }
                break;
            }
            return distToAnchor > (double)this.mapCycleConfig.ANCHOR_RADIUS ? "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length() : "".length() >>> "\u0000\u0000".length();
        }
        return (boolean)(29883 ^ 29883);
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private boolean KeepShipInPreferredRegion() {
        block51: {
            long l = \u13e8;
            block31: while (true) {
                switch ((int)l) {
                    case -4213305: {
                        l = (0xA5CL ^ 0xF43F0D2C7A3CB029L) / (-8682584025552947512L >>> "\u0000\u0000".length());
                        continue block31;
                    }
                    case 1415186628: {
                        break block31;
                    }
                }
                break;
            }
            if (this.shipIsInPreferredRegion()) return "".length() >>> "\u0000\u0000".length();
            while (true) {
                long l2;
                long l3;
                if ((l3 = (l2 = \u13e8 - (0x7002L ^ 0x6BBE0E05F004306BL)) == 0L ? 0 : (l2 < 0L ? -1 : 1)) == false) continue;
                if (l3 == (0x14D6 ^ 0xFFFFEB29)) {
                    if (this.isUnsafe()) {
                        break;
                    }
                    break block51;
                }
                l3 = 0x45A5 ^ 0x6C01FDA0;
            }
            long l4 = \u13e8;
            block33: while (true) {
                switch ((int)l4) {
                    case -1292458270: {
                        l4 = (0x45CDL ^ 0x4F54B9DAC55A8181L) / (0x47E8L ^ 0x8905D82866E78A1EL);
                        continue block33;
                    }
                    case 1415186628: {
                        break block33;
                    }
                }
                break;
            }
            if (this.isWaitingForSafetyCloak()) {
                while (true) {
                    long l5;
                    long l6;
                    if ((l6 = (l5 = \u13e8 - (0x4758L ^ 0xED88D0F1F53505B7L)) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) continue;
                    if (l6 == (0x1E68 ^ 0xFFFFE197)) {
                        if (!this.npcSubnameInSight()) {
                            break;
                        }
                        break block51;
                    }
                    l6 = 0x7C58 ^ 0x6D3DED8F;
                }
                long l7 = \u13e8;
                block35: while (true) {
                    switch ((int)l7) {
                        case 873483207: {
                            l7 = (0x5676L ^ 0x4FA1C3159FB9D547L) / (0x7A35L ^ 0xFA7EFB675E1FDACAL);
                            continue block35;
                        }
                        case 1415186628: {
                            break block35;
                        }
                    }
                    break;
                }
                this.flyToSafety();
                return (0x3F2A ^ 0x3F2B) != 0;
            }
        }
        long l = \u13e8;
        block36: while (true) {
            switch ((int)l) {
                case -552365149: {
                    l = (0x3944L ^ 0x494E28F62162AD22L) / (0x239FL ^ 0x2FD40A69328C2003L);
                    continue block36;
                }
                case 1415186628: {
                    break block36;
                }
            }
            break;
        }
        this.stopFlyToSafety();
        while (true) {
            long l8;
            long l9;
            if ((l9 = (l8 = \u13e8 - (-1405876850135998268L >>> "\u0000\u0000".length())) == 0L ? 0 : (l8 < 0L ? -1 : 1)) == false) continue;
            if (l9 == (0x430C ^ 0xFFFFBCF3)) break;
            l9 = 0x79C2 ^ 0x16491EFE;
        }
        long l10 = System.currentTimeMillis();
        while (true) {
            long l11;
            long l12;
            if ((l12 = (l11 = \u13e8 - (0x755L ^ 0xEA39DAF1268C1A61L)) == 0L ? 0 : (l11 < 0L ? -1 : 1)) == false) continue;
            if (l12 == (0x7F98 ^ 0xFFFF8067)) {
                if (l10 - this.keepShipInpreferedRegionStartMilis <= 20000L >>> "\u0000\u0000".length()) return "".length() >>> "\u0000\u0000".length() != 0;
                break;
            }
            l12 = 0x3389 ^ 0x87B4133C;
        }
        long l13 = \u13e8;
        block39: while (true) {
            switch ((int)l13) {
                case -147283947: {
                    l13 = (0x6FC3L ^ 0x5384B35E6DFF5AA3L) / (0x1796L ^ 0x34E9F38D797AC28AL);
                    continue block39;
                }
                case 1415186628: {
                    break block39;
                }
            }
            break;
        }
        long l14 = System.currentTimeMillis();
        long l15 = \u13e8;
        boolean bl = true;
        block40: while (true) {
            long l16;
            if (!bl || (bl = false) || !true) {
                l15 = l16 / (0x7D70L ^ 0x8EC391B77177B5FCL);
            }
            switch ((int)l15) {
                case 432709912: {
                    l16 = 0x1C47L ^ 0xBE9F91EC8D87CE5EL;
                    continue block40;
                }
                case 1129667873: {
                    l16 = 0x6AFCL ^ 0xB3E4CD7A2B748330L;
                    continue block40;
                }
                case 1415186628: {
                    break block40;
                }
            }
            break;
        }
        this.keepShipInpreferedRegionStartMilis = l14;
        long l17 = \u13e8;
        boolean bl2 = true;
        block41: while (true) {
            long l18;
            if (!bl2 || (bl2 = false) || !true) {
                l17 = l18 / (2237495419083546836L >>> "\u0000\u0000".length());
            }
            switch ((int)l17) {
                case -840777022: {
                    l18 = 0x614FL ^ 0xB42364DCF67B16B7L;
                    continue block41;
                }
                case -752553420: {
                    l18 = 0x5CFL ^ 0xFE5029B8D6A7F353L;
                    continue block41;
                }
                case 1370562289: {
                    l18 = -7998629796792430036L >>> "\u0000\u0000".length();
                    continue block41;
                }
                case 1415186628: {
                    break block41;
                }
            }
            break;
        }
        this.DriveToMapAnchor((0x4989 ^ 0x4988) != 0);
        return "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private void DriveRandomlyInPreferredRegion() {
        long l = \u13e8;
        boolean bl = true;
        block11: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (-898355701374634820L >>> "\u0000\u0000".length());
            }
            switch ((int)l) {
                case 584304645: {
                    l2 = 0x2762L ^ 0xC8713FB62BB274DL;
                    continue block11;
                }
                case 1415186628: {
                    break block11;
                }
                case 2138287539: {
                    l2 = 0x795FL ^ 0xD5E08B12F2250534L;
                    continue block11;
                }
            }
            break;
        }
        long l3 = \u13e8;
        boolean bl2 = true;
        block12: while (true) {
            long l4;
            if (!bl2 || (bl2 = false) || !true) {
                l3 = l4 / (4920451177560774132L >>> "\u0000\u0000".length());
            }
            switch ((int)l3) {
                case -922373842: {
                    l4 = 0x88FL ^ 0x7DBBB1577581C705L;
                    continue block12;
                }
                case -271739063: {
                    l4 = 0x160AL ^ 0x4E26D902C0AD8311L;
                    continue block12;
                }
                case 1415186628: {
                    break block12;
                }
                case 1464001713: {
                    l4 = 0x3CBFL ^ 0x1B82A5A16821419EL;
                    continue block12;
                }
            }
            break;
        }
        this.drive.moveRandom();
    }

    /*
     * Unable to fully structure code
     */
    private void DriveToMapAnchor(boolean moveRandomIfNoAnchor) {
        block52: {
            block53: {
                block54: {
                    while (true) {
                        if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (958L ^ 7955773988646256197L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                        if (v0 == (23113 ^ -23114)) break;
                        v0 = 13858 ^ -1692283919;
                    }
                    v1 = MapCycleModule.\u13e8;
                    if (true) ** GOTO lbl10
                    block37: while (true) {
                        v1 = v2 / (24696L ^ -747778971003572424L);
lbl10:
                        // 2 sources

                        switch ((int)v1) {
                            case -328986807: {
                                v2 = -8932886656195370172L >>> "\u0000\u0000".length();
                                continue block37;
                            }
                            case 636643762: {
                                v2 = 22347L ^ 7856748211164454204L;
                                continue block37;
                            }
                            case 1415186628: {
                                break block37;
                            }
                        }
                        break;
                    }
                    if (!this.mapCycleConfig.ENABLE_ANCHOR_POSITION) break block53;
                    v3 = MapCycleModule.\u13e8;
                    if (true) ** GOTO lbl24
                    block38: while (true) {
                        v3 = v4 / (18886L ^ 7659993415466561311L);
lbl24:
                        // 2 sources

                        switch ((int)v3) {
                            case -1460388123: {
                                v4 = 23581L ^ -4597936458304753204L;
                                continue block38;
                            }
                            case 877844011: {
                                v4 = -5443263004840258948L >>> "\u0000\u0000".length();
                                continue block38;
                            }
                            case 1415186628: {
                                break block38;
                            }
                        }
                        break;
                    }
                    v5 = MapCycleModule.\u13e8;
                    if (true) ** GOTO lbl37
                    block39: while (true) {
                        v5 = (19459L ^ -2298305323784668112L) / (19201L ^ -2855824458583038817L);
lbl37:
                        // 2 sources

                        switch ((int)v5) {
                            case -681880810: {
                                continue block39;
                            }
                            case 1415186628: {
                                break block39;
                            }
                        }
                        break;
                    }
                    v6 = this.hero.map;
                    v7 = MapCycleModule.\u13e8;
                    if (true) ** GOTO lbl47
                    block40: while (true) {
                        v7 = v8 / (14641L ^ 7738166103375900855L);
lbl47:
                        // 2 sources

                        switch ((int)v7) {
                            case 58422902: {
                                v8 = 27319L ^ -5322200427655699139L;
                                continue block40;
                            }
                            case 813006665: {
                                v8 = 27083L ^ -3745524615326252559L;
                                continue block40;
                            }
                            case 1415186628: {
                                break block40;
                            }
                        }
                        break;
                    }
                    v9 = v6.id;
                    v10 = MapCycleModule.\u13e8;
                    if (true) ** GOTO lbl61
                    block41: while (true) {
                        v10 = v11 / (25344L ^ 6151101954087832085L);
lbl61:
                        // 2 sources

                        switch ((int)v10) {
                            case -1317810236: {
                                v11 = 25798L ^ 5471503102229599488L;
                                continue block41;
                            }
                            case 327796900: {
                                v11 = -5183312431978371744L >>> "\u0000\u0000".length();
                                continue block41;
                            }
                            case 1415186628: {
                                break block41;
                            }
                            case 1995219994: {
                                v11 = 32371L ^ -5071858174009317412L;
                                continue block41;
                            }
                        }
                        break;
                    }
                    anchor = this.GetAnchorLocationForMap(v9);
                    if (anchor != null) break block54;
                    if (moveRandomIfNoAnchor) {
                        while (true) {
                            if ((v12 = (cfr_temp_1 = MapCycleModule.\u13e8 - (16129L ^ -4039469488664085079L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                            if (v12 == (19329 ^ 19328)) break;
                            v12 = 8546 ^ -207067043;
                        }
                        while (true) {
                            if ((v13 = (cfr_temp_2 = MapCycleModule.\u13e8 - (9549L ^ -684987675772327809L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                            if (v13 == (11572 ^ -11573)) {
                                this.drive.moveRandom();
                                break block52;
                            }
                            v13 = 9450 ^ -2036126033;
                        }
                    }
                    break block52;
                }
                while (true) {
                    if ((v14 = (cfr_temp_3 = MapCycleModule.\u13e8 - (15613L ^ -1579536913913262002L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                    if (v14 == (17314 ^ -17315)) break;
                    v14 = 21245 ^ -1535726053;
                }
                while (true) {
                    if ((v15 = (cfr_temp_4 = MapCycleModule.\u13e8 - (16191L ^ -6185366597206946036L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                    if (v15 == (23946 ^ 23947)) break;
                    v15 = 6413 ^ -441238489;
                }
                v16 = this.ConstructRandomAnchorLocation(anchor);
                v17 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl105
                block46: while (true) {
                    v17 = v18 / (22787L ^ -6817098967382896512L);
lbl105:
                    // 2 sources

                    switch ((int)v17) {
                        case -949042201: {
                            v18 = 24736L ^ -8389796909941188471L;
                            continue block46;
                        }
                        case -479358777: {
                            v18 = 19528L ^ 8343500434021687598L;
                            continue block46;
                        }
                        case 940084817: {
                            v18 = 24753L ^ -2830258809867182219L;
                            continue block46;
                        }
                        case 1415186628: {
                            break block46;
                        }
                    }
                    break;
                }
                this.drive.move(v16);
                break block52;
            }
            v19 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl124
            block47: while (true) {
                v19 = v20 / (8145L ^ -8116721053336335872L);
lbl124:
                // 2 sources

                switch ((int)v19) {
                    case 1415186628: {
                        break block47;
                    }
                    case 1637704198: {
                        v20 = 4492L ^ -4492279297346121758L;
                        continue block47;
                    }
                    case 2020036152: {
                        v20 = 32688L ^ 7584182664636001068L;
                        continue block47;
                    }
                }
                break;
            }
            while (true) {
                if ((v21 = (cfr_temp_5 = MapCycleModule.\u13e8 - (24567L ^ -81606537690857162L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                if (v21 == (27733 ^ -27734)) {
                    this.drive.moveRandom();
                    break;
                }
                v21 = 27075 ^ 2084466082;
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private Location ConstructRandomAnchorLocation(Location anchor) {
        while (true) {
            if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (8539L ^ 5661782738170370143L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v0 == (10215 ^ -10216)) break;
            v0 = 1839899396 >>> "\u0000\u0000".length();
        }
        anchor_x_rand_offset = this.RandomiseAnchorOffset();
        v1 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl12
        block27: while (true) {
            v1 = v2 / (15719L ^ 8898728282423338497L);
lbl12:
            // 2 sources

            switch ((int)v1) {
                case -1458159831: {
                    v2 = 17580L ^ 3588004933192255246L;
                    continue block27;
                }
                case -1090621406: {
                    v2 = 6956612254719778288L >>> "\u0000\u0000".length();
                    continue block27;
                }
                case 1415186628: {
                    break block27;
                }
            }
            break;
        }
        anchor_y_rand_offset = this.RandomiseAnchorOffset();
        v3 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl26
        block28: while (true) {
            v3 = (25770L ^ 459781337994361282L) / (4156L ^ -288636590292595737L);
lbl26:
            // 2 sources

            switch ((int)v3) {
                case 1415186628: {
                    break block28;
                }
                case 2067989878: {
                    continue block28;
                }
            }
            break;
        }
        v4 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl35
        block29: while (true) {
            v4 = v5 / (17627L ^ -52300604555021273L);
lbl35:
            // 2 sources

            switch ((int)v4) {
                case 860000940: {
                    v5 = 6572385524897851212L >>> "\u0000\u0000".length();
                    continue block29;
                }
                case 1415186628: {
                    break block29;
                }
                case 1505631610: {
                    v5 = 2881L ^ 4634397922618893457L;
                    continue block29;
                }
                case 1889396469: {
                    v5 = 28212L ^ 4723714513423225473L;
                    continue block29;
                }
            }
            break;
        }
        v6 = anchor.x + anchor_x_rand_offset;
        v7 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl52
        block30: while (true) {
            v7 = v8 / (627L ^ -8804973865548372967L);
lbl52:
            // 2 sources

            switch ((int)v7) {
                case -1843603536: {
                    v8 = 5217L ^ -5690745340055019470L;
                    continue block30;
                }
                case -1690827193: {
                    v8 = 5571050045333493076L >>> "\u0000\u0000".length();
                    continue block30;
                }
                case 1415186628: {
                    break block30;
                }
            }
            break;
        }
        v9 = anchor.y + anchor_y_rand_offset;
        v10 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl66
        block31: while (true) {
            v10 = v11 / (29312L ^ -2918666319633185493L);
lbl66:
            // 2 sources

            switch ((int)v10) {
                case -1272622764: {
                    v11 = 22095L ^ 4744966529718342173L;
                    continue block31;
                }
                case 1415186628: {
                    break block31;
                }
                case 1683014737: {
                    v11 = 28289L ^ -2444652435147770816L;
                    continue block31;
                }
                case 2005312060: {
                    v11 = 17554L ^ -7809514939340517968L;
                    continue block31;
                }
            }
            break;
        }
        return new Location(v6, v9);
    }

    /*
     * Unable to fully structure code
     */
    private double RandomiseAnchorOffset() {
        while (true) {
            if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (-9043216234926959604L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v0 == (22270 ^ -22271)) break;
            v0 = 10281 ^ 1333024638;
        }
        while (true) {
            if ((v1 = (cfr_temp_1 = MapCycleModule.\u13e8 - (18409L ^ -2717529475947510291L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v1 == (19958 ^ -19959)) break;
            v1 = 5473 ^ -183296393;
        }
        anchorRadius = this.mapCycleConfig.ANCHOR_RADIUS;
        v2 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl18
        block13: while (true) {
            v2 = v3 / (16779L ^ 5597460141342259009L);
lbl18:
            // 2 sources

            switch ((int)v2) {
                case -821024640: {
                    v3 = 1485L ^ 357834651984122906L;
                    continue block13;
                }
                case -796002601: {
                    v3 = 12917L ^ -6502667690824199215L;
                    continue block13;
                }
                case 1131323913: {
                    v3 = 22986L ^ -7051014208676231587L;
                    continue block13;
                }
                case 1415186628: {
                    break block13;
                }
            }
            break;
        }
        negate = Math.random() < 0.5 ? "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length() : 6903 ^ 6903;
        v4 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl35
        block14: while (true) {
            v4 = v5 / (5135L ^ 7350216984170489569L);
lbl35:
            // 2 sources

            switch ((int)v4) {
                case -255501449: {
                    v5 = 9768L ^ 7571096466004819499L;
                    continue block14;
                }
                case 1372020173: {
                    v5 = 15117L ^ -2171283605575233650L;
                    continue block14;
                }
                case 1415186628: {
                    break block14;
                }
            }
            break;
        }
        return Math.random() * (double)anchorRadius * (double)(negate != 0 ? 5409 ^ -5410 : "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length());
    }

    /*
     * Enabled aggressive block sorting
     */
    private Location GetAnchorLocationForMap(int mapId) {
        MapInfo cycleWorkMapInfo;
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x635EL ^ 0x987D37D90F29D315L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x64A9 ^ 0x64A8)) break;
            l2 = 0x2F30 ^ 0xD0E48D60;
        }
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = \u13e8 - (0x5564L ^ 0x9496D27C8206AFA2L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l3 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l3 = 568393568 >>> "\u0000\u0000".length();
        }
        Map<String, MapInfo> configCycleMapInfosMap = this.mapCycleConfig.CYCLE_MAP_INFOS;
        long l = \u13e8;
        block10: while (true) {
            switch ((int)l) {
                case 624480732: {
                    l = (5368998370134654820L >>> "\u0000\u0000".length()) / (0x1E7DL ^ 0x631EA78FFF284760L);
                    continue block10;
                }
                case 1415186628: {
                    break block10;
                }
            }
            break;
        }
        String mapName = this.getMapName(mapId);
        while (true) {
            long l4;
            long l5;
            if ((l5 = (l4 = \u13e8 - (0x4A29L ^ 0x91FCE3CF980D7C6CL)) == 0L ? 0 : (l4 < 0L ? -1 : 1)) == false) continue;
            if (l5 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                cycleWorkMapInfo = configCycleMapInfosMap.get(mapName);
                if (cycleWorkMapInfo == null) {
                    return null;
                }
                break;
            }
            l5 = 0x4983 ^ 0x15B75D1B;
        }
        while (true) {
            long l6;
            long l7;
            if ((l7 = (l6 = \u13e8 - (0x55AAL ^ 0xC5ED96D42EA36E3FL)) == 0L ? 0 : (l6 < 0L ? -1 : 1)) == false) continue;
            if (l7 == (0x3786 ^ 0x3787)) break;
            l7 = 0x26A9 ^ 0xEE26C324;
        }
        if (cycleWorkMapInfo.anchor_x < 0) return null;
        while (true) {
            long l8;
            long l9;
            if ((l9 = (l8 = \u13e8 - (0xD7CL ^ 0xC0FCEE57B383D371L)) == 0L ? 0 : (l8 < 0L ? -1 : 1)) == false) continue;
            if (l9 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l9 = 0x6247 ^ 0x8430DFBC;
        }
        if (cycleWorkMapInfo.anchor_y < 0) return null;
        long l10 = \u13e8;
        block14: while (true) {
            switch ((int)l10) {
                case -1499889880: {
                    l10 = (0x4AE4L ^ 0xC16A4C879A787A6CL) / (0x790AL ^ 0x6158F11021BD8D57L);
                    continue block14;
                }
                case 1415186628: {
                    break block14;
                }
            }
            break;
        }
        while (true) {
            long l11;
            long l12;
            if ((l12 = (l11 = \u13e8 - (0x75CFL ^ 0xB2399245E3A5F0D1L)) == 0L ? 0 : (l11 < 0L ? -1 : 1)) == false) continue;
            if (l12 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l12 = 0x6E43 ^ 0xFC7B6F75;
        }
        double d = cycleWorkMapInfo.anchor_x * (400 >>> "\u0000\u0000".length());
        while (true) {
            long l13;
            long l14;
            if ((l14 = (l13 = \u13e8 - (0x3687L ^ 0x5B5681F85499F942L)) == 0L ? 0 : (l13 < 0L ? -1 : 1)) == false) continue;
            if (l14 == (0x6E69 ^ 0xFFFF9196)) break;
            l14 = -1032950992 >>> "\u0000\u0000".length();
        }
        double d2 = cycleWorkMapInfo.anchor_y * (400 >>> "\u0000\u0000".length());
        while (true) {
            long l15;
            long l16;
            if ((l16 = (l15 = \u13e8 - (0x48B3L ^ 0x5DD292BB8EBE6EDBL)) == 0L ? 0 : (l15 < 0L ? -1 : 1)) == false) continue;
            if (l16 == (0x4E38 ^ 0xFFFFB1C7)) {
                return new Location(d, d2);
            }
            l16 = 0x2490 ^ 0x428F5D01;
        }
    }

    /*
     * Unable to fully structure code
     */
    private void pressKeyOnFirstLock() {
        block23: {
            while (true) {
                if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (22992L ^ 970737899620607637L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v0 == (5004 ^ -5005)) break;
                v0 = 21629 ^ -1216341411;
            }
            while (true) {
                if ((v1 = (cfr_temp_1 = MapCycleModule.\u13e8 - (29011L ^ 5749935625291455952L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v1 == (527 ^ -528)) break;
                v1 = 29095 ^ -1506693609;
            }
            v2 = this.hero.map;
            v3 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl16
            block13: while (true) {
                v3 = v4 / (16389L ^ 5319499549105841451L);
lbl16:
                // 2 sources

                switch ((int)v3) {
                    case -1840800194: {
                        v4 = 4827L ^ -687062558797140101L;
                        continue block13;
                    }
                    case -1838378386: {
                        v4 = 23946L ^ -4877556164224968376L;
                        continue block13;
                    }
                    case 1415186628: {
                        break block13;
                    }
                }
                break;
            }
            currentMap = v2.id;
            while (true) {
                if ((v5 = (cfr_temp_2 = MapCycleModule.\u13e8 - (23142L ^ -8405994662022825099L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v5 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v5 = 1552482520 >>> "\u0000\u0000".length();
            }
            mapName = this.getMapName(currentMap);
            while (true) {
                if ((v6 = (cfr_temp_3 = MapCycleModule.\u13e8 - (30378L ^ -1941959125901766098L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v6 == (27138 ^ -27139)) break;
                v6 = 21176 ^ -1082782941;
            }
            while (true) {
                if ((v7 = (cfr_temp_4 = MapCycleModule.\u13e8 - (-6532134510292660116L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v7 == (1283 ^ -1284)) break;
                v7 = 32742 ^ -1079573872;
            }
            v8 = this.mapCycleConfig.CYCLE_MAP_INFOS;
            while (true) {
                if ((v9 = (cfr_temp_5 = MapCycleModule.\u13e8 - (32207L ^ 8646486936974185006L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                if (v9 == (4808 ^ -4809)) break;
                v9 = 26605 ^ -919507797;
            }
            currentMapInfo = v8.get(mapName);
            if (currentMapInfo == null) break block23;
            while (true) {
                if ((v10 = (cfr_temp_6 = MapCycleModule.\u13e8 - (9L ^ -6131215866598341276L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                if (v10 == (25154 ^ 25155)) break;
                v10 = 24061 ^ 190083495;
            }
            if (!currentMapInfo.enableKeyPressOnFirstLock) break block23;
            v11 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl60
            block19: while (true) {
                v11 = v12 / (27572L ^ -7284325524543093980L);
lbl60:
                // 2 sources

                switch ((int)v11) {
                    case -1656451267: {
                        v12 = 21774L ^ 8764572213901947011L;
                        continue block19;
                    }
                    case -985317119: {
                        v12 = 20260L ^ -4681212765502061798L;
                        continue block19;
                    }
                    case 476604352: {
                        v12 = -4797811890502179528L >>> "\u0000\u0000".length();
                        continue block19;
                    }
                    case 1415186628: {
                        break block19;
                    }
                }
                break;
            }
            while (true) {
                if ((v13 = (cfr_temp_7 = MapCycleModule.\u13e8 - (25863L ^ 7908738881053499986L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                if (v13 == (6397 ^ -6398)) break;
                v13 = -100251424 >>> "\u0000\u0000".length();
            }
            v14 = this.keyFirstLockConfig.KEY_WHEN_FIRST_LOCKED_ON_NPC_SUBNAME;
            while (true) {
                if ((v15 = (cfr_temp_8 = MapCycleModule.\u13e8 - (-992663139067415336L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                if (v15 == (28540 ^ -28541)) {
                    ApiExtensions.keyboardClick(v14);
                    break;
                }
                v15 = 8887 ^ -1926567887;
            }
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private void tryBuyCloakCPU(boolean cond) {
        if (!cond) return;
        long l = \u13e8;
        boolean bl = true;
        block10: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x747FL ^ 0x92440E64A08C3DCDL);
            }
            switch ((int)l) {
                case -916434175: {
                    l2 = 0x40DAL ^ 0xF8BF4D80B0DF5F55L;
                    continue block10;
                }
                case -700351026: {
                    l2 = 4513076215250668124L >>> "\u0000\u0000".length();
                    continue block10;
                }
                case 1415186628: {
                    break block10;
                }
            }
            break;
        }
        long l3 = \u13e8;
        boolean bl2 = true;
        block11: while (true) {
            long l4;
            if (!bl2 || (bl2 = false) || !true) {
                l3 = l4 / (0x37EDL ^ 0xAA18C45D7BA8C98EL);
            }
            switch ((int)l3) {
                case 693099073: {
                    l4 = -3987268839217607048L >>> "\u0000\u0000".length();
                    continue block11;
                }
                case 1045031486: {
                    l4 = 0x11F9L ^ 0x5D0E9CBA78D199F8L;
                    continue block11;
                }
                case 1415186628: {
                    break block11;
                }
            }
            break;
        }
        if (this.hero.invisible) {
            while (true) {
                long l5;
                long l6;
                if ((l6 = (l5 = \u13e8 - (0x4D80L ^ 0x41DCB7C8D0CF5EBAL)) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) continue;
                if (l6 == (0xD6A ^ 0xFFFFF295)) {
                    UserLogs.LogAlreadyInvisibleNoCloak(this);
                    return;
                }
                l6 = 0x55B5 ^ 0x7B6EE7C5;
            }
        }
        while (true) {
            long l7;
            long l8;
            if ((l8 = (l7 = \u13e8 - (0x278FL ^ 0x2A97468CD3784078L)) == 0L ? 0 : (l7 < 0L ? -1 : 1)) == false) continue;
            if (l8 == (0x4F2A ^ 0xFFFFB0D5)) break;
            l8 = 0x97A ^ 0x625E27B4;
        }
        while (true) {
            long l9;
            long l10;
            if ((l10 = (l9 = \u13e8 - (0x7533L ^ 0xDDBFBAD76F26B8F3L)) == 0L ? 0 : (l9 < 0L ? -1 : 1)) == false) continue;
            if (l10 == (0x7F40 ^ 0xFFFF80BF)) break;
            l10 = 0x1B82 ^ 0xB59B0896;
        }
        IAction iAction = () -> {
            while (true) {
                long l;
                long l2;
                if ((l2 = (l = \u13e8 - (0x7AL ^ 0xA68C455314C82FB9L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
                if (l2 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                l2 = 0x6DAF ^ 0xC1587D0E;
            }
            long l = \u13e8;
            block11: while (true) {
                switch ((int)l) {
                    case 932609511: {
                        l = (0x2D9EL ^ 0xF8292B0C006AEBF4L) / (0x7020L ^ 0x59620214CF7E447BL);
                        continue block11;
                    }
                    case 1415186628: {
                        break block11;
                    }
                }
                break;
            }
            BackpageManager backpageManager = this.main.backpage;
            long l3 = \u13e8;
            boolean bl = true;
            block12: while (true) {
                long l4;
                if (!bl || (bl = false) || !true) {
                    l3 = l4 / (0x54F6L ^ 0x80BB1E5B7A206444L);
                }
                switch ((int)l3) {
                    case -1703871973: {
                        l4 = 0x2E74L ^ 0xDCD0791909E5F0DFL;
                        continue block12;
                    }
                    case -1557153191: {
                        l4 = 0x43BBL ^ 0xC3B08857248746B4L;
                        continue block12;
                    }
                    case -714924871: {
                        l4 = 2430358915150588044L >>> "\u0000\u0000".length();
                        continue block12;
                    }
                    case 1415186628: {
                        break block12;
                    }
                }
                break;
            }
            DoShop.BuySingleCloakCpu(this, backpageManager);
        };
        while (true) {
            long l11;
            long l12;
            if ((l12 = (l11 = \u13e8 - (0x74A6L ^ 0xE4A979FD67C118D1L)) == 0L ? 0 : (l11 < 0L ? -1 : 1)) == false) continue;
            if (l12 == (0x398A ^ 0xFFFFC675)) {
                this.scheduledActionManager.add(iAction);
                return;
            }
            l12 = 0x3737 ^ 0xB5E70A3B;
        }
    }

    /*
     * Unable to fully structure code
     */
    private void pressKeyAfterKill(int currentMap) {
        block38: {
            block39: {
                v0 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl5
                block26: while (true) {
                    v0 = v1 / (24131L ^ 7056006395295049292L);
lbl5:
                    // 2 sources

                    switch ((int)v0) {
                        case -440668806: {
                            v1 = 11988L ^ -4849238934414155232L;
                            continue block26;
                        }
                        case 371441309: {
                            v1 = 7589L ^ -2236494426455569438L;
                            continue block26;
                        }
                        case 1415186628: {
                            break block26;
                        }
                    }
                    break;
                }
                mapName = this.getMapName(currentMap);
                v2 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl19
                block27: while (true) {
                    v2 = v3 / (2698L ^ -3024185197908011644L);
lbl19:
                    // 2 sources

                    switch ((int)v2) {
                        case -2041693523: {
                            v3 = 28130L ^ 8717784815106967686L;
                            continue block27;
                        }
                        case 1415186628: {
                            break block27;
                        }
                        case 1622451560: {
                            v3 = 18660L ^ 8938801675940804632L;
                            continue block27;
                        }
                    }
                    break;
                }
                while (true) {
                    if ((v4 = (cfr_temp_0 = MapCycleModule.\u13e8 - (896L ^ 6575114813571036072L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                    if (v4 == (18275 ^ -18276)) break;
                    v4 = 10632 ^ 1444325608;
                }
                v5 = this.mapCycleConfig.CYCLE_MAP_INFOS;
                while (true) {
                    if ((v6 = (cfr_temp_1 = MapCycleModule.\u13e8 - (-757740864395351860L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                    if (v6 == (3390 ^ -3391)) break;
                    v6 = 14636 ^ -1088145187;
                }
                currentMapInfo = v5.get(mapName);
                if (currentMapInfo == null) break block38;
                while (true) {
                    if ((v7 = (cfr_temp_2 = MapCycleModule.\u13e8 - (3456L ^ -8218583478647604719L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                    if (v7 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                    v7 = 8802 ^ 284567092;
                }
                if (!currentMapInfo.enableKeyPressAfterKill) break block39;
                while (true) {
                    if ((v8 = (cfr_temp_3 = MapCycleModule.\u13e8 - (19295L ^ 6723678024042251954L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                    if (v8 == (14195 ^ -14196)) break;
                    v8 = 7938 ^ -779768176;
                }
                v9 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl56
                block32: while (true) {
                    v9 = v10 / (28019L ^ -1150074898890721524L);
lbl56:
                    // 2 sources

                    switch ((int)v9) {
                        case 201861372: {
                            v10 = 9964L ^ -8064582542509752276L;
                            continue block32;
                        }
                        case 856597654: {
                            v10 = 23163L ^ -3814620999239705418L;
                            continue block32;
                        }
                        case 1415186628: {
                            break block32;
                        }
                        case 1674600379: {
                            v10 = 14426L ^ -6843718063324731089L;
                            continue block32;
                        }
                    }
                    break;
                }
                v11 = this.afterKillConfig.KEY_AFTER_KILL;
                v12 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl73
                block33: while (true) {
                    v12 = v13 / (8694L ^ -7214230209889590349L);
lbl73:
                    // 2 sources

                    switch ((int)v12) {
                        case -1875695193: {
                            v13 = 1660L ^ -6263060701979487897L;
                            continue block33;
                        }
                        case 66773183: {
                            v13 = 15830L ^ 2107195245964937789L;
                            continue block33;
                        }
                        case 1392570375: {
                            v13 = 7082L ^ -2668200429149255936L;
                            continue block33;
                        }
                        case 1415186628: {
                            break block33;
                        }
                    }
                    break;
                }
                ApiExtensions.keyboardClick(v11);
            }
            v14 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl91
            block34: while (true) {
                v14 = (20572L ^ 5069764477735012779L) / (32586L ^ -6675572852239534269L);
lbl91:
                // 2 sources

                switch ((int)v14) {
                    case -447324286: {
                        continue block34;
                    }
                    case 1415186628: {
                        break block34;
                    }
                }
                break;
            }
            while (true) {
                if ((v15 = (cfr_temp_4 = MapCycleModule.\u13e8 - (16863L ^ -2163796176881309018L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v15 == (1111 ^ -1112)) break;
                v15 = 21608 ^ 1376218363;
            }
            v16 = this.afterKillConfig.ENABLE_BUY_CLOAK_CPU_AFTER_KILL;
            while (true) {
                if ((v17 = (cfr_temp_5 = MapCycleModule.\u13e8 - (21493L ^ -2796180562140026142L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                if (v17 == (29768 ^ -29769)) {
                    this.tryBuyCloakCPU(v16);
                    break;
                }
                v17 = 7289 ^ -181051494;
            }
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public Long getMsSinceKilledNpc() {
        long l = \u13e8;
        boolean bl = true;
        block6: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x23CFL ^ 0xEF7AB76C3068D2B6L);
            }
            switch ((int)l) {
                case -1555573693: {
                    l2 = 8580687927464022620L >>> "\u0000\u0000".length();
                    continue block6;
                }
                case -203921155: {
                    l2 = 0x3CE8L ^ 0x74298E384F23B47DL;
                    continue block6;
                }
                case 1415186628: {
                    break block6;
                }
                case 1718517881: {
                    l2 = 0x4288L ^ 0x8FA7E73D7C5909C3L;
                    continue block6;
                }
            }
            break;
        }
        while (true) {
            long l3;
            long l4;
            if ((l4 = (l3 = \u13e8 - (8388884502080741612L >>> "\u0000\u0000".length())) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) continue;
            if (l4 == (0x6223 ^ 0xFFFF9DDC)) break;
            l4 = 0x5FA3 ^ 0x3BA14BE9;
        }
        com.github.manolo8.darkbot.core.objects.Map map = this.hero.map;
        while (true) {
            long l5;
            long l6;
            if ((l6 = (l5 = \u13e8 - (7047722446160797492L >>> "\u0000\u0000".length())) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) continue;
            if (l6 == (0x31A1 ^ 0xFFFFCE5E)) break;
            l6 = 0x712C ^ 0xD2729DA9;
        }
        int n = map.id;
        while (true) {
            long l7;
            long l8;
            if ((l8 = (l7 = \u13e8 - (0x4201L ^ 0xC890FBD14783BC2EL)) == 0L ? 0 : (l7 < 0L ? -1 : 1)) == false) continue;
            if (l8 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                return this.getMsSinceKilledNpc(n);
            }
            l8 = 0x542D ^ 0x94E0D49F;
        }
    }

    /*
     * Unable to fully structure code
     */
    private Long getMsSinceKilledNpc(int mapId) {
        block26: {
            while (true) {
                if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (13882L ^ -9120713880925706900L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v0 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v0 = 17018 ^ 936623948;
            }
            v1 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl10
            block15: while (true) {
                v1 = v2 / (26143L ^ -565757483963653026L);
lbl10:
                // 2 sources

                switch ((int)v1) {
                    case -1648288999: {
                        v2 = 8031L ^ -6153294220756742435L;
                        continue block15;
                    }
                    case 531907554: {
                        v2 = 31260L ^ -8464657488574728369L;
                        continue block15;
                    }
                    case 739662467: {
                        v2 = 32562L ^ 626692586012485845L;
                        continue block15;
                    }
                    case 1415186628: {
                        break block15;
                    }
                }
                break;
            }
            if (!this.predictNpcSpawnConfig.ENABLE_TRACK_NPC_SPAWN_TIME) break block26;
            while (true) {
                if ((v3 = (cfr_temp_1 = MapCycleModule.\u13e8 - (1792628247336343232L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v3 == (28275 ^ -28276)) break;
                v3 = 28070 ^ -1604532610;
            }
            v4 = this.getMapIdToSubnameKillStartMS();
            while (true) {
                if ((v5 = (cfr_temp_2 = MapCycleModule.\u13e8 - (6040L ^ -4556811455222289066L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v5 == (30306 ^ 30307)) break;
                v5 = 28530 ^ 2020857399;
            }
            v6 = mapId;
            while (true) {
                if ((v7 = (cfr_temp_3 = MapCycleModule.\u13e8 - (30236L ^ -5831239865228301837L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v7 == (17327 ^ 17326)) break;
                v7 = 19901 ^ 1480281409;
            }
            if (!v4.containsKey(v6)) break block26;
            v8 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl45
            block19: while (true) {
                v8 = (8510L ^ 4138617702360533811L) / (19527L ^ -2045757022761944551L);
lbl45:
                // 2 sources

                switch ((int)v8) {
                    case 781204132: {
                        continue block19;
                    }
                    case 1415186628: {
                        break block19;
                    }
                }
                break;
            }
            v9 = this.getMapIdToSubnameKillStartMS();
            while (true) {
                if ((v10 = (cfr_temp_4 = MapCycleModule.\u13e8 - (-5974076386792423008L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v10 == (20245 ^ -20246)) break;
                v10 = 15572 ^ -591397856;
            }
            v11 = mapId;
            while (true) {
                if ((v12 = (cfr_temp_5 = MapCycleModule.\u13e8 - (31691L ^ -7435280269744287478L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                if (v12 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v12 = 2176 ^ -685134758;
            }
            subnameKillStartMS = v9.get(v11);
            if (subnameKillStartMS == null) {
                return null;
            }
            while (true) {
                if ((v13 = (cfr_temp_6 = MapCycleModule.\u13e8 - (21209L ^ 4648261127609708037L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                if (v13 == (27196 ^ -27197)) break;
                v13 = 11147 ^ -2140549293;
            }
            v14 = System.currentTimeMillis();
            v15 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl75
            block23: while (true) {
                v15 = (13021L ^ -2843552823600700461L) / (3821536907482456560L >>> "\u0000\u0000".length());
lbl75:
                // 2 sources

                switch ((int)v15) {
                    case 574608101: {
                        continue block23;
                    }
                    case 1415186628: {
                        break block23;
                    }
                }
                break;
            }
            v16 = v14 - subnameKillStartMS;
            while (true) {
                if ((v17 = (cfr_temp_7 = MapCycleModule.\u13e8 - (3984L ^ -9041952801142532259L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                if (v17 == (1981 ^ 1980)) break;
                v17 = 13066 ^ 623311378;
            }
            return v16;
        }
        return null;
    }

    /*
     * Unable to fully structure code
     */
    private Long getMsTillWithinNPCSpawnPeriod(int mapId) {
        v0 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl5
        block25: while (true) {
            v0 = v1 / (5987L ^ -5057723136861090777L);
lbl5:
            // 2 sources

            switch ((int)v0) {
                case -643301415: {
                    v1 = 7698L ^ -2630327578508915979L;
                    continue block25;
                }
                case 1415186628: {
                    break block25;
                }
                case 1841325027: {
                    v1 = 4067L ^ -3033906060138881796L;
                    continue block25;
                }
            }
            break;
        }
        timeSinceKilledMs = this.getMsSinceKilledNpc(mapId);
        if (timeSinceKilledMs == null) {
            return null;
        }
        while (true) {
            if ((v2 = (cfr_temp_0 = MapCycleModule.\u13e8 - (15832L ^ -1028171088944597369L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v2 == (13330 ^ -13331)) break;
            v2 = 5473 ^ 1252370252;
        }
        v3 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl26
        block27: while (true) {
            v3 = v4 / (27706L ^ 6958229465055123894L);
lbl26:
            // 2 sources

            switch ((int)v3) {
                case -1548102526: {
                    v4 = 4249L ^ 4637151333474969511L;
                    continue block27;
                }
                case 699838512: {
                    v4 = 31647L ^ -3832630991402727972L;
                    continue block27;
                }
                case 1415186628: {
                    break block27;
                }
            }
            break;
        }
        while (true) {
            if ((v5 = (cfr_temp_1 = MapCycleModule.\u13e8 - (6357L ^ 5996801754657312910L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v5 == (1000 ^ -1001)) break;
            v5 = 5413 ^ -1049972149;
        }
        v6 = this.predictNpcSpawnConfig.NPC_SUBNAME_SPAWN_TIME_MINS;
        while (true) {
            if ((v7 = (cfr_temp_2 = MapCycleModule.\u13e8 - (23623L ^ 4700410811947276439L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v7 == (10226 ^ -10227)) break;
            v7 = 1877 ^ 899135372;
        }
        v8 = TimeUnit.MINUTES.toMillis(v6);
        v9 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl51
        block30: while (true) {
            v9 = (-45253287110321812L >>> "\u0000\u0000".length()) / (23254L ^ -1934961572248708868L);
lbl51:
            // 2 sources

            switch ((int)v9) {
                case 1363393221: {
                    continue block30;
                }
                case 1415186628: {
                    break block30;
                }
            }
            break;
        }
        v10 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl60
        block31: while (true) {
            v10 = v11 / (3252L ^ -9099239904234632398L);
lbl60:
            // 2 sources

            switch ((int)v10) {
                case 911959200: {
                    v11 = 639L ^ 7896426851275604169L;
                    continue block31;
                }
                case 1415186628: {
                    break block31;
                }
                case 2038400448: {
                    v11 = 12946L ^ -6238801103250685567L;
                    continue block31;
                }
            }
            break;
        }
        while (true) {
            if ((v12 = (cfr_temp_3 = MapCycleModule.\u13e8 - (23101L ^ 5766692232215857731L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v12 == (28168 ^ -28169)) break;
            v12 = 27954 ^ -697649581;
        }
        v13 = this.predictNpcSpawnConfig.PREPARE_FOR_SPAWN_PERIOD_SECONDS;
        v14 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl79
        block33: while (true) {
            v14 = v15 / (-2573595057745749136L >>> "\u0000\u0000".length());
lbl79:
            // 2 sources

            switch ((int)v14) {
                case -669531443: {
                    v15 = 16161L ^ -3972734843645565231L;
                    continue block33;
                }
                case -47719454: {
                    v15 = 4959438235056828480L >>> "\u0000\u0000".length();
                    continue block33;
                }
                case 165516541: {
                    v15 = 2619532372037137376L >>> "\u0000\u0000".length();
                    continue block33;
                }
                case 1415186628: {
                    break block33;
                }
            }
            break;
        }
        pool = v8 - TimeUnit.SECONDS.toMillis(v13);
        while (true) {
            if ((v16 = (cfr_temp_4 = MapCycleModule.\u13e8 - (8533L ^ -767253166573138612L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v16 == (32172 ^ -32173)) break;
            v16 = 27150 ^ 1799166509;
        }
        v17 = pool - timeSinceKilledMs;
        while (true) {
            if ((v18 = (cfr_temp_5 = MapCycleModule.\u13e8 - (3429796101528350756L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
            if (v18 == (25932 ^ -25933)) break;
            v18 = 12397 ^ 769830079;
        }
        return v17;
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public Long getMsTillWithinNPCSpawnPeriod() {
        while (true) {
            if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (-5540427562646513008L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v0 == (12709 ^ -12710)) break;
            v0 = 24425 ^ -1710427825;
        }
        v1 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl11
        block12: while (true) {
            v1 = v2 / (30210L ^ 3812530556276649332L);
lbl11:
            // 2 sources

            switch ((int)v1) {
                case -640994654: {
                    v2 = 13507L ^ 772313579826451636L;
                    continue block12;
                }
                case -189906352: {
                    v2 = 14144L ^ 5915787179543445927L;
                    continue block12;
                }
                case 1415186628: {
                    break block12;
                }
            }
            break;
        }
        v3 = this.hero.map;
        v4 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl25
        block13: while (true) {
            v4 = v5 / (15479L ^ -6798074909541132917L);
lbl25:
            // 2 sources

            switch ((int)v4) {
                case -802542812: {
                    v5 = 737634682323240016L >>> "\u0000\u0000".length();
                    continue block13;
                }
                case -290571383: {
                    v5 = 20856L ^ -2038515339666603191L;
                    continue block13;
                }
                case 1217697946: {
                    v5 = 9066804123875789368L >>> "\u0000\u0000".length();
                    continue block13;
                }
                case 1415186628: {
                    break block13;
                }
            }
            break;
        }
        v6 = v3.id;
        while (true) {
            if ((v7 = (cfr_temp_1 = MapCycleModule.\u13e8 - (2416L ^ -1742348845156159288L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v7 == (19263 ^ -19264)) break;
            v7 = 6921 ^ -732472830;
        }
        return this.getMsTillWithinNPCSpawnPeriod(v6);
    }

    /*
     * Enabled aggressive block sorting
     */
    private boolean withinPrepareForNPCSpawnPeriod(long depthWithinMs) {
        int n;
        block8: {
            Long msTillWithinNpcSpawnPeriod;
            while (true) {
                long l;
                long l2;
                if ((l2 = (l = \u13e8 - (-7467338721549720876L >>> "\u0000\u0000".length())) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (l2 == (0x7B76 ^ 0xFFFF8489)) {
                    msTillWithinNpcSpawnPeriod = this.getMsTillWithinNPCSpawnPeriod();
                    if (msTillWithinNpcSpawnPeriod != null) {
                        break;
                    }
                    break block8;
                }
                l2 = 0x4B2 ^ 0xC5124ADF;
            }
            while (true) {
                long l;
                long l3;
                if ((l3 = (l = \u13e8 - (0x409L ^ 0x8D015D19F50C3DB9L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (l3 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                    if (msTillWithinNpcSpawnPeriod <= -depthWithinMs) {
                        break;
                    }
                    break block8;
                }
                l3 = 0x1147 ^ 0x650818DE;
            }
            n = 0x203F ^ 0x203E;
            return n != 0;
        }
        n = "".length() >>> "\u0000\u0000".length();
        return n != 0;
    }

    private boolean withinPrepareForNPCSpawnPeriod() {
        long l = 0L >>> "\u0000\u0000".length();
        while (true) {
            long l2;
            long l3;
            if ((l3 = (l2 = \u13e8 - (0x57CFL ^ 0xFDE8B0BFE6F94196L)) == 0L ? 0 : (l2 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l3 == (0x6660 ^ 0xFFFF999F)) break;
            l3 = 0x4C42 ^ 0xC73C384B;
        }
        return this.withinPrepareForNPCSpawnPeriod(l);
    }

    /*
     * Unable to fully structure code
     */
    private boolean shootDuringWaitPeriod() {
        block15: {
            while (true) {
                if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (20814L ^ -8995039738964551675L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (v0 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v0 = 9926 ^ -1959723146;
            }
            if (!this.isUnsafe()) break block15;
            v1 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl12
            block12: while (true) {
                v1 = v2 / (24093L ^ -3750234664442782529L);
lbl12:
                // 2 sources

                switch ((int)v1) {
                    case -1786286227: {
                        v2 = 9935L ^ 8107582043353121349L;
                        continue block12;
                    }
                    case 994099613: {
                        v2 = -5421564678996422672L >>> "\u0000\u0000".length();
                        continue block12;
                    }
                    case 1415186628: {
                        break block12;
                    }
                }
                break;
            }
            v3 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl25
            block13: while (true) {
                v3 = v4 / (27327L ^ -1327330119767540254L);
lbl25:
                // 2 sources

                switch ((int)v3) {
                    case -1504886905: {
                        v4 = 6105L ^ -780897221481117772L;
                        continue block13;
                    }
                    case -1161212289: {
                        v4 = 18792L ^ -568158036758530081L;
                        continue block13;
                    }
                    case 22521135: {
                        v4 = 1905238638243861580L >>> "\u0000\u0000".length();
                        continue block13;
                    }
                    case 1415186628: {
                        break block13;
                    }
                }
                break;
            }
            return (boolean)(this.mapCycleSafetyConfig.WAIT_FOR_NPC_SUBNAME_IF_UNSAFE_AFTER_KILL == false ? 703 ^ 702 : 14373 ^ 14373);
        }
        return (boolean)(4823 ^ 4822);
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private boolean onlyShootDuringWaitPeriod() {
        block59: {
            block58: {
                v0 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl5
                block35: while (true) {
                    v0 = (6669L ^ -7449821603662505298L) / (26249L ^ -8109630223715505569L);
lbl5:
                    // 2 sources

                    switch ((int)v0) {
                        case -1224833854: {
                            continue block35;
                        }
                        case 1415186628: {
                            break block35;
                        }
                    }
                    break;
                }
                v1 = System.currentTimeMillis();
                v2 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl15
                block36: while (true) {
                    v2 = v3 / (32303L ^ 8884798946497060405L);
lbl15:
                    // 2 sources

                    switch ((int)v2) {
                        case -466743479: {
                            v3 = 27704L ^ -283116211619043585L;
                            continue block36;
                        }
                        case 1148104069: {
                            v3 = 21197L ^ -6869243205575666679L;
                            continue block36;
                        }
                        case 1415186628: {
                            break block36;
                        }
                        case 1460817577: {
                            v3 = 14501L ^ 8256383681914618798L;
                            continue block36;
                        }
                    }
                    break;
                }
                if (v1 - this.onlyShootDuringWaitTicksPeriodStartMilis > 4000L >>> "\u0000\u0000".length()) {
                    while (true) {
                        if ((v4 = (cfr_temp_0 = MapCycleModule.\u13e8 - (8005L ^ 8294656464913418087L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                        if (v4 == (11506 ^ -11507)) break;
                        v4 = 21480 ^ 1631502849;
                    }
                    v5 = System.currentTimeMillis();
                    while (true) {
                        if ((v6 = (cfr_temp_1 = MapCycleModule.\u13e8 - (-3899001768555812188L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                        if (v6 != (5340 ^ -5341)) {
                            v6 = 1433 ^ 632252124;
                            continue;
                        }
                        break;
                    }
                } else {
                    while (true) {
                        if ((v7 = (cfr_temp_2 = MapCycleModule.\u13e8 - (21453L ^ 3123381058947563662L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                        if (v7 == (2539 ^ -2540)) break;
                        v7 = 14755 ^ -624904093;
                    }
                    return this.onlyShootDuringWaitPeriod_cachedRet;
                }
                this.onlyShootDuringWaitTicksPeriodStartMilis = v5;
                while (true) {
                    if ((v8 = (cfr_temp_3 = MapCycleModule.\u13e8 - (562754222448979504L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                    if (v8 == (11743 ^ -11744)) break;
                    v8 = 13997 ^ 1799107952;
                }
                if (this.isWaitingForSafetyCloak()) break block58;
                v9 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl57
                block41: while (true) {
                    v9 = (12612L ^ 4100062545289513805L) / (14060L ^ 5814901192207134577L);
lbl57:
                    // 2 sources

                    switch ((int)v9) {
                        case 1415186628: {
                            break block41;
                        }
                        case 2092061859: {
                            continue block41;
                        }
                    }
                    break;
                }
                v10 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl66
                block42: while (true) {
                    v10 = v11 / (18578L ^ 4958259955986235991L);
lbl66:
                    // 2 sources

                    switch ((int)v10) {
                        case -1654734886: {
                            v11 = 27918L ^ 8109003496670765254L;
                            continue block42;
                        }
                        case 1379937536: {
                            v11 = 5392L ^ 8568424892176889723L;
                            continue block42;
                        }
                        case 1415186628: {
                            break block42;
                        }
                    }
                    break;
                }
                if (!this.mapCycleSafetyConfig.WAIT_FOR_NPC_SUBNAME_IF_UNSAFE) break block59;
                while (true) {
                    if ((v12 = (cfr_temp_4 = MapCycleModule.\u13e8 - (18473L ^ 6228059609359907153L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                    if (v12 == (19159 ^ -19160)) break;
                    v12 = 3367 ^ -902665469;
                }
                if (!this.isUnsafe()) break block59;
            }
            v13 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
            while (true) {
                if ((v14 = (cfr_temp_5 = MapCycleModule.\u13e8 - (-3575383818562905864L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                if (v14 == (17609 ^ -17610)) break;
                v14 = 8832 ^ -1994572937;
            }
            this.onlyShootDuringWaitPeriod_cachedRet = v13;
            return "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        }
        v15 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl96
        block45: while (true) {
            v15 = v16 / (10911L ^ 9131546376021050570L);
lbl96:
            // 2 sources

            switch ((int)v15) {
                case -1695121451: {
                    v16 = -4384516079579890380L >>> "\u0000\u0000".length();
                    continue block45;
                }
                case 973519078: {
                    v16 = 8824L ^ -5742239232069277234L;
                    continue block45;
                }
                case 1415186628: {
                    break block45;
                }
            }
            break;
        }
        while (true) {
            if ((v17 = (cfr_temp_6 = MapCycleModule.\u13e8 - (29279L ^ -5065152484334110903L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
            if (v17 == (9390 ^ 9391)) break;
            v17 = 25776 ^ 1384176471;
        }
        if (!this.predictNpcSpawnConfig.DISABLE_SHOOTING_WHEN_WITHIN_PREDICTED_SPAWN_PERIOD) ** GOTO lbl-1000
        v18 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl115
        block47: while (true) {
            v18 = v19 / (5183L ^ 1766913393575055739L);
lbl115:
            // 2 sources

            switch ((int)v18) {
                case 289437497: {
                    v19 = 22354L ^ -6473532268581705329L;
                    continue block47;
                }
                case 524220373: {
                    v19 = 20340L ^ 8080246100200972707L;
                    continue block47;
                }
                case 1415186628: {
                    break block47;
                }
                case 1967801419: {
                    v19 = 5833L ^ 6941029191774533627L;
                    continue block47;
                }
            }
            break;
        }
        if (this.withinPrepareForNPCSpawnPeriod()) {
            v20 = 6735 ^ 6734;
        } else lbl-1000:
        // 2 sources

        {
            v20 = 28136 ^ 28136;
        }
        shoot = v20;
        v21 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl136
        block48: while (true) {
            v21 = v22 / (1150L ^ 2520067652685789273L);
lbl136:
            // 2 sources

            switch ((int)v21) {
                case -621303499: {
                    v22 = 19931L ^ -1126171251315066282L;
                    continue block48;
                }
                case 1415186628: {
                    break block48;
                }
                case 1437865814: {
                    v22 = 16510L ^ -3790720794320838475L;
                    continue block48;
                }
            }
            break;
        }
        this.onlyShootDuringWaitPeriod_cachedRet = shoot;
        return this.onlyShootDuringWaitPeriod_cachedRet;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private void timestampSubnameKill(int currentMapId, Long offsetMs) {
        Long l;
        if (offsetMs == null) {
            l = null;
        } else {
            while (true) {
                long l2;
                long l3;
                if ((l3 = (l2 = \u13e8 - (8821183805497711860L >>> "\u0000\u0000".length())) == 0L ? 0 : (l2 < 0L ? -1 : 1)) == false) continue;
                if (l3 == (0x79D2 ^ 0xFFFF862D)) break;
                l3 = 0x9B1 ^ 0x648CD13E;
            }
            long l4 = System.currentTimeMillis();
            while (true) {
                long l5;
                long l6;
                if ((l6 = (l5 = \u13e8 - (0x75FL ^ 0xE0D0977B2FFD8807L)) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) continue;
                if (l6 == (0x25A3 ^ 0xFFFFDA5C)) break;
                l6 = 0x178A ^ 0x4D228511;
            }
            long l7 = l4 + offsetMs;
            while (true) {
                long l8;
                long l9;
                if ((l9 = (l8 = \u13e8 - (-7230172226779637064L >>> "\u0000\u0000".length())) == 0L ? 0 : (l8 < 0L ? -1 : 1)) == false) continue;
                if (l9 == (0x664C ^ 0xFFFF99B3)) {
                    l = l7;
                    break;
                }
                l9 = 0x172F ^ 0x9B4CA184;
            }
        }
        Long value = l;
        long l10 = \u13e8;
        boolean bl = true;
        block9: while (true) {
            long l11;
            if (!bl || (bl = false) || !true) {
                l10 = l11 / (0x205FL ^ 0x56BBC9F3B3E09CB2L);
            }
            switch ((int)l10) {
                case -2083966517: {
                    l11 = 0x2038L ^ 0x9FDDD1AEFC5A67EFL;
                    continue block9;
                }
                case 1415186628: {
                    break block9;
                }
                case 1520816558: {
                    l11 = 0x3F9AL ^ 0x4B6EE77054954D81L;
                    continue block9;
                }
                case 1921613848: {
                    l11 = 0x2920L ^ 0x60C9BC83C445CB31L;
                    continue block9;
                }
            }
            break;
        }
        HashMap<Integer, Long> hashMap = this.getMapIdToSubnameKillStartMS();
        while (true) {
            long l12;
            long l13;
            if ((l13 = (l12 = \u13e8 - (0x4F28L ^ 0x82C435E54EA9B09BL)) == 0L ? 0 : (l12 < 0L ? -1 : 1)) == false) continue;
            if (l13 == (0xA82 ^ 0xA83)) break;
            l13 = 0x4AD3 ^ 0xA7154DAE;
        }
        Integer n = currentMapId;
        while (true) {
            long l14;
            long l15;
            if ((l15 = (l14 = \u13e8 - (0xE94L ^ 0xBE2A119700FCA796L)) == 0L ? 0 : (l14 < 0L ? -1 : 1)) == false) continue;
            if (l15 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                hashMap.put(n, value);
                return;
            }
            l15 = 0x370 ^ 0xC5951D58;
        }
    }

    /*
     * Unable to fully structure code
     */
    private void lostLockTimeStampNpcKilled(int currentMap) {
        block22: {
            v0 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl5
            block13: while (true) {
                v0 = (2577808832698660396L >>> "\u0000\u0000".length()) / (-2265363105508108440L >>> "\u0000\u0000".length());
lbl5:
                // 2 sources

                switch ((int)v0) {
                    case -186534819: {
                        continue block13;
                    }
                    case 1415186628: {
                        break block13;
                    }
                }
                break;
            }
            while (true) {
                if ((v1 = (cfr_temp_0 = MapCycleModule.\u13e8 - (1886L ^ 5471587927753338122L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v1 == (20958 ^ -20959)) break;
                v1 = 8916 ^ -662929711;
            }
            trackingOffset = this.predictNpcSpawnConfig.ON_DEATH_TRACK_NPC_OFFSET_SECONDS;
            if (trackingOffset < 0) {
                while (true) {
                    if ((v2 = (cfr_temp_1 = MapCycleModule.\u13e8 - (32446L ^ 7834491964746717335L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                    if (v2 == (16015 ^ -16016)) {
                        this.timestampSubnameKill(currentMap, null);
                        break block22;
                    }
                    v2 = 12116 ^ 80092107;
                }
            }
            while (true) {
                if ((v3 = (cfr_temp_2 = MapCycleModule.\u13e8 - (25952L ^ -1854262839668286958L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v3 == (25958 ^ -25959)) break;
                v3 = 9064 ^ 4767931;
            }
            v4 = trackingOffset;
            v5 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl34
            block17: while (true) {
                v5 = v6 / (26654L ^ 5011905854599465001L);
lbl34:
                // 2 sources

                switch ((int)v5) {
                    case 874189967: {
                        v6 = -1263873615245854800L >>> "\u0000\u0000".length();
                        continue block17;
                    }
                    case 1415186628: {
                        break block17;
                    }
                    case 1679627261: {
                        v6 = 28442L ^ 120159627660058299L;
                        continue block17;
                    }
                }
                break;
            }
            v7 = TimeUnit.SECONDS.toMillis(v4);
            while (true) {
                if ((v8 = (cfr_temp_3 = MapCycleModule.\u13e8 - (27249L ^ -6920058038572505913L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v8 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v8 = 14438 ^ 1166919486;
            }
            v9 = v7;
            v10 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl54
            block19: while (true) {
                v10 = (1780L ^ 7695020427311417626L) / (14738L ^ -8546047042275086837L);
lbl54:
                // 2 sources

                switch ((int)v10) {
                    case 1415186628: {
                        break block19;
                    }
                    case 2051480861: {
                        continue block19;
                    }
                }
                break;
            }
            this.timestampSubnameKill(currentMap, v9);
        }
    }

    /*
     * Unable to fully structure code
     */
    private HashMap<Integer, Long> getMapIdToSubnameKillStartMS() {
        block31: {
            while (true) {
                if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (4987851392386725700L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v0 == (25698 ^ -25699)) break;
                v0 = 1516641748 >>> "\u0000\u0000".length();
            }
            if (PersistantStoragePathFinder.getInstance() != null) break block31;
            v1 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl11
            block24: while (true) {
                v1 = v2 / (19397L ^ -7339775976061833334L);
lbl11:
                // 2 sources

                switch ((int)v1) {
                    case -943045880: {
                        v2 = 21325L ^ 6000962086401366492L;
                        continue block24;
                    }
                    case 1415186628: {
                        break block24;
                    }
                    case 1948101565: {
                        v2 = 434L ^ 4940369060976633448L;
                        continue block24;
                    }
                }
                break;
            }
            v3 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl24
            block25: while (true) {
                v3 = v4 / (4156L ^ -1783083498199014939L);
lbl24:
                // 2 sources

                switch ((int)v3) {
                    case 310133382: {
                        v4 = 7415L ^ -9181991123743390264L;
                        continue block25;
                    }
                    case 750176183: {
                        v4 = 24551L ^ -8739807379566859293L;
                        continue block25;
                    }
                    case 834764097: {
                        v4 = -2652619751232894672L >>> "\u0000\u0000".length();
                        continue block25;
                    }
                    case 1415186628: {
                        break block25;
                    }
                }
                break;
            }
            this.mapIdToSubnameKillStartMS.clear();
            v5 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl41
            block26: while (true) {
                v5 = v6 / (950L ^ 7419060839715241059L);
lbl41:
                // 2 sources

                switch ((int)v5) {
                    case -2015324038: {
                        v6 = 23228L ^ 5139334950902125471L;
                        continue block26;
                    }
                    case -1553621428: {
                        v6 = 16862L ^ -1431135249825293074L;
                        continue block26;
                    }
                    case 340733766: {
                        v6 = 18015L ^ -7585105085689062028L;
                        continue block26;
                    }
                    case 1415186628: {
                        break block26;
                    }
                }
                break;
            }
            return this.mapIdToSubnameKillStartMS;
        }
        while (true) {
            if ((v7 = (cfr_temp_1 = MapCycleModule.\u13e8 - (17779L ^ -7325701670051234194L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v7 == (8897 ^ 8896)) break;
            v7 = 7530 ^ -1926695097;
        }
        v8 = PersistantStoragePathFinder.getInstance();
        v9 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl65
        block28: while (true) {
            v9 = v10 / (19562L ^ 4701457494749365494L);
lbl65:
            // 2 sources

            switch ((int)v9) {
                case -1602912660: {
                    v10 = 26032L ^ -7807552018799077900L;
                    continue block28;
                }
                case -552848394: {
                    v10 = 23441L ^ 7565896887936604927L;
                    continue block28;
                }
                case -459918169: {
                    v10 = 5555562347270309208L >>> "\u0000\u0000".length();
                    continue block28;
                }
                case 1415186628: {
                    break block28;
                }
            }
            break;
        }
        v11 = v8.getPersistentState();
        while (true) {
            if ((v12 = (cfr_temp_2 = MapCycleModule.\u13e8 - (16410L ^ -2443844135383791999L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v12 == (4854 ^ -4855)) break;
            v12 = 15147 ^ 1385501594;
        }
        v13 = v11.MAP_CYCLE;
        while (true) {
            if ((v14 = (cfr_temp_3 = MapCycleModule.\u13e8 - (25154L ^ -4552477347581049049L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v14 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v14 = 24840 ^ 618316171;
        }
        return v13.MAP_ID_TO_SUBNAME_KILL_START_MS;
    }

    /*
     * Unable to fully structure code
     */
    private void checkMapSwitch() {
        block259: {
            block254: {
                block255: {
                    block258: {
                        block257: {
                            block256: {
                                block253: {
                                    block251: {
                                        block252: {
                                            block250: {
                                                block249: {
                                                    block248: {
                                                        while (true) {
                                                            if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (30888L ^ -5164677399569985549L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                                                            if (v0 == (8090 ^ 8091)) break;
                                                            v0 = 12323 ^ -1543083874;
                                                        }
                                                        while (true) {
                                                            if ((v1 = (cfr_temp_1 = MapCycleModule.\u13e8 - (22255L ^ 9122468357654656116L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                                                            if (v1 == (21702 ^ -21703)) break;
                                                            v1 = 22569 ^ -1601959525;
                                                        }
                                                        maxMapDeathsBeforeSwitch = this.deathCountConditionConfig.MAX_MAP_DEATHS_BEFORE_SWITCH;
                                                        switchOnMaxMapDeathsEnabled = maxMapDeathsBeforeSwitch != 0 ? "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length() : 31440 ^ 31440;
                                                        v2 = MapCycleModule.\u13e8;
                                                        if (true) ** GOTO lbl17
                                                        block171: while (true) {
                                                            v2 = (9598L ^ 6383131707091867966L) / (28875L ^ 1330225410729717474L);
lbl17:
                                                            // 2 sources

                                                            switch ((int)v2) {
                                                                case 1286985948: {
                                                                    continue block171;
                                                                }
                                                                case 1415186628: {
                                                                    break block171;
                                                                }
                                                            }
                                                            break;
                                                        }
                                                        v3 = MapCycleModule.\u13e8;
                                                        if (true) ** GOTO lbl26
                                                        block172: while (true) {
                                                            v3 = v4 / (8063L ^ -7385346423209629256L);
lbl26:
                                                            // 2 sources

                                                            switch ((int)v3) {
                                                                case 1088595242: {
                                                                    v4 = 21798L ^ -7970921244371427866L;
                                                                    continue block172;
                                                                }
                                                                case 1415186628: {
                                                                    break block172;
                                                                }
                                                                case 1951711227: {
                                                                    v4 = 31832L ^ -4201861695797520509L;
                                                                    continue block172;
                                                                }
                                                            }
                                                            break;
                                                        }
                                                        v5 = this.hero.map;
                                                        v6 = MapCycleModule.\u13e8;
                                                        if (true) ** GOTO lbl40
                                                        block173: while (true) {
                                                            v6 = (9992L ^ 8603290922734995213L) / (618487967669950728L >>> "\u0000\u0000".length());
lbl40:
                                                            // 2 sources

                                                            switch ((int)v6) {
                                                                case 1395051716: {
                                                                    continue block173;
                                                                }
                                                                case 1415186628: {
                                                                    break block173;
                                                                }
                                                            }
                                                            break;
                                                        }
                                                        currentMap = v5.id;
                                                        if (switchOnMaxMapDeathsEnabled == 0) break block248;
                                                        v7 = MapCycleModule.\u13e8;
                                                        if (true) ** GOTO lbl51
                                                        block174: while (true) {
                                                            v7 = v8 / (7257L ^ 8800976863981852188L);
lbl51:
                                                            // 2 sources

                                                            switch ((int)v7) {
                                                                case -463450323: {
                                                                    v8 = 12396L ^ 2643301758218104787L;
                                                                    continue block174;
                                                                }
                                                                case -422044700: {
                                                                    v8 = 31027L ^ 5973976633549140765L;
                                                                    continue block174;
                                                                }
                                                                case 334311466: {
                                                                    v8 = 3261L ^ -7937950589207553894L;
                                                                    continue block174;
                                                                }
                                                                case 1415186628: {
                                                                    break block174;
                                                                }
                                                            }
                                                            break;
                                                        }
                                                        while (true) {
                                                            if ((v9 = (cfr_temp_2 = MapCycleModule.\u13e8 - (3521L ^ -8497628317067382432L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                                                            if (v9 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                                                            v9 = -459766256 >>> "\u0000\u0000".length();
                                                        }
                                                        if (this.deathsOnCurrentMap.getMapId() == currentMap) break block248;
                                                        v10 = MapCycleModule.\u13e8;
                                                        if (true) ** GOTO lbl73
                                                        block176: while (true) {
                                                            v10 = v11 / (14363L ^ -7443119935920564068L);
lbl73:
                                                            // 2 sources

                                                            switch ((int)v10) {
                                                                case -522841112: {
                                                                    v11 = 25910L ^ 2732243284127494722L;
                                                                    continue block176;
                                                                }
                                                                case 190062632: {
                                                                    v11 = 1183L ^ -2376842496332510546L;
                                                                    continue block176;
                                                                }
                                                                case 1415186628: {
                                                                    break block176;
                                                                }
                                                            }
                                                            break;
                                                        }
                                                        while (true) {
                                                            if ((v12 = (cfr_temp_3 = MapCycleModule.\u13e8 - (9737L ^ 5048442871157439970L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                                                            if (v12 == (29822 ^ -29823)) {
                                                                this.deathsOnCurrentMap.resetChangeMapId(currentMap);
                                                                break;
                                                            }
                                                            v12 = 5638 ^ -38885228;
                                                        }
                                                    }
                                                    if (currentMap == (6301 ^ -6302)) {
                                                        while (true) {
                                                            if ((v13 = (cfr_temp_4 = MapCycleModule.\u13e8 - (8875L ^ -6701197854110655040L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                                                            if (v13 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                                                            v13 = -277756864 >>> "\u0000\u0000".length();
                                                        }
                                                        this.markAllLogsAsRead();
                                                        while (true) {
                                                            if ((v14 = (cfr_temp_5 = MapCycleModule.\u13e8 - (12594L ^ 1635006395333386859L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                                                            if (v14 == (22188 ^ -22189)) break;
                                                            v14 = 165698772 >>> "\u0000\u0000".length();
                                                        }
                                                        this.markLatestDeathsKnown();
                                                        return;
                                                    }
                                                    while (true) {
                                                        if ((v15 = (cfr_temp_6 = MapCycleModule.\u13e8 - (17666L ^ -5261824257392221868L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                                                        if (v15 == (8037 ^ 8036)) break;
                                                        v15 = 18597 ^ 874398164;
                                                    }
                                                    while (true) {
                                                        if ((v16 = (cfr_temp_7 = MapCycleModule.\u13e8 - (5193L ^ 8006824113598061868L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                                                        if (v16 == (8945 ^ -8946)) break;
                                                        v16 = -891442764 >>> "\u0000\u0000".length();
                                                    }
                                                    v17 = this.mainConfig.GENERAL;
                                                    while (true) {
                                                        if ((v18 = (cfr_temp_8 = MapCycleModule.\u13e8 - (24620L ^ -7381483924393454324L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                                                        if (v18 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                                                        v18 = 1942756632 >>> "\u0000\u0000".length();
                                                    }
                                                    if (v17.WORKING_MAP == currentMap) break block249;
                                                    v19 = MapCycleModule.\u13e8;
                                                    if (true) ** GOTO lbl125
                                                    block183: while (true) {
                                                        v19 = v20 / (23569L ^ 5342284321780643626L);
lbl125:
                                                        // 2 sources

                                                        switch ((int)v19) {
                                                            case 189426555: {
                                                                v20 = 29367L ^ -8029118491191689725L;
                                                                continue block183;
                                                            }
                                                            case 958661101: {
                                                                v20 = 3554L ^ -72491337599553237L;
                                                                continue block183;
                                                            }
                                                            case 1240296165: {
                                                                v20 = 15293L ^ 5685851025333804919L;
                                                                continue block183;
                                                            }
                                                            case 1415186628: {
                                                                break block183;
                                                            }
                                                        }
                                                        break;
                                                    }
                                                    this.markAllLogsAsRead();
                                                    v21 = MapCycleModule.\u13e8;
                                                    if (true) ** GOTO lbl142
                                                    block184: while (true) {
                                                        v21 = v22 / (29875L ^ -3461422740407895028L);
lbl142:
                                                        // 2 sources

                                                        switch ((int)v21) {
                                                            case -1186658986: {
                                                                v22 = 5772132775346008796L >>> "\u0000\u0000".length();
                                                                continue block184;
                                                            }
                                                            case 344669255: {
                                                                v22 = 13588L ^ 1624035374950961246L;
                                                                continue block184;
                                                            }
                                                            case 1415186628: {
                                                                break block184;
                                                            }
                                                        }
                                                        break;
                                                    }
                                                    this.markLatestDeathsKnown();
                                                    return;
                                                }
                                                while (true) {
                                                    if ((v23 = (cfr_temp_9 = MapCycleModule.\u13e8 - (588L ^ -384521123324654194L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
                                                    if (v23 == (6534 ^ -6535)) break;
                                                    v23 = 218289296 >>> "\u0000\u0000".length();
                                                }
                                                if (!this.awaitingRevive) break block250;
                                                v24 = MapCycleModule.\u13e8;
                                                if (true) ** GOTO lbl164
                                                block186: while (true) {
                                                    v24 = v25 / (31488L ^ 819870798169089813L);
lbl164:
                                                    // 2 sources

                                                    switch ((int)v24) {
                                                        case -92538372: {
                                                            v25 = 19327L ^ -762297151287806660L;
                                                            continue block186;
                                                        }
                                                        case 182199297: {
                                                            v25 = 28450L ^ -767115646384531385L;
                                                            continue block186;
                                                        }
                                                        case 1415186628: {
                                                            break block186;
                                                        }
                                                    }
                                                    break;
                                                }
                                                this.markAllLogsAsRead();
                                                while (true) {
                                                    if ((v26 = (cfr_temp_10 = MapCycleModule.\u13e8 - (21173L ^ 5843997081208601483L)) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
                                                    if (v26 == (4023 ^ -4024)) break;
                                                    v26 = 27845 ^ 1137831996;
                                                }
                                                this.markLatestDeathsKnown();
                                                while (true) {
                                                    if ((v27 = (cfr_temp_11 = MapCycleModule.\u13e8 - (20531L ^ -7658657379722450915L)) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
                                                    if (v27 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                                                    v27 = 30051 ^ 2059721899;
                                                }
                                                if (!this.hasRevived()) {
                                                    return;
                                                }
                                                v28 = MapCycleModule.\u13e8;
                                                if (true) ** GOTO lbl191
                                                block189: while (true) {
                                                    v28 = v29 / (2004L ^ 4150807161935014315L);
lbl191:
                                                    // 2 sources

                                                    switch ((int)v28) {
                                                        case -1388804260: {
                                                            v29 = 13662L ^ 6408022377908012641L;
                                                            continue block189;
                                                        }
                                                        case 409776440: {
                                                            v29 = 6594932438496417948L >>> "\u0000\u0000".length();
                                                            continue block189;
                                                        }
                                                        case 1415186628: {
                                                            break block189;
                                                        }
                                                    }
                                                    break;
                                                }
                                                this.awaitingRevive = 25548 ^ 25548;
                                            }
                                            while (true) {
                                                if ((v30 = (cfr_temp_12 = MapCycleModule.\u13e8 - (16329L ^ -6160537777282776660L)) == 0L ? 0 : (cfr_temp_12 < 0L ? -1 : 1)) == false) continue;
                                                if (v30 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                                                v30 = 10560 ^ 437455603;
                                            }
                                            if (!this.progressAfterKillSeconds(currentMap)) break block251;
                                            while (true) {
                                                if ((v31 = (cfr_temp_13 = MapCycleModule.\u13e8 - (31242L ^ 8832493302185459533L)) == 0L ? 0 : (cfr_temp_13 < 0L ? -1 : 1)) == false) continue;
                                                if (v31 == (8646 ^ -8647)) break;
                                                v31 = 27621 ^ 1459539494;
                                            }
                                            if (this.nextMapIdAfterWaitKillPeriod == null) break block252;
                                            while (true) {
                                                if ((v32 = (cfr_temp_14 = MapCycleModule.\u13e8 - (7771178594745732852L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_14 < 0L ? -1 : 1)) == false) continue;
                                                if (v32 == (11626 ^ -11627)) break;
                                                v32 = 11076 ^ 90337138;
                                            }
                                            v33 = MapCycleModule.\u13e8;
                                            if (true) ** GOTO lbl223
                                            block193: while (true) {
                                                v33 = v34 / (19703L ^ 3281277866974498349L);
lbl223:
                                                // 2 sources

                                                switch ((int)v33) {
                                                    case -1096211515: {
                                                        v34 = 9465L ^ -3804902841030419339L;
                                                        continue block193;
                                                    }
                                                    case -590272528: {
                                                        v34 = 28199L ^ -4628759263350553494L;
                                                        continue block193;
                                                    }
                                                    case 1210067059: {
                                                        v34 = -6363933115453584260L >>> "\u0000\u0000".length();
                                                        continue block193;
                                                    }
                                                    case 1415186628: {
                                                        break block193;
                                                    }
                                                }
                                                break;
                                            }
                                            v35 = this.nextMapIdAfterWaitKillPeriod;
                                            v36 = MapCycleModule.\u13e8;
                                            if (true) ** GOTO lbl240
                                            block194: while (true) {
                                                v36 = v37 / (-6717305274982280420L >>> "\u0000\u0000".length());
lbl240:
                                                // 2 sources

                                                switch ((int)v36) {
                                                    case -1824726908: {
                                                        v37 = 6550624390291458520L >>> "\u0000\u0000".length();
                                                        continue block194;
                                                    }
                                                    case -1250052704: {
                                                        v37 = 17461L ^ 8615514253739791032L;
                                                        continue block194;
                                                    }
                                                    case 1415186628: {
                                                        break block194;
                                                    }
                                                    case 1420515644: {
                                                        v37 = 14211L ^ 2208848595215441398L;
                                                        continue block194;
                                                    }
                                                }
                                                break;
                                            }
                                            this.hasKilledBehemoth(currentMap, v35);
                                        }
                                        return;
                                    }
                                    while (true) {
                                        if ((v38 = (cfr_temp_15 = MapCycleModule.\u13e8 - (17441L ^ 7886282477221392399L)) == 0L ? 0 : (cfr_temp_15 < 0L ? -1 : 1)) == false) continue;
                                        if (v38 == ("\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() ^ -38)) break;
                                        v38 = 14843 ^ 1894118840;
                                    }
                                    if (this.decrementWaitTicksOnRefreshableMap == null) break block253;
                                    v39 = MapCycleModule.\u13e8;
                                    if (true) ** GOTO lbl267
                                    block196: while (true) {
                                        v39 = v40 / (12146L ^ -1605755276753181133L);
lbl267:
                                        // 2 sources

                                        switch ((int)v39) {
                                            case -1806049444: {
                                                v40 = 23473L ^ 5757419178909015040L;
                                                continue block196;
                                            }
                                            case -866219927: {
                                                v40 = 5728L ^ 5816906787243363537L;
                                                continue block196;
                                            }
                                            case -743509858: {
                                                v40 = 32336L ^ 171806986834121155L;
                                                continue block196;
                                            }
                                            case 1415186628: {
                                                break block196;
                                            }
                                        }
                                        break;
                                    }
                                    while (true) {
                                        if ((v41 = (cfr_temp_16 = MapCycleModule.\u13e8 - (30924L ^ 5721205558610064522L)) == 0L ? 0 : (cfr_temp_16 < 0L ? -1 : 1)) == false) continue;
                                        if (v41 == (5915 ^ -5916)) break;
                                        v41 = 12830 ^ -1606057180;
                                    }
                                    if (!this.decrementWaitTicksOnRefreshableMap.booleanValue()) break block253;
                                    v42 = MapCycleModule.\u13e8;
                                    if (true) ** GOTO lbl289
                                    block198: while (true) {
                                        v42 = (2486L ^ -3791039936810456340L) / (31317L ^ 1662663997763121120L);
lbl289:
                                        // 2 sources

                                        switch ((int)v42) {
                                            case -833414278: {
                                                continue block198;
                                            }
                                            case 1415186628: {
                                                break block198;
                                            }
                                        }
                                        break;
                                    }
                                    isRefreshMap = this.isRefreshableMap(currentMap);
                                    if (!isRefreshMap) break block253;
                                    v43 = MapCycleModule.\u13e8;
                                    if (true) ** GOTO lbl300
                                    block199: while (true) {
                                        v43 = v44 / (-5742471110568400884L >>> "\u0000\u0000".length());
lbl300:
                                        // 2 sources

                                        switch ((int)v43) {
                                            case -1683391734: {
                                                v44 = 16143L ^ -4924388300701288536L;
                                                continue block199;
                                            }
                                            case -739742342: {
                                                v44 = 21883L ^ 2523840856802736169L;
                                                continue block199;
                                            }
                                            case 1415186628: {
                                                break block199;
                                            }
                                        }
                                        break;
                                    }
                                    v45 = (boolean)(27856 ^ 27856);
                                    while (true) {
                                        if ((v46 = (cfr_temp_17 = MapCycleModule.\u13e8 - (5216L ^ -3844969250717643910L)) == 0L ? 0 : (cfr_temp_17 < 0L ? -1 : 1)) == false) continue;
                                        if (v46 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                                        v46 = 5844 ^ -1740500464;
                                    }
                                    this.decrementWaitTicksOnRefreshableMap = v45;
                                    while (true) {
                                        if ((v47 = (cfr_temp_18 = MapCycleModule.\u13e8 - (9552L ^ -4082696428555629305L)) == 0L ? 0 : (cfr_temp_18 < 0L ? -1 : 1)) == false) continue;
                                        if (v47 == (31790 ^ 31791)) break;
                                        v47 = 4639 ^ -1936576498;
                                    }
                                    while (true) {
                                        if ((v48 = (cfr_temp_19 = MapCycleModule.\u13e8 - (13003L ^ -3272200358664878539L)) == 0L ? 0 : (cfr_temp_19 < 0L ? -1 : 1)) == false) continue;
                                        if (v48 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                                        v48 = 16532 ^ -2027485625;
                                    }
                                    v49 = this.afterKillConfig.WAIT_SECONDS_AFTER_KILL;
                                    while (true) {
                                        if ((v50 = (cfr_temp_20 = MapCycleModule.\u13e8 - (1642626861792406636L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_20 < 0L ? -1 : 1)) == false) continue;
                                        if (v50 == (20315 ^ -20316)) break;
                                        v50 = -1552539192 >>> "\u0000\u0000".length();
                                    }
                                    v51 = MapCycleModule.\u13e8;
                                    if (true) ** GOTO lbl336
                                    block204: while (true) {
                                        v51 = v52 / (13593L ^ -8555308802948069717L);
lbl336:
                                        // 2 sources

                                        switch ((int)v51) {
                                            case 467122182: {
                                                v52 = 1515L ^ -369794432470567630L;
                                                continue block204;
                                            }
                                            case 1235566773: {
                                                v52 = 15716L ^ -7080731402784792855L;
                                                continue block204;
                                            }
                                            case 1415186628: {
                                                break block204;
                                            }
                                        }
                                        break;
                                    }
                                    v53 = v49 - this.tempExtraWaitSecondsConfig.TEMP_EXTRA_WAIT_SECONDS;
                                    v54 = MapCycleModule.\u13e8;
                                    if (true) ** GOTO lbl350
                                    block205: while (true) {
                                        v54 = v55 / (5460L ^ -3787111670882946847L);
lbl350:
                                        // 2 sources

                                        switch ((int)v54) {
                                            case -846842795: {
                                                v55 = 23026L ^ 7977315141676679723L;
                                                continue block205;
                                            }
                                            case -85683523: {
                                                v55 = 24255L ^ 125774326420268841L;
                                                continue block205;
                                            }
                                            case 1415186628: {
                                                break block205;
                                            }
                                        }
                                        break;
                                    }
                                    this.afterKillConfig.WAIT_SECONDS_AFTER_KILL = v53;
                                    v56 = MapCycleModule.\u13e8;
                                    if (true) ** GOTO lbl364
                                    block206: while (true) {
                                        v56 = v57 / (5335684180766085436L >>> "\u0000\u0000".length());
lbl364:
                                        // 2 sources

                                        switch ((int)v56) {
                                            case -1316276666: {
                                                v57 = 2667L ^ 8032820999555286605L;
                                                continue block206;
                                            }
                                            case 273048251: {
                                                v57 = 3438170840787019588L >>> "\u0000\u0000".length();
                                                continue block206;
                                            }
                                            case 1415186628: {
                                                break block206;
                                            }
                                        }
                                        break;
                                    }
                                    UserLogs.LogExtraWaitTicksRemoved(this);
                                }
                                while (true) {
                                    if ((v58 = (cfr_temp_21 = MapCycleModule.\u13e8 - (20854L ^ -6310791626296580013L)) == 0L ? 0 : (cfr_temp_21 < 0L ? -1 : 1)) == false) continue;
                                    if (v58 == (29431 ^ 29430)) break;
                                    v58 = 27113 ^ 272517680;
                                }
                                cycleWorkMapsList = this.getPrioritySortedCycleWorkMapIds();
                                v59 = MapCycleModule.\u13e8;
                                if (true) ** GOTO lbl385
                                block208: while (true) {
                                    v59 = v60 / (13446L ^ -3221500734502251072L);
lbl385:
                                    // 2 sources

                                    switch ((int)v59) {
                                        case 273289706: {
                                            v60 = 24100L ^ -5061178898066459028L;
                                            continue block208;
                                        }
                                        case 842496991: {
                                            v60 = 23859L ^ 2947757042476822410L;
                                            continue block208;
                                        }
                                        case 1415186628: {
                                            break block208;
                                        }
                                        case 2003766660: {
                                            v60 = 31591L ^ 8526954942837145881L;
                                            continue block208;
                                        }
                                    }
                                    break;
                                }
                                size = cycleWorkMapsList.size();
                                if (size == 0) {
                                    return;
                                }
                                v61 = MapCycleModule.\u13e8;
                                if (true) ** GOTO lbl404
                                block209: while (true) {
                                    v61 = (3510722398521302672L >>> "\u0000\u0000".length()) / (2225L ^ -6021837935320117787L);
lbl404:
                                    // 2 sources

                                    switch ((int)v61) {
                                        case 964821063: {
                                            continue block209;
                                        }
                                        case 1415186628: {
                                            break block209;
                                        }
                                    }
                                    break;
                                }
                                v62 = currentMap;
                                v63 = MapCycleModule.\u13e8;
                                if (true) ** GOTO lbl414
                                block210: while (true) {
                                    v63 = v64 / (11371L ^ 5245377658212420951L);
lbl414:
                                    // 2 sources

                                    switch ((int)v63) {
                                        case -2021057764: {
                                            v64 = 26146L ^ 1233026279796711836L;
                                            continue block210;
                                        }
                                        case -1480527769: {
                                            v64 = 29761L ^ 5576905645956549240L;
                                            continue block210;
                                        }
                                        case 1415186628: {
                                            break block210;
                                        }
                                        case 2004062880: {
                                            v64 = 19956L ^ 4524586194868961616L;
                                            continue block210;
                                        }
                                    }
                                    break;
                                }
                                workMapIdx = cycleWorkMapsList.indexOf(v62);
                                v65 = MapCycleModule.\u13e8;
                                if (true) ** GOTO lbl431
                                block211: while (true) {
                                    v65 = v66 / (6093504249950758744L >>> "\u0000\u0000".length());
lbl431:
                                    // 2 sources

                                    switch ((int)v65) {
                                        case 648253350: {
                                            v66 = 16984L ^ -653751104317751774L;
                                            continue block211;
                                        }
                                        case 1415186628: {
                                            break block211;
                                        }
                                        case 1926403051: {
                                            v66 = 5833L ^ 4710732596001636223L;
                                            continue block211;
                                        }
                                    }
                                    break;
                                }
                                while (true) {
                                    if ((v67 = (cfr_temp_22 = MapCycleModule.\u13e8 - (28599L ^ 5185278639892790992L)) == 0L ? 0 : (cfr_temp_22 < 0L ? -1 : 1)) == false) continue;
                                    if (v67 == (8486 ^ -8487)) break;
                                    v67 = 3260 ^ 2051645385;
                                }
                                nextMap = cycleWorkMapsList.get((workMapIdx + (22540 ^ 22541)) % size);
                                while (true) {
                                    if ((v68 = (cfr_temp_23 = MapCycleModule.\u13e8 - (32380L ^ -3877273206022195786L)) == 0L ? 0 : (cfr_temp_23 < 0L ? -1 : 1)) == false) continue;
                                    if (v68 == ("\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() ^ "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length())) break;
                                    v68 = 650 ^ -1241811627;
                                }
                                this.cachedNextWorkMapId = nextMap;
                                v69 = isOnCycleMap = workMapIdx >= 0 ? 3912 ^ 3913 : "".length() >>> "\u0000\u0000".length();
                                if (isOnCycleMap == 0) break block254;
                                v70 = MapCycleModule.\u13e8;
                                if (true) ** GOTO lbl458
                                block214: while (true) {
                                    v70 = (9221L ^ 6799071408701328048L) / (18989L ^ -2073638099524801867L);
lbl458:
                                    // 2 sources

                                    switch ((int)v70) {
                                        case 1415186628: {
                                            break block214;
                                        }
                                        case 1612048636: {
                                            continue block214;
                                        }
                                    }
                                    break;
                                }
                                v71 = currentMap;
                                while (true) {
                                    if ((v72 = (cfr_temp_24 = MapCycleModule.\u13e8 - (15084L ^ -2134898843796729627L)) == 0L ? 0 : (cfr_temp_24 < 0L ? -1 : 1)) == false) continue;
                                    if (v72 == (31164 ^ -31165)) break;
                                    v72 = 30355 ^ -1135429732;
                                }
                                this.timeSpentOnMapUpdate(v71, cycleWorkMapsList);
                                v73 = MapCycleModule.\u13e8;
                                if (true) ** GOTO lbl474
                                block216: while (true) {
                                    v73 = v74 / (-8425071546536654788L >>> "\u0000\u0000".length());
lbl474:
                                    // 2 sources

                                    switch ((int)v73) {
                                        case -296419440: {
                                            v74 = 27736L ^ 8670181964019913475L;
                                            continue block216;
                                        }
                                        case 98897230: {
                                            v74 = 3153L ^ 6636953492616363144L;
                                            continue block216;
                                        }
                                        case 581254161: {
                                            v74 = -8784055214613307776L >>> "\u0000\u0000".length();
                                            continue block216;
                                        }
                                        case 1415186628: {
                                            break block216;
                                        }
                                    }
                                    break;
                                }
                                hasDied = this.hasDied();
                                if (!hasDied) break block255;
                                v75 = MapCycleModule.\u13e8;
                                if (true) ** GOTO lbl492
                                block217: while (true) {
                                    v75 = v76 / (16923L ^ 8981933721959287462L);
lbl492:
                                    // 2 sources

                                    switch ((int)v75) {
                                        case 862045923: {
                                            v76 = 722L ^ -8996641511569105530L;
                                            continue block217;
                                        }
                                        case 1415186628: {
                                            break block217;
                                        }
                                        case 1658269702: {
                                            v76 = 14134L ^ 7699893229026623752L;
                                            continue block217;
                                        }
                                    }
                                    break;
                                }
                                UserLogs.LogBotDied(this);
                                v77 = MapCycleModule.\u13e8;
                                if (true) ** GOTO lbl506
                                block218: while (true) {
                                    v77 = v78 / (10511L ^ 2241983691200225816L);
lbl506:
                                    // 2 sources

                                    switch ((int)v77) {
                                        case -461478998: {
                                            v78 = 1385L ^ 4978747956584416627L;
                                            continue block218;
                                        }
                                        case -305450223: {
                                            v78 = 31405L ^ -1330382856107754809L;
                                            continue block218;
                                        }
                                        case 807899891: {
                                            v78 = 14907L ^ -5281525014463434679L;
                                            continue block218;
                                        }
                                        case 1415186628: {
                                            break block218;
                                        }
                                    }
                                    break;
                                }
                                while (true) {
                                    if ((v79 = (cfr_temp_25 = MapCycleModule.\u13e8 - (28228L ^ 8456475237586488768L)) == 0L ? 0 : (cfr_temp_25 < 0L ? -1 : 1)) == false) continue;
                                    if (v79 == (17708 ^ -17709)) break;
                                    v79 = 4705 ^ -701209746;
                                }
                                if (!this.npcSubnameConditionConfig.COUNT_DEATH_AS_SUBNAME_KILL) break block256;
                                v80 = MapCycleModule.\u13e8;
                                if (true) ** GOTO lbl528
                                block220: while (true) {
                                    v80 = (8880L ^ -6442120440412711516L) / (22234L ^ -6462323730888532516L);
lbl528:
                                    // 2 sources

                                    switch ((int)v80) {
                                        case 305982963: {
                                            continue block220;
                                        }
                                        case 1415186628: {
                                            break block220;
                                        }
                                    }
                                    break;
                                }
                                v81 = MapCycleModule.\u13e8;
                                if (true) ** GOTO lbl537
                                block221: while (true) {
                                    v81 = v82 / (27507L ^ -511107800118918696L);
lbl537:
                                    // 2 sources

                                    switch ((int)v81) {
                                        case -1665244979: {
                                            v82 = 29267L ^ 5821812320124794777L;
                                            continue block221;
                                        }
                                        case -211211350: {
                                            v82 = 7778L ^ -2901851292695346335L;
                                            continue block221;
                                        }
                                        case 1415186628: {
                                            break block221;
                                        }
                                        case 2020062061: {
                                            v82 = 15462L ^ -3522420607125992733L;
                                            continue block221;
                                        }
                                    }
                                    break;
                                }
                                this.shootingBeheState.tryIncrementDeathsWhileShooting();
                                break block257;
                            }
                            v83 = MapCycleModule.\u13e8;
                            if (true) ** GOTO lbl556
                            block222: while (true) {
                                v83 = v84 / (31211L ^ -859118990408055652L);
lbl556:
                                // 2 sources

                                switch ((int)v83) {
                                    case -2144205778: {
                                        v84 = 1619L ^ -7476361521666143616L;
                                        continue block222;
                                    }
                                    case 211103793: {
                                        v84 = 31769L ^ 7907855034856123968L;
                                        continue block222;
                                    }
                                    case 1415186628: {
                                        break block222;
                                    }
                                }
                                break;
                            }
                            while (true) {
                                if ((v85 = (cfr_temp_26 = MapCycleModule.\u13e8 - (-2166633225606628960L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_26 < 0L ? -1 : 1)) == false) continue;
                                if (v85 == (9554 ^ -9555)) {
                                    this.shootingBeheState.reset();
                                    break;
                                }
                                v85 = 7581 ^ -1441374815;
                            }
                        }
                        if (switchOnMaxMapDeathsEnabled == 0) {
                            return;
                        }
                        while (true) {
                            if ((v86 = (cfr_temp_27 = MapCycleModule.\u13e8 - (6614L ^ 7346105854652125792L)) == 0L ? 0 : (cfr_temp_27 < 0L ? -1 : 1)) == false) continue;
                            if (v86 == (26514 ^ -26515)) break;
                            v86 = 3443 ^ -1118919686;
                        }
                        v87 = MapCycleModule.\u13e8;
                        if (true) ** GOTO lbl584
                        block225: while (true) {
                            v87 = (10540L ^ 4890184940188018147L) / (28818L ^ 7258010769847788917L);
lbl584:
                            // 2 sources

                            switch ((int)v87) {
                                case -126029933: {
                                    continue block225;
                                }
                                case 1415186628: {
                                    break block225;
                                }
                            }
                            break;
                        }
                        this.deathsOnCurrentMap.incrementDeaths();
                        while (true) {
                            if ((v88 = (cfr_temp_28 = MapCycleModule.\u13e8 - (12307L ^ -517475948594940293L)) == 0L ? 0 : (cfr_temp_28 < 0L ? -1 : 1)) == false) continue;
                            if (v88 == (15149 ^ -15150)) break;
                            v88 = 17762 ^ 523115172;
                        }
                        v89 = MapCycleModule.\u13e8;
                        if (true) ** GOTO lbl600
                        block227: while (true) {
                            v89 = v90 / (13750L ^ -8140524729145931809L);
lbl600:
                            // 2 sources

                            switch ((int)v89) {
                                case -1092348199: {
                                    v90 = 16007L ^ 6054262465783855880L;
                                    continue block227;
                                }
                                case 119237697: {
                                    v90 = 31050L ^ 4798782057939256066L;
                                    continue block227;
                                }
                                case 229295981: {
                                    v90 = 14202L ^ 6639985055108893738L;
                                    continue block227;
                                }
                                case 1415186628: {
                                    break block227;
                                }
                            }
                            break;
                        }
                        if (this.deathsOnCurrentMap.getDeaths() < maxMapDeathsBeforeSwitch) break block258;
                        while (true) {
                            if ((v91 = (cfr_temp_29 = MapCycleModule.\u13e8 - (17388L ^ 6514030472382642333L)) == 0L ? 0 : (cfr_temp_29 < 0L ? -1 : 1)) == false) continue;
                            if (v91 == (24491 ^ -24492)) break;
                            v91 = 28527 ^ -1532988906;
                        }
                        v92 = MapCycleModule.\u13e8;
                        if (true) ** GOTO lbl622
                        block229: while (true) {
                            v92 = v93 / (23419L ^ -6590277607323517895L);
lbl622:
                            // 2 sources

                            switch ((int)v92) {
                                case 831417002: {
                                    v93 = 31745L ^ -7044617725434784366L;
                                    continue block229;
                                }
                                case 1107602542: {
                                    v93 = 13832L ^ -2924571945186909629L;
                                    continue block229;
                                }
                                case 1415186628: {
                                    break block229;
                                }
                                case 1832095780: {
                                    v93 = 20261L ^ -6879249064429915371L;
                                    continue block229;
                                }
                            }
                            break;
                        }
                        this.shootingBeheState.reset();
                        while (true) {
                            if ((v94 = (cfr_temp_30 = MapCycleModule.\u13e8 - (25604L ^ -4928855645920116134L)) == 0L ? 0 : (cfr_temp_30 < 0L ? -1 : 1)) == false) continue;
                            if (v94 == (15116 ^ 15117)) break;
                            v94 = 7761 ^ 17460537;
                        }
                        v95 = MapCycleModule.\u13e8;
                        if (true) ** GOTO lbl644
                        block231: while (true) {
                            v95 = (30947L ^ 7973580390223430898L) / (19640L ^ -433725134440158301L);
lbl644:
                            // 2 sources

                            switch ((int)v95) {
                                case -1620503949: {
                                    continue block231;
                                }
                                case 1415186628: {
                                    break block231;
                                }
                            }
                            break;
                        }
                        this.deathsOnCurrentMap.resetDeaths();
                        v96 = MapCycleModule.\u13e8;
                        if (true) ** GOTO lbl654
                        block232: while (true) {
                            v96 = v97 / (6438L ^ 2544066934559672096L);
lbl654:
                            // 2 sources

                            switch ((int)v96) {
                                case -209228225: {
                                    v97 = 9404L ^ 4133921002284924137L;
                                    continue block232;
                                }
                                case 1415186628: {
                                    break block232;
                                }
                                case 1778627655: {
                                    v97 = 12381L ^ 8092338151853858966L;
                                    continue block232;
                                }
                            }
                            break;
                        }
                        this.lostLockTimeStampNpcKilled(currentMap);
                        while (true) {
                            if ((v98 = (cfr_temp_31 = MapCycleModule.\u13e8 - (7273817091333713124L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_31 < 0L ? -1 : 1)) == false) continue;
                            if (v98 == (9750 ^ -9751)) break;
                            v98 = 1185 ^ 1296333486;
                        }
                        this.startAfterKillPeriod(nextMap);
                        while (true) {
                            if ((v99 = (cfr_temp_32 = MapCycleModule.\u13e8 - (22458L ^ -6732706540755459069L)) == 0L ? 0 : (cfr_temp_32 < 0L ? -1 : 1)) == false) continue;
                            if (v99 == (2351 ^ 2350)) {
                                UserLogs.LogMaxDeathsReached(this);
                                break;
                            }
                            v99 = 26941 ^ 1543413468;
                        }
                    }
                    return;
                }
                while (true) {
                    if ((v100 = (cfr_temp_33 = MapCycleModule.\u13e8 - (-9120292606978488580L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_33 < 0L ? -1 : 1)) == false) continue;
                    if (v100 == (21988 ^ -21989)) break;
                    v100 = 32554 ^ 1102199403;
                }
                if (this.hasKilledBehemoth(currentMap, nextMap)) {
                    return;
                }
                break block259;
            }
            while (true) {
                if ((v101 = (cfr_temp_34 = MapCycleModule.\u13e8 - (16215L ^ 7535080657400517431L)) == 0L ? 0 : (cfr_temp_34 < 0L ? -1 : 1)) == false) continue;
                if (v101 == (17273 ^ -17274)) break;
                v101 = -1053621652 >>> "\u0000\u0000".length();
            }
            v102 = this.getInitialWorkMapId(cycleWorkMapsList);
            while (true) {
                if ((v103 = (cfr_temp_35 = MapCycleModule.\u13e8 - (10893L ^ 4365257378464771576L)) == 0L ? 0 : (cfr_temp_35 < 0L ? -1 : 1)) == false) continue;
                if (v103 == (20135 ^ -20136)) break;
                v103 = 9464 ^ -594923931;
            }
            v104 = v102;
            var11_11 = new byte[3395 ^ 3404];
            var11_11[3778 ^ 3781] = 24329 ^ 24366;
            var11_11["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 2321 ^ 2353;
            var11_11["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 19769 ^ 19786;
            var11_11[6267 ^ 6270] = 388 >>> "\u0000\u0000".length();
            var11_11[28282 ^ 28284] = 432 >>> "\u0000\u0000".length();
            var11_11["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 24621 ^ 24665;
            var11_11["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 420 >>> "\u0000\u0000".length();
            var11_11["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 476 >>> "\u0000\u0000".length();
            var11_11["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 6687 ^ 6763;
            var11_11["".length() >>> "\u0000\u0000".length()] = 28817 ^ 28888;
            var11_11[7567 ^ 7566] = 26598 ^ 26504;
            var11_11["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 560 ^ 542;
            var11_11[32463 ^ 32450] = 18729 ^ 18753;
            var11_11["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 2253 ^ 2212;
            var11_11["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 396 >>> "\u0000\u0000".length();
            var11_11[31155 ^ 31161] = 15125 ^ 15228;
            v105 = new String(var11_11);
            while (true) {
                if ((v106 = (cfr_temp_36 = MapCycleModule.\u13e8 - (16585L ^ 4411746028696396416L)) == 0L ? 0 : (cfr_temp_36 < 0L ? -1 : 1)) == false) continue;
                if (v106 == (30232 ^ -30233)) {
                    this.switchToMap(currentMap, v104, v105);
                    break;
                }
                v106 = 28774 ^ -1085560983;
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private boolean hasKilledBehemoth(int currentMap, int nextMap) {
        block71: {
            block72: {
                v0 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl5
                block51: while (true) {
                    v0 = v1 / (32422L ^ 4942448445324188662L);
lbl5:
                    // 2 sources

                    switch ((int)v0) {
                        case -1072506889: {
                            v1 = 21862L ^ -2379777195411035166L;
                            continue block51;
                        }
                        case -866967276: {
                            v1 = 4159L ^ -3513204064507668312L;
                            continue block51;
                        }
                        case 1415186628: {
                            break block51;
                        }
                    }
                    break;
                }
                deathFromLogs = this.tryDetermineNpcKilledFromUnseenLogs();
                v2 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl19
                block52: while (true) {
                    v2 = v3 / (26240L ^ -4926016799949474353L);
lbl19:
                    // 2 sources

                    switch ((int)v2) {
                        case -1628140404: {
                            v3 = 23658L ^ -7650703873454009327L;
                            continue block52;
                        }
                        case -145904418: {
                            v3 = 3095L ^ 6217802963746641256L;
                            continue block52;
                        }
                        case 1415186628: {
                            break block52;
                        }
                        case 1528525000: {
                            v3 = 32490L ^ -4232316689125001054L;
                            continue block52;
                        }
                    }
                    break;
                }
                deathFromOutOfSight = this.tryDetermineNpcKilledFromSight();
                while (true) {
                    if ((v4 = (cfr_temp_0 = MapCycleModule.\u13e8 - (14910L ^ 6169962576354463458L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                    if (v4 == (2498 ^ -2499)) break;
                    v4 = 26051 ^ -1892564727;
                }
                deathInPast = this.tryDetermineNpcDeadInPast();
                v5 = killedBehemoth = deathFromLogs != false || deathFromOutOfSight != false || deathInPast != false ? "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length() : "".length() >>> "\u0000\u0000".length();
                if (!killedBehemoth) break block71;
                v6 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl44
                block54: while (true) {
                    v6 = v7 / (26032L ^ -1985030572252505037L);
lbl44:
                    // 2 sources

                    switch ((int)v6) {
                        case -1914144133: {
                            v7 = 11801L ^ -2866962401410203134L;
                            continue block54;
                        }
                        case -591889049: {
                            v7 = 28339L ^ -4244744583543303658L;
                            continue block54;
                        }
                        case -163606548: {
                            v7 = 1374L ^ -4674992582090161134L;
                            continue block54;
                        }
                        case 1415186628: {
                            break block54;
                        }
                    }
                    break;
                }
                UserLogs.LogNpcKilled(this, deathFromLogs, deathFromOutOfSight, deathInPast);
                v8 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl61
                block55: while (true) {
                    v8 = (20627L ^ -6008668836805041873L) / (-5983723509243741296L >>> "\u0000\u0000".length());
lbl61:
                    // 2 sources

                    switch ((int)v8) {
                        case -1510617504: {
                            continue block55;
                        }
                        case 1415186628: {
                            break block55;
                        }
                    }
                    break;
                }
                while (true) {
                    if ((v9 = (cfr_temp_1 = MapCycleModule.\u13e8 - (25453L ^ 5726113812010097316L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                    if (v9 == (12146 ^ -12147)) break;
                    v9 = 60258104 >>> "\u0000\u0000".length();
                }
                hadDeathsWhileShooting = this.shootingBeheState.getDeathsWhileShooting() > 0 ? 30694 ^ 30695 : "".length() >>> "\u0000\u0000".length();
                while (true) {
                    if ((v10 = (cfr_temp_2 = MapCycleModule.\u13e8 - (11148L ^ 349027607347840075L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                    if (v10 == (21304 ^ -21305)) break;
                    v10 = 25916 ^ -149276939;
                }
                v11 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl81
                block58: while (true) {
                    v11 = v12 / (4945L ^ -6735332286956961284L);
lbl81:
                    // 2 sources

                    switch ((int)v11) {
                        case -846577357: {
                            v12 = 24466L ^ -9099666339232188548L;
                            continue block58;
                        }
                        case 661951897: {
                            v12 = 23195L ^ 3372045961151034773L;
                            continue block58;
                        }
                        case 1415186628: {
                            break block58;
                        }
                        case 1900542240: {
                            v12 = 10212L ^ 1249863825928692326L;
                            continue block58;
                        }
                    }
                    break;
                }
                this.shootingBeheState.reset();
                if (!deathInPast) break block72;
                v13 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl99
                block59: while (true) {
                    v13 = (26526L ^ -4933671569590483741L) / (2845L ^ -7837678382217405484L);
lbl99:
                    // 2 sources

                    switch ((int)v13) {
                        case 241740742: {
                            continue block59;
                        }
                        case 1415186628: {
                            break block59;
                        }
                    }
                    break;
                }
                this.timestampSubnameKill(currentMap, null);
                v14 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl109
                block60: while (true) {
                    v14 = v15 / (9203L ^ -191251561614772701L);
lbl109:
                    // 2 sources

                    switch ((int)v14) {
                        case -1582935106: {
                            v15 = 31764L ^ -7339102452181231107L;
                            continue block60;
                        }
                        case -855395918: {
                            v15 = 1647L ^ -6385602178884018858L;
                            continue block60;
                        }
                        case 148312204: {
                            v15 = 18497L ^ 8468804175961736665L;
                            continue block60;
                        }
                        case 1415186628: {
                            break block60;
                        }
                    }
                    break;
                }
                v16 = nextMap;
                var9_8 = new byte["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
                var9_8["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 24524 ^ -24532;
                var9_8["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 420 >>> "\u0000\u0000".length();
                var9_8[3029 ^ 3030] = 4827 ^ 4859;
                var9_8["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 13058 ^ 13090;
                var9_8["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 6517 ^ 6405;
                var9_8["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 396 >>> "\u0000\u0000".length();
                var9_8["".length() >>> "\u0000\u0000".length()] = 26197 ^ 26139;
                var9_8["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 16745 ^ 16669;
                var9_8["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 21324 ^ 21356;
                var9_8["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 10239 ^ 10127;
                var9_8["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 7082 ^ 7129;
                var9_8["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 464 >>> "\u0000\u0000".length();
                var9_8["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 388 >>> "\u0000\u0000".length();
                var9_8["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 404 >>> "\u0000\u0000".length();
                var9_8["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 420 >>> "\u0000\u0000".length();
                var9_8[2086 ^ 2093] = 128 >>> "\u0000\u0000".length();
                var9_8[12174 ^ 12163] = 416 >>> "\u0000\u0000".length();
                var9_8["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 440 >>> "\u0000\u0000".length();
                var9_8[16660 ^ 16656] = 8113 ^ 8149;
                var9_8["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 404 >>> "\u0000\u0000".length();
                var9_8[31180 ^ 31179] = 5165 ^ 5193;
                var9_8["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 32027 ^ 32053;
                v17 = new String(var9_8);
                v18 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl150
                block61: while (true) {
                    v18 = v19 / (16960L ^ -5155102420133682769L);
lbl150:
                    // 2 sources

                    switch ((int)v18) {
                        case -353737719: {
                            v19 = 11188L ^ -8145230009525292477L;
                            continue block61;
                        }
                        case 1415186628: {
                            break block61;
                        }
                        case 1894032066: {
                            v19 = 11309L ^ 8379667484196233972L;
                            continue block61;
                        }
                        case 2044163833: {
                            v19 = 29433L ^ -6400085130102177038L;
                            continue block61;
                        }
                    }
                    break;
                }
                this.switchToMap(currentMap, v16, v17);
                break block71;
            }
            v20 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl169
            block62: while (true) {
                v20 = (13195L ^ -6571183089804392587L) / (22614L ^ -2229782341586596361L);
lbl169:
                // 2 sources

                switch ((int)v20) {
                    case -1756400824: {
                        continue block62;
                    }
                    case 1415186628: {
                        break block62;
                    }
                }
                break;
            }
            UserLogs.LogNpcDeathTimeStampTaken(this, nextMap);
            while (true) {
                if ((v21 = (cfr_temp_3 = MapCycleModule.\u13e8 - (27565L ^ 5480133345936809997L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v21 == (15270 ^ -15271)) break;
                v21 = 25646 ^ 1962038281;
            }
            this.pressKeyAfterKill(currentMap);
            v22 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl185
            block64: while (true) {
                v22 = (17584L ^ -6663165432743791239L) / (13214L ^ -219641165463953149L);
lbl185:
                // 2 sources

                switch ((int)v22) {
                    case 804179915: {
                        continue block64;
                    }
                    case 1415186628: {
                        break block64;
                    }
                }
                break;
            }
            this.startAfterKillPeriod(nextMap);
            if (deathFromOutOfSight && hadDeathsWhileShooting != 0) {
                while (true) {
                    if ((v23 = (cfr_temp_4 = MapCycleModule.\u13e8 - (31955L ^ 4375126977278319889L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                    if (v23 == (7144 ^ -7145)) {
                        this.lostLockTimeStampNpcKilled(currentMap);
                        break block71;
                    }
                    v23 = 13445 ^ -1472756008;
                }
            }
            v24 = 0L >>> "\u0000\u0000".length();
            while (true) {
                if ((v25 = (cfr_temp_5 = MapCycleModule.\u13e8 - (24861L ^ -6763091688829003178L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                if (v25 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v25 = 7121 ^ -1931349810;
            }
            v26 = v24;
            while (true) {
                if ((v27 = (cfr_temp_6 = MapCycleModule.\u13e8 - (7307L ^ 745355473277964112L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                if (v27 == (28136 ^ -28137)) {
                    this.timestampSubnameKill(currentMap, v26);
                    break;
                }
                v27 = 24422 ^ -965359593;
            }
        }
        return killedBehemoth;
    }

    /*
     * Unable to fully structure code
     */
    private void startAfterKillPeriod(int nextMap) {
        block22: {
            while (true) {
                if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (1259685540003041056L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v0 == (28384 ^ -28385)) break;
                v0 = 8626 ^ -24849152;
            }
            if (this.npcKilledTimeStampMs != null) break block22;
            while (true) {
                if ((v1 = (cfr_temp_1 = MapCycleModule.\u13e8 - (8642487588764640868L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v1 == (25323 ^ -25324)) break;
                v1 = 146 ^ 1816087129;
            }
            v2 = System.currentTimeMillis();
            v3 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl17
            block18: while (true) {
                v3 = v4 / (18653L ^ -5342953557085261601L);
lbl17:
                // 2 sources

                switch ((int)v3) {
                    case 12843131: {
                        v4 = 25588L ^ 1310247131314553670L;
                        continue block18;
                    }
                    case 200967013: {
                        v4 = 1567878262714742264L >>> "\u0000\u0000".length();
                        continue block18;
                    }
                    case 227661277: {
                        v4 = 31657L ^ -2799322627633244375L;
                        continue block18;
                    }
                    case 1415186628: {
                        break block18;
                    }
                }
                break;
            }
            v5 = v2;
            v6 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl34
            block19: while (true) {
                v6 = v7 / (2093L ^ 6030810247278459006L);
lbl34:
                // 2 sources

                switch ((int)v6) {
                    case -1659697279: {
                        v7 = -4252639774257334696L >>> "\u0000\u0000".length();
                        continue block19;
                    }
                    case 140622058: {
                        v7 = 16640L ^ -4270156208042476043L;
                        continue block19;
                    }
                    case 1415186628: {
                        break block19;
                    }
                }
                break;
            }
            this.npcKilledTimeStampMs = v5;
            while (true) {
                if ((v8 = (cfr_temp_2 = MapCycleModule.\u13e8 - (24374L ^ -424020141423106674L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v8 == (26297 ^ -26298)) break;
                v8 = 15052 ^ -84841489;
            }
            v9 = nextMap;
            v10 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl54
            block21: while (true) {
                v10 = v11 / (25144L ^ -8056635378917015448L);
lbl54:
                // 2 sources

                switch ((int)v10) {
                    case 487585173: {
                        v11 = 28718L ^ 4223249743899612805L;
                        continue block21;
                    }
                    case 1415186628: {
                        break block21;
                    }
                    case 1839983038: {
                        v11 = 7008L ^ -3499189323184016670L;
                        continue block21;
                    }
                }
                break;
            }
            this.nextMapIdAfterWaitKillPeriod = v9;
        }
    }

    /*
     * Unable to fully structure code
     */
    private int getInitialWorkMapId(List<Integer> cycleWorkMapsList) {
        block45: {
            block44: {
                v0 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl5
                block31: while (true) {
                    v0 = v1 / (4107845930179765404L >>> "\u0000\u0000".length());
lbl5:
                    // 2 sources

                    switch ((int)v0) {
                        case -1076294068: {
                            v1 = 7224L ^ -6027377744172239099L;
                            continue block31;
                        }
                        case 1379969734: {
                            v1 = 6038L ^ 8940223893879825877L;
                            continue block31;
                        }
                        case 1415186628: {
                            break block31;
                        }
                        case 1845384437: {
                            v1 = 656L ^ 5616095896512777416L;
                            continue block31;
                        }
                    }
                    break;
                }
                while (true) {
                    if ((v2 = (cfr_temp_0 = MapCycleModule.\u13e8 - (8363L ^ -8829163956428888722L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                    if (v2 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                    v2 = 14236 ^ 2117442802;
                }
                if (!this.adaptiveChecksConfig.ENABLE_INITIAL_MAP_IS_LONGEST_WAIT_MAP) break block44;
                while (true) {
                    if ((v3 = (cfr_temp_1 = MapCycleModule.\u13e8 - (7730L ^ -8480231953684198676L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                    if (v3 == (25005 ^ 25004)) break;
                    v3 = 21889 ^ -1853540255;
                }
                if (this.longestWaitCycleMapId == null) break block44;
                v4 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl33
                block34: while (true) {
                    v4 = v5 / (28595L ^ -103124302852952159L);
lbl33:
                    // 2 sources

                    switch ((int)v4) {
                        case -552032873: {
                            v5 = 45L ^ -3696192871724705173L;
                            continue block34;
                        }
                        case -458124176: {
                            v5 = 27531L ^ 4777661503143298990L;
                            continue block34;
                        }
                        case 1358647836: {
                            v5 = -4620688186631497008L >>> "\u0000\u0000".length();
                            continue block34;
                        }
                        case 1415186628: {
                            break block34;
                        }
                    }
                    break;
                }
                while (true) {
                    if ((v6 = (cfr_temp_2 = MapCycleModule.\u13e8 - (14156L ^ -7490936757524275630L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                    if (v6 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                    v6 = 7439 ^ -643984302;
                }
                if (!cycleWorkMapsList.contains(this.longestWaitCycleMapId)) break block44;
                v7 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl55
                block36: while (true) {
                    v7 = (21414L ^ 7120744019802637531L) / (30938L ^ -8853952879849644309L);
lbl55:
                    // 2 sources

                    switch ((int)v7) {
                        case 1319966145: {
                            continue block36;
                        }
                        case 1415186628: {
                            break block36;
                        }
                    }
                    break;
                }
                while (true) {
                    if ((v8 = (cfr_temp_3 = MapCycleModule.\u13e8 - (10988L ^ -8230683187913317005L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                    if (v8 == (18027 ^ 18026)) break;
                    v8 = 10700 ^ -1577348591;
                }
                return this.longestWaitCycleMapId;
            }
            v9 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl71
            block38: while (true) {
                v9 = v10 / (9722L ^ -5376823168863207484L);
lbl71:
                // 2 sources

                switch ((int)v9) {
                    case -2143794359: {
                        v10 = 23241L ^ -402276901869755523L;
                        continue block38;
                    }
                    case -1496410308: {
                        v10 = 6300L ^ 9034945111338815113L;
                        continue block38;
                    }
                    case 1052702959: {
                        v10 = 5348L ^ -6959975802023064070L;
                        continue block38;
                    }
                    case 1415186628: {
                        break block38;
                    }
                }
                break;
            }
            while (true) {
                if ((v11 = (cfr_temp_4 = MapCycleModule.\u13e8 - (324916014877937300L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v11 == (22083 ^ -22084)) break;
                v11 = 9229 ^ 1595098723;
            }
            v12 = this.cachedNextWorkMapId;
            while (true) {
                if ((v13 = (cfr_temp_5 = MapCycleModule.\u13e8 - (-2273819175271836224L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                if (v13 == (16283 ^ -16284)) break;
                v13 = 1705 ^ -1868587016;
            }
            if (!cycleWorkMapsList.contains(v12)) break block45;
            v14 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl99
            block41: while (true) {
                v14 = v15 / (-7357399657096679748L >>> "\u0000\u0000".length());
lbl99:
                // 2 sources

                switch ((int)v14) {
                    case -2111857833: {
                        v15 = 15983L ^ -38519305502890678L;
                        continue block41;
                    }
                    case 278524003: {
                        v15 = 2935L ^ 5837679255904809529L;
                        continue block41;
                    }
                    case 1415186628: {
                        break block41;
                    }
                }
                break;
            }
            return this.cachedNextWorkMapId;
        }
        while (true) {
            if ((v16 = (cfr_temp_6 = MapCycleModule.\u13e8 - (14708L ^ -3341438884564603420L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
            if (v16 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v16 = 22798 ^ -133051793;
        }
        v17 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl119
        block43: while (true) {
            v17 = (8438L ^ 5736913602905418676L) / (5916L ^ -1108178108581786206L);
lbl119:
            // 2 sources

            switch ((int)v17) {
                case -522587286: {
                    continue block43;
                }
                case 1415186628: {
                    break block43;
                }
            }
            break;
        }
        return cycleWorkMapsList.get(12989 ^ 12989);
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private void resetAdaptiveMapIdToTimeSpent() {
        long l = \u13e8;
        block22: while (true) {
            switch ((int)l) {
                case 1415186628: {
                    break block22;
                }
                case 1809519379: {
                    l = (0x477DL ^ 0x68DF4AD8FFCEC624L) / (0x566L ^ 0xED9FA3DAACEAA5EAL);
                    continue block22;
                }
            }
            break;
        }
        UserLogs.LogResetMapIdToTimeSpent(this);
        long l2 = \u13e8;
        boolean bl = true;
        block23: while (true) {
            long l3;
            if (!bl || (bl = false) || !true) {
                l2 = l3 / (0x2B7FL ^ 0xD1C0E0D888B251F5L);
            }
            switch ((int)l2) {
                case 334397883: {
                    l3 = 0x3453L ^ 0xE81CA7B24911724EL;
                    continue block23;
                }
                case 1311215537: {
                    l3 = 0x75FCL ^ 0x74EDB56FECEC134EL;
                    continue block23;
                }
                case 1415186628: {
                    break block23;
                }
            }
            break;
        }
        while (true) {
            long l4;
            long l5;
            if ((l5 = (l4 = \u13e8 - (0x50C0L ^ 0x81B2BFCE4359FCAL)) == 0L ? 0 : (l4 < 0L ? -1 : 1)) == false) continue;
            if (l5 == (0x433 ^ 0xFFFFFBCC)) break;
            l5 = "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() ^ 0x77418568;
        }
        this.mapIdToTickCountBucket.clear();
        while (true) {
            long l6;
            long l7;
            if ((l7 = (l6 = \u13e8 - (0x20B5L ^ 0xEEF4B3051ED5CEBDL)) == 0L ? 0 : (l6 < 0L ? -1 : 1)) == false) continue;
            if (l7 == (0xF1D ^ 0xFFFFF0E2)) break;
            l7 = 0x5087 ^ 0x77BCE796;
        }
        this.preventTimeSpentUpdates = 0x5EA6 ^ 0x5EA6;
        long l8 = \u13e8;
        block26: while (true) {
            switch ((int)l8) {
                case -1378052660: {
                    l8 = (0x4800L ^ 0xC24B47F5C165FE4CL) / (0x3D42L ^ 0xBE4920945F6CE17FL);
                    continue block26;
                }
                case 1415186628: {
                    break block26;
                }
            }
            break;
        }
        this.cachedLongestTimeSpentEntry = null;
        long l9 = \u13e8;
        boolean bl2 = true;
        block27: while (true) {
            long l10;
            if (!bl2 || (bl2 = false) || !true) {
                l9 = l10 / (0x467AL ^ 0x596AEA1642F441BDL);
            }
            switch ((int)l9) {
                case -1220039040: {
                    l10 = 0x117CL ^ 0xE5F385990554EEB7L;
                    continue block27;
                }
                case -899560444: {
                    l10 = 0x2F8CL ^ 0x11A680432DB53571L;
                    continue block27;
                }
                case 1415186628: {
                    break block27;
                }
            }
            break;
        }
        this.longestWaitCycleMapId = null;
        long l11 = \u13e8;
        block28: while (true) {
            switch ((int)l11) {
                case -748809534: {
                    l11 = (0xF7L ^ 0xF99CDC651EAFAC53L) / (0x968L ^ 0x748A4DF2AC70DD46L);
                    continue block28;
                }
                case 1415186628: {
                    break block28;
                }
            }
            break;
        }
        this.adaptiveCheckStartTimestampMs = null;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void clearNonCycleMaps(List<Integer> cycleWorkMapIds) {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x4D3AL ^ 0xF5A5BA9E26677157L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x63E2 ^ 0xFFFF9C1D)) break;
            l2 = 0x12EF ^ 0xFCB98007;
        }
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = \u13e8 - (0x4ADCL ^ 0x5F55A5E9750B0508L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l3 == (0x50FA ^ 0xFFFFAF05)) break;
            l3 = 0x48BA ^ 0x3748AB0C;
        }
        while (true) {
            long l;
            long l4;
            if ((l4 = (l = \u13e8 - (6402388167752396688L >>> "\u0000\u0000".length())) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l4 == (0x119E ^ 0xFFFFEE61)) break;
            l4 = 0x3693 ^ 0x7A07B0D5;
        }
        Set<Integer> set = this.mapIdToTickCountBucket.keySet();
        while (true) {
            long l;
            long l5;
            if ((l5 = (l = \u13e8 - (0x7199L ^ 0x9DA0067E3AAD9B8FL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l5 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l5 = 0x73A4 ^ 0xCE5E96CC;
        }
        ArrayList<Integer> loggedWorkMapIds = new ArrayList<Integer>(set);
        while (true) {
            long l;
            long l6;
            if ((l6 = (l = \u13e8 - (0x39B0L ^ 0xDDC3D6834819BC88L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l6 == (0x24D9 ^ 0xFFFFDB26)) break;
            l6 = 0x69D3 ^ 0x9B78A873;
        }
        Iterator iterator = loggedWorkMapIds.iterator();
        while (true) {
            long l;
            long l7;
            if ((l7 = (l = \u13e8 - (0x6EA2L ^ 0x701B6DC900BD9B22L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l7 == (0x556F ^ 0xFFFFAA90)) {
                if (!iterator.hasNext()) {
                    return;
                }
            } else {
                l7 = 0xA91 ^ 0xCBCA2791;
                continue;
            }
            long l8 = \u13e8;
            block22: while (true) {
                switch ((int)l8) {
                    case 1415186628: {
                        break block22;
                    }
                    case 1811327735: {
                        l8 = (0x63AAL ^ 0xDEC300A2F32BADAEL) / (-1619850298292226232L >>> "\u0000\u0000".length());
                        continue block22;
                    }
                }
                break;
            }
            Integer loggedMapId = (Integer)iterator.next();
            long l9 = \u13e8;
            block23: while (true) {
                switch ((int)l9) {
                    case 1415186628: {
                        break block23;
                    }
                    case 1511829104: {
                        l9 = (0xEE4L ^ 0x925F1299407C5067L) / (0x21CDL ^ 0x618845AB93B4D313L);
                        continue block23;
                    }
                }
                break;
            }
            if (cycleWorkMapIds.contains(loggedMapId)) continue;
            long l10 = \u13e8;
            block24: while (true) {
                switch ((int)l10) {
                    case -2729348: {
                        l10 = (0x182DL ^ 0x68894D4701AC5793L) / (0x44C7L ^ 0xB372F7D956DE9F48L);
                        continue block24;
                    }
                    case 1415186628: {
                        break block24;
                    }
                }
                break;
            }
            long l11 = \u13e8;
            block25: while (true) {
                switch ((int)l11) {
                    case 1020043703: {
                        l11 = (0x48AAL ^ 0x9E1C351E896AB053L) / (0x28E5L ^ 0x9B525E9243B90CBFL);
                        continue block25;
                    }
                    case 1415186628: {
                        break block25;
                    }
                }
                break;
            }
            this.mapIdToTickCountBucket.remove(loggedMapId);
        }
    }

    /*
     * Unable to fully structure code
     */
    private void timeSpentOnMapUpdate(Integer currentMapId, List<Integer> cycleWorkMapIds) {
        block348: {
            block356: {
                block358: {
                    block357: {
                        block350: {
                            block355: {
                                block353: {
                                    block352: {
                                        block351: {
                                            block349: {
                                                block345: {
                                                    block347: {
                                                        block346: {
                                                            v0 = MapCycleModule.\u13e8;
                                                            if (true) ** GOTO lbl5
                                                            block245: while (true) {
                                                                v0 = v1 / (330L ^ 4948832499433671306L);
lbl5:
                                                                // 2 sources

                                                                switch ((int)v0) {
                                                                    case -2057094646: {
                                                                        v1 = 31274L ^ -3921960687191419268L;
                                                                        continue block245;
                                                                    }
                                                                    case -1254336082: {
                                                                        v1 = 21771L ^ -4671845380570903604L;
                                                                        continue block245;
                                                                    }
                                                                    case 1415186628: {
                                                                        break block245;
                                                                    }
                                                                }
                                                                break;
                                                            }
                                                            while (true) {
                                                                if ((v2 = (cfr_temp_0 = MapCycleModule.\u13e8 - (17819L ^ 6169165676364709316L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                                                                if (v2 == (21053 ^ -21054)) break;
                                                                v2 = 31208 ^ -131251469;
                                                            }
                                                            if (!this.adaptiveChecksConfig.ENABLE_ADAPTIVE_CHECKS) {
                                                                return;
                                                            }
                                                            v3 = MapCycleModule.\u13e8;
                                                            if (true) ** GOTO lbl25
                                                            block247: while (true) {
                                                                v3 = v4 / (6050L ^ 5490270424739069645L);
lbl25:
                                                                // 2 sources

                                                                switch ((int)v3) {
                                                                    case -1912408783: {
                                                                        v4 = 18052L ^ -8055364242649905326L;
                                                                        continue block247;
                                                                    }
                                                                    case -1201610751: {
                                                                        v4 = 1147L ^ -6228640302087310852L;
                                                                        continue block247;
                                                                    }
                                                                    case -901189665: {
                                                                        v4 = 31194L ^ -4314734233369214563L;
                                                                        continue block247;
                                                                    }
                                                                    case 1415186628: {
                                                                        break block247;
                                                                    }
                                                                }
                                                                break;
                                                            }
                                                            if (cycleWorkMapIds.size() <= (20966 ^ 20967)) {
                                                                return;
                                                            }
                                                            while (true) {
                                                                if ((v5 = (cfr_temp_1 = MapCycleModule.\u13e8 - (6577L ^ -2443131630809818689L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                                                                if (v5 == (27857 ^ -27858)) break;
                                                                v5 = 10332 ^ 1188811922;
                                                            }
                                                            if (this.timeSpentOnMapUpdateStartMs == null) break block346;
                                                            while (true) {
                                                                if ((v6 = (cfr_temp_2 = MapCycleModule.\u13e8 - (19619L ^ 513092312822236251L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                                                                if (v6 == (7049 ^ -7050)) break;
                                                                v6 = 20432 ^ -928070648;
                                                            }
                                                            v7 = System.currentTimeMillis();
                                                            v8 = MapCycleModule.\u13e8;
                                                            if (true) ** GOTO lbl55
                                                            block250: while (true) {
                                                                v8 = v9 / (24351L ^ -8152541017988482728L);
lbl55:
                                                                // 2 sources

                                                                switch ((int)v8) {
                                                                    case -1207903639: {
                                                                        v9 = 5781L ^ -5950399906854748398L;
                                                                        continue block250;
                                                                    }
                                                                    case 1415186628: {
                                                                        break block250;
                                                                    }
                                                                    case 1844793755: {
                                                                        v9 = 32248L ^ -4596231803852324784L;
                                                                        continue block250;
                                                                    }
                                                                }
                                                                break;
                                                            }
                                                            v10 = MapCycleModule.\u13e8;
                                                            if (true) ** GOTO lbl68
                                                            block251: while (true) {
                                                                v10 = v11 / (25552L ^ -6443862042544121293L);
lbl68:
                                                                // 2 sources

                                                                switch ((int)v10) {
                                                                    case -1195372440: {
                                                                        v11 = 31098L ^ 4486445601374475237L;
                                                                        continue block251;
                                                                    }
                                                                    case -1032790368: {
                                                                        v11 = 24070L ^ 8591676513439367267L;
                                                                        continue block251;
                                                                    }
                                                                    case 845749848: {
                                                                        v11 = 1749L ^ 210246550628115123L;
                                                                        continue block251;
                                                                    }
                                                                    case 1415186628: {
                                                                        break block251;
                                                                    }
                                                                }
                                                                break;
                                                            }
                                                            if (v7 - this.timeSpentOnMapUpdateStartMs <= 20000L >>> "\u0000\u0000".length()) break block347;
                                                        }
                                                        v12 = MapCycleModule.\u13e8;
                                                        if (true) ** GOTO lbl86
                                                        block252: while (true) {
                                                            v12 = (5091683667601731588L >>> "\u0000\u0000".length()) / (27927L ^ -5779149297234062975L);
lbl86:
                                                            // 2 sources

                                                            switch ((int)v12) {
                                                                case 79441123: {
                                                                    continue block252;
                                                                }
                                                                case 1415186628: {
                                                                    break block252;
                                                                }
                                                            }
                                                            break;
                                                        }
                                                        v13 = System.currentTimeMillis();
                                                        while (true) {
                                                            if ((v14 = (cfr_temp_3 = MapCycleModule.\u13e8 - (17493L ^ -2146600216373112936L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                                                            if (v14 == (2450 ^ -2451)) break;
                                                            v14 = 1840 ^ -1771800921;
                                                        }
                                                        v15 = v13;
                                                        while (true) {
                                                            if ((v16 = (cfr_temp_4 = MapCycleModule.\u13e8 - (13986L ^ -8958449691070166803L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                                                            if (v16 != "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                                                                v16 = 19014 ^ -1644391583;
                                                                continue;
                                                            }
                                                            break block345;
                                                            break;
                                                        }
                                                    }
                                                    return;
                                                }
                                                this.timeSpentOnMapUpdateStartMs = v15;
                                                v17 = MapCycleModule.\u13e8;
                                                if (true) ** GOTO lbl112
                                                block255: while (true) {
                                                    v17 = v18 / (31119L ^ -399592589623351628L);
lbl112:
                                                    // 2 sources

                                                    switch ((int)v17) {
                                                        case 52821661: {
                                                            v18 = 22094L ^ -1307024769769389476L;
                                                            continue block255;
                                                        }
                                                        case 1065006953: {
                                                            v18 = 25982L ^ -521858498221809549L;
                                                            continue block255;
                                                        }
                                                        case 1415186628: {
                                                            break block255;
                                                        }
                                                        case 1730680955: {
                                                            v18 = 16429L ^ -7618671776257184689L;
                                                            continue block255;
                                                        }
                                                    }
                                                    break;
                                                }
                                                while (true) {
                                                    if ((v19 = (cfr_temp_5 = MapCycleModule.\u13e8 - (16325L ^ -8793801284530560059L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                                                    if (v19 == (6809 ^ 6808)) break;
                                                    v19 = 32435 ^ 1603499822;
                                                }
                                                enableAdaptiveRefresh = this.adaptiveChecksConfig.ENABLE_AUTO_CONFIGURE_REFRESH_MAP;
                                                v20 = MapCycleModule.\u13e8;
                                                if (true) ** GOTO lbl134
                                                block257: while (true) {
                                                    v20 = v21 / (21429L ^ 2687469653424250445L);
lbl134:
                                                    // 2 sources

                                                    switch ((int)v20) {
                                                        case -876956686: {
                                                            v21 = 2568L ^ -3158300847040171248L;
                                                            continue block257;
                                                        }
                                                        case 898327380: {
                                                            v21 = 19063L ^ -2231629318693338406L;
                                                            continue block257;
                                                        }
                                                        case 968784186: {
                                                            v21 = -5692110168924488248L >>> "\u0000\u0000".length();
                                                            continue block257;
                                                        }
                                                        case 1415186628: {
                                                            break block257;
                                                        }
                                                    }
                                                    break;
                                                }
                                                v22 = MapCycleModule.\u13e8;
                                                if (true) ** GOTO lbl150
                                                block258: while (true) {
                                                    v22 = (23606L ^ 8993065018994484217L) / (22955L ^ -774716278295135914L);
lbl150:
                                                    // 2 sources

                                                    switch ((int)v22) {
                                                        case -1112013858: {
                                                            continue block258;
                                                        }
                                                        case 1415186628: {
                                                            break block258;
                                                        }
                                                    }
                                                    break;
                                                }
                                                enableAdaptiveKFL = this.adaptiveChecksConfig.ENABLE_AUTO_CONFIGURE_KFL;
                                                if (!enableAdaptiveRefresh && !enableAdaptiveKFL) break block348;
                                                v23 = MapCycleModule.\u13e8;
                                                if (true) ** GOTO lbl161
                                                block259: while (true) {
                                                    v23 = (17010L ^ -9215238066236830865L) / (6014L ^ -1725691611840026803L);
lbl161:
                                                    // 2 sources

                                                    switch ((int)v23) {
                                                        case 43354517: {
                                                            continue block259;
                                                        }
                                                        case 1415186628: {
                                                            break block259;
                                                        }
                                                    }
                                                    break;
                                                }
                                                v24 = MapCycleModule.\u13e8;
                                                if (true) ** GOTO lbl170
                                                block260: while (true) {
                                                    v24 = v25 / (8269L ^ -7409658744372261747L);
lbl170:
                                                    // 2 sources

                                                    switch ((int)v24) {
                                                        case -811403239: {
                                                            v25 = 167L ^ -6410622686294694125L;
                                                            continue block260;
                                                        }
                                                        case -413145185: {
                                                            v25 = 19025L ^ -9055407525062810394L;
                                                            continue block260;
                                                        }
                                                        case 786234394: {
                                                            v25 = 21719L ^ -6711130498573919109L;
                                                            continue block260;
                                                        }
                                                        case 1415186628: {
                                                            break block260;
                                                        }
                                                    }
                                                    break;
                                                }
                                                if (!this.adaptiveChecksConfig.RESET_ADAPTIVE_CHECK) break block349;
                                                while (true) {
                                                    if ((v26 = (cfr_temp_6 = MapCycleModule.\u13e8 - (7252L ^ -6667286008842037850L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                                                    if (v26 == (15456 ^ 15457)) break;
                                                    v26 = 9002 ^ 2011206507;
                                                }
                                                this.resetAdaptiveMapIdToTimeSpent();
                                                while (true) {
                                                    if ((v27 = (cfr_temp_7 = MapCycleModule.\u13e8 - (23053L ^ 4423130482994173916L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                                                    if (v27 == (12012 ^ -12013)) break;
                                                    v27 = 8695 ^ -713706447;
                                                }
                                                v28 = "".length() >>> "\u0000\u0000".length();
                                                v29 = MapCycleModule.\u13e8;
                                                if (true) ** GOTO lbl199
                                                block263: while (true) {
                                                    v29 = v30 / (17040L ^ -2547334198396795028L);
lbl199:
                                                    // 2 sources

                                                    switch ((int)v29) {
                                                        case 1188214202: {
                                                            v30 = 1335219150442852396L >>> "\u0000\u0000".length();
                                                            continue block263;
                                                        }
                                                        case 1415186628: {
                                                            break block263;
                                                        }
                                                        case 1500409729: {
                                                            v30 = 31783L ^ 5723004896657535703L;
                                                            continue block263;
                                                        }
                                                        case 1582466447: {
                                                            v30 = 27129L ^ 5736045428847660433L;
                                                            continue block263;
                                                        }
                                                    }
                                                    break;
                                                }
                                                this.adaptiveChecksConfig.RESET_ADAPTIVE_CHECK = v28;
                                            }
                                            v31 = MapCycleModule.\u13e8;
                                            if (true) ** GOTO lbl217
                                            block264: while (true) {
                                                v31 = (25363L ^ 8985684175585830923L) / (21348L ^ 7154610205110262854L);
lbl217:
                                                // 2 sources

                                                switch ((int)v31) {
                                                    case 1229752194: {
                                                        continue block264;
                                                    }
                                                    case 1415186628: {
                                                        break block264;
                                                    }
                                                }
                                                break;
                                            }
                                            if (this.preventTimeSpentUpdates) break block350;
                                            while (true) {
                                                if ((v32 = (cfr_temp_8 = MapCycleModule.\u13e8 - (15508L ^ -5683657832973097227L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                                                if (v32 == (20628 ^ 20629)) break;
                                                v32 = 19018 ^ 1846528288;
                                            }
                                            if (this.adaptiveCheckStartTimestampMs != null) break block351;
                                            v33 = MapCycleModule.\u13e8;
                                            if (true) ** GOTO lbl233
                                            block266: while (true) {
                                                v33 = v34 / (616596210324965188L >>> "\u0000\u0000".length());
lbl233:
                                                // 2 sources

                                                switch ((int)v33) {
                                                    case 787039705: {
                                                        v34 = 13650L ^ 2105096184290908535L;
                                                        continue block266;
                                                    }
                                                    case 915295467: {
                                                        v34 = 30814L ^ 7710509210960555927L;
                                                        continue block266;
                                                    }
                                                    case 1415186628: {
                                                        break block266;
                                                    }
                                                }
                                                break;
                                            }
                                            UserLogs.LogAdaptiveCheckStart(this);
                                            while (true) {
                                                if ((v35 = (cfr_temp_9 = MapCycleModule.\u13e8 - (5727L ^ -1466440797518746226L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
                                                if (v35 == (28327 ^ -28328)) break;
                                                v35 = 19651 ^ 1835428643;
                                            }
                                            v36 = System.currentTimeMillis();
                                            v37 = MapCycleModule.\u13e8;
                                            if (true) ** GOTO lbl253
                                            block268: while (true) {
                                                v37 = v38 / (18192L ^ 5672763211146567630L);
lbl253:
                                                // 2 sources

                                                switch ((int)v37) {
                                                    case -1567458255: {
                                                        v38 = 10820L ^ -8772204749626995244L;
                                                        continue block268;
                                                    }
                                                    case -262982191: {
                                                        v38 = 12549L ^ -5772480471877916941L;
                                                        continue block268;
                                                    }
                                                    case 1415186628: {
                                                        break block268;
                                                    }
                                                    case 1817736285: {
                                                        v38 = 13364L ^ -2866791201717520210L;
                                                        continue block268;
                                                    }
                                                }
                                                break;
                                            }
                                            v39 = v36;
                                            v40 = MapCycleModule.\u13e8;
                                            if (true) ** GOTO lbl270
                                            block269: while (true) {
                                                v40 = v41 / (7233L ^ 7942314615520046032L);
lbl270:
                                                // 2 sources

                                                switch ((int)v40) {
                                                    case 8798078: {
                                                        v41 = 31792L ^ -9015389825383298494L;
                                                        continue block269;
                                                    }
                                                    case 392030171: {
                                                        v41 = -810775789346989076L >>> "\u0000\u0000".length();
                                                        continue block269;
                                                    }
                                                    case 847667473: {
                                                        v41 = -2660362723383585700L >>> "\u0000\u0000".length();
                                                        continue block269;
                                                    }
                                                    case 1415186628: {
                                                        break block269;
                                                    }
                                                }
                                                break;
                                            }
                                            this.adaptiveCheckStartTimestampMs = v39;
                                            return;
                                        }
                                        v42 = MapCycleModule.\u13e8;
                                        if (true) ** GOTO lbl289
                                        block270: while (true) {
                                            v42 = v43 / (4355L ^ -488707842244046607L);
lbl289:
                                            // 2 sources

                                            switch ((int)v42) {
                                                case 72577290: {
                                                    v43 = 14581L ^ -8802660210867165867L;
                                                    continue block270;
                                                }
                                                case 1043764971: {
                                                    v43 = 20469L ^ 6107131820544899260L;
                                                    continue block270;
                                                }
                                                case 1105598983: {
                                                    v43 = 7154L ^ 3782861222438383925L;
                                                    continue block270;
                                                }
                                                case 1415186628: {
                                                    break block270;
                                                }
                                            }
                                            break;
                                        }
                                        while (true) {
                                            if ((v44 = (cfr_temp_10 = MapCycleModule.\u13e8 - (-9034421531979671500L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
                                            if (v44 == (32711 ^ -32712)) break;
                                            v44 = 14134 ^ -423316651;
                                        }
                                        if (this.mapIdToTickCountBucket.containsKey(currentMapId)) break block352;
                                        v45 = MapCycleModule.\u13e8;
                                        if (true) ** GOTO lbl311
                                        block272: while (true) {
                                            v45 = (11559L ^ 7022665135731322887L) / (9886L ^ 4791851678573863755L);
lbl311:
                                            // 2 sources

                                            switch ((int)v45) {
                                                case -2016082351: {
                                                    continue block272;
                                                }
                                                case 1415186628: {
                                                    break block272;
                                                }
                                            }
                                            break;
                                        }
                                        UserLogs.LogFirstTimeMapSeen(this, currentMapId);
                                        while (true) {
                                            if ((v46 = (cfr_temp_11 = MapCycleModule.\u13e8 - (6935L ^ -1212502493202442434L)) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
                                            if (v46 == (23808 ^ -23809)) break;
                                            v46 = 30113 ^ -1491083151;
                                        }
                                        v47 = 0L >>> "\u0000\u0000".length();
                                        while (true) {
                                            if ((v48 = (cfr_temp_12 = MapCycleModule.\u13e8 - (22150L ^ -4272351823366072883L)) == 0L ? 0 : (cfr_temp_12 < 0L ? -1 : 1)) == false) continue;
                                            if (v48 == (10967 ^ 10966)) break;
                                            v48 = 16638 ^ 1600813940;
                                        }
                                        v49 = v47;
                                        while (true) {
                                            if ((v50 = (cfr_temp_13 = MapCycleModule.\u13e8 - (14492L ^ 8325073226901336786L)) == 0L ? 0 : (cfr_temp_13 < 0L ? -1 : 1)) == false) continue;
                                            if (v50 == (9512 ^ -9513)) break;
                                            v50 = 23700 ^ -1384209480;
                                        }
                                        this.mapIdToTickCountBucket.put(currentMapId, v49);
                                        return;
                                    }
                                    v51 = MapCycleModule.\u13e8;
                                    if (true) ** GOTO lbl341
                                    block276: while (true) {
                                        v51 = v52 / (4553L ^ 6207737730608674108L);
lbl341:
                                        // 2 sources

                                        switch ((int)v51) {
                                            case -1782964928: {
                                                v52 = 10541L ^ 8696034593070244253L;
                                                continue block276;
                                            }
                                            case 1415186628: {
                                                break block276;
                                            }
                                            case 1475546924: {
                                                v52 = -3664244243778451008L >>> "\u0000\u0000".length();
                                                continue block276;
                                            }
                                            case 1578031249: {
                                                v52 = 12456L ^ 3605698391616498321L;
                                                continue block276;
                                            }
                                        }
                                        break;
                                    }
                                    while (true) {
                                        if ((v53 = (cfr_temp_14 = MapCycleModule.\u13e8 - (35L ^ -5756277404096889527L)) == 0L ? 0 : (cfr_temp_14 < 0L ? -1 : 1)) == false) continue;
                                        if (v53 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                                        v53 = 4770 ^ -256310879;
                                    }
                                    v54 = MapCycleModule.\u13e8;
                                    if (true) ** GOTO lbl362
                                    block278: while (true) {
                                        v54 = v55 / (2849L ^ 8215512506113406500L);
lbl362:
                                        // 2 sources

                                        switch ((int)v54) {
                                            case 612856443: {
                                                v55 = 24695L ^ -2725262547609946268L;
                                                continue block278;
                                            }
                                            case 1415186628: {
                                                break block278;
                                            }
                                            case 1799318766: {
                                                v55 = 2212L ^ -4700238128226307782L;
                                                continue block278;
                                            }
                                        }
                                        break;
                                    }
                                    currentTickCountBucket = this.mapIdToTickCountBucket.get(currentMapId);
                                    v56 = MapCycleModule.\u13e8;
                                    if (true) ** GOTO lbl376
                                    block279: while (true) {
                                        v56 = v57 / (22158L ^ 6566534240422206322L);
lbl376:
                                        // 2 sources

                                        switch ((int)v56) {
                                            case -1909774818: {
                                                v57 = 27140L ^ -1034959304135207869L;
                                                continue block279;
                                            }
                                            case 266331544: {
                                                v57 = 15436L ^ -4450931353240179246L;
                                                continue block279;
                                            }
                                            case 1415186628: {
                                                break block279;
                                            }
                                        }
                                        break;
                                    }
                                    v58 = MapCycleModule.\u13e8;
                                    if (true) ** GOTO lbl389
                                    block280: while (true) {
                                        v58 = (27737L ^ 7233625606930220368L) / (3431L ^ -7527073867017548764L);
lbl389:
                                        // 2 sources

                                        switch ((int)v58) {
                                            case -241297960: {
                                                continue block280;
                                            }
                                            case 1415186628: {
                                                break block280;
                                            }
                                        }
                                        break;
                                    }
                                    v59 = MapCycleModule.\u13e8;
                                    if (true) ** GOTO lbl398
                                    block281: while (true) {
                                        v59 = v60 / (32257L ^ -109547196963120783L);
lbl398:
                                        // 2 sources

                                        switch ((int)v59) {
                                            case -1495790622: {
                                                v60 = 31612L ^ -6047034577898517580L;
                                                continue block281;
                                            }
                                            case -1078405150: {
                                                v60 = 21255L ^ 4074826529298590223L;
                                                continue block281;
                                            }
                                            case -888989661: {
                                                v60 = 8521L ^ -5017187757967262739L;
                                                continue block281;
                                            }
                                            case 1415186628: {
                                                break block281;
                                            }
                                        }
                                        break;
                                    }
                                    v61 = this.adaptiveChecksConfig.ADAPTIVE_CHECK_MINUTES;
                                    while (true) {
                                        if ((v62 = (cfr_temp_15 = MapCycleModule.\u13e8 - (14781L ^ -2763011445550978873L)) == 0L ? 0 : (cfr_temp_15 < 0L ? -1 : 1)) == false) continue;
                                        if (v62 == (30133 ^ -30134)) break;
                                        v62 = 2082 ^ -1034105608;
                                    }
                                    adaptiveCheckMs = TimeUnit.MINUTES.toMillis(v61);
                                    while (true) {
                                        if ((v63 = (cfr_temp_16 = MapCycleModule.\u13e8 - (-157855265745234400L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_16 < 0L ? -1 : 1)) == false) continue;
                                        if (v63 == (771 ^ -772)) break;
                                        v63 = 27095 ^ -852894078;
                                    }
                                    v64 = System.currentTimeMillis();
                                    v65 = MapCycleModule.\u13e8;
                                    if (true) ** GOTO lbl427
                                    block284: while (true) {
                                        v65 = v66 / (1238L ^ -3753375909855131723L);
lbl427:
                                        // 2 sources

                                        switch ((int)v65) {
                                            case -1196554111: {
                                                v66 = 15023L ^ 1695818928016236803L;
                                                continue block284;
                                            }
                                            case 1131989841: {
                                                v66 = 6034L ^ -864489276506243210L;
                                                continue block284;
                                            }
                                            case 1363380272: {
                                                v66 = 10007L ^ -9091822852545206866L;
                                                continue block284;
                                            }
                                            case 1415186628: {
                                                break block284;
                                            }
                                        }
                                        break;
                                    }
                                    v67 = MapCycleModule.\u13e8;
                                    if (true) ** GOTO lbl443
                                    block285: while (true) {
                                        v67 = v68 / (3832L ^ 8178356568139464378L);
lbl443:
                                        // 2 sources

                                        switch ((int)v67) {
                                            case 667308525: {
                                                v68 = 25768L ^ 7121632935582257718L;
                                                continue block285;
                                            }
                                            case 1231855779: {
                                                v68 = 23112L ^ -2318809085262142313L;
                                                continue block285;
                                            }
                                            case 1415186628: {
                                                break block285;
                                            }
                                            case 1719404877: {
                                                v68 = 27094L ^ 5909717522925992871L;
                                                continue block285;
                                            }
                                        }
                                        break;
                                    }
                                    msEllapsed = v64 - this.adaptiveCheckStartTimestampMs;
                                    if (msEllapsed >= adaptiveCheckMs) break block353;
                                    while (true) {
                                        if ((v69 = (cfr_temp_17 = MapCycleModule.\u13e8 - (19322L ^ 8290739942124885213L)) == 0L ? 0 : (cfr_temp_17 < 0L ? -1 : 1)) == false) continue;
                                        if (v69 == (26247 ^ -26248)) break;
                                        v69 = 10638 ^ -1528566594;
                                    }
                                    while (true) {
                                        if ((v70 = (cfr_temp_18 = MapCycleModule.\u13e8 - (9677L ^ -6225015883090519312L)) == 0L ? 0 : (cfr_temp_18 < 0L ? -1 : 1)) == false) continue;
                                        if (v70 == (21669 ^ 21668)) break;
                                        v70 = 928 ^ -64035754;
                                    }
                                    v71 = currentTickCountBucket + (27950L ^ 27951L);
                                    v72 = MapCycleModule.\u13e8;
                                    if (true) ** GOTO lbl472
                                    block288: while (true) {
                                        v72 = (21888L ^ 6428404200080470696L) / (26750L ^ -7317248446994945470L);
lbl472:
                                        // 2 sources

                                        switch ((int)v72) {
                                            case -1527040143: {
                                                continue block288;
                                            }
                                            case 1415186628: {
                                                break block288;
                                            }
                                        }
                                        break;
                                    }
                                    this.mapIdToTickCountBucket.replace(currentMapId, v71);
                                    return;
                                }
                                v73 = MapCycleModule.\u13e8;
                                if (true) ** GOTO lbl485
                                block289: while (true) {
                                    v73 = v74 / (8463L ^ -1028191253692734708L);
lbl485:
                                    // 2 sources

                                    switch ((int)v73) {
                                        case -2006779990: {
                                            v74 = 2482240588535431220L >>> "\u0000\u0000".length();
                                            continue block289;
                                        }
                                        case -669195472: {
                                            v74 = 19784L ^ -6927429864591257092L;
                                            continue block289;
                                        }
                                        case 1415186628: {
                                            break block289;
                                        }
                                        case 1437578966: {
                                            v74 = 8103L ^ -1262850548958551335L;
                                            continue block289;
                                        }
                                    }
                                    break;
                                }
                                this.clearNonCycleMaps(cycleWorkMapIds);
                                mapIdLongestTimeSpentBucketEntry = null;
                                while (true) {
                                    if ((v75 = (cfr_temp_19 = MapCycleModule.\u13e8 - (27530L ^ 6896332063828545111L)) == 0L ? 0 : (cfr_temp_19 < 0L ? -1 : 1)) == false) continue;
                                    if (v75 == (10078 ^ -10079)) break;
                                    v75 = 28455 ^ 826081935;
                                }
                                while (true) {
                                    if ((v76 = (cfr_temp_20 = MapCycleModule.\u13e8 - (20064L ^ 8970457272714715838L)) == 0L ? 0 : (cfr_temp_20 < 0L ? -1 : 1)) == false) continue;
                                    if (v76 == (2267 ^ -2268)) break;
                                    v76 = 6220 ^ 2140740252;
                                }
                                v77 = this.mapIdToTickCountBucket.entrySet();
                                v78 = MapCycleModule.\u13e8;
                                if (true) ** GOTO lbl514
                                block292: while (true) {
                                    v78 = v79 / (18243L ^ -5004418768549118201L);
lbl514:
                                    // 2 sources

                                    switch ((int)v78) {
                                        case -776656065: {
                                            v79 = 389L ^ 5586515220910345229L;
                                            continue block292;
                                        }
                                        case -538700224: {
                                            v79 = 31449L ^ 4671105371756704304L;
                                            continue block292;
                                        }
                                        case 1415186628: {
                                            break block292;
                                        }
                                        case 1499454456: {
                                            v79 = 1330L ^ -5800278188399288222L;
                                            continue block292;
                                        }
                                    }
                                    break;
                                }
                                var12_14 = v77.iterator();
                                while (true) {
                                    block354: {
                                        if ((v80 = (cfr_temp_21 = MapCycleModule.\u13e8 - (11587L ^ -3066049097945817305L)) == 0L ? 0 : (cfr_temp_21 < 0L ? -1 : 1)) == false) continue;
                                        if (v80 != "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                                            v80 = 3324 ^ -849723965;
                                            continue;
                                        }
                                        if (!var12_14.hasNext()) break;
                                        while (true) {
                                            if ((v81 = (cfr_temp_22 = MapCycleModule.\u13e8 - (5634L ^ 8582308277890933826L)) == 0L ? 0 : (cfr_temp_22 < 0L ? -1 : 1)) == false) continue;
                                            if (v81 == (19201 ^ -19202)) break;
                                            v81 = 2648 ^ -456445341;
                                        }
                                        entry = var12_14.next();
                                        if (mapIdLongestTimeSpentBucketEntry == null) break block354;
                                        while (true) {
                                            if ((v82 = (cfr_temp_23 = MapCycleModule.\u13e8 - (20723L ^ -13623694659347167L)) == 0L ? 0 : (cfr_temp_23 < 0L ? -1 : 1)) == false) continue;
                                            if (v82 == (26258 ^ -26259)) break;
                                            v82 = 20341 ^ -1628229746;
                                        }
                                        while (true) {
                                            if ((v83 = (cfr_temp_24 = MapCycleModule.\u13e8 - (9768L ^ -2576194333624652908L)) == 0L ? 0 : (cfr_temp_24 < 0L ? -1 : 1)) == false) continue;
                                            if (v83 == (9608 ^ -9609)) break;
                                            v83 = 25545 ^ 665614000;
                                        }
                                        v84 = MapCycleModule.\u13e8;
                                        if (true) ** GOTO lbl554
                                        block297: while (true) {
                                            v84 = v85 / (31646L ^ -1379429662916015784L);
lbl554:
                                            // 2 sources

                                            switch ((int)v84) {
                                                case -191991619: {
                                                    v85 = -8679774277399369216L >>> "\u0000\u0000".length();
                                                    continue block297;
                                                }
                                                case 201455844: {
                                                    v85 = 4109L ^ 7699337196085497274L;
                                                    continue block297;
                                                }
                                                case 1373652872: {
                                                    v85 = -8238208112395226792L >>> "\u0000\u0000".length();
                                                    continue block297;
                                                }
                                                case 1415186628: {
                                                    break block297;
                                                }
                                            }
                                            break;
                                        }
                                        if (entry.getValue().compareTo(mapIdLongestTimeSpentBucketEntry.getValue()) <= 0) continue;
                                    }
                                    mapIdLongestTimeSpentBucketEntry = entry;
                                }
                                if (mapIdLongestTimeSpentBucketEntry == null) break block355;
                                v86 = MapCycleModule.\u13e8;
                                if (true) ** GOTO lbl575
                                block298: while (true) {
                                    v86 = (19128L ^ -8916897034150394642L) / (3416813656649983144L >>> "\u0000\u0000".length());
lbl575:
                                    // 2 sources

                                    switch ((int)v86) {
                                        case 1158139490: {
                                            continue block298;
                                        }
                                        case 1415186628: {
                                            break block298;
                                        }
                                    }
                                    break;
                                }
                                this.cachedLongestTimeSpentEntry = mapIdLongestTimeSpentBucketEntry;
                                v87 = MapCycleModule.\u13e8;
                                if (true) ** GOTO lbl585
                                block299: while (true) {
                                    v87 = v88 / (672162946916329004L >>> "\u0000\u0000".length());
lbl585:
                                    // 2 sources

                                    switch ((int)v87) {
                                        case -1471408339: {
                                            v88 = 20636L ^ -342050080012349029L;
                                            continue block299;
                                        }
                                        case -1100021011: {
                                            v88 = 20536L ^ -1513815744624892415L;
                                            continue block299;
                                        }
                                        case -50040007: {
                                            v88 = 17446L ^ -1928494006379466858L;
                                            continue block299;
                                        }
                                        case 1415186628: {
                                            break block299;
                                        }
                                    }
                                    break;
                                }
                                v89 = (Integer)mapIdLongestTimeSpentBucketEntry.getKey();
                                while (true) {
                                    if ((v90 = (cfr_temp_25 = MapCycleModule.\u13e8 - (20541L ^ -1498623407274265277L)) == 0L ? 0 : (cfr_temp_25 < 0L ? -1 : 1)) == false) continue;
                                    if (v90 == (26384 ^ -26385)) {
                                        UserLogs.LogDiscoveredLongestMap(this, v89);
                                        break;
                                    }
                                    v90 = 28434 ^ 1789593929;
                                }
                            }
                            while (true) {
                                if ((v91 = (cfr_temp_26 = MapCycleModule.\u13e8 - (883L ^ 4487641468654253919L)) == 0L ? 0 : (cfr_temp_26 < 0L ? -1 : 1)) == false) continue;
                                if (v91 == (11220 ^ -11221)) {
                                    this.preventTimeSpentUpdates = 25240 ^ 25241;
                                    break;
                                }
                                v91 = 22274 ^ -879807069;
                            }
                        }
                        while (true) {
                            if ((v92 = (cfr_temp_27 = MapCycleModule.\u13e8 - (31863L ^ 8242368003125765760L)) == 0L ? 0 : (cfr_temp_27 < 0L ? -1 : 1)) == false) continue;
                            if (v92 == (6364 ^ -6365)) break;
                            v92 = 28001 ^ -1271975198;
                        }
                        if (this.cachedLongestTimeSpentEntry == null) break block348;
                        v93 = MapCycleModule.\u13e8;
                        if (true) ** GOTO lbl624
                        block303: while (true) {
                            v93 = v94 / (5455L ^ -2713484986565731673L);
lbl624:
                            // 2 sources

                            switch ((int)v93) {
                                case -391748083: {
                                    v94 = 29870L ^ -5483465763936648618L;
                                    continue block303;
                                }
                                case -132998861: {
                                    v94 = 8535815466300562656L >>> "\u0000\u0000".length();
                                    continue block303;
                                }
                                case 1062725190: {
                                    v94 = -2404024893580693236L >>> "\u0000\u0000".length();
                                    continue block303;
                                }
                                case 1415186628: {
                                    break block303;
                                }
                            }
                            break;
                        }
                        while (true) {
                            if ((v95 = (cfr_temp_28 = MapCycleModule.\u13e8 - (26850L ^ -6719901327151486758L)) == 0L ? 0 : (cfr_temp_28 < 0L ? -1 : 1)) == false) continue;
                            if (v95 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                            v95 = 2500 ^ 1891906278;
                        }
                        cachedLongestTimeSpentMapId = this.cachedLongestTimeSpentEntry.getKey();
                        v96 = MapCycleModule.\u13e8;
                        if (true) ** GOTO lbl646
                        block305: while (true) {
                            v96 = (15096L ^ -1654298789151561831L) / (29092L ^ 8925706455032134145L);
lbl646:
                            // 2 sources

                            switch ((int)v96) {
                                case 985395969: {
                                    continue block305;
                                }
                                case 1415186628: {
                                    break block305;
                                }
                            }
                            break;
                        }
                        this.longestWaitCycleMapId = cachedLongestTimeSpentMapId;
                        while (true) {
                            if ((v97 = (cfr_temp_29 = MapCycleModule.\u13e8 - (14216L ^ -7456307730337976707L)) == 0L ? 0 : (cfr_temp_29 < 0L ? -1 : 1)) == false) continue;
                            if (v97 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                            v97 = 3195 ^ -300555787;
                        }
                        longestTimeSpentMapIdIndex = cycleWorkMapIds.indexOf(cachedLongestTimeSpentMapId);
                        if (longestTimeSpentMapIdIndex < 0) break block356;
                        while (true) {
                            if ((v98 = (cfr_temp_30 = MapCycleModule.\u13e8 - (31728L ^ 6001722581144241650L)) == 0L ? 0 : (cfr_temp_30 < 0L ? -1 : 1)) == false) continue;
                            if (v98 == (6009 ^ -6010)) break;
                            v98 = 8274 ^ -202204127;
                        }
                        while (true) {
                            if ((v99 = (cfr_temp_31 = MapCycleModule.\u13e8 - (26065L ^ 4481037101505164369L)) == 0L ? 0 : (cfr_temp_31 < 0L ? -1 : 1)) == false) continue;
                            if (v99 == (24954 ^ -24955)) break;
                            v99 = 8038 ^ 1394114677;
                        }
                        workMapInfos = new ArrayList<MapInfo>();
                        while (true) {
                            if ((v100 = (cfr_temp_32 = MapCycleModule.\u13e8 - (30266L ^ -3502362370490124750L)) == 0L ? 0 : (cfr_temp_32 < 0L ? -1 : 1)) == false) continue;
                            if (v100 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                            v100 = 22877 ^ -679785414;
                        }
                        v101 = MapCycleModule.\u13e8;
                        if (true) ** GOTO lbl679
                        block310: while (true) {
                            v101 = v102 / (21755L ^ 4016202266333367790L);
lbl679:
                            // 2 sources

                            switch ((int)v101) {
                                case -1870334032: {
                                    v102 = 6315L ^ 5528214392949029831L;
                                    continue block310;
                                }
                                case -1631236392: {
                                    v102 = 22068L ^ -3993812472224985946L;
                                    continue block310;
                                }
                                case 1415186628: {
                                    break block310;
                                }
                            }
                            break;
                        }
                        v103 = this.mapCycleConfig.CYCLE_MAP_INFOS;
                        while (true) {
                            if ((v104 = (cfr_temp_33 = MapCycleModule.\u13e8 - (4827L ^ -7657189129728804956L)) == 0L ? 0 : (cfr_temp_33 < 0L ? -1 : 1)) == false) continue;
                            if (v104 == (15999 ^ 15998)) break;
                            v104 = 25099 ^ 1367866264;
                        }
                        v105 = v103.values();
                        v106 = MapCycleModule.\u13e8;
                        if (true) ** GOTO lbl699
                        block312: while (true) {
                            v106 = v107 / (3473L ^ -6097760108897357757L);
lbl699:
                            // 2 sources

                            switch ((int)v106) {
                                case -1262201479: {
                                    v107 = 20241L ^ -4051978629501148020L;
                                    continue block312;
                                }
                                case 1242348213: {
                                    v107 = 28940L ^ -1562537433939868213L;
                                    continue block312;
                                }
                                case 1415186628: {
                                    break block312;
                                }
                            }
                            break;
                        }
                        var8_17 = v105.iterator();
                        while (true) {
                            v108 = MapCycleModule.\u13e8;
                            if (true) ** GOTO lbl714
                            block314: while (true) {
                                v108 = v109 / (15233L ^ -4723413332244648623L);
lbl714:
                                // 2 sources

                                switch ((int)v108) {
                                    case 481262766: {
                                        v109 = 8477L ^ 4657463078954500398L;
                                        continue block314;
                                    }
                                    case 1415186628: {
                                        break block314;
                                    }
                                    case 2082420861: {
                                        v109 = 2210L ^ -7089683356851868579L;
                                        continue block314;
                                    }
                                }
                                break;
                            }
                            if (!var8_17.hasNext()) break;
                            v110 = MapCycleModule.\u13e8;
                            if (true) ** GOTO lbl728
                            block315: while (true) {
                                v110 = v111 / (8536L ^ -6802399842008836165L);
lbl728:
                                // 2 sources

                                switch ((int)v110) {
                                    case 179522956: {
                                        v111 = 1307629933146902368L >>> "\u0000\u0000".length();
                                        continue block315;
                                    }
                                    case 642851302: {
                                        v111 = 2730L ^ -3539431139955492146L;
                                        continue block315;
                                    }
                                    case 1415186628: {
                                        break block315;
                                    }
                                }
                                break;
                            }
                            cycleMapInfo = var8_17.next();
                            while (true) {
                                if ((v112 = (cfr_temp_34 = MapCycleModule.\u13e8 - (6480L ^ 3204852495263046103L)) == 0L ? 0 : (cfr_temp_34 < 0L ? -1 : 1)) == false) continue;
                                if (v112 == (515 ^ -516)) break;
                                v112 = 28969 ^ -1919480088;
                            }
                            cycleMapId = cycleMapInfo.cachedMapId;
                            if (cycleMapId == null) continue;
                            while (true) {
                                if ((v113 = (cfr_temp_35 = MapCycleModule.\u13e8 - (17156L ^ -5449267136269267589L)) == 0L ? 0 : (cfr_temp_35 < 0L ? -1 : 1)) == false) continue;
                                if (v113 == (24787 ^ 24786)) break;
                                v113 = -1571761104 >>> "\u0000\u0000".length();
                            }
                            if (!cycleWorkMapIds.contains(cycleMapId)) continue;
                            v114 = MapCycleModule.\u13e8;
                            if (true) ** GOTO lbl755
                            block318: while (true) {
                                v114 = (11371L ^ -3102955740984403549L) / (19256L ^ 4662627167609354431L);
lbl755:
                                // 2 sources

                                switch ((int)v114) {
                                    case 941558364: {
                                        continue block318;
                                    }
                                    case 1415186628: {
                                        break block318;
                                    }
                                }
                                break;
                            }
                            workMapInfos.add(cycleMapInfo);
                        }
                        if (!enableAdaptiveRefresh) break block357;
                        v115 = longestTimeSpentMapIdIndex - ("\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length());
                        v116 = MapCycleModule.\u13e8;
                        if (true) ** GOTO lbl769
                        block319: while (true) {
                            v116 = (29509L ^ 5899681636387203372L) / (23826L ^ -8369662376376237749L);
lbl769:
                            // 2 sources

                            switch ((int)v116) {
                                case 417296506: {
                                    continue block319;
                                }
                                case 1415186628: {
                                    break block319;
                                }
                            }
                            break;
                        }
                        v117 = cycleWorkMapIds.size();
                        v118 = MapCycleModule.\u13e8;
                        if (true) ** GOTO lbl779
                        block320: while (true) {
                            v118 = (15463L ^ 7457719849965228579L) / (7723L ^ 7299171163617169187L);
lbl779:
                            // 2 sources

                            switch ((int)v118) {
                                case -592517059: {
                                    continue block320;
                                }
                                case 1415186628: {
                                    break block320;
                                }
                            }
                            break;
                        }
                        refreshableMapIdIndex = Math.floorMod(v115, v117);
                        while (true) {
                            if ((v119 = (cfr_temp_36 = MapCycleModule.\u13e8 - (11553L ^ 2889116284992838312L)) == 0L ? 0 : (cfr_temp_36 < 0L ? -1 : 1)) == false) continue;
                            if (v119 == (21077 ^ -21078)) break;
                            v119 = 32262 ^ 582063379;
                        }
                        refreshableMapId = cycleWorkMapIds.get(refreshableMapIdIndex);
                        v120 = MapCycleModule.\u13e8;
                        if (true) ** GOTO lbl795
                        block322: while (true) {
                            v120 = (1152L ^ -1232377774358644720L) / (14388L ^ -8222590967908370595L);
lbl795:
                            // 2 sources

                            switch ((int)v120) {
                                case -90702173: {
                                    continue block322;
                                }
                                case 1415186628: {
                                    break block322;
                                }
                            }
                            break;
                        }
                        var10_19 = workMapInfos.iterator();
                        while (true) {
                            v121 = MapCycleModule.\u13e8;
                            if (true) ** GOTO lbl806
                            block324: while (true) {
                                v121 = v122 / (30723L ^ -7343185972564146201L);
lbl806:
                                // 2 sources

                                switch ((int)v121) {
                                    case -1000960671: {
                                        v122 = 20040L ^ -8461733508596841441L;
                                        continue block324;
                                    }
                                    case -222290147: {
                                        v122 = 6990L ^ -7423664355373071254L;
                                        continue block324;
                                    }
                                    case 980543594: {
                                        v122 = 647L ^ 4993010882189407109L;
                                        continue block324;
                                    }
                                    case 1415186628: {
                                        break block324;
                                    }
                                }
                                break;
                            }
                            if (!var10_19.hasNext()) break;
                            while (true) {
                                if ((v123 = (cfr_temp_37 = MapCycleModule.\u13e8 - (91L ^ 7081310644025517801L)) == 0L ? 0 : (cfr_temp_37 < 0L ? -1 : 1)) == false) continue;
                                if (v123 == (27309 ^ -27310)) break;
                                v123 = 22610 ^ -1067468207;
                            }
                            workMapInfo = (MapInfo)var10_19.next();
                            v124 = MapCycleModule.\u13e8;
                            if (true) ** GOTO lbl829
                            block326: while (true) {
                                v124 = v125 / (5947L ^ 5858794026373043633L);
lbl829:
                                // 2 sources

                                switch ((int)v124) {
                                    case -640563654: {
                                        v125 = 22500L ^ -2465652818109407267L;
                                        continue block326;
                                    }
                                    case 1415186628: {
                                        break block326;
                                    }
                                    case 1889836384: {
                                        v125 = 3347L ^ -533838778913833624L;
                                        continue block326;
                                    }
                                }
                                break;
                            }
                            v126 = workMapInfo.cachedMapId;
                            v127 = MapCycleModule.\u13e8;
                            if (true) ** GOTO lbl843
                            block327: while (true) {
                                v127 = v128 / (16728L ^ 6538248857342678534L);
lbl843:
                                // 2 sources

                                switch ((int)v127) {
                                    case -694890653: {
                                        v128 = 26495L ^ 2202552065629809210L;
                                        continue block327;
                                    }
                                    case 1088564061: {
                                        v128 = 11412L ^ -3667798387627564416L;
                                        continue block327;
                                    }
                                    case 1415186628: {
                                        break block327;
                                    }
                                }
                                break;
                            }
                            v129 = v126.equals(refreshableMapId);
                            v130 = MapCycleModule.\u13e8;
                            if (true) ** GOTO lbl857
                            block328: while (true) {
                                v130 = (21632L ^ 7502612702076658329L) / (22343L ^ 6587273246599405513L);
lbl857:
                                // 2 sources

                                switch ((int)v130) {
                                    case -2128069283: {
                                        continue block328;
                                    }
                                    case 1415186628: {
                                        break block328;
                                    }
                                }
                                break;
                            }
                            workMapInfo.isRefreshable = v129;
                        }
                    }
                    if (!enableAdaptiveKFL) break block358;
                    v131 = MapCycleModule.\u13e8;
                    if (true) ** GOTO lbl870
                    block329: while (true) {
                        v131 = v132 / (8446L ^ 4636722546992777307L);
lbl870:
                        // 2 sources

                        switch ((int)v131) {
                            case -1812885632: {
                                v132 = 16495L ^ -7245005039336049090L;
                                continue block329;
                            }
                            case -287859227: {
                                v132 = -4392622458258751252L >>> "\u0000\u0000".length();
                                continue block329;
                            }
                            case 1415186628: {
                                break block329;
                            }
                        }
                        break;
                    }
                    var8_17 = workMapInfos.iterator();
                    while (true) {
                        if ((v133 = (cfr_temp_38 = MapCycleModule.\u13e8 - (16868L ^ -1837456679106719275L)) == 0L ? 0 : (cfr_temp_38 < 0L ? -1 : 1)) == false) continue;
                        if (v133 != (6311 ^ -6312)) {
                            v133 = 14453 ^ -900616659;
                            continue;
                        }
                        if (!var8_17.hasNext()) break;
                        while (true) {
                            if ((v134 = (cfr_temp_39 = MapCycleModule.\u13e8 - (29317L ^ -6817625372436759230L)) == 0L ? 0 : (cfr_temp_39 < 0L ? -1 : 1)) == false) continue;
                            if (v134 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                            v134 = 4605 ^ 68343737;
                        }
                        workMapInfo = var8_17.next();
                        while (true) {
                            if ((v135 = (cfr_temp_40 = MapCycleModule.\u13e8 - (31016L ^ -5788841651402943134L)) == 0L ? 0 : (cfr_temp_40 < 0L ? -1 : 1)) == false) continue;
                            if (v135 == (308 ^ 309)) break;
                            v135 = 1238246856 >>> "\u0000\u0000".length();
                        }
                        v136 = workMapInfo.cachedMapId;
                        v137 = MapCycleModule.\u13e8;
                        if (true) ** GOTO lbl902
                        block333: while (true) {
                            v137 = v138 / (9326L ^ 7852197497209825468L);
lbl902:
                            // 2 sources

                            switch ((int)v137) {
                                case -562871462: {
                                    v138 = 25079L ^ 4698491390085361973L;
                                    continue block333;
                                }
                                case 1161041570: {
                                    v138 = 22741L ^ 8819141746160902159L;
                                    continue block333;
                                }
                                case 1235720369: {
                                    v138 = 26089L ^ -7645269085708471676L;
                                    continue block333;
                                }
                                case 1415186628: {
                                    break block333;
                                }
                            }
                            break;
                        }
                        v139 = v136.equals(cachedLongestTimeSpentMapId) == false ? 9103 ^ 9102 : 18067 ^ 18067;
                        v140 = MapCycleModule.\u13e8;
                        if (true) ** GOTO lbl919
                        block334: while (true) {
                            v140 = v141 / (23417L ^ -274435262571266833L);
lbl919:
                            // 2 sources

                            switch ((int)v140) {
                                case -2090391145: {
                                    v141 = 18883L ^ 4058370071133163302L;
                                    continue block334;
                                }
                                case -697171478: {
                                    v141 = 20878L ^ -2657838446054310745L;
                                    continue block334;
                                }
                                case 1415186628: {
                                    break block334;
                                }
                            }
                            break;
                        }
                        workMapInfo.enableKeyPressOnFirstLock = v139;
                    }
                }
                v142 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl935
                block335: while (true) {
                    v142 = (343L ^ 616668105901383993L) / (30738L ^ -5451934421869796538L);
lbl935:
                    // 2 sources

                    switch ((int)v142) {
                        case 1415186628: {
                            break block335;
                        }
                        case 2094742025: {
                            continue block335;
                        }
                    }
                    break;
                }
                this.cachedLongestTimeSpentEntry = null;
                break block348;
            }
            while (true) {
                if ((v143 = (cfr_temp_41 = MapCycleModule.\u13e8 - (3642L ^ -66480461161316244L)) == 0L ? 0 : (cfr_temp_41 < 0L ? -1 : 1)) == false) continue;
                if (v143 == (30414 ^ -30415)) {
                    this.resetAdaptiveMapIdToTimeSpent();
                    break;
                }
                v143 = 153635320 >>> "\u0000\u0000".length();
            }
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private boolean tryHandleRefreshConfigChangeRequirement() {
        int n;
        block30: {
            int n2;
            block31: {
                block29: {
                    long l = \u13e8;
                    boolean bl = true;
                    block15: while (true) {
                        long l2;
                        if (!bl || (bl = false) || !true) {
                            l = l2 / (0x8FDL ^ 0x548A9FCD76BE03B8L);
                        }
                        switch ((int)l) {
                            case -620738211: {
                                l2 = 0x6FA2L ^ 0xBE2D20E0E2C1675AL;
                                continue block15;
                            }
                            case -66579864: {
                                l2 = 0x32DEL ^ 0x7C90F3934E331B70L;
                                continue block15;
                            }
                            case 848368582: {
                                l2 = 0x70CEL ^ 0xE51A5FBDF1ACD915L;
                                continue block15;
                            }
                            case 1415186628: {
                                break block15;
                            }
                        }
                        break;
                    }
                    if (!this.requiresChangeToRefreshConfig) return (0x8F5 ^ 0x8F4) != 0;
                    while (true) {
                        long l3;
                        long l4;
                        if ((l4 = (l3 = \u13e8 - (0x1B42L ^ 0x3E8573CE456425BDL)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) {
                            continue;
                        }
                        if (l4 == (0x543C ^ 0xFFFFABC3)) {
                            if (!this.tryChangeToRefreshConfig()) {
                                break;
                            }
                            break block29;
                        }
                        l4 = 0x3D2C ^ 0xD27740BA;
                    }
                    n2 = 0x5E20 ^ 0x5E21;
                    break block31;
                }
                n2 = "".length() >>> "\u0000\u0000".length();
            }
            long l = \u13e8;
            boolean bl = true;
            block17: while (true) {
                long l5;
                if (!bl || (bl = false) || !true) {
                    l = l5 / (0x7F79L ^ 0xF619BE03ACF6C03CL);
                }
                switch ((int)l) {
                    case -1110819358: {
                        l5 = 0x1C91L ^ 0x72E3C5ED784B1E56L;
                        continue block17;
                    }
                    case 1181472915: {
                        l5 = 0x39D2L ^ 0xD49A2E0A18C04248L;
                        continue block17;
                    }
                    case 1415186628: {
                        break block17;
                    }
                }
                break;
            }
            this.requiresChangeToRefreshConfig = n2;
            while (true) {
                long l6;
                long l7;
                if ((l7 = (l6 = \u13e8 - (0x65E7L ^ 0xF50C594098A9497DL)) == 0L ? 0 : (l6 < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (l7 == (0x447B ^ 0xFFFFBB84)) {
                    if (this.requiresChangeToRefreshConfig) {
                        break;
                    }
                    break block30;
                }
                l7 = 0x54B7 ^ 0xAE67042B;
            }
            long l8 = \u13e8;
            block19: while (true) {
                switch ((int)l8) {
                    case 632927842: {
                        l8 = (0x72BCL ^ 0x19143B161FCDCD53L) / (0x13F2L ^ 0x8F4FF5B25AD367EFL);
                        continue block19;
                    }
                    case 1415186628: {
                        break block19;
                    }
                }
                break;
            }
            if (this.inWaitTicksPeriod()) {
                n = 0x73E8 ^ 0x73E8;
                return n != 0;
            }
        }
        n = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        return n != 0;
    }

    /*
     * Exception decompiling
     */
    public void backgroundTick() {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 8[SWITCH]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Unable to fully structure code
     */
    private void updateLicenseStatusLabel() {
        block32: {
            block35: {
                block34: {
                    block33: {
                        v0 = MapCycleModule.\u13e8;
                        if (true) ** GOTO lbl5
                        block21: while (true) {
                            v0 = v1 / (1293L ^ -2250623431879060594L);
lbl5:
                            // 2 sources

                            switch ((int)v0) {
                                case -171037216: {
                                    v1 = 32650L ^ 6583192666079063270L;
                                    continue block21;
                                }
                                case 478835065: {
                                    v1 = 30896L ^ -5474957727523811352L;
                                    continue block21;
                                }
                                case 517434734: {
                                    v1 = 8336L ^ -4427028428327028793L;
                                    continue block21;
                                }
                                case 1415186628: {
                                    break block21;
                                }
                            }
                            break;
                        }
                        v2 = System.currentTimeMillis();
                        while (true) {
                            if ((v3 = (cfr_temp_0 = MapCycleModule.\u13e8 - (5207L ^ -8164211003188029115L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                            if (v3 == (16925 ^ 16924)) break;
                            v3 = 26823 ^ -372303086;
                        }
                        if (v2 - this.lastUpdateLicenseStatusLabel <= 20000L >>> "\u0000\u0000".length()) break block33;
                        while (true) {
                            if ((v4 = (cfr_temp_1 = MapCycleModule.\u13e8 - (9717L ^ -4132858657949124825L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                            if (v4 == (9564 ^ 9565)) break;
                            v4 = 20058 ^ 1582022447;
                        }
                        v5 = System.currentTimeMillis();
                        v6 = MapCycleModule.\u13e8;
                        if (true) ** GOTO lbl34
                        block24: while (true) {
                            v6 = v7 / (37644871402337420L >>> "\u0000\u0000".length());
lbl34:
                            // 2 sources

                            switch ((int)v6) {
                                case 316035206: {
                                    v7 = 22593L ^ -8163681187488861479L;
                                    continue block24;
                                }
                                case 824157410: {
                                    v7 = 2548L ^ -5727703931963433867L;
                                    continue block24;
                                }
                                case 1415186628: {
                                    break block24;
                                }
                            }
                            break;
                        }
                        break block34;
                    }
                    return;
                }
                this.lastUpdateLicenseStatusLabel = v5;
                while (true) {
                    if ((v8 = (cfr_temp_2 = MapCycleModule.\u13e8 - (14420L ^ -6770482049499043302L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                    if (v8 == (14334 ^ 14335)) break;
                    v8 = 10824 ^ 402436791;
                }
                if (!this.__cachedHasLicense) break block35;
                v9 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl58
                block26: while (true) {
                    v9 = v10 / (15112L ^ 5938778975538751493L);
lbl58:
                    // 2 sources

                    switch ((int)v9) {
                        case -286750284: {
                            v10 = 18082L ^ -2688297315111219399L;
                            continue block26;
                        }
                        case 316199426: {
                            v10 = 21803L ^ -3029434716086551816L;
                            continue block26;
                        }
                        case 678970499: {
                            v10 = 10719L ^ -9100222541231781705L;
                            continue block26;
                        }
                        case 1415186628: {
                            break block26;
                        }
                    }
                    break;
                }
                var2_1 = new byte[22688 ^ 22706];
                var2_1[4701 ^ 4690] = 13034 ^ -12980;
                var2_1[936 ^ 935] = 440 >>> "\u0000\u0000".length();
                var2_1["".length() >>> "\u0000\u0000".length()] = 9575 ^ 9534;
                var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 25475 ^ 25507;
                var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 396 >>> "\u0000\u0000".length();
                var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 404 >>> "\u0000\u0000".length();
                var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 128 >>> "\u0000\u0000".length();
                var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 13376 ^ 13366;
                var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 460 >>> "\u0000\u0000".length();
                var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 388 >>> "\u0000\u0000".length();
                var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 388 >>> "\u0000\u0000".length();
                var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 416 >>> "\u0000\u0000".length();
                var2_1[29133 ^ 29126] = 29672 ^ 29572;
                var2_1[17624 ^ 17622] = 404 >>> "\u0000\u0000".length();
                var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 26270 ^ 26347;
                var2_1[4315 ^ 4316] = 404 >>> "\u0000\u0000".length();
                var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 420 >>> "\u0000\u0000".length();
                var2_1["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 444 >>> "\u0000\u0000".length();
                var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 128 >>> "\u0000\u0000".length();
                v11 = new String(var2_1);
                while (true) {
                    if ((v12 = (cfr_temp_3 = MapCycleModule.\u13e8 - (10884L ^ 451274526931142958L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                    if (v12 == (6161 ^ -6162)) {
                        this.twLicenseStatusLabel.setText(v11);
                        break block32;
                    }
                    v12 = 15228 ^ -429795986;
                }
            }
            v13 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl103
            block28: while (true) {
                v13 = (413L ^ 5535321731447604522L) / (21852L ^ -7835918949642653283L);
lbl103:
                // 2 sources

                switch ((int)v13) {
                    case -1295804072: {
                        continue block28;
                    }
                    case 1415186628: {
                        break block28;
                    }
                }
                break;
            }
            var2_2 = new byte[7002 ^ 6991];
            var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 18066 ^ 18168;
            var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 404 >>> "\u0000\u0000".length();
            var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 128 >>> "\u0000\u0000".length();
            var2_2[24873 ^ 24873] = 312 >>> "\u0000\u0000".length();
            var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 7321 ^ 7418;
            var2_2["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 7299 ^ 7404;
            var2_2[12518 ^ 12522] = 7475 ^ 7489;
            var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 31188 ^ 31220;
            var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 12738 ^ 12715;
            var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 128 >>> "\u0000\u0000".length();
            var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 420 >>> "\u0000\u0000".length();
            var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 456 >>> "\u0000\u0000".length();
            var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 480 >>> "\u0000\u0000".length();
            var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 29482 ^ 29530;
            var2_2[2197 ^ 2203] = 404 >>> "\u0000\u0000".length();
            var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 21666 ^ 21703;
            var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 11258 ^ 11158;
            var2_2[17875 ^ 17876] = 22559 ^ 22641;
            var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 4574 ^ 4538;
            var2_2[4804 ^ 4812] = 25817 ^ 25770;
            var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 18440 ^ 18535;
            var2_2[31320 ^ 31307] = 9334 ^ 9235;
            v14 = new String(var2_2);
            while (true) {
                if ((v15 = (cfr_temp_4 = MapCycleModule.\u13e8 - (7811L ^ -3960725675652800554L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v15 == (3261 ^ 3260)) {
                    this.twLicenseStatusLabel.setText(v14);
                    break;
                }
                v15 = 16573 ^ -1265169553;
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private void updateLicenseDisplayLabel() {
        block61: {
            block64: {
                block63: {
                    block62: {
                        v0 = MapCycleModule.\u13e8;
                        if (true) ** GOTO lbl5
                        block44: while (true) {
                            v0 = v1 / (31529L ^ -1427408475538886719L);
lbl5:
                            // 2 sources

                            switch ((int)v0) {
                                case -1911730230: {
                                    v1 = 6120L ^ 7816722852077831097L;
                                    continue block44;
                                }
                                case -1730952480: {
                                    v1 = 26346L ^ 5869287785569587582L;
                                    continue block44;
                                }
                                case 923284960: {
                                    v1 = -2969118074723370240L >>> "\u0000\u0000".length();
                                    continue block44;
                                }
                                case 1415186628: {
                                    break block44;
                                }
                            }
                            break;
                        }
                        v2 = System.currentTimeMillis();
                        v3 = MapCycleModule.\u13e8;
                        if (true) ** GOTO lbl22
                        block45: while (true) {
                            v3 = v4 / (5842L ^ -1457741683251865090L);
lbl22:
                            // 2 sources

                            switch ((int)v3) {
                                case -1007080468: {
                                    v4 = -8381903343982389640L >>> "\u0000\u0000".length();
                                    continue block45;
                                }
                                case 1172147552: {
                                    v4 = 3424924273278274176L >>> "\u0000\u0000".length();
                                    continue block45;
                                }
                                case 1415186628: {
                                    break block45;
                                }
                            }
                            break;
                        }
                        if (v2 - this.lastUpdateLicenseDisplayLabel <= 20000L >>> "\u0000\u0000".length()) break block62;
                        while (true) {
                            if ((v5 = (cfr_temp_0 = MapCycleModule.\u13e8 - (26081L ^ 3874115116213049554L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                            if (v5 == (3045 ^ -3046)) break;
                            v5 = 4681 ^ 687544133;
                        }
                        v6 = System.currentTimeMillis();
                        v7 = MapCycleModule.\u13e8;
                        if (true) ** GOTO lbl42
                        block47: while (true) {
                            v7 = v8 / (-6987545712561238960L >>> "\u0000\u0000".length());
lbl42:
                            // 2 sources

                            switch ((int)v7) {
                                case -1298194331: {
                                    v8 = 13288L ^ 7848669931797338910L;
                                    continue block47;
                                }
                                case 723563033: {
                                    v8 = 16904L ^ -6708014875808052936L;
                                    continue block47;
                                }
                                case 1099199009: {
                                    v8 = 3697L ^ -829150947486742966L;
                                    continue block47;
                                }
                                case 1415186628: {
                                    break block47;
                                }
                            }
                            break;
                        }
                        break block63;
                    }
                    return;
                }
                this.lastUpdateLicenseDisplayLabel = v6;
                v9 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl63
                block48: while (true) {
                    v9 = (23014L ^ -3004190630837893628L) / (5766L ^ 8347295469753556709L);
lbl63:
                    // 2 sources

                    switch ((int)v9) {
                        case 462333855: {
                            continue block48;
                        }
                        case 1415186628: {
                            break block48;
                        }
                    }
                    break;
                }
                v10 = AuthAPI.getInstance();
                while (true) {
                    if ((v11 = (cfr_temp_1 = MapCycleModule.\u13e8 - (17742L ^ 8064304602945257049L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                    if (v11 == (14257 ^ -14258)) break;
                    v11 = 14308 ^ -1906549603;
                }
                userId = LicenseData.getDiscordUserId(v10);
                if (userId != null) break block64;
                v12 = MapCycleModule.\u13e8;
                if (true) ** GOTO lbl80
                block50: while (true) {
                    v12 = v13 / (7142L ^ 1708274147464209109L);
lbl80:
                    // 2 sources

                    switch ((int)v12) {
                        case -1470266608: {
                            v13 = 9081L ^ -3372369580804027442L;
                            continue block50;
                        }
                        case 883203395: {
                            v13 = 27809L ^ -7562916123452016591L;
                            continue block50;
                        }
                        case 1415186628: {
                            break block50;
                        }
                        case 1773390124: {
                            v13 = 4833L ^ -1677650500483667350L;
                            continue block50;
                        }
                    }
                    break;
                }
                var3_2 = new byte[164 >>> "\u0000\u0000".length()];
                var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 25580 ^ 25472;
                var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 2315 ^ 2347;
                var3_2[27105 ^ 27108] = 420 >>> "\u0000\u0000".length();
                var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 408 >>> "\u0000\u0000".length();
                var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 16406 ^ 16498;
                var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 400 >>> "\u0000\u0000".length();
                var3_2[148 >>> "\u0000\u0000".length()] = 23787 ^ 23693;
                var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 404 >>> "\u0000\u0000".length();
                var3_2[21267 ^ 21274] = 444 >>> "\u0000\u0000".length();
                var3_2[132 >>> "\u0000\u0000".length()] = 432 >>> "\u0000\u0000".length();
                var3_2[6089 ^ 6094] = 4407 ^ 4375;
                var3_2[27997 ^ 28029] = 128 >>> "\u0000\u0000".length();
                var3_2[152 >>> "\u0000\u0000".length()] = 420 >>> "\u0000\u0000".length();
                var3_2[136 >>> "\u0000\u0000".length()] = 444 >>> "\u0000\u0000".length();
                var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 855 ^ 820;
                var3_2[8266 ^ 8274] = 400 >>> "\u0000\u0000".length();
                var3_2[24084 ^ 24072] = 5708 ^ 5668;
                var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 176 >>> "\u0000\u0000".length();
                var3_2["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 2861 ^ 2910;
                var3_2[156 >>> "\u0000\u0000".length()] = 28310 ^ 28410;
                var3_2[16268 ^ 16271] = 20765 ^ 20847;
                var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 4197 ^ 4112;
                var3_2[3331 ^ 3367] = 26146 ^ 26114;
                var3_2[15087 ^ 15087] = 340 >>> "\u0000\u0000".length();
                var3_2[28469 ^ 28445] = 21743 ^ 21642;
                var3_2[25754 ^ 25741] = 440 >>> "\u0000\u0000".length();
                var3_2[23436 ^ 23442] = 7809 ^ 7906;
                var3_2[11852 ^ 11842] = 29171 ^ 29140;
                var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 432 >>> "\u0000\u0000".length();
                var3_2[20632 ^ 20626] = 468 >>> "\u0000\u0000".length();
                var3_2[13765 ^ 13786] = 8260 ^ 8239;
                var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 9558 ^ 9590;
                var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 6852 ^ 6822;
                var3_2[28576 ^ 28584] = 396 >>> "\u0000\u0000".length();
                var3_2[22015 ^ 21996] = 26220 ^ 26188;
                var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 3055 ^ 2954;
                var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 31536 ^ 31573;
                var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 464 >>> "\u0000\u0000".length();
                var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 440 >>> "\u0000\u0000".length();
                var3_2[18139 ^ 18126] = 444 >>> "\u0000\u0000".length();
                var3_2[23552 ^ 23587] = 25705 ^ 25614;
                var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 128 >>> "\u0000\u0000".length();
                v14 = new String(var3_2);
                while (true) {
                    if ((v15 = (cfr_temp_2 = MapCycleModule.\u13e8 - (18331L ^ -1192674682027645603L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                    if (v15 == (13583 ^ -13584)) {
                        this.twLicenseLabel.setText(v14);
                        break block61;
                    }
                    v15 = 29242 ^ 1866406597;
                }
            }
            v16 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl148
            block52: while (true) {
                v16 = v17 / (2561L ^ 6616468725407218788L);
lbl148:
                // 2 sources

                switch ((int)v16) {
                    case 393803584: {
                        v17 = 3148L ^ -3444559744208950885L;
                        continue block52;
                    }
                    case 1415186628: {
                        break block52;
                    }
                    case 1820951437: {
                        v17 = 32034L ^ 8786398982499704637L;
                        continue block52;
                    }
                }
                break;
            }
            while (true) {
                if ((v18 = (cfr_temp_3 = MapCycleModule.\u13e8 - (27186L ^ 4858412724833355964L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v18 == (22058 ^ -22059)) break;
                v18 = 32403 ^ -2020794752;
            }
            while (true) {
                if ((v19 = (cfr_temp_4 = MapCycleModule.\u13e8 - (12370L ^ -2917886741736542521L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v19 == (30546 ^ -30547)) break;
                v19 = -264995428 >>> "\u0000\u0000".length();
            }
            v20 = new StringBuilder();
            var3_3 = new byte["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
            var3_3[24819 ^ 24819] = 29262 ^ -29245;
            var3_3[24704 ^ 24704] = 8048 ^ 7973;
            var3_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 24621 ^ 24599;
            var3_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 21755 ^ 21650;
            var3_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 23086 ^ 23115;
            var3_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 20528 ^ 20496;
            var3_3[12636 ^ 12637] = 28760 ^ 28715;
            var3_3[16117 ^ 16118] = 456 >>> "\u0000\u0000".length();
            var3_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 23259 ^ 23231;
            var3_3[30420 ^ 30416] = 24877 ^ 24845;
            v21 = new String(var3_3);
            v22 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl184
            block55: while (true) {
                v22 = v23 / (9064L ^ -7782490627775929869L);
lbl184:
                // 2 sources

                switch ((int)v22) {
                    case 663038858: {
                        v23 = 32251L ^ 8414178354417870701L;
                        continue block55;
                    }
                    case 1415186628: {
                        break block55;
                    }
                    case 1748911377: {
                        v23 = 22193L ^ -3430067861895020095L;
                        continue block55;
                    }
                    case 1881884599: {
                        v23 = 25818L ^ -4196159580760802740L;
                        continue block55;
                    }
                }
                break;
            }
            v24 = v20.append(v21);
            v25 = MapCycleModule.\u13e8;
            if (true) ** GOTO lbl201
            block56: while (true) {
                v25 = v26 / (13057L ^ -8078369756125777600L);
lbl201:
                // 2 sources

                switch ((int)v25) {
                    case -1835902613: {
                        v26 = 21708L ^ -6724426817438483677L;
                        continue block56;
                    }
                    case 915558959: {
                        v26 = 27619L ^ 863716922865146882L;
                        continue block56;
                    }
                    case 1415186628: {
                        break block56;
                    }
                    case 1822987342: {
                        v26 = 13500L ^ 4288596359319622109L;
                        continue block56;
                    }
                }
                break;
            }
            v27 = v24.append(userId);
            while (true) {
                if ((v28 = (cfr_temp_5 = MapCycleModule.\u13e8 - (14192L ^ -4841709010323884977L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                if (v28 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v28 = 32105 ^ 93688403;
            }
            v29 = v27.toString();
            while (true) {
                if ((v30 = (cfr_temp_6 = MapCycleModule.\u13e8 - (30447L ^ 1609297917288400661L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                if (v30 == (30507 ^ -30508)) {
                    this.twLicenseLabel.setText(v29);
                    break;
                }
                v30 = 31988 ^ -124742055;
            }
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private void setStubbornModuleConfigs() {
        long l = \u13e8;
        boolean bl = true;
        block15: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x5F20L ^ 0xAF0C7F0A8B43341BL);
            }
            switch ((int)l) {
                case 378367044: {
                    l2 = -5226632719528824516L >>> "\u0000\u0000".length();
                    continue block15;
                }
                case 1415186628: {
                    break block15;
                }
                case 1688810984: {
                    l2 = 0xA55L ^ 0x851DDD58306A4917L;
                    continue block15;
                }
                case 1727651483: {
                    l2 = 0x1E11L ^ 0xE2FBFA9EFAF9EB53L;
                    continue block15;
                }
            }
            break;
        }
        long l3 = \u13e8;
        block16: while (true) {
            switch ((int)l3) {
                case -945075974: {
                    l3 = (0x5B96L ^ 0x7048FC9A36FFFCAAL) / (0x4188L ^ 0xC2FCFDBCCB1B4445L);
                    continue block16;
                }
                case 1415186628: {
                    break block16;
                }
            }
            break;
        }
        long l4 = \u13e8;
        boolean bl2 = true;
        block17: while (true) {
            long l5;
            if (!bl2 || (bl2 = false) || !true) {
                l4 = l5 / (0x53EEL ^ 0x95CCE1D46CD7C86FL);
            }
            switch ((int)l4) {
                case -2119564730: {
                    l5 = 0x2473L ^ 0x9B618341A2C252CBL;
                    continue block17;
                }
                case 685111104: {
                    l5 = 9054009807754969904L >>> "\u0000\u0000".length();
                    continue block17;
                }
                case 1415186628: {
                    break block17;
                }
            }
            break;
        }
        this.lootModule.setConfig(this.betterLootModuleConfig);
    }

    /*
     * Exception decompiling
     */
    public void tickModule() {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 36[SWITCH]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public Integer getNextMapIdAfterWaitKillPeriod() {
        long l = \u13e8;
        block4: while (true) {
            switch ((int)l) {
                case 1415186628: {
                    return this.nextMapIdAfterWaitKillPeriod;
                }
                case 1851937111: {
                    l = (0x43FAL ^ 0xD0DCC653FEF466DFL) / (0x24F0L ^ 0x6D4F74C881A9FEBBL);
                    continue block4;
                }
            }
            break;
        }
        return this.nextMapIdAfterWaitKillPeriod;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public Collection<JComponent> getExtraMenuItems(PluginAPI api) {
        byte[] byArray = new byte["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
        byArray["".length() >>> "\u0000\u0000".length()] = 340 >>> "\u0000\u0000".length();
        byArray["".length() >>> "\u0000\u0000".length()] = 0x4732 ^ 0x477E;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() ^ "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length()] = 440 >>> "\u0000\u0000".length();
        byArray[0x26BE ^ 0x26BC] = 0x2691 ^ 0x26F2;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x681A ^ 0x687F;
        byArray[0x7A64 ^ 0x7A65] = 420 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x5FFC ^ 0x5F8F;
        byArray[0x627E ^ 0x627D] = 404 >>> "\u0000\u0000".length();
        String string = new String(byArray);
        JLabel[] jLabelArray = new JLabel["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
        long l = \u13e8;
        boolean bl = true;
        block6: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x150L ^ 0x992A600E3BE41566L);
            }
            switch ((int)l) {
                case -994998472: {
                    l2 = 0x6BA0L ^ 0xE9E25470F6413A52L;
                    continue block6;
                }
                case 391514050: {
                    l2 = 0x213EL ^ 0xFCDD99F5CD91B707L;
                    continue block6;
                }
                case 1134652528: {
                    l2 = 0x576FL ^ 0xAF8CBC9D14BF004FL;
                    continue block6;
                }
                case 1415186628: {
                    break block6;
                }
            }
            break;
        }
        jLabelArray[0x778A ^ 0x778A] = this.twLicenseStatusLabel;
        while (true) {
            long l3;
            long l4;
            if ((l4 = (l3 = \u13e8 - (5302341915496825956L >>> "\u0000\u0000".length())) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) continue;
            if (l4 == (0x7007 ^ 0xFFFF8FF8)) break;
            l4 = 0x5D59 ^ 0x400D191E;
        }
        jLabelArray[0x4D27 ^ 0x4D26] = this.twLicenseLabel;
        while (true) {
            long l5;
            long l6;
            if ((l6 = (l5 = \u13e8 - (0x960L ^ 0xF930FF2EB1F391D0L)) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) continue;
            if (l6 == (0x57E4 ^ 0xFFFFA81B)) {
                return ExtraMenuExtensions.MapCycleFirstMenu(this, string, jLabelArray);
            }
            l6 = 0x3583 ^ 0xA10EAEDC;
        }
    }

    private static /* synthetic */ Integer lambda$getPrioritySortedCycleWorkMapIds$6(MapInfo mapInfo) {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x6F43L ^ 0xF1752F07767A9520L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == (0x15F3 ^ 0xFFFFEA0C)) break;
            l2 = 0xF84 ^ 0x8D4FAE1;
        }
        return mapInfo.cachedMapId;
    }

    /*
     * Unable to fully structure code
     */
    private static /* synthetic */ Integer lambda$getPrioritySortedCycleWorkMapIds$5(MapInfo mapInfo) {
        while (true) {
            if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (9508L ^ 6849207559183527557L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (22064 ^ -22065)) break;
            v0 = 10199 ^ 1842648065;
        }
        v1 = mapInfo.priority;
        v2 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl11
        block6: while (true) {
            v2 = v3 / (13787L ^ -5487876375238021079L);
lbl11:
            // 2 sources

            switch ((int)v2) {
                case -362863281: {
                    v3 = 3116L ^ 1160045840923626147L;
                    continue block6;
                }
                case 201888851: {
                    v3 = 16387L ^ -1385604378608847939L;
                    continue block6;
                }
                case 1415186628: {
                    break block6;
                }
            }
            break;
        }
        return v1;
    }

    private /* synthetic */ void lambda$updatePetTick$4() {
        int n = "".length() >>> "\u0000\u0000".length();
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x6496L ^ 0xC260D39D3429F02FL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l2 = 0x5A29 ^ 0xA08DF6B2;
        }
        this.sentPetGuardModeKey = n;
    }

    /*
     * Unable to fully structure code
     */
    private /* synthetic */ void lambda$HandleAfterRestart$2() {
        while (true) {
            if ((v0 = (cfr_temp_0 = MapCycleModule.\u13e8 - (24118L ^ 3488547720859809526L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (4736 ^ -4737)) break;
            v0 = 23893 ^ -2056373319;
        }
        v1 = (boolean)(4183 ^ 4182);
        v2 = MapCycleModule.\u13e8;
        if (true) ** GOTO lbl11
        block6: while (true) {
            v2 = v3 / (24385L ^ 7796301616800156620L);
lbl11:
            // 2 sources

            switch ((int)v2) {
                case -858940655: {
                    v3 = 4652L ^ -5511494498919482900L;
                    continue block6;
                }
                case 1415186628: {
                    break block6;
                }
                case 1483048080: {
                    v3 = 131L ^ -2028387518431279316L;
                    continue block6;
                }
            }
            break;
        }
        this.decrementWaitTicksOnRefreshableMap = v1;
    }

    /*
     * Enabled aggressive block sorting
     */
    private /* synthetic */ boolean lambda$getNumberOfBoxesInSight$0(String subname, Box box) {
        int n;
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x24EAL ^ 0x5633E7A351AFC96CL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x489 ^ 0xFFFFFB76)) break;
            l2 = 0x1686 ^ 0xB7E48DA1;
        }
        String string = box.type;
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = \u13e8 - (0x571AL ^ 0xF7C1534503D64D0AL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l3 == (0x2B51 ^ 0xFFFFD4AE)) break;
            l3 = 0x5BF6 ^ 0x9801D5D1;
        }
        String string2 = string.toLowerCase();
        while (true) {
            long l;
            long l4;
            if ((l4 = (l = \u13e8 - (8502535981404159080L >>> "\u0000\u0000".length())) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l4 == (0x5C70 ^ 0xFFFFA38F)) break;
            l4 = 1444627356 >>> "\u0000\u0000".length();
        }
        String string3 = subname.toLowerCase();
        long l = \u13e8;
        block11: while (true) {
            switch ((int)l) {
                case 1415186628: {
                    break block11;
                }
                case 1779055728: {
                    l = (0x3D77L ^ 0xAACEAA7E1A99E397L) / (0x1D68L ^ 0x43964AD406F9F63EL);
                    continue block11;
                }
            }
            break;
        }
        if (string2.contains(string3)) {
            long l5 = \u13e8;
            block12: while (true) {
                switch ((int)l5) {
                    case -2068879366: {
                        l5 = (0x219DL ^ 0x59A02A837F9DA3A4L) / (0x62CBL ^ 0x551DA94B54325670L);
                        continue block12;
                    }
                    case 1415186628: {
                        break block12;
                    }
                }
                break;
            }
            if (this.shouldCollectBox(box)) {
                n = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
                return n != 0;
            }
        }
        n = 0x4BD0 ^ 0x4BD0;
        return n != 0;
    }
}

