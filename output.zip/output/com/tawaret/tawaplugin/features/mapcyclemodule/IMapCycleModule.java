/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.core.itf.Module
 *  com.github.manolo8.darkbot.core.objects.Map
 */
package com.tawaret.tawaplugin.features.mapcyclemodule;

import com.github.manolo8.darkbot.core.itf.Module;
import com.github.manolo8.darkbot.core.objects.Map;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.AfterKillConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.KeyFirstLockConfig;

public interface IMapCycleModule
extends Module {
    public Integer getNextMapIdAfterWaitKillPeriod();

    public Long getAfterNpcKillSecondsPast();

    public AfterKillConfig getAfterKillConfig();

    public String getMapName(int var1);

    public Long getKeyFirstLockMsPast();

    public KeyFirstLockConfig getKeyFirstLockConfig();

    public Boolean getAwaitingRevive();

    public Map getCurrentHeroMap();

    public Integer getGeneralBotWorkingMapId();

    public String getFallbackStatusMsg();

    public Long getNumberOfBoxesInSight();

    public String status();

    public String stoppedStatus();

    public Long getMsTillWithinNPCSpawnPeriod();

    public Integer getExcessSecondsAfterPredictedSpawn();

    public Integer getExcessSecondsMax();

    public int getWaitSecondsAfterKill();
}

