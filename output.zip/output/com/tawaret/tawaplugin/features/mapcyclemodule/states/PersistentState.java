/*
 * Decompiled with CFR 0.152.
 */
package com.tawaret.tawaplugin.features.mapcyclemodule.states;

import java.util.HashMap;

public class PersistentState {
    public final HashMap<Integer, Long> MAP_ID_TO_SUBNAME_KILL_START_MS;
    private final HashMap<Integer, Long> BACK_UP;
    public static long \u13e8 = 1085494399441299672L;

    /*
     * Unable to fully structure code
     */
    public PersistentState() {
        while (true) {
            if ((v0 = (cfr_temp_0 = PersistentState.\u13e8 - (16123L ^ 8943671363814602148L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (22478 ^ -22479)) break;
            v0 = 6847 ^ -1358926074;
        }
        super();
        v1 = PersistentState.\u13e8;
        if (true) ** GOTO lbl11
        block16: while (true) {
            v1 = v2 / (25065L ^ 7499838041957706425L);
lbl11:
            // 2 sources

            switch ((int)v1) {
                case -1268782888: {
                    break block16;
                }
                case -583115686: {
                    v2 = 3473L ^ 375099628415742996L;
                    continue block16;
                }
                case -254832525: {
                    v2 = -1705230098601783300L >>> "\u0000\u0000".length();
                    continue block16;
                }
            }
            break;
        }
        while (true) {
            if ((v3 = (cfr_temp_1 = PersistentState.\u13e8 - (20029L ^ 5721954916890330814L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v3 == (24959 ^ -24960)) break;
            v3 = 1722 ^ 1561781004;
        }
        v4 = new HashMap<K, V>();
        v5 = PersistentState.\u13e8;
        if (true) ** GOTO lbl30
        block18: while (true) {
            v5 = v6 / (-7530272957617104068L >>> "\u0000\u0000".length());
lbl30:
            // 2 sources

            switch ((int)v5) {
                case -1268782888: {
                    break block18;
                }
                case 455692739: {
                    v6 = 15668L ^ 3209978983256377764L;
                    continue block18;
                }
                case 485908590: {
                    v6 = 16224L ^ 8718935299260007869L;
                    continue block18;
                }
                case 821981346: {
                    v6 = 19240L ^ 9169058303465650268L;
                    continue block18;
                }
            }
            break;
        }
        this.MAP_ID_TO_SUBNAME_KILL_START_MS = v4;
        while (true) {
            if ((v7 = (cfr_temp_2 = PersistentState.\u13e8 - (22127L ^ 5753292788745712896L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v7 == (201 ^ -202)) break;
            v7 = 21893 ^ -808868120;
        }
        v8 = PersistentState.\u13e8;
        if (true) ** GOTO lbl52
        block20: while (true) {
            v8 = (-3879663436433111516L >>> "\u0000\u0000".length()) / (13870L ^ -3371521465792410290L);
lbl52:
            // 2 sources

            switch ((int)v8) {
                case -1268782888: {
                    break block20;
                }
                case -606153836: {
                    continue block20;
                }
            }
            break;
        }
        v9 = new HashMap<K, V>();
        while (true) {
            if ((v10 = (cfr_temp_3 = PersistentState.\u13e8 - (3717L ^ -8338306729826960119L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v10 == (10038 ^ 10039)) break;
            v10 = 22619 ^ 812612629;
        }
        this.BACK_UP = v9;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private void swapMaps(HashMap<Integer, Long> to, HashMap<Integer, Long> from) {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0xF5DL ^ 0xE2ADD3E4FB414448L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x4F9E ^ 0x4F9F)) break;
            l2 = 0x250 ^ 0xEF5EC3F1;
        }
        to.clear();
        long l = \u13e8;
        block10: while (true) {
            switch ((int)l) {
                case -1268782888: {
                    break block10;
                }
                case 844271053: {
                    l = (0x42C8L ^ 0xC20F97272AE4E605L) / (0x35BL ^ 0x80F055CCEAAD2C59L);
                    continue block10;
                }
            }
            break;
        }
        to.putAll(from);
        long l3 = \u13e8;
        boolean bl = true;
        block11: while (true) {
            long l4;
            if (!bl || (bl = false) || !true) {
                l3 = l4 / (0x25E4L ^ 0xF8456C9A6217280EL);
            }
            switch ((int)l3) {
                case -2003656895: {
                    l4 = 0x4F77L ^ 0xE537DB93A63247D0L;
                    continue block11;
                }
                case -1268782888: {
                    break block11;
                }
                case 392680167: {
                    l4 = 3161491228394625836L >>> "\u0000\u0000".length();
                    continue block11;
                }
            }
            break;
        }
        from.clear();
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public void saveAndReset() {
        long l = \u13e8;
        boolean bl = true;
        block9: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x63E1L ^ 0xFA2C17AD2D7CF59AL);
            }
            switch ((int)l) {
                case -1702658023: {
                    l2 = 0x1503L ^ 0xAFB43AF1877FE4D9L;
                    continue block9;
                }
                case -1268782888: {
                    break block9;
                }
                case 2001784602: {
                    l2 = 7381139850697746964L >>> "\u0000\u0000".length();
                    continue block9;
                }
            }
            break;
        }
        while (true) {
            long l3;
            long l4;
            if ((l4 = (l3 = \u13e8 - (0x3908L ^ 0xBA1E926E474D7756L)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) continue;
            if (l4 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l4 = 0x389F ^ 0x69108125;
        }
        long l5 = \u13e8;
        block11: while (true) {
            switch ((int)l5) {
                case -1585814102: {
                    l5 = (0x600DL ^ 0x5D93417AB86B6E96L) / (0x58AAL ^ 0xA91B54F94CDF58FBL);
                    continue block11;
                }
                case -1268782888: {
                    break block11;
                }
            }
            break;
        }
        this.swapMaps(this.BACK_UP, this.MAP_ID_TO_SUBNAME_KILL_START_MS);
    }

    /*
     * Unable to fully structure code
     */
    public void loadFromSaved() {
        while (true) {
            if ((v0 = (cfr_temp_0 = PersistentState.\u13e8 - (697L ^ -2245027477592260290L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v0 == (26798 ^ 26799)) break;
            v0 = 7533 ^ -302527442;
        }
        while (true) {
            if ((v1 = (cfr_temp_1 = PersistentState.\u13e8 - (4276735483553753636L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v1 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v1 = 11140 ^ 1856563699;
        }
        v2 = PersistentState.\u13e8;
        if (true) ** GOTO lbl17
        block8: while (true) {
            v2 = v3 / (5681L ^ 6474212745451048991L);
lbl17:
            // 2 sources

            switch ((int)v2) {
                case -1268782888: {
                    break block8;
                }
                case 750691972: {
                    v3 = 21577L ^ 6930498862032628100L;
                    continue block8;
                }
                case 1007726396: {
                    v3 = 6138L ^ 8577856406506188981L;
                    continue block8;
                }
                case 2015401371: {
                    v3 = 13474L ^ -8500014268492039850L;
                    continue block8;
                }
            }
            break;
        }
        this.swapMaps(this.MAP_ID_TO_SUBNAME_KILL_START_MS, this.BACK_UP);
    }
}

