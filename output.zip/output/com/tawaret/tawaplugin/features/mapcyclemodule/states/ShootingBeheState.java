/*
 * Decompiled with CFR 0.152.
 */
package com.tawaret.tawaplugin.features.mapcyclemodule.states;

import com.tawaret.tawaplugin.features.mapcyclemodule.logging.UserLogs;
import com.tawaret.tawaplugin.logging.ILoggable;

public class ShootingBeheState
implements ILoggable {
    private State state;
    private Long firstTimeTimeStampMs;
    private int deathsWhileShooting;
    public static long \u13e8 = -7597574750999668460L;

    /*
     * Unable to fully structure code
     */
    public ShootingBeheState() {
        v0 = ShootingBeheState.\u13e8;
        if (true) ** GOTO lbl5
        block16: while (true) {
            v0 = v1 / (16054L ^ -7050659122325387254L);
lbl5:
            // 2 sources

            switch ((int)v0) {
                case -2077222636: {
                    break block16;
                }
                case 690991766: {
                    v1 = 3016L ^ -2304633115820112644L;
                    continue block16;
                }
                case 1189704018: {
                    v1 = 16651L ^ -6863663995557672448L;
                    continue block16;
                }
            }
            break;
        }
        super();
        while (true) {
            if ((v2 = (cfr_temp_0 = ShootingBeheState.\u13e8 - (25402L ^ 8749517630241925128L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v2 == (32084 ^ -32085)) break;
            v2 = 23317 ^ -1418424940;
        }
        v3 = ShootingBeheState.\u13e8;
        if (true) ** GOTO lbl25
        block18: while (true) {
            v3 = v4 / (9008L ^ -1784580322742270660L);
lbl25:
            // 2 sources

            switch ((int)v3) {
                case -2077222636: {
                    break block18;
                }
                case -1211837476: {
                    v4 = -2152060332050174144L >>> "\u0000\u0000".length();
                    continue block18;
                }
                case -373863763: {
                    v4 = 22465L ^ -434598688338238628L;
                    continue block18;
                }
                case 818267088: {
                    v4 = 4948722990242481912L >>> "\u0000\u0000".length();
                    continue block18;
                }
            }
            break;
        }
        this.state = State.NONE;
        v5 = "".length() >>> "\u0000\u0000".length();
        v6 = ShootingBeheState.\u13e8;
        if (true) ** GOTO lbl43
        block19: while (true) {
            v6 = v7 / (20539L ^ 3861101764774664062L);
lbl43:
            // 2 sources

            switch ((int)v6) {
                case -2077222636: {
                    break block19;
                }
                case -1491625437: {
                    v7 = 32424L ^ 5911669231407347070L;
                    continue block19;
                }
                case -64379047: {
                    v7 = 13202L ^ 4205991767236994509L;
                    continue block19;
                }
            }
            break;
        }
        this.deathsWhileShooting = v5;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public void tryIncrementDeathsWhileShooting() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x4182L ^ 0x6155F766A11A6935L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == (0x51EB ^ 0xFFFFAE14)) {
                if (!this.isStillShooting()) return;
                break;
            }
            l2 = 0x5FFB ^ 0x6A1B256A;
        }
        long l = \u13e8;
        boolean bl = true;
        block13: while (true) {
            long l3;
            if (!bl || (bl = false) || !true) {
                l = l3 / (0x75FCL ^ 0x43AB4975DFE617DAL);
            }
            switch ((int)l) {
                case -2077222636: {
                    break block13;
                }
                case -1399036658: {
                    l3 = 0x14EBL ^ 0xB8D60A390A504C32L;
                    continue block13;
                }
                case 1068292993: {
                    l3 = -405013614341345068L >>> "\u0000\u0000".length();
                    continue block13;
                }
                case 1401094709: {
                    l3 = 0x7049L ^ 0x655E9EEA94F2F996L;
                    continue block13;
                }
            }
            break;
        }
        int n = this.deathsWhileShooting + ("\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length());
        long l4 = \u13e8;
        boolean bl2 = true;
        block14: while (true) {
            long l5;
            if (!bl2 || (bl2 = false) || !true) {
                l4 = l5 / (0x6F94L ^ 0x1D1A46051810EDF9L);
            }
            switch ((int)l4) {
                case -2077222636: {
                    break block14;
                }
                case -1631749161: {
                    l5 = 0x5EEL ^ 0x6BDB81E685D9B880L;
                    continue block14;
                }
                case 1273188931: {
                    l5 = 0x7747L ^ 0x58DD25363D929511L;
                    continue block14;
                }
                case 1739468077: {
                    l5 = 0x57D7L ^ 0xFCF8B8C1BC72063DL;
                    continue block14;
                }
            }
            break;
        }
        this.deathsWhileShooting = n;
    }

    public int getDeathsWhileShooting() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (-2398896254476792228L >>> "\u0000\u0000".length())) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == (0x1F6A ^ 0xFFFFE095)) break;
            l2 = 0x145C ^ 0x59FC127D;
        }
        return this.deathsWhileShooting;
    }

    public boolean isFirstTime() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x4C82L ^ 0x3A8FEC3629C95D69L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == (0x6C37 ^ 0xFFFF93C8)) break;
            l2 = 0x1FA6 ^ 0xEBE2EF4D;
        }
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = \u13e8 - (0x53DBL ^ 0xBD3BFB7D9477B64EL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l3 == (0x44E8 ^ 0xFFFFBB17)) break;
            l3 = 0xD84 ^ 0xED713B66;
        }
        return (this.state == State.FIRST ? 0x5979 ^ 0x5978 : "".length() >>> "\u0000\u0000".length()) != 0;
    }

    /*
     * Unable to fully structure code
     */
    public boolean isStillShooting() {
        while (true) {
            if ((v0 = (cfr_temp_0 = ShootingBeheState.\u13e8 - (22375L ^ 7490137254755381454L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v0 == (9427 ^ -9428)) break;
            v0 = 23203 ^ 1178518915;
        }
        v1 = ShootingBeheState.\u13e8;
        if (true) ** GOTO lbl11
        block7: while (true) {
            v1 = v2 / (21846L ^ -7173921253503966630L);
lbl11:
            // 2 sources

            switch ((int)v1) {
                case -2077222636: {
                    break block7;
                }
                case -1915957753: {
                    v2 = 2576L ^ 8905813564381090429L;
                    continue block7;
                }
                case -710533762: {
                    v2 = 7344L ^ 5507533243791679838L;
                    continue block7;
                }
                case -651772123: {
                    v2 = 15041L ^ 8997959885345924077L;
                    continue block7;
                }
            }
            break;
        }
        return (boolean)(this.state == State.STILL ? "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length() : 8941 ^ 8941);
    }

    /*
     * Unable to fully structure code
     */
    public void reset() {
        v0 = "".length() >>> "\u0000\u0000".length();
        v1 = ShootingBeheState.\u13e8;
        if (true) ** GOTO lbl6
        block9: while (true) {
            v1 = (28442L ^ 8889945163543251478L) / (12693L ^ 543254627974346274L);
lbl6:
            // 2 sources

            switch ((int)v1) {
                case -2077222636: {
                    break block9;
                }
                case -55821735: {
                    continue block9;
                }
            }
            break;
        }
        this.deathsWhileShooting = v0;
        while (true) {
            if ((v2 = (cfr_temp_0 = ShootingBeheState.\u13e8 - (17788L ^ -261292338669798763L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v2 == (30041 ^ -30042)) break;
            v2 = -407929028 >>> "\u0000\u0000".length();
        }
        while (true) {
            if ((v3 = (cfr_temp_1 = ShootingBeheState.\u13e8 - (23750L ^ -2833971934694199500L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v3 == (10496 ^ -10497)) break;
            v3 = 17314 ^ 1858483160;
        }
        this.state = State.NONE;
        v4 = ShootingBeheState.\u13e8;
        if (true) ** GOTO lbl27
        block12: while (true) {
            v4 = v5 / (22392L ^ 2656738317215916401L);
lbl27:
            // 2 sources

            switch ((int)v4) {
                case -2077222636: {
                    break block12;
                }
                case -231038807: {
                    v5 = 22353L ^ -3042834739154508869L;
                    continue block12;
                }
                case 1911388560: {
                    v5 = 28456L ^ 8802389819127952972L;
                    continue block12;
                }
            }
            break;
        }
        this.consumeFirstTimeTimeStampMs();
    }

    public Long getFirstTimeTimeStampMs() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x428AL ^ 0xB67B0EAE2D942BECL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == (0x50B5 ^ 0xFFFFAF4A)) break;
            l2 = 0x6F42 ^ 0x6CDA6AC5;
        }
        return this.firstTimeTimeStampMs;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public void consumeFirstTimeTimeStampMs() {
        long l = \u13e8;
        boolean bl = true;
        block6: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x19F8L ^ 0x56C4014CB7FE5C36L);
            }
            switch ((int)l) {
                case -2081413886: {
                    l2 = 0x7638L ^ 0xEBC720FC4590D4EAL;
                    continue block6;
                }
                case -2077222636: {
                    break block6;
                }
                case -1342351984: {
                    l2 = 0x38B7L ^ 0x946369F3CC4E02F3L;
                    continue block6;
                }
                case -580871639: {
                    l2 = 0x5EB0L ^ 0xA5E0FA67F6AD9A3BL;
                    continue block6;
                }
            }
            break;
        }
        this.firstTimeTimeStampMs = null;
    }

    /*
     * Unable to fully structure code
     */
    private void setFirstTimeTimeStepMs() {
        v0 = ShootingBeheState.\u13e8;
        if (true) ** GOTO lbl5
        block15: while (true) {
            v0 = (28227L ^ -5961948584538486706L) / (1101567806570005116L >>> "\u0000\u0000".length());
lbl5:
            // 2 sources

            switch ((int)v0) {
                case -2077222636: {
                    break block15;
                }
                case 1793612201: {
                    continue block15;
                }
            }
            break;
        }
        v1 = System.currentTimeMillis();
        v2 = ShootingBeheState.\u13e8;
        if (true) ** GOTO lbl15
        block16: while (true) {
            v2 = v3 / (31377L ^ 376647192434530087L);
lbl15:
            // 2 sources

            switch ((int)v2) {
                case -2077222636: {
                    break block16;
                }
                case -331773143: {
                    v3 = 16696L ^ 4644820243187008388L;
                    continue block16;
                }
                case 628976425: {
                    v3 = -3493703932608049796L >>> "\u0000\u0000".length();
                    continue block16;
                }
            }
            break;
        }
        v4 = v1;
        while (true) {
            if ((v5 = (cfr_temp_0 = ShootingBeheState.\u13e8 - (10677L ^ 3074371617164708179L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v5 == (5481 ^ -5482)) break;
            v5 = 15789 ^ 1271119505;
        }
        this.firstTimeTimeStampMs = v4;
        v6 = ShootingBeheState.\u13e8;
        if (true) ** GOTO lbl35
        block18: while (true) {
            v6 = v7 / (23362L ^ -4281106470865805456L);
lbl35:
            // 2 sources

            switch ((int)v6) {
                case -2077222636: {
                    break block18;
                }
                case -1571068769: {
                    v7 = 31108L ^ -3030482813846561890L;
                    continue block18;
                }
                case -226015429: {
                    v7 = 4628534564587108040L >>> "\u0000\u0000".length();
                    continue block18;
                }
                case 1836895950: {
                    v7 = 27286L ^ 6089677301468443825L;
                    continue block18;
                }
            }
            break;
        }
        UserLogs.LogFirstTimeShootingBehe(this);
    }

    /*
     * Unable to fully structure code
     */
    public void advance() {
        while (true) {
            if ((v0 = (cfr_temp_0 = ShootingBeheState.\u13e8 - (7006L ^ -2577133520850850008L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v0 == (19880 ^ -19881)) break;
            v0 = 8389 ^ -367370784;
        }
        while (true) {
            if ((v1 = (cfr_temp_1 = ShootingBeheState.\u13e8 - (-7527790312135523844L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v1 == (28384 ^ -28385)) break;
            v1 = 25955 ^ -760457920;
        }
        while (true) {
            if ((v2 = (cfr_temp_2 = ShootingBeheState.\u13e8 - (4054L ^ 6778577991685981349L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v2 == (19825 ^ -19826)) break;
            v2 = 26405 ^ -717042199;
        }
        switch (1.$SwitchMap$com$tawaret$tawaplugin$features$mapcyclemodule$states$ShootingBeheState$State[this.state.ordinal()]) {
            case 1: {
                while (true) {
                    if ((v3 = (cfr_temp_3 = ShootingBeheState.\u13e8 - (23675L ^ 5520048609605399359L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) {
                        continue;
                    }
                    if (v3 == (19381 ^ -19382)) break;
                    v3 = 18733 ^ -1777010483;
                }
                v4 = ShootingBeheState.\u13e8;
                if (true) ** GOTO lbl31
                block37: while (true) {
                    v4 = v5 / (-1644338098131657940L >>> "\u0000\u0000".length());
lbl31:
                    // 2 sources

                    switch ((int)v4) {
                        case -2077222636: {
                            break block37;
                        }
                        case 330987969: {
                            v5 = 18033L ^ 8482543773309678235L;
                            continue block37;
                        }
                        case 441213073: {
                            v5 = 1044L ^ 7098749869245734166L;
                            continue block37;
                        }
                        case 1790500216: {
                            v5 = 10226L ^ -6773160905983438814L;
                            continue block37;
                        }
                    }
                    break;
                }
                this.state = State.FIRST;
                v6 = ShootingBeheState.\u13e8;
                if (true) ** GOTO lbl48
                block38: while (true) {
                    v6 = v7 / (16248L ^ -7346825958476244382L);
lbl48:
                    // 2 sources

                    switch ((int)v6) {
                        case -2077222636: {
                            break block38;
                        }
                        case 100530952: {
                            v7 = 30706L ^ -3151542893811671654L;
                            continue block38;
                        }
                        case 1209595294: {
                            v7 = 13221L ^ -4480694465328500631L;
                            continue block38;
                        }
                        case 1994595097: {
                            v7 = 29815L ^ -70505427748068042L;
                            continue block38;
                        }
                    }
                    break;
                }
                this.setFirstTimeTimeStepMs();
                return;
            }
            case 2: {
                v8 = ShootingBeheState.\u13e8;
                if (true) ** GOTO lbl67
                block39: while (true) {
                    v8 = v9 / (29388L ^ -5373265398145915062L);
lbl67:
                    // 2 sources

                    switch ((int)v8) {
                        case -2077222636: {
                            break block39;
                        }
                        case -1349853142: {
                            v9 = 2344L ^ 5845268249793380135L;
                            continue block39;
                        }
                        case 592478040: {
                            v9 = 21271L ^ 4769540491727300802L;
                            continue block39;
                        }
                        case 989738662: {
                            v9 = 26588L ^ -367611124474016824L;
                            continue block39;
                        }
                    }
                    break;
                }
                v10 = ShootingBeheState.\u13e8;
                if (true) ** GOTO lbl83
                block40: while (true) {
                    v10 = v11 / (2378L ^ -2969479884413099561L);
lbl83:
                    // 2 sources

                    switch ((int)v10) {
                        case -2077222636: {
                            break block40;
                        }
                        case -1391246590: {
                            v11 = 27931L ^ -1292513396312845191L;
                            continue block40;
                        }
                        case 639354263: {
                            v11 = 28200L ^ -2866914443194935248L;
                            continue block40;
                        }
                    }
                    break;
                }
                this.state = State.STILL;
            }
            case 3: {
                return;
            }
        }
        v12 = ShootingBeheState.\u13e8;
        if (true) ** GOTO lbl99
        block41: while (true) {
            v12 = v13 / (25183L ^ 5690335141979883685L);
lbl99:
            // 2 sources

            switch ((int)v12) {
                case -2077222636: {
                    break block41;
                }
                case -1151577036: {
                    v13 = 8620L ^ -1489224849722316095L;
                    continue block41;
                }
                case 651952821: {
                    v13 = -7360002330768065332L >>> "\u0000\u0000".length();
                    continue block41;
                }
            }
            break;
        }
        while (true) {
            if ((v14 = (cfr_temp_4 = ShootingBeheState.\u13e8 - (31338L ^ -1593331929652073919L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v14 == (13115 ^ -13116)) break;
            v14 = 19874 ^ 5413554;
        }
        throw new RuntimeException();
    }

    private static final class State
    extends Enum<State> {
        public static final /* enum */ State FIRST;
        public static final /* enum */ State STILL;
        public static final /* enum */ State NONE;
        private static final /* synthetic */ State[] $VALUES;
        static long \u13e8 = -7927800346201886255L;

        public static State[] values() {
            while (true) {
                long l;
                long l2;
                if ((l2 = (l = \u13e8 - (0x6B40L ^ 0xC232DB0F0DA4808AL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (l2 == (0x58BB ^ 0xFFFFA744)) break;
                l2 = 0x5F64 ^ 0x498AB530;
            }
            while (true) {
                long l;
                long l3;
                if ((l3 = (l = \u13e8 - (0x8BDL ^ 0x74C5AF7B841B366EL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (l3 == (0x24E4 ^ 0xFFFFDB1B)) break;
                l3 = 533151508 >>> "\u0000\u0000".length();
            }
            return (State[])$VALUES.clone();
        }

        /*
         * Enabled aggressive block sorting
         */
        public static State valueOf(String name) {
            long l = \u13e8;
            block4: while (true) {
                switch ((int)l) {
                    case -1570049583: {
                        return Enum.valueOf(State.class, name);
                    }
                    case 377517184: {
                        l = (0x6D2FL ^ 0xF8DE5D82B1C847A9L) / (0x24A5L ^ 0x40D0E343FD5930CEL);
                        continue block4;
                    }
                }
                break;
            }
            return Enum.valueOf(State.class, name);
        }

        /*
         * Handled impossible loop by adding 'first' condition
         * Enabled aggressive block sorting
         */
        private State() {
            long l = \u13e8;
            boolean bl = true;
            block6: while (true) {
                long l2;
                if (!bl || (bl = false) || !true) {
                    l = l2 / (0x79CEL ^ 0x4CDB3A453F81E1DBL);
                }
                switch ((int)l) {
                    case -1570049583: {
                        break block6;
                    }
                    case -1565094245: {
                        l2 = 0x7DABL ^ 0x5BA6CC4803E10CF2L;
                        continue block6;
                    }
                    case 345802188: {
                        l2 = 0x65FDL ^ 0xF85EC1DD42FDFE94L;
                        continue block6;
                    }
                    case 902740342: {
                        l2 = 6287122242184804928L >>> "\u0000\u0000".length();
                        continue block6;
                    }
                }
                break;
            }
        }

        /*
         * Unable to fully structure code
         */
        private static /* synthetic */ State[] $values() {
            v0 = new State[25803 ^ 25800];
            v1 = "".length() >>> "\u0000\u0000".length();
            while (true) {
                if ((v2 = (cfr_temp_0 = State.\u13e8 - (-6004611138308227832L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (v2 == (3030 ^ -3031)) break;
                v2 = 5810 ^ -1686023440;
            }
            v0[v1] = State.FIRST;
            v3 = State.\u13e8;
            if (true) ** GOTO lbl14
            block7: while (true) {
                v3 = v4 / (19049L ^ -8113076746967543689L);
lbl14:
                // 2 sources

                switch ((int)v3) {
                    case -1570049583: {
                        break block7;
                    }
                    case -778011212: {
                        v4 = 28732L ^ -7013114222197569168L;
                        continue block7;
                    }
                    case 430605642: {
                        v4 = 5126L ^ 5148999926411374669L;
                        continue block7;
                    }
                    case 1695555440: {
                        v4 = 5629L ^ -280933967177267222L;
                        continue block7;
                    }
                }
                break;
            }
            v0[16800 ^ 16801] = State.STILL;
            v5 = "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
            while (true) {
                if ((v6 = (cfr_temp_1 = State.\u13e8 - (8865L ^ 8781555813326378379L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (v6 == (3176 ^ -3177)) break;
                v6 = 30683 ^ -1332623296;
            }
            v0[v5] = State.NONE;
            return v0;
        }

        /*
         * Unable to fully structure code
         */
        static {
            while (true) {
                if ((v0 = (cfr_temp_0 = State.\u13e8 - (23358L ^ -4176536668403660583L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v0 == (11363 ^ -11364)) break;
                v0 = 2785 ^ 2045117165;
            }
            var1 = new byte[24203 ^ 24206];
            var1["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 11250 ^ -11208;
            var1[4507 ^ 4506] = 30962 ^ 30907;
            var1[4332 ^ 4335] = 20758 ^ 20805;
            var1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 336 >>> "\u0000\u0000".length();
            var1[23847 ^ 23845] = 3218 ^ 3264;
            var1["".length() >>> "\u0000\u0000".length()] = 280 >>> "\u0000\u0000".length();
            v1 = new String(var1);
            while (true) {
                if ((v2 = (cfr_temp_1 = State.\u13e8 - (8162L ^ -1239453155524990103L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v2 == (18598 ^ -18599)) break;
                v2 = -422581596 >>> "\u0000\u0000".length();
            }
            v3 = new State();
            v4 = State.\u13e8;
            if (true) ** GOTO lbl24
            block30: while (true) {
                v4 = (8485L ^ -1224881478718047571L) / (2707107294062544320L >>> "\u0000\u0000".length());
lbl24:
                // 2 sources

                switch ((int)v4) {
                    case -1570049583: {
                        break block30;
                    }
                    case 400414384: {
                        continue block30;
                    }
                }
                break;
            }
            State.FIRST = v3;
            v5 = State.\u13e8;
            if (true) ** GOTO lbl34
            block31: while (true) {
                v5 = (26644L ^ 5806318919339744638L) / (14420L ^ -3942612817433277613L);
lbl34:
                // 2 sources

                switch ((int)v5) {
                    case -1570049583: {
                        break block31;
                    }
                    case 60120801: {
                        continue block31;
                    }
                }
                break;
            }
            var1 = new byte[1651 ^ 1654];
            var1[2044 ^ 2044] = 1613 ^ 1587;
            var1[2375 ^ 2375] = 5839 ^ 5788;
            var1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 13060 ^ 13128;
            var1["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 7854 ^ 7930;
            var1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 304 >>> "\u0000\u0000".length();
            var1[19034 ^ 19032] = 292 >>> "\u0000\u0000".length();
            v6 = new String(var1);
            while (true) {
                if ((v7 = (cfr_temp_2 = State.\u13e8 - (2356L ^ 3549042868412253237L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v7 == (13213 ^ -13214)) break;
                v7 = -193060000 >>> "\u0000\u0000".length();
            }
            v8 = new State();
            while (true) {
                if ((v9 = (cfr_temp_3 = State.\u13e8 - (6097L ^ -8122702461813389945L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v9 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v9 = 27598 ^ 1383478539;
            }
            State.STILL = v8;
            v10 = State.\u13e8;
            if (true) ** GOTO lbl63
            block34: while (true) {
                v10 = v11 / (266L ^ -7386848081101764782L);
lbl63:
                // 2 sources

                switch ((int)v10) {
                    case -1591032425: {
                        v11 = 27400L ^ 3902777632636713710L;
                        continue block34;
                    }
                    case -1570049583: {
                        break block34;
                    }
                    case 1744295754: {
                        v11 = 28086L ^ 4971585646878080213L;
                        continue block34;
                    }
                }
                break;
            }
            var1 = new byte["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
            var1[28074 ^ 28073] = 16303 ^ -16294;
            var1[27423 ^ 27420] = 276 >>> "\u0000\u0000".length();
            var1["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 316 >>> "\u0000\u0000".length();
            var1[8045 ^ 8045] = 12399 ^ 12321;
            var1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 11229 ^ 11155;
            v12 = new String(var1);
            v13 = State.\u13e8;
            if (true) ** GOTO lbl83
            block35: while (true) {
                v13 = v14 / (-6984934564409203320L >>> "\u0000\u0000".length());
lbl83:
                // 2 sources

                switch ((int)v13) {
                    case -1570049583: {
                        break block35;
                    }
                    case -1424933995: {
                        v14 = 10454L ^ -4780536311880592365L;
                        continue block35;
                    }
                    case 327307551: {
                        v14 = 19188L ^ 8681667574192372628L;
                        continue block35;
                    }
                    case 617286967: {
                        v14 = 26409L ^ -6088490750100677709L;
                        continue block35;
                    }
                }
                break;
            }
            v15 = new State();
            v16 = State.\u13e8;
            if (true) ** GOTO lbl100
            block36: while (true) {
                v16 = (21440L ^ 7860575153341943757L) / (21754L ^ 4426729178114398883L);
lbl100:
                // 2 sources

                switch ((int)v16) {
                    case -1570049583: {
                        break block36;
                    }
                    case -596509746: {
                        continue block36;
                    }
                }
                break;
            }
            State.NONE = v15;
            while (true) {
                if ((v17 = (cfr_temp_4 = State.\u13e8 - (9083L ^ 9209028984256073149L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v17 == (17541 ^ -17542)) break;
                v17 = 14708 ^ -804981526;
            }
            v18 = State.$values();
            v19 = State.\u13e8;
            if (true) ** GOTO lbl116
            block38: while (true) {
                v19 = v20 / (11066L ^ -3776615542247827079L);
lbl116:
                // 2 sources

                switch ((int)v19) {
                    case -1570049583: {
                        break block38;
                    }
                    case -566966611: {
                        v20 = 4262L ^ 7199676977911022986L;
                        continue block38;
                    }
                    case 1464435681: {
                        v20 = -454496935783136716L >>> "\u0000\u0000".length();
                        continue block38;
                    }
                }
                break;
            }
            State.$VALUES = v18;
        }
    }
}

