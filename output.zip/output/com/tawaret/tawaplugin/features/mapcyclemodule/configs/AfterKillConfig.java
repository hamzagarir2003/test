/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.config.types.Num
 *  com.github.manolo8.darkbot.config.types.Option
 */
package com.tawaret.tawaplugin.features.mapcyclemodule.configs;

import com.github.manolo8.darkbot.config.types.Num;
import com.github.manolo8.darkbot.config.types.Option;

public class AfterKillConfig {
    @Option(value="Wait seconds after kill", description="Number of seconds to wait after kill before switching maps, \"0\" - instant switch")
    @Num(min=0, max=20000, step=10)
    public int WAIT_SECONDS_AFTER_KILL;
    @Option(value="Press Key After Kill (KAK)", description="Presses the given key after a kill is detected, which could be from lost lock")
    public Character KEY_AFTER_KILL;
    @Option(value="Wait until NPC subname gone", description="After kill bot will wait until all NPC with this subname (case-insensitive) are gone from preferred region (empty to disable)")
    public String ATTEND_SUBNAME;
    @Option(value="Wait until BOX name gone", description="After kill bot will wait until all boxes are gone")
    public boolean SHOULD_WAIT_UNTIL_SOLAR_CLASH_GONE;
    @Option(value="Buy CLOAK CPU (single-use) after kill")
    public boolean ENABLE_BUY_CLOAK_CPU_AFTER_KILL;
    public static long \u13e8 = -4094969050591659710L;

    /*
     * Unable to fully structure code
     */
    public AfterKillConfig() {
        while (true) {
            if ((v0 = (cfr_temp_0 = AfterKillConfig.\u13e8 - (24563L ^ 8231904158588718701L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (23299 ^ -23300)) break;
            v0 = 27464 ^ -917171455;
        }
        super();
        v1 = AfterKillConfig.\u13e8;
        if (true) ** GOTO lbl11
        block23: while (true) {
            v1 = v2 / (4361L ^ 7445561407346948468L);
lbl11:
            // 2 sources

            switch ((int)v1) {
                case -1396585837: {
                    v2 = 3808L ^ -4150244845919775938L;
                    continue block23;
                }
                case -781654583: {
                    v2 = 1463L ^ 3918352104204370482L;
                    continue block23;
                }
                case 893647170: {
                    break block23;
                }
                case 1866804973: {
                    v2 = 10291L ^ -7935660255686773163L;
                    continue block23;
                }
            }
            break;
        }
        this.WAIT_SECONDS_AFTER_KILL = 13870 ^ 13870;
        while (true) {
            if ((v3 = (cfr_temp_1 = AfterKillConfig.\u13e8 - (19826L ^ 4767870783170040356L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v3 == (8915 ^ -8916)) break;
            v3 = 25601 ^ -1091136626;
        }
        this.KEY_AFTER_KILL = null;
        var2_1 = new byte["".length() >>> "\u0000\u0000".length()];
        v4 = new String(var2_1);
        v5 = AfterKillConfig.\u13e8;
        if (true) ** GOTO lbl36
        block25: while (true) {
            v5 = (2115L ^ -1361540451776828351L) / (28923L ^ -7895999229878902970L);
lbl36:
            // 2 sources

            switch ((int)v5) {
                case 893647170: {
                    break block25;
                }
                case 1430000107: {
                    continue block25;
                }
            }
            break;
        }
        this.ATTEND_SUBNAME = v4;
        v6 = AfterKillConfig.\u13e8;
        if (true) ** GOTO lbl46
        block26: while (true) {
            v6 = v7 / (8769L ^ 6595650535398107963L);
lbl46:
            // 2 sources

            switch ((int)v6) {
                case -1808643374: {
                    v7 = 2642L ^ -2676807076154828573L;
                    continue block26;
                }
                case 685846015: {
                    v7 = 398L ^ -6904989106994429115L;
                    continue block26;
                }
                case 884078787: {
                    v7 = 29799L ^ -6528813539536189496L;
                    continue block26;
                }
                case 893647170: {
                    break block26;
                }
            }
            break;
        }
        this.SHOULD_WAIT_UNTIL_SOLAR_CLASH_GONE = 11509 ^ 11509;
        v8 = "".length() >>> "\u0000\u0000".length();
        v9 = AfterKillConfig.\u13e8;
        if (true) ** GOTO lbl64
        block27: while (true) {
            v9 = v10 / (15845L ^ 7582178060852495690L);
lbl64:
            // 2 sources

            switch ((int)v9) {
                case -1049830880: {
                    v10 = 15416L ^ -8772613347638332731L;
                    continue block27;
                }
                case -327617698: {
                    v10 = 1972L ^ -8782364266037534696L;
                    continue block27;
                }
                case 893647170: {
                    break block27;
                }
                case 1642342934: {
                    v10 = 30601L ^ 8348162212281152094L;
                    continue block27;
                }
            }
            break;
        }
        this.ENABLE_BUY_CLOAK_CPU_AFTER_KILL = v8;
    }
}

