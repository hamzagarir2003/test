/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.config.types.Num
 *  com.github.manolo8.darkbot.config.types.Option
 */
package com.tawaret.tawaplugin.features.mapcyclemodule.configs;

import com.github.manolo8.darkbot.config.types.Num;
import com.github.manolo8.darkbot.config.types.Option;

public class TempExtraWaitSecondsConfig {
    @Option(value="Minutes Duration", description="Removes the 'Temp extra wait seconds' after this many minutes after server restart")
    @Num(min=0, max=240, step=1)
    public int TEMP_EXTRA_WAIT_DURATION_AFTER_RESTART;
    @Option(value="Extra wait seconds", description="Increases wait seconds after kill by this value after server restart, 0 to disable")
    @Num(min=0, max=20000, step=10)
    public int TEMP_EXTRA_WAIT_SECONDS;
    private static long \u13e8 = -363943701065582452L;

    public TempExtraWaitSecondsConfig() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (-8292309873998026668L >>> "\u0000\u0000".length())) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x2E3D ^ 0xFFFFD1C2)) break;
            l2 = 0x5423 ^ 0xB4E5E0B;
        }
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = \u13e8 - (0x28D2L ^ 0xAEC4F3198A9161DFL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l3 == (0x6ED3 ^ 0x6ED2)) break;
            l3 = 0x41C6 ^ 0xBB61019A;
        }
        this.TEMP_EXTRA_WAIT_DURATION_AFTER_RESTART = 0x7617 ^ 0x7609;
        int n = "".length() >>> "\u0000\u0000".length();
        while (true) {
            long l;
            long l4;
            if ((l4 = (l = \u13e8 - (0x1CFCL ^ 0xD25B3EA7F1177651L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l4 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l4 = 0x53B4 ^ 0x442F2774;
        }
        this.TEMP_EXTRA_WAIT_SECONDS = n;
    }
}

