/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.config.types.Option
 */
package com.tawaret.tawaplugin.features.mapcyclemodule.configs;

import com.github.manolo8.darkbot.config.types.Option;

public class MiscellaneousConfig {
    @Option(value="Box name to show in statistics", description="Shows the count of all such boxes on the current map")
    public String BOX_NAME;
    protected static long \u13e8 = 1497515533178221261L;

    public MiscellaneousConfig() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x4B9AL ^ 0x72B6A0510FF692B5L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x76AB ^ 0xFFFF8954)) break;
            l2 = -1628198252 >>> "\u0000\u0000".length();
        }
        byte[] byArray = new byte[0x6F9A ^ 0x6F91];
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x2679 ^ 0xFFFFD9D5;
        byArray[0x236D ^ 0x2369] = 0x7349 ^ 0x731B;
        byArray["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 316 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 332 >>> "\u0000\u0000".length();
        byArray[0x809 ^ 0x80B] = 0x509C ^ 0x50D0;
        byArray[0x3BC6 ^ 0x3BC6] = 0x3B2 ^ 0x3E1;
        byArray[0x80B ^ 0x80D] = 0x6D69 ^ 0x6D2A;
        byArray[0x706B ^ 0x706E] = 0x4EFB ^ 0x4EA4;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x4CE7 ^ 0x4CA6;
        byArray[0x3912 ^ 0x3918] = 0x5F71 ^ 0x5F39;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x5F47 ^ 0x5F0B;
        byArray[0x1045 ^ 0x1046] = 260 >>> "\u0000\u0000".length();
        String string = new String(byArray);
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = \u13e8 - (0x2A0CL ^ 0xFFDB0A7D17803B4AL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l3 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l3 = -611802740 >>> "\u0000\u0000".length();
        }
        this.BOX_NAME = string;
    }
}

