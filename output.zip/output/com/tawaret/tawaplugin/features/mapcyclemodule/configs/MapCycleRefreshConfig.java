/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.config.Config$ShipConfig
 *  com.github.manolo8.darkbot.config.types.Option
 */
package com.tawaret.tawaplugin.features.mapcyclemodule.configs;

import com.github.manolo8.darkbot.config.Config;
import com.github.manolo8.darkbot.config.types.Option;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.ExtraSecondsOnRefreshableMapsConfig;

public class MapCycleRefreshConfig {
    @Option(value="Enable in-place map refresh", description="Refreshes without going to safety, on the spot")
    public boolean USE_IN_PLACE_REFRESH;
    @Option(value="Only refresh during 'Wait period after kill'")
    public boolean ONLY_REFRESH_DURING_WAIT_PERIOD_AFTER_KILL;
    @Option(value="Enable Refresh Config", description="Switches to your 'Refresh Config' before performing the refresh")
    public boolean ENABLE_REFRESH_CONFIG;
    @Option(value="Refresh config")
    public Config.ShipConfig REFRESH_CONFIG;
    @Option(value="Extra Seconds On Refreshable Maps")
    public ExtraSecondsOnRefreshableMapsConfig EXTRA_SECONDS_ON_REFRESHABLE_MAPS_CONFIG;
    private static long \u13e8 = -4879738147030770070L;

    /*
     * Unable to fully structure code
     */
    public MapCycleRefreshConfig() {
        v0 = MapCycleRefreshConfig.\u13e8;
        if (true) ** GOTO lbl5
        block35: while (true) {
            v0 = v1 / (26543L ^ 6170196175402983946L);
lbl5:
            // 2 sources

            switch ((int)v0) {
                case 357129504: {
                    v1 = 13720L ^ -911133966038715597L;
                    continue block35;
                }
                case 420729750: {
                    v1 = -1458134273753880608L >>> "\u0000\u0000".length();
                    continue block35;
                }
                case 1565449834: {
                    break block35;
                }
            }
            break;
        }
        super();
        v2 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        v3 = MapCycleRefreshConfig.\u13e8;
        if (true) ** GOTO lbl20
        block36: while (true) {
            v3 = (16594L ^ 1606241032513289581L) / (24506L ^ -5270211197704815076L);
lbl20:
            // 2 sources

            switch ((int)v3) {
                case 1053590217: {
                    continue block36;
                }
                case 1565449834: {
                    break block36;
                }
            }
            break;
        }
        this.USE_IN_PLACE_REFRESH = v2;
        while (true) {
            if ((v4 = (cfr_temp_0 = MapCycleRefreshConfig.\u13e8 - (31484L ^ 4803399601743874121L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v4 == (9570 ^ -9571)) break;
            v4 = 8775 ^ 1124460478;
        }
        this.ONLY_REFRESH_DURING_WAIT_PERIOD_AFTER_KILL = 26360 ^ 26361;
        v5 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        while (true) {
            if ((v6 = (cfr_temp_1 = MapCycleRefreshConfig.\u13e8 - (1199L ^ -751708296130772673L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v6 == (13594 ^ -13595)) break;
            v6 = -1804947560 >>> "\u0000\u0000".length();
        }
        this.ENABLE_REFRESH_CONFIG = v5;
        v7 = MapCycleRefreshConfig.\u13e8;
        if (true) ** GOTO lbl43
        block39: while (true) {
            v7 = v8 / (9033L ^ -570218365123293414L);
lbl43:
            // 2 sources

            switch ((int)v7) {
                case 862384509: {
                    v8 = 18416L ^ 3408611371663401952L;
                    continue block39;
                }
                case 916495759: {
                    v8 = 5759414886535130412L >>> "\u0000\u0000".length();
                    continue block39;
                }
                case 1565449834: {
                    break block39;
                }
            }
            break;
        }
        v9 = 228 >>> "\u0000\u0000".length();
        v10 = MapCycleRefreshConfig.\u13e8;
        if (true) ** GOTO lbl57
        block40: while (true) {
            v10 = (17325L ^ -2008204094698909848L) / (23064L ^ 6242181115703544147L);
lbl57:
            // 2 sources

            switch ((int)v10) {
                case -236636466: {
                    continue block40;
                }
                case 1565449834: {
                    break block40;
                }
            }
            break;
        }
        v11 = Character.valueOf(v9);
        while (true) {
            if ((v12 = (cfr_temp_2 = MapCycleRefreshConfig.\u13e8 - (23962L ^ -6874953606476525865L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v12 == (29314 ^ 29315)) break;
            v12 = 25579 ^ 1852735625;
        }
        v13 = new Config.ShipConfig(18614 ^ 18612, v11);
        v14 = MapCycleRefreshConfig.\u13e8;
        if (true) ** GOTO lbl73
        block42: while (true) {
            v14 = v15 / (11669L ^ -5033041787678224117L);
lbl73:
            // 2 sources

            switch ((int)v14) {
                case -1405489666: {
                    v15 = 27856L ^ 5362378786104687683L;
                    continue block42;
                }
                case 1094068214: {
                    v15 = 13811L ^ 6259766102069904734L;
                    continue block42;
                }
                case 1565449834: {
                    break block42;
                }
                case 1804763306: {
                    v15 = 14126L ^ -7962212027614824770L;
                    continue block42;
                }
            }
            break;
        }
        this.REFRESH_CONFIG = v13;
        v16 = MapCycleRefreshConfig.\u13e8;
        if (true) ** GOTO lbl90
        block43: while (true) {
            v16 = v17 / (23643L ^ 5932576526864835061L);
lbl90:
            // 2 sources

            switch ((int)v16) {
                case -1616495885: {
                    v17 = 19567L ^ -5059918133358686037L;
                    continue block43;
                }
                case -81543892: {
                    v17 = 23268L ^ 5767896176898858170L;
                    continue block43;
                }
                case 602534252: {
                    v17 = 30809L ^ 8300041061119145536L;
                    continue block43;
                }
                case 1565449834: {
                    break block43;
                }
            }
            break;
        }
        while (true) {
            if ((v18 = (cfr_temp_3 = MapCycleRefreshConfig.\u13e8 - (23597L ^ -1604795237068123336L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v18 == (31870 ^ -31871)) break;
            v18 = 15502 ^ 886004221;
        }
        v19 = new ExtraSecondsOnRefreshableMapsConfig();
        v20 = MapCycleRefreshConfig.\u13e8;
        if (true) ** GOTO lbl112
        block45: while (true) {
            v20 = v21 / (11153L ^ -5601699870135613948L);
lbl112:
            // 2 sources

            switch ((int)v20) {
                case -944287563: {
                    v21 = 10234L ^ -7771796699541887123L;
                    continue block45;
                }
                case 247067624: {
                    v21 = 10936L ^ -8740100064771077775L;
                    continue block45;
                }
                case 1565449834: {
                    break block45;
                }
            }
            break;
        }
        this.EXTRA_SECONDS_ON_REFRESHABLE_MAPS_CONFIG = v19;
    }
}

