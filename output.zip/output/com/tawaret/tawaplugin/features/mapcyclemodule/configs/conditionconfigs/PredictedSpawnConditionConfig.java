/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.config.types.Num
 *  com.github.manolo8.darkbot.config.types.Option
 */
package com.tawaret.tawaplugin.features.mapcyclemodule.configs.conditionconfigs;

import com.github.manolo8.darkbot.config.types.Num;
import com.github.manolo8.darkbot.config.types.Option;

public class PredictedSpawnConditionConfig {
    @Option(value="Enable")
    public boolean ENABLE;
    @Option(value="Prediction tolerance (Seconds)", description="Time after predicted spawn to then switch maps")
    @Num(min=5, max=50000, step=1)
    public int PREDICTION_TOLERANCE_SECONDS;
    private static long \u13e8 = 1653866296252275089L;

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public PredictedSpawnConditionConfig() {
        long l = \u13e8;
        boolean bl = true;
        block15: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x4919L ^ 0x7F509440054FDCE7L);
            }
            switch ((int)l) {
                case -496352011: {
                    l2 = 1809868293615046264L >>> "\u0000\u0000".length();
                    continue block15;
                }
                case -461679388: {
                    l2 = 0x398FL ^ 0xD8F690A56CE6FF72L;
                    continue block15;
                }
                case 1176213905: {
                    break block15;
                }
            }
            break;
        }
        long l3 = \u13e8;
        boolean bl2 = true;
        block16: while (true) {
            long l4;
            if (!bl2 || (bl2 = false) || !true) {
                l3 = l4 / (-9117675044247438064L >>> "\u0000\u0000".length());
            }
            switch ((int)l3) {
                case -2075470008: {
                    l4 = 0x4E67L ^ 0x4183C276ECC33B5AL;
                    continue block16;
                }
                case 160453184: {
                    l4 = 0x1E74L ^ 0x6DFD45EC9760E0F9L;
                    continue block16;
                }
                case 1176213905: {
                    break block16;
                }
                case 1492901173: {
                    l4 = 0xD8AL ^ 0xFE5D96BBE82C965AL;
                    continue block16;
                }
            }
            break;
        }
        this.ENABLE = 0x19AB ^ 0x19AB;
        long l5 = \u13e8;
        block17: while (true) {
            switch ((int)l5) {
                case 1110025661: {
                    l5 = (0x52BCL ^ 0xDAAB3FDD4322A086L) / (0x74EEL ^ 0x7DC5843110A5B890L);
                    continue block17;
                }
                case 1176213905: {
                    break block17;
                }
            }
            break;
        }
        this.PREDICTION_TOLERANCE_SECONDS = 0x2E9E ^ 0x2E8A;
    }
}

