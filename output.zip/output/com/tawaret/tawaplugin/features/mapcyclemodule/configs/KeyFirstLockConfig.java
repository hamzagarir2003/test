/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.config.types.Num
 *  com.github.manolo8.darkbot.config.types.Option
 */
package com.tawaret.tawaplugin.features.mapcyclemodule.configs;

import com.github.manolo8.darkbot.config.types.Num;
import com.github.manolo8.darkbot.config.types.Option;

public class KeyFirstLockConfig {
    @Option(value="Press Key when First Locking (KFL) NPC", description="Press the given key when the \"NPC subname\" is first locked on")
    public Character KEY_WHEN_FIRST_LOCKED_ON_NPC_SUBNAME;
    @Option(value="Wait ms before key press", description="Waits this number of ms after locking before pressing the key")
    @Num(min=0, max=60000, step=100)
    public int WAIT_MS_AFTER_FIRST_LOCK;
    protected static long \u13e8 = -626083666591708059L;

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public KeyFirstLockConfig() {
        long l = \u13e8;
        block14: while (true) {
            switch ((int)l) {
                case -879960693: {
                    l = (0x5B09L ^ 0xB36C4587EB4B2945L) / (0x50DEL ^ 0x472BD88A5D4BBF11L);
                    continue block14;
                }
                case -316634011: {
                    break block14;
                }
            }
            break;
        }
        long l2 = \u13e8;
        boolean bl = true;
        block15: while (true) {
            long l3;
            if (!bl || (bl = false) || !true) {
                l2 = l3 / (0x86CL ^ 0x523298A4DFDBB14AL);
            }
            switch ((int)l2) {
                case -1941456940: {
                    l3 = 0x60DDL ^ 0xE76C2984CA959805L;
                    continue block15;
                }
                case -445426372: {
                    l3 = 0x31B0L ^ 0x739192972EF4AE3DL;
                    continue block15;
                }
                case -316634011: {
                    break block15;
                }
                case 1204653866: {
                    l3 = 0x2F10L ^ 0x6F6431B463665AC6L;
                    continue block15;
                }
            }
            break;
        }
        this.KEY_WHEN_FIRST_LOCKED_ON_NPC_SUBNAME = null;
        int n = 2400 >>> "\u0000\u0000".length();
        long l4 = \u13e8;
        block16: while (true) {
            switch ((int)l4) {
                case -316634011: {
                    break block16;
                }
                case 128603939: {
                    l4 = (0x5AAFL ^ 0x801D5E23463CB56DL) / (0x495CL ^ 0x3B53B9FC29FB97C5L);
                    continue block16;
                }
            }
            break;
        }
        this.WAIT_MS_AFTER_FIRST_LOCK = n;
    }
}

