/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.config.types.Option
 */
package com.tawaret.tawaplugin.features.mapcyclemodule.configs.conditionconfigs;

import com.github.manolo8.darkbot.config.types.Option;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.conditionconfigs.DeathCountConditionConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.conditionconfigs.LoglineSubstringConditionConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.conditionconfigs.NpcSubnameConditionConfig;

public class MapChangeConditionConfig {
    @Option(value="Death Count")
    public DeathCountConditionConfig DEATH_COUNT_CONFIG;
    @Option(value="Npc Subname")
    public NpcSubnameConditionConfig NPC_SUBNAME_CONFIG;
    @Option(value="Logline Substring")
    public LoglineSubstringConditionConfig LOG_LINE_SUBSTRING_CONFIG;
    protected static long \u13e8 = -5188461102329693452L;

    /*
     * Unable to fully structure code
     */
    public MapChangeConditionConfig() {
        while (true) {
            if ((v0 = (cfr_temp_0 = MapChangeConditionConfig.\u13e8 - (21416L ^ -5876843194457533950L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v0 = 481214088 >>> "\u0000\u0000".length();
        }
        super();
        while (true) {
            if ((v1 = (cfr_temp_1 = MapChangeConditionConfig.\u13e8 - (-2189623549659577980L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v1 == (24612 ^ -24613)) break;
            v1 = 1077 ^ -376284997;
        }
        while (true) {
            if ((v2 = (cfr_temp_2 = MapChangeConditionConfig.\u13e8 - (30786L ^ 4090569261263315034L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v2 == (28632 ^ -28633)) break;
            v2 = 30358 ^ -937493718;
        }
        v3 = new DeathCountConditionConfig();
        v4 = MapChangeConditionConfig.\u13e8;
        if (true) ** GOTO lbl22
        block16: while (true) {
            v4 = (3543L ^ 3225423623579030153L) / (9094L ^ -4741713580291906075L);
lbl22:
            // 2 sources

            switch ((int)v4) {
                case -122357004: {
                    break block16;
                }
                case 1810701538: {
                    continue block16;
                }
            }
            break;
        }
        this.DEATH_COUNT_CONFIG = v3;
        while (true) {
            if ((v5 = (cfr_temp_3 = MapChangeConditionConfig.\u13e8 - (8779L ^ -1528623713827659331L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v5 == (8324 ^ -8325)) break;
            v5 = 8150 ^ -1485393924;
        }
        while (true) {
            if ((v6 = (cfr_temp_4 = MapChangeConditionConfig.\u13e8 - (16584L ^ -6593187129191517750L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v6 == (21600 ^ 21601)) break;
            v6 = 7052 ^ -1702030110;
        }
        v7 = new NpcSubnameConditionConfig();
        v8 = MapChangeConditionConfig.\u13e8;
        if (true) ** GOTO lbl43
        block19: while (true) {
            v8 = (31777L ^ 3975084038991385642L) / (13892L ^ -1611776024468305607L);
lbl43:
            // 2 sources

            switch ((int)v8) {
                case -122357004: {
                    break block19;
                }
                case 1697965008: {
                    continue block19;
                }
            }
            break;
        }
        this.NPC_SUBNAME_CONFIG = v7;
        while (true) {
            if ((v9 = (cfr_temp_5 = MapChangeConditionConfig.\u13e8 - (755652296806900548L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
            if (v9 == (29810 ^ -29811)) break;
            v9 = 5396 ^ -1559267490;
        }
        v10 = MapChangeConditionConfig.\u13e8;
        if (true) ** GOTO lbl58
        block21: while (true) {
            v10 = v11 / (21166L ^ -2036432364601826318L);
lbl58:
            // 2 sources

            switch ((int)v10) {
                case -1307505551: {
                    v11 = 5717L ^ 7742482938840397133L;
                    continue block21;
                }
                case -122357004: {
                    break block21;
                }
                case 2144624996: {
                    v11 = 13206L ^ 7784722743289996803L;
                    continue block21;
                }
            }
            break;
        }
        v12 = new LoglineSubstringConditionConfig();
        while (true) {
            if ((v13 = (cfr_temp_6 = MapChangeConditionConfig.\u13e8 - (6401735052154743396L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
            if (v13 == (23988 ^ -23989)) break;
            v13 = 1067 ^ 2131708238;
        }
        this.LOG_LINE_SUBSTRING_CONFIG = v12;
    }
}

