/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.config.types.Num
 *  com.github.manolo8.darkbot.config.types.Option
 */
package com.tawaret.tawaplugin.features.mapcyclemodule.configs;

import com.github.manolo8.darkbot.config.types.Num;
import com.github.manolo8.darkbot.config.types.Option;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.TempExtraWaitSecondsConfig;

public class ServerRestartHandlerConfig {
    @Option(value="Enable check for server restart")
    public boolean ENABLE_CHECK_SERVER_RESTART;
    @Option(value="Server restart minutes delay", description="Time to wait after seeing server will restart, then execute after restart procedures")
    @Num(min=5, max=60, step=1)
    public int SERVER_RESTART_MINS_DELAY;
    @Option(value="Collect behe boxes on game server restart")
    public boolean COLLECT_BEHE_BOXES_ON_GAME_SERVER_RESTART;
    @Option(value="Stop collect behe boxes after server restart")
    public boolean STOP_COLLECT_BEHE_BOXES_AFTER_SERVER_RESTART;
    @Option(value="Reverse rotation after server restart")
    public boolean REVERSE_ROTATION_ON_SERVER_RESTART;
    @Option(value="Wait Seconds After Kill Temporary Extra Seconds")
    public TempExtraWaitSecondsConfig TEMP_EXTRA_WAIT_SECONDS_CONFIG;
    protected static long \u13e8 = 3543486446283966592L;

    /*
     * Unable to fully structure code
     */
    public ServerRestartHandlerConfig() {
        while (true) {
            if ((v0 = (cfr_temp_0 = ServerRestartHandlerConfig.\u13e8 - (2835L ^ -3456062370190848607L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v0 = 6648 ^ 1140845812;
        }
        super();
        v1 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        v2 = ServerRestartHandlerConfig.\u13e8;
        if (true) ** GOTO lbl12
        block37: while (true) {
            v2 = v3 / (1388L ^ -8729017699368421253L);
lbl12:
            // 2 sources

            switch ((int)v2) {
                case -1175833995: {
                    v3 = 29969L ^ -3110968370210787749L;
                    continue block37;
                }
                case -952178900: {
                    v3 = 24130L ^ 3075967875327280633L;
                    continue block37;
                }
                case -364579696: {
                    v3 = 23853L ^ 6058051179498041072L;
                    continue block37;
                }
                case 288016512: {
                    break block37;
                }
            }
            break;
        }
        this.ENABLE_CHECK_SERVER_RESTART = v1;
        v4 = "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        v5 = ServerRestartHandlerConfig.\u13e8;
        if (true) ** GOTO lbl30
        block38: while (true) {
            v5 = (1946L ^ -3282211837811475549L) / (23782L ^ -8906496287933218262L);
lbl30:
            // 2 sources

            switch ((int)v5) {
                case -1707036133: {
                    continue block38;
                }
                case 288016512: {
                    break block38;
                }
            }
            break;
        }
        this.SERVER_RESTART_MINS_DELAY = v4;
        v6 = ServerRestartHandlerConfig.\u13e8;
        if (true) ** GOTO lbl40
        block39: while (true) {
            v6 = v7 / (16024L ^ -1499792815920101279L);
lbl40:
            // 2 sources

            switch ((int)v6) {
                case -1990492760: {
                    v7 = 23284L ^ -484402685227396169L;
                    continue block39;
                }
                case -697562925: {
                    v7 = 22421L ^ -2617291338024900473L;
                    continue block39;
                }
                case 288016512: {
                    break block39;
                }
            }
            break;
        }
        this.COLLECT_BEHE_BOXES_ON_GAME_SERVER_RESTART = 16748 ^ 16749;
        v8 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        v9 = ServerRestartHandlerConfig.\u13e8;
        if (true) ** GOTO lbl55
        block40: while (true) {
            v9 = (-7616018186068885748L >>> "\u0000\u0000".length()) / (30499L ^ 7843671343315930180L);
lbl55:
            // 2 sources

            switch ((int)v9) {
                case -119788289: {
                    continue block40;
                }
                case 288016512: {
                    break block40;
                }
            }
            break;
        }
        this.STOP_COLLECT_BEHE_BOXES_AFTER_SERVER_RESTART = v8;
        v10 = "".length() >>> "\u0000\u0000".length();
        v11 = ServerRestartHandlerConfig.\u13e8;
        if (true) ** GOTO lbl66
        block41: while (true) {
            v11 = v12 / (26225L ^ -4535108450722690200L);
lbl66:
            // 2 sources

            switch ((int)v11) {
                case -1812252059: {
                    v12 = 17109L ^ 3234631994651367912L;
                    continue block41;
                }
                case -1364219684: {
                    v12 = 30449L ^ 72500353198034562L;
                    continue block41;
                }
                case 288016512: {
                    break block41;
                }
                case 771584642: {
                    v12 = 3352515589412400744L >>> "\u0000\u0000".length();
                    continue block41;
                }
            }
            break;
        }
        this.REVERSE_ROTATION_ON_SERVER_RESTART = v10;
        while (true) {
            if ((v13 = (cfr_temp_1 = ServerRestartHandlerConfig.\u13e8 - (28657L ^ -2933771204609016595L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v13 == (30592 ^ 30593)) break;
            v13 = 14070 ^ 2031989662;
        }
        v14 = ServerRestartHandlerConfig.\u13e8;
        if (true) ** GOTO lbl88
        block43: while (true) {
            v14 = v15 / (29841L ^ -4121519252770611298L);
lbl88:
            // 2 sources

            switch ((int)v14) {
                case 288016512: {
                    break block43;
                }
                case 661888534: {
                    v15 = 13036L ^ -5300619374697327219L;
                    continue block43;
                }
                case 1054738940: {
                    v15 = 17406L ^ -749116017140409294L;
                    continue block43;
                }
            }
            break;
        }
        v16 = new TempExtraWaitSecondsConfig();
        v17 = ServerRestartHandlerConfig.\u13e8;
        if (true) ** GOTO lbl102
        block44: while (true) {
            v17 = v18 / (7315L ^ -4055714150861184989L);
lbl102:
            // 2 sources

            switch ((int)v17) {
                case -2049085222: {
                    v18 = 21608L ^ -6026482591459851993L;
                    continue block44;
                }
                case 288016512: {
                    break block44;
                }
                case 1028489920: {
                    v18 = 31280L ^ -7106437484812230381L;
                    continue block44;
                }
                case 2106839375: {
                    v18 = 30394L ^ 5131051021241302725L;
                    continue block44;
                }
            }
            break;
        }
        this.TEMP_EXTRA_WAIT_SECONDS_CONFIG = v16;
    }
}

