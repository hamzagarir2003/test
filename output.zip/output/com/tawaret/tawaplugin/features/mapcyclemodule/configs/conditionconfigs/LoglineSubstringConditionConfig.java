/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.config.types.Option
 */
package com.tawaret.tawaplugin.features.mapcyclemodule.configs.conditionconfigs;

import com.github.manolo8.darkbot.config.types.Option;

public class LoglineSubstringConditionConfig {
    @Option(value="Enable logline substring detection")
    public boolean USE_LOG_LINE_SUBSTRING;
    @Option(value="Logline substring (case-sensitive)", description="Npc will be considered dead if a logline is found to contain this value (empty to disable)")
    public String LOG_LINE_SUBSTRING;
    static long \u13e8 = -303019632210641583L;

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public LoglineSubstringConditionConfig() {
        long l = \u13e8;
        boolean bl = true;
        block9: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x1890L ^ 0x4D9CF684362C30F4L);
            }
            switch ((int)l) {
                case -1182742563: {
                    l2 = 0x33C8L ^ 0x635770EF2F77A4D7L;
                    continue block9;
                }
                case -31621807: {
                    break block9;
                }
                case 432577315: {
                    l2 = 0x47E6L ^ 0xC6BA0CEC4A98F7EDL;
                    continue block9;
                }
            }
            break;
        }
        int n = "".length() >>> "\u0000\u0000".length();
        while (true) {
            long l3;
            long l4;
            if ((l4 = (l3 = \u13e8 - (0x6FEBL ^ 0xB6551049EC862F90L)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) continue;
            if (l4 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l4 = 0x74F3 ^ 0x67CF5952;
        }
        this.USE_LOG_LINE_SUBSTRING = n;
        byte[] byArray = new byte[0x2025 ^ 0x2025];
        String string = new String(byArray);
        long l5 = \u13e8;
        block11: while (true) {
            switch ((int)l5) {
                case -776965830: {
                    l5 = (0x3D90L ^ 0xF8B94FE1C3CBD6D6L) / (0x6B4FL ^ 0x5B5A9462409BC4EFL);
                    continue block11;
                }
                case -31621807: {
                    break block11;
                }
            }
            break;
        }
        this.LOG_LINE_SUBSTRING = string;
    }
}

