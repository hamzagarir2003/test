/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.config.types.Num
 *  com.github.manolo8.darkbot.config.types.Option
 */
package com.tawaret.tawaplugin.features.mapcyclemodule.configs.conditionconfigs;

import com.github.manolo8.darkbot.config.types.Num;
import com.github.manolo8.darkbot.config.types.Option;

public class NpcSubnameConditionConfig {
    @Option(value="Move to NPC subname periodically")
    public boolean MOVE_TO_NPC_SUBNAME;
    @Option(value="Period for above (Ms)")
    @Num(min=200, max=50000, step=10)
    public int MOVE_TO_NPC_SUBNAME_PERIOD_MS;
    @Option(value="Count death while shooting subname as kill")
    public boolean COUNT_DEATH_AS_SUBNAME_KILL;
    protected static long \u13e8 = -2761226294683371411L;

    /*
     * Unable to fully structure code
     */
    public NpcSubnameConditionConfig() {
        while (true) {
            if ((v0 = (cfr_temp_0 = NpcSubnameConditionConfig.\u13e8 - (-4922609530839460064L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (25903 ^ -25904)) break;
            v0 = 23766 ^ -1531162743;
        }
        super();
        v1 = NpcSubnameConditionConfig.\u13e8;
        if (true) ** GOTO lbl11
        block11: while (true) {
            v1 = v2 / (18604L ^ -2179550850208088474L);
lbl11:
            // 2 sources

            switch ((int)v1) {
                case -1997670291: {
                    break block11;
                }
                case -1876825127: {
                    v2 = 4279L ^ -4164777559932361443L;
                    continue block11;
                }
                case 698313175: {
                    v2 = 28735L ^ -5709251731661964280L;
                    continue block11;
                }
            }
            break;
        }
        this.MOVE_TO_NPC_SUBNAME = 25237 ^ 25237;
        v3 = 20000 >>> "\u0000\u0000".length();
        while (true) {
            if ((v4 = (cfr_temp_1 = NpcSubnameConditionConfig.\u13e8 - (31426L ^ -8931703500095085851L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v4 == (14866 ^ 14867)) break;
            v4 = 31157 ^ 617319886;
        }
        this.MOVE_TO_NPC_SUBNAME_PERIOD_MS = v3;
        v5 = NpcSubnameConditionConfig.\u13e8;
        if (true) ** GOTO lbl32
        block13: while (true) {
            v5 = v6 / (8834L ^ -7046053027752856263L);
lbl32:
            // 2 sources

            switch ((int)v5) {
                case -1997670291: {
                    break block13;
                }
                case -1277529161: {
                    v6 = 24941L ^ -4338967199757599338L;
                    continue block13;
                }
                case 449380318: {
                    v6 = 17084L ^ 6362036253119741187L;
                    continue block13;
                }
            }
            break;
        }
        this.COUNT_DEATH_AS_SUBNAME_KILL = 877 ^ 876;
    }
}

