/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.config.types.Num
 *  com.github.manolo8.darkbot.config.types.Option
 *  com.github.manolo8.darkbot.config.types.suppliers.PetGears
 *  eu.darkbot.api.config.annotations.Dropdown
 *  eu.darkbot.api.game.enums.PetGear
 */
package com.tawaret.tawaplugin.features.mapcyclemodule.configs;

import com.github.manolo8.darkbot.config.types.Num;
import com.github.manolo8.darkbot.config.types.Option;
import com.github.manolo8.darkbot.config.types.suppliers.PetGears;
import eu.darkbot.api.config.annotations.Dropdown;
import eu.darkbot.api.game.enums.PetGear;

public class MapCyclePetConfig {
    @Option(value="Enable PET to guard only when NPC subname is in sight")
    public boolean ENABLE_PET_GUARD_NPC_IN_SIGHT;
    @Option(value="PET guard mode")
    @Dropdown(options=PetGears.class)
    public PetGear GUARD_MODE_ID;
    @Option(value="PET guard mode hotkey")
    public Character PET_GUARD_MODE_KEY;
    @Option(value="PET guard mode key send wait ms")
    @Num(min=100, max=5000, step=100)
    public int PET_GUARD_MODE_KEY_MS;
    @Option(value="Repair PET while waiting", description="Switches gear to PET repair (must have gear to use) until PET on full HP")
    public boolean REPAIR_PET_WHILE_WAITING;
    private static long \u13e8 = -121008508809781426L;

    /*
     * Unable to fully structure code
     */
    public MapCyclePetConfig() {
        while (true) {
            if ((v0 = (cfr_temp_0 = MapCyclePetConfig.\u13e8 - (11374L ^ 103242692962727027L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (15351 ^ -15352)) break;
            v0 = 7036 ^ -521327146;
        }
        super();
        v1 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        v2 = MapCyclePetConfig.\u13e8;
        if (true) ** GOTO lbl12
        block32: while (true) {
            v2 = v3 / (28313L ^ -1548964466494524070L);
lbl12:
            // 2 sources

            switch ((int)v2) {
                case -1487472110: {
                    v3 = 25564L ^ -1414592272514443822L;
                    continue block32;
                }
                case -259764958: {
                    v3 = 9022L ^ -3914987653160968582L;
                    continue block32;
                }
                case 26730318: {
                    break block32;
                }
            }
            break;
        }
        this.ENABLE_PET_GUARD_NPC_IN_SIGHT = v1;
        v4 = MapCyclePetConfig.\u13e8;
        if (true) ** GOTO lbl26
        block33: while (true) {
            v4 = v5 / (16022L ^ 8281243247997011322L);
lbl26:
            // 2 sources

            switch ((int)v4) {
                case -2012846922: {
                    v5 = 14758L ^ -3318747083704132893L;
                    continue block33;
                }
                case 26730318: {
                    break block33;
                }
                case 860557483: {
                    v5 = 18951L ^ 4705336111319125197L;
                    continue block33;
                }
            }
            break;
        }
        v6 = MapCyclePetConfig.\u13e8;
        if (true) ** GOTO lbl39
        block34: while (true) {
            v6 = v7 / (15826L ^ -8863189103422088285L);
lbl39:
            // 2 sources

            switch ((int)v6) {
                case -278040456: {
                    v7 = 16294L ^ -4282225145827177069L;
                    continue block34;
                }
                case 26730318: {
                    break block34;
                }
                case 1727959021: {
                    v7 = 16068L ^ -8376287708624266360L;
                    continue block34;
                }
            }
            break;
        }
        this.GUARD_MODE_ID = PetGear.GUARD;
        v8 = MapCyclePetConfig.\u13e8;
        if (true) ** GOTO lbl53
        block35: while (true) {
            v8 = v9 / (19621L ^ 7361990134342738651L);
lbl53:
            // 2 sources

            switch ((int)v8) {
                case 26730318: {
                    break block35;
                }
                case 238092865: {
                    v9 = 26339L ^ -2169732260652853084L;
                    continue block35;
                }
                case 679657547: {
                    v9 = 16065L ^ 3769467020282471907L;
                    continue block35;
                }
                case 1693919698: {
                    v9 = 26543L ^ -5290360242201997778L;
                    continue block35;
                }
            }
            break;
        }
        v10 = Character.valueOf((char)(9024 ^ 8978));
        v11 = MapCyclePetConfig.\u13e8;
        if (true) ** GOTO lbl70
        block36: while (true) {
            v11 = (1029L ^ 2389402748585756975L) / (32709L ^ -672436110294620309L);
lbl70:
            // 2 sources

            switch ((int)v11) {
                case 26730318: {
                    break block36;
                }
                case 338733641: {
                    continue block36;
                }
            }
            break;
        }
        this.PET_GUARD_MODE_KEY = v10;
        v12 = 4000 >>> "\u0000\u0000".length();
        while (true) {
            if ((v13 = (cfr_temp_1 = MapCyclePetConfig.\u13e8 - (26838L ^ -6531726530642307442L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v13 == (18363 ^ 18362)) break;
            v13 = 16864 ^ 1999862198;
        }
        this.PET_GUARD_MODE_KEY_MS = v12;
        v14 = MapCyclePetConfig.\u13e8;
        if (true) ** GOTO lbl87
        block38: while (true) {
            v14 = v15 / (9020L ^ -2731937692434958281L);
lbl87:
            // 2 sources

            switch ((int)v14) {
                case -1604473025: {
                    v15 = 7699L ^ -2057667087203969524L;
                    continue block38;
                }
                case -490675804: {
                    v15 = 28353L ^ -960830509561129071L;
                    continue block38;
                }
                case 26730318: {
                    break block38;
                }
                case 1787556416: {
                    v15 = 18991L ^ -5329638944590089369L;
                    continue block38;
                }
            }
            break;
        }
        this.REPAIR_PET_WHILE_WAITING = 14814 ^ 14814;
    }
}

