/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.config.types.Num
 *  com.github.manolo8.darkbot.config.types.Option
 */
package com.tawaret.tawaplugin.features.mapcyclemodule.configs;

import com.github.manolo8.darkbot.config.types.Num;
import com.github.manolo8.darkbot.config.types.Option;

public class AdaptiveChecksConfig {
    @Option(value="Enable adaptive checks")
    public boolean ENABLE_ADAPTIVE_CHECKS;
    @Option(value="Force reset adaptive check", description="Resets adaptive check caches then begins again, flag is then set back to false")
    public boolean RESET_ADAPTIVE_CHECK;
    @Option(value="Minutes to perform adaptive check at")
    @Num(min=1, max=240, step=1)
    public int ADAPTIVE_CHECK_MINUTES;
    @Option(value="Enable auto configure refresh map", description="Automatically configures the map to refresh on (this is the map that leads to the map with the highest time spent on)")
    public boolean ENABLE_AUTO_CONFIGURE_REFRESH_MAP;
    @Option(value="Enable auto configure KFL (Kill First Lock)", description="Automatically configures the KFL flags per cycle map based on time spent")
    public boolean ENABLE_AUTO_CONFIGURE_KFL;
    @Option(value="Enable initial work map is longest wait map", description="Requires enabling adaptive refresh")
    public boolean ENABLE_INITIAL_MAP_IS_LONGEST_WAIT_MAP;
    public static long \u13e8 = -5449375104488458946L;

    /*
     * Unable to fully structure code
     */
    public AdaptiveChecksConfig() {
        v0 = AdaptiveChecksConfig.\u13e8;
        if (true) ** GOTO lbl5
        block25: while (true) {
            v0 = v1 / (18875L ^ 1228775056679017941L);
lbl5:
            // 2 sources

            switch ((int)v0) {
                case -1982137352: {
                    v1 = -1992242466885971636L >>> "\u0000\u0000".length();
                    continue block25;
                }
                case -384060098: {
                    break block25;
                }
                case 289031492: {
                    v1 = 8566L ^ 7294022134961129412L;
                    continue block25;
                }
            }
            break;
        }
        super();
        v2 = "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() ^ "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length();
        v3 = AdaptiveChecksConfig.\u13e8;
        if (true) ** GOTO lbl20
        block26: while (true) {
            v3 = v4 / (3192L ^ -7084922625454323766L);
lbl20:
            // 2 sources

            switch ((int)v3) {
                case -739689590: {
                    v4 = 13861L ^ 7102982897775578428L;
                    continue block26;
                }
                case -502953294: {
                    v4 = 6841L ^ 5089808125344114018L;
                    continue block26;
                }
                case -384060098: {
                    break block26;
                }
            }
            break;
        }
        this.ENABLE_ADAPTIVE_CHECKS = v2;
        v5 = "".length() >>> "\u0000\u0000".length();
        v6 = AdaptiveChecksConfig.\u13e8;
        if (true) ** GOTO lbl35
        block27: while (true) {
            v6 = (12904L ^ -4908725260098449872L) / (27906L ^ -6050816936538799808L);
lbl35:
            // 2 sources

            switch ((int)v6) {
                case -2047827343: {
                    continue block27;
                }
                case -384060098: {
                    break block27;
                }
            }
            break;
        }
        this.RESET_ADAPTIVE_CHECK = v5;
        while (true) {
            if ((v7 = (cfr_temp_0 = AdaptiveChecksConfig.\u13e8 - (11468L ^ 8428553905895144796L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v7 == (10043 ^ -10044)) break;
            v7 = -442327868 >>> "\u0000\u0000".length();
        }
        this.ADAPTIVE_CHECK_MINUTES = 19745 ^ 19741;
        while (true) {
            if ((v8 = (cfr_temp_1 = AdaptiveChecksConfig.\u13e8 - (1481L ^ -8965092184063344680L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v8 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v8 = 8246 ^ -639191942;
        }
        this.ENABLE_AUTO_CONFIGURE_REFRESH_MAP = 20723 ^ 20722;
        v9 = AdaptiveChecksConfig.\u13e8;
        if (true) ** GOTO lbl57
        block30: while (true) {
            v9 = v10 / (32461L ^ -9160799606858465928L);
lbl57:
            // 2 sources

            switch ((int)v9) {
                case -384060098: {
                    break block30;
                }
                case 474388237: {
                    v10 = 19720L ^ -736369948915758838L;
                    continue block30;
                }
                case 2020010703: {
                    v10 = 22685L ^ 522487112585528351L;
                    continue block30;
                }
            }
            break;
        }
        this.ENABLE_AUTO_CONFIGURE_KFL = 2576 ^ 2576;
        v11 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        v12 = AdaptiveChecksConfig.\u13e8;
        if (true) ** GOTO lbl72
        block31: while (true) {
            v12 = v13 / (27086L ^ -3455971423661551085L);
lbl72:
            // 2 sources

            switch ((int)v12) {
                case -2131387574: {
                    v13 = 6567794675896560276L >>> "\u0000\u0000".length();
                    continue block31;
                }
                case -384060098: {
                    break block31;
                }
                case 493882562: {
                    v13 = 14167L ^ 7205589928989185236L;
                    continue block31;
                }
                case 567678171: {
                    v13 = 14379L ^ -6329005010444565102L;
                    continue block31;
                }
            }
            break;
        }
        this.ENABLE_INITIAL_MAP_IS_LONGEST_WAIT_MAP = v11;
    }
}

