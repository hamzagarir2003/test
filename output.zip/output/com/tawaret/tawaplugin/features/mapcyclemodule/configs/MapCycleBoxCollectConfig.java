/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.config.Config$ShipConfig
 *  com.github.manolo8.darkbot.config.types.Num
 *  com.github.manolo8.darkbot.config.types.Option
 */
package com.tawaret.tawaplugin.features.mapcyclemodule.configs;

import com.github.manolo8.darkbot.config.Config;
import com.github.manolo8.darkbot.config.types.Num;
import com.github.manolo8.darkbot.config.types.Option;

public class MapCycleBoxCollectConfig {
    @Option(value="Enable collect config")
    public boolean ENABLE_COLLECT_CONFIG;
    @Option(value="Box collect config", description="Should be veteran and honour config")
    public Config.ShipConfig COLLECT_BOX;
    @Option(value="Press formation key (Seconds)", description="Presses the formation key every X seconds when bot is collecting boxes, 0 to disable")
    @Num(min=0, max=10, step=1)
    public int PRESS_COLLECT_FORMATION_KEY_SECONDS;
    @Option(value="Only collect boxes in preferred region", description="Useful to ignore invoke boxes")
    public boolean ONLY_COLLECT_BOXES_IN_PREFERRED_REGION;
    protected static long \u13e8 = -6448727658959340767L;

    /*
     * Unable to fully structure code
     */
    public MapCycleBoxCollectConfig() {
        v0 = MapCycleBoxCollectConfig.\u13e8;
        if (true) ** GOTO lbl5
        block14: while (true) {
            v0 = (23605L ^ 1152126928277661794L) / (-8210201878621593040L >>> "\u0000\u0000".length());
lbl5:
            // 2 sources

            switch ((int)v0) {
                case -866273309: {
                    continue block14;
                }
                case 1786641185: {
                    break block14;
                }
            }
            break;
        }
        super();
        v1 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        v2 = MapCycleBoxCollectConfig.\u13e8;
        if (true) ** GOTO lbl16
        block15: while (true) {
            v2 = (32326L ^ -4385273324834016097L) / (10521L ^ 6546436463706119861L);
lbl16:
            // 2 sources

            switch ((int)v2) {
                case -1992462741: {
                    continue block15;
                }
                case 1786641185: {
                    break block15;
                }
            }
            break;
        }
        this.ENABLE_COLLECT_CONFIG = v1;
        while (true) {
            if ((v3 = (cfr_temp_0 = MapCycleBoxCollectConfig.\u13e8 - (25355L ^ -1928835437876464047L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v3 == (20918 ^ -20919)) break;
            v3 = "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() ^ 1431056190;
        }
        v4 = "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        v5 = 212 >>> "\u0000\u0000".length();
        v6 = MapCycleBoxCollectConfig.\u13e8;
        if (true) ** GOTO lbl33
        block17: while (true) {
            v6 = v7 / (-8471663782808364328L >>> "\u0000\u0000".length());
lbl33:
            // 2 sources

            switch ((int)v6) {
                case -522240517: {
                    v7 = -5416777466617249976L >>> "\u0000\u0000".length();
                    continue block17;
                }
                case -379582484: {
                    v7 = 27274L ^ 700524713182418848L;
                    continue block17;
                }
                case -170008604: {
                    v7 = 22375L ^ -504862305770041784L;
                    continue block17;
                }
                case 1786641185: {
                    break block17;
                }
            }
            break;
        }
        v8 = Character.valueOf(v5);
        while (true) {
            if ((v9 = (cfr_temp_1 = MapCycleBoxCollectConfig.\u13e8 - (29210L ^ -3316658910126234818L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v9 == (22104 ^ -22105)) break;
            v9 = 2144 ^ -251176289;
        }
        v10 = new Config.ShipConfig(v4, v8);
        while (true) {
            if ((v11 = (cfr_temp_2 = MapCycleBoxCollectConfig.\u13e8 - (26145L ^ 5010565777109492122L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v11 == (8191 ^ -8192)) break;
            v11 = 7926 ^ 1950888382;
        }
        this.COLLECT_BOX = v10;
        while (true) {
            if ((v12 = (cfr_temp_3 = MapCycleBoxCollectConfig.\u13e8 - (3059L ^ -75895005150808610L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v12 == (31919 ^ -31920)) break;
            v12 = 8269 ^ -2119001670;
        }
        this.PRESS_COLLECT_FORMATION_KEY_SECONDS = 29753 ^ 29753;
        v13 = "".length() >>> "\u0000\u0000".length();
        while (true) {
            if ((v14 = (cfr_temp_4 = MapCycleBoxCollectConfig.\u13e8 - (-6774169358145399256L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v14 == (25568 ^ -25569)) break;
            v14 = -102233740 >>> "\u0000\u0000".length();
        }
        this.ONLY_COLLECT_BOXES_IN_PREFERRED_REGION = v13;
    }
}

