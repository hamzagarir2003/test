/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.config.Config$ShipConfig
 *  com.github.manolo8.darkbot.config.types.Num
 *  com.github.manolo8.darkbot.config.types.Option
 */
package com.tawaret.tawaplugin.features.mapcyclemodule.configs;

import com.github.manolo8.darkbot.config.Config;
import com.github.manolo8.darkbot.config.types.Num;
import com.github.manolo8.darkbot.config.types.Option;

public class NpcRewardConfig {
    @Option(value="Enable NPC reward config")
    public boolean ENABLE_NPC_REWARD_CONFIG;
    @Option(value="NPC reward config", description="Switches to this config when NPC is below hp threshold")
    public Config.ShipConfig NPC_REWARD_CONFIG;
    @Option(value="NPC reward hp threshold")
    @Num(min=0, max=2000000000, step=100000)
    public int NPC_REWARD_HP_THRESH;
    @Option(value="Press key when NPC below hp")
    public Character KEY_ON_NPC_BELOW_HP;
    private static long \u13e8 = 8161250086212979802L;

    /*
     * Unable to fully structure code
     */
    public NpcRewardConfig() {
        v0 = NpcRewardConfig.\u13e8;
        if (true) ** GOTO lbl5
        block12: while (true) {
            v0 = v1 / (30347L ^ -4484240866941648794L);
lbl5:
            // 2 sources

            switch ((int)v0) {
                case -1747334054: {
                    break block12;
                }
                case -736611323: {
                    v1 = 21227L ^ 7367527540952793103L;
                    continue block12;
                }
                case -148045385: {
                    v1 = 30351L ^ -8964728659051018781L;
                    continue block12;
                }
                case 1680610482: {
                    v1 = 6681L ^ 6145987680036156867L;
                    continue block12;
                }
            }
            break;
        }
        super();
        while (true) {
            if ((v2 = (cfr_temp_0 = NpcRewardConfig.\u13e8 - (27622L ^ 5437541142601373838L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v2 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v2 = 28005 ^ -1449774266;
        }
        this.ENABLE_NPC_REWARD_CONFIG = 12091 ^ 12091;
        while (true) {
            if ((v3 = (cfr_temp_1 = NpcRewardConfig.\u13e8 - (17256L ^ 7824908322678772427L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v3 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v3 = 12383 ^ -169771793;
        }
        while (true) {
            if ((v4 = (cfr_temp_2 = NpcRewardConfig.\u13e8 - (4177L ^ -6299302512978355057L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v4 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v4 = 18757 ^ 1624180203;
        }
        v5 = Character.valueOf((char)(20664 ^ 20621));
        while (true) {
            if ((v6 = (cfr_temp_3 = NpcRewardConfig.\u13e8 - (30924L ^ -369314872685544160L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v6 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v6 = 8706 ^ 845891584;
        }
        v7 = new Config.ShipConfig(28990 ^ 28988, v5);
        while (true) {
            if ((v8 = (cfr_temp_4 = NpcRewardConfig.\u13e8 - (27233L ^ -15599663328659130L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v8 == (24984 ^ 24985)) break;
            v8 = 7959 ^ 1621307573;
        }
        this.NPC_REWARD_CONFIG = v7;
        v9 = 1200000 >>> "\u0000\u0000".length();
        while (true) {
            if ((v10 = (cfr_temp_5 = NpcRewardConfig.\u13e8 - (5611609316833342692L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
            if (v10 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v10 = 24457 ^ 986039293;
        }
        this.NPC_REWARD_HP_THRESH = v9;
        v11 = NpcRewardConfig.\u13e8;
        if (true) ** GOTO lbl58
        block19: while (true) {
            v11 = v12 / (29276L ^ -6863166045278744793L);
lbl58:
            // 2 sources

            switch ((int)v11) {
                case -1747334054: {
                    break block19;
                }
                case -1094105410: {
                    v12 = 19335L ^ -1516305509757289494L;
                    continue block19;
                }
                case -927675953: {
                    v12 = 17987L ^ 5948922038563379813L;
                    continue block19;
                }
                case 1132085096: {
                    v12 = 26520L ^ 6122973971930614138L;
                    continue block19;
                }
            }
            break;
        }
        this.KEY_ON_NPC_BELOW_HP = null;
    }
}

