/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.config.types.Num
 *  com.github.manolo8.darkbot.config.types.Option
 */
package com.tawaret.tawaplugin.features.mapcyclemodule.configs;

import com.github.manolo8.darkbot.config.types.Num;
import com.github.manolo8.darkbot.config.types.Option;

public class MapCycleSafetyConfig {
    @Option(value="Safe ability key", description="Orcus ability key, sometime to help you survive")
    public Character SAFE_ABILITY_KEY;
    @Option(value="Minimum number of NPCs for unsafeness", description="Presses your 'Safe ability key' if the number of NPCS in sight is greater or equal to this value")
    @Num(min=0, max=100, step=1)
    public int MIN_NUM_NPCS_UNSAFE;
    @Option(value="Only count npc subname gone", description="If enabled, only counts npcs whose names contain the Wait until NPC subname gone value")
    public boolean ONLY_COUNT_NPC_SUBNAME_GONE;
    @Option(value="Buy cloak (single-use) if unsafe", description="Buys cloak if the number of npcs in sight exceeds the minimum specified")
    public boolean BUY_CLOAK_IF_UNSAFE;
    @Option(value="Allow buy cloak (after kill)", description="Allows buying cloak if within wait after kill period")
    public boolean ALLOW_BUY_CLOAK_WITHIN_WAIT_AFTER_KILL_PERIOD;
    @Option(value="Wait for npc subname if unsafe (before kill)", description="Stops shooting other npcs if unsafe (recommended enable buy cloak if unsafe as well)")
    public boolean WAIT_FOR_NPC_SUBNAME_IF_UNSAFE;
    @Option(value="Wait for npc subname if unsafe (after kill)", description="Stops shooting other npcs if unsafe, if within after kill period (recommended enable buy cloak if unsafe as well)")
    public boolean WAIT_FOR_NPC_SUBNAME_IF_UNSAFE_AFTER_KILL;
    @Option(value="Saftey HP percentage")
    @Num(min=0, max=100, step=1)
    public int SAFTEY_HP_THRESHOLD;
    @Option(value="Press safety key while shooting behe when below safety")
    public boolean USE_SAFETY_KEY_WHEN_BELOW_HP_SAFETY;
    @Option(value="Insta-shield key")
    public Character INSTA_SHIELD_KEY;
    @Option(value="Insta-shield HP percentage", description="Press insta-shield key if while shooting behe below this hp")
    @Num(min=0, max=100, step=1)
    public int INSTA_SHIELD_HP_THRESHOLD;
    private static long \u13e8 = -8002735096994420012L;

    /*
     * Unable to fully structure code
     */
    public MapCycleSafetyConfig() {
        v0 = MapCycleSafetyConfig.\u13e8;
        if (true) ** GOTO lbl5
        block47: while (true) {
            v0 = v1 / (26194L ^ -8204863502786937896L);
lbl5:
            // 2 sources

            switch ((int)v0) {
                case 327727145: {
                    v1 = 18396L ^ -7958392037459555197L;
                    continue block47;
                }
                case 1305556756: {
                    v1 = 1351L ^ 7829365428655734215L;
                    continue block47;
                }
                case 1612229332: {
                    break block47;
                }
                case 1700791802: {
                    v1 = 29326L ^ 8040677993864481938L;
                    continue block47;
                }
            }
            break;
        }
        super();
        v2 = MapCycleSafetyConfig.\u13e8;
        if (true) ** GOTO lbl22
        block48: while (true) {
            v2 = v3 / (25265L ^ 8039166420431042972L);
lbl22:
            // 2 sources

            switch ((int)v2) {
                case -1349134874: {
                    v3 = 22860L ^ -467951658093099538L;
                    continue block48;
                }
                case 738851334: {
                    v3 = -8505127224965569824L >>> "\u0000\u0000".length();
                    continue block48;
                }
                case 1041640926: {
                    v3 = 22035L ^ 9219286655995221021L;
                    continue block48;
                }
                case 1612229332: {
                    break block48;
                }
            }
            break;
        }
        v4 = Character.valueOf((char)(12763 ^ 12781));
        while (true) {
            if ((v5 = (cfr_temp_0 = MapCycleSafetyConfig.\u13e8 - (12371L ^ 6128573575945154720L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v5 == (3686 ^ -3687)) break;
            v5 = 10778 ^ 1940173578;
        }
        this.SAFE_ABILITY_KEY = v4;
        v6 = "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        v7 = MapCycleSafetyConfig.\u13e8;
        if (true) ** GOTO lbl46
        block50: while (true) {
            v7 = v8 / (23164L ^ -5427300038402702580L);
lbl46:
            // 2 sources

            switch ((int)v7) {
                case 248099171: {
                    v8 = 32151L ^ -4019658022488092783L;
                    continue block50;
                }
                case 587211433: {
                    v8 = 27766L ^ 6134202487763792178L;
                    continue block50;
                }
                case 1612229332: {
                    break block50;
                }
            }
            break;
        }
        this.MIN_NUM_NPCS_UNSAFE = v6;
        while (true) {
            if ((v9 = (cfr_temp_1 = MapCycleSafetyConfig.\u13e8 - (9592L ^ -6317208165558118023L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v9 == (19704 ^ -19705)) break;
            v9 = 19783 ^ -307804964;
        }
        this.ONLY_COUNT_NPC_SUBNAME_GONE = 32614 ^ 32615;
        v10 = MapCycleSafetyConfig.\u13e8;
        if (true) ** GOTO lbl66
        block52: while (true) {
            v10 = v11 / (11793L ^ -969010906198902757L);
lbl66:
            // 2 sources

            switch ((int)v10) {
                case 857264694: {
                    v11 = 7442L ^ -6655744579148047403L;
                    continue block52;
                }
                case 947389425: {
                    v11 = 11773L ^ -153633401200994310L;
                    continue block52;
                }
                case 1612229332: {
                    break block52;
                }
            }
            break;
        }
        this.BUY_CLOAK_IF_UNSAFE = 17654 ^ 17654;
        v12 = MapCycleSafetyConfig.\u13e8;
        if (true) ** GOTO lbl80
        block53: while (true) {
            v12 = v13 / (18975L ^ -1644173526389989153L);
lbl80:
            // 2 sources

            switch ((int)v12) {
                case -106665439: {
                    v13 = 19560L ^ -2353664808576596922L;
                    continue block53;
                }
                case 922008139: {
                    v13 = 20532L ^ -5641914484857863302L;
                    continue block53;
                }
                case 1612229332: {
                    break block53;
                }
            }
            break;
        }
        this.ALLOW_BUY_CLOAK_WITHIN_WAIT_AFTER_KILL_PERIOD = 14870 ^ 14871;
        v14 = "".length() >>> "\u0000\u0000".length();
        v15 = MapCycleSafetyConfig.\u13e8;
        if (true) ** GOTO lbl95
        block54: while (true) {
            v15 = v16 / (17345L ^ 2025344187225488910L);
lbl95:
            // 2 sources

            switch ((int)v15) {
                case -1821210275: {
                    v16 = 9570L ^ -8960236684843888234L;
                    continue block54;
                }
                case 1370710675: {
                    v16 = 1444004529881947932L >>> "\u0000\u0000".length();
                    continue block54;
                }
                case 1612229332: {
                    break block54;
                }
            }
            break;
        }
        this.WAIT_FOR_NPC_SUBNAME_IF_UNSAFE = v14;
        v17 = MapCycleSafetyConfig.\u13e8;
        if (true) ** GOTO lbl109
        block55: while (true) {
            v17 = v18 / (25717L ^ 7141204140776932012L);
lbl109:
            // 2 sources

            switch ((int)v17) {
                case -974023223: {
                    v18 = -6593602570551196676L >>> "\u0000\u0000".length();
                    continue block55;
                }
                case 1612229332: {
                    break block55;
                }
                case 2029752667: {
                    v18 = 18810L ^ 3675900534973897470L;
                    continue block55;
                }
            }
            break;
        }
        this.WAIT_FOR_NPC_SUBNAME_IF_UNSAFE_AFTER_KILL = 17741 ^ 17741;
        v19 = 240 >>> "\u0000\u0000".length();
        while (true) {
            if ((v20 = (cfr_temp_2 = MapCycleSafetyConfig.\u13e8 - (-6170195212872812888L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v20 == (27250 ^ -27251)) break;
            v20 = 394286124 >>> "\u0000\u0000".length();
        }
        this.SAFTEY_HP_THRESHOLD = v19;
        v21 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        v22 = MapCycleSafetyConfig.\u13e8;
        if (true) ** GOTO lbl131
        block57: while (true) {
            v22 = (3409L ^ 83501917624258810L) / (19561L ^ 6771712449315037338L);
lbl131:
            // 2 sources

            switch ((int)v22) {
                case -1676915899: {
                    continue block57;
                }
                case 1612229332: {
                    break block57;
                }
            }
            break;
        }
        this.USE_SAFETY_KEY_WHEN_BELOW_HP_SAFETY = v21;
        while (true) {
            if ((v23 = (cfr_temp_3 = MapCycleSafetyConfig.\u13e8 - (2749300124449485532L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v23 == (10837 ^ -10838)) break;
            v23 = 17565 ^ -2057829787;
        }
        this.INSTA_SHIELD_KEY = null;
        v24 = MapCycleSafetyConfig.\u13e8;
        if (true) ** GOTO lbl147
        block59: while (true) {
            v24 = v25 / (32259L ^ 663087207011951175L);
lbl147:
            // 2 sources

            switch ((int)v24) {
                case -1915800677: {
                    v25 = 5355L ^ -1272127483723356753L;
                    continue block59;
                }
                case -1258216142: {
                    v25 = 13553L ^ -459484477285967170L;
                    continue block59;
                }
                case 718970741: {
                    v25 = 6430L ^ 8647225079866461239L;
                    continue block59;
                }
                case 1612229332: {
                    break block59;
                }
            }
            break;
        }
        this.INSTA_SHIELD_HP_THRESHOLD = 2552 ^ 2506;
    }
}

