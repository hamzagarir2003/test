/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.config.types.Num
 *  com.github.manolo8.darkbot.config.types.Option
 */
package com.tawaret.tawaplugin.features.mapcyclemodule.configs;

import com.github.manolo8.darkbot.config.types.Num;
import com.github.manolo8.darkbot.config.types.Option;
import com.tawaret.tawaplugin.features.mapcyclemodule.configs.conditionconfigs.PredictedSpawnConditionConfig;

public class PredictNpcSpawnConfig {
    @Option(value="Enable track npc spawn time")
    public boolean ENABLE_TRACK_NPC_SPAWN_TIME;
    @Option(value="Disable shooting when within predict spawn period")
    public boolean DISABLE_SHOOTING_WHEN_WITHIN_PREDICTED_SPAWN_PERIOD;
    @Option(value="Wait in safety until predict spawn time under (Seconds)", description="-1 to disable")
    @Num(min=-1, max=10000, step=1)
    public int WAIT_IN_SAFETY_UNTIL_UNDER_SECONDS;
    @Option(value="Logout while waiting in safety", description="Will relog and wait without logging out depending on the logout offset")
    public boolean LOGOUT_WHILE_WAITING_IN_SAFETY;
    @Option(value="NPC subname spawn time (Minutes)")
    @Num(min=1, max=60, step=1)
    public int NPC_SUBNAME_SPAWN_TIME_MINS;
    @Option(value="NPC prepare for spawn period (Seconds)")
    @Num(min=0, max=600, step=1)
    public int PREPARE_FOR_SPAWN_PERIOD_SECONDS;
    @Option(value="On death track npc offset (Seconds)", description="On max deaths reached, bot will say the npc has died this amount of seconds in the future, -1 to set as unknown")
    @Num(min=-1, max=600, step=1)
    public int ON_DEATH_TRACK_NPC_OFFSET_SECONDS;
    @Option(value="Press key on predicted spawn period start")
    public Character KEY_ON_PREDICTED_SPAWN_PERIOD_START;
    @Option(value="Press key on predicted spawn period start #2")
    public Character KEY_ON_PREDICTED_SPAWN_PERIOD_START_2;
    @Option(value="Predicted spawn start press key depth (Ms)", description="Ms within predicted spawn period start to only afterwards press the key(s)")
    @Num(min=0, max=60000, step=500)
    public int KEY_PREPARE_DEPTH_MS;
    @Option(value="Map Change Condition", description="Npc subname death is marked as unknown, and bot changes to next map if condition is met")
    public PredictedSpawnConditionConfig MAP_CHANGE_COND_CONFIG;
    @Option(value="Stay until next map predicted spawn threshold (Seconds)", description="Stays on current map after npc is killed until next map predicted spawn seconds is less than this value (-1 to disable)")
    @Num(min=-1, max=99999, step=1)
    public int STAY_TILL_NEXT_MAP_PREDICTED_SPAWN_THRESHOLD;
    protected static long \u13e8 = 4279321950300117493L;

    /*
     * Unable to fully structure code
     */
    public PredictNpcSpawnConfig() {
        while (true) {
            if ((v0 = (cfr_temp_0 = PredictNpcSpawnConfig.\u13e8 - (13690L ^ 9084961127730029508L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == ("\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() ^ -23)) break;
            v0 = 8987 ^ -2128452394;
        }
        super();
        v1 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        while (true) {
            if ((v2 = (cfr_temp_1 = PredictNpcSpawnConfig.\u13e8 - (5434265154356632364L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v2 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v2 = 425 ^ -419650493;
        }
        this.ENABLE_TRACK_NPC_SPAWN_TIME = v1;
        v3 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        while (true) {
            if ((v4 = (cfr_temp_2 = PredictNpcSpawnConfig.\u13e8 - (2630095830117547324L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v4 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v4 = 29877 ^ 1499670473;
        }
        this.DISABLE_SHOOTING_WHEN_WITHIN_PREDICTED_SPAWN_PERIOD = v3;
        while (true) {
            if ((v5 = (cfr_temp_3 = PredictNpcSpawnConfig.\u13e8 - (6749L ^ 4810416692637273108L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v5 == (8588 ^ -8589)) break;
            v5 = 21548 ^ 2093399915;
        }
        this.WAIT_IN_SAFETY_UNTIL_UNDER_SECONDS = 26326 ^ -26327;
        v6 = "".length() >>> "\u0000\u0000".length();
        v7 = PredictNpcSpawnConfig.\u13e8;
        if (true) ** GOTO lbl32
        block43: while (true) {
            v7 = v8 / (-8944441738175186996L >>> "\u0000\u0000".length());
lbl32:
            // 2 sources

            switch ((int)v7) {
                case -850656847: {
                    v8 = 13522L ^ -6308025522737598790L;
                    continue block43;
                }
                case 168831787: {
                    v8 = 27198L ^ -1035233342523592605L;
                    continue block43;
                }
                case 388733429: {
                    break block43;
                }
            }
            break;
        }
        this.LOGOUT_WHILE_WAITING_IN_SAFETY = v6;
        v9 = PredictNpcSpawnConfig.\u13e8;
        if (true) ** GOTO lbl46
        block44: while (true) {
            v9 = (10460L ^ 6421732177623907695L) / (3993L ^ -7421579339191004881L);
lbl46:
            // 2 sources

            switch ((int)v9) {
                case -1755086621: {
                    continue block44;
                }
                case 388733429: {
                    break block44;
                }
            }
            break;
        }
        this.NPC_SUBNAME_SPAWN_TIME_MINS = 1748 ^ 1755;
        v10 = PredictNpcSpawnConfig.\u13e8;
        if (true) ** GOTO lbl56
        block45: while (true) {
            v10 = (29509L ^ -1830145107127601344L) / (12254L ^ -7921165454822870368L);
lbl56:
            // 2 sources

            switch ((int)v10) {
                case 388733429: {
                    break block45;
                }
                case 1992035417: {
                    continue block45;
                }
            }
            break;
        }
        this.PREPARE_FOR_SPAWN_PERIOD_SECONDS = 4488 ^ 4482;
        v11 = "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        v12 = PredictNpcSpawnConfig.\u13e8;
        if (true) ** GOTO lbl67
        block46: while (true) {
            v12 = v13 / (12751L ^ 2428003100107052605L);
lbl67:
            // 2 sources

            switch ((int)v12) {
                case -6192673: {
                    v13 = 21354L ^ -5251995029865712524L;
                    continue block46;
                }
                case 388733429: {
                    break block46;
                }
                case 1674727744: {
                    v13 = 7586L ^ 1447607267588330888L;
                    continue block46;
                }
                case 1760561137: {
                    v13 = 20800L ^ -8924641291086665191L;
                    continue block46;
                }
            }
            break;
        }
        this.ON_DEATH_TRACK_NPC_OFFSET_SECONDS = v11;
        while (true) {
            if ((v14 = (cfr_temp_4 = PredictNpcSpawnConfig.\u13e8 - (7142L ^ 9145553193514665177L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v14 == (3448 ^ -3449)) break;
            v14 = 4898 ^ -983555980;
        }
        this.KEY_ON_PREDICTED_SPAWN_PERIOD_START = null;
        while (true) {
            if ((v15 = (cfr_temp_5 = PredictNpcSpawnConfig.\u13e8 - (6502L ^ -4966601985675959346L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
            if (v15 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v15 = 9995 ^ 1225938225;
        }
        this.KEY_ON_PREDICTED_SPAWN_PERIOD_START_2 = null;
        v16 = "".length() >>> "\u0000\u0000".length();
        v17 = PredictNpcSpawnConfig.\u13e8;
        if (true) ** GOTO lbl97
        block49: while (true) {
            v17 = (10823L ^ 3392537863040570434L) / (26382L ^ -8802763838117541112L);
lbl97:
            // 2 sources

            switch ((int)v17) {
                case -251405635: {
                    continue block49;
                }
                case 388733429: {
                    break block49;
                }
            }
            break;
        }
        this.KEY_PREPARE_DEPTH_MS = v16;
        v18 = PredictNpcSpawnConfig.\u13e8;
        if (true) ** GOTO lbl107
        block50: while (true) {
            v18 = v19 / (5258L ^ 8981470166967424159L);
lbl107:
            // 2 sources

            switch ((int)v18) {
                case -839669365: {
                    v19 = -2950850469237916956L >>> "\u0000\u0000".length();
                    continue block50;
                }
                case 388733429: {
                    break block50;
                }
                case 671899094: {
                    v19 = 24068L ^ -3554359071974215693L;
                    continue block50;
                }
                case 2029893502: {
                    v19 = 8969L ^ 7766211007886245406L;
                    continue block50;
                }
            }
            break;
        }
        while (true) {
            if ((v20 = (cfr_temp_6 = PredictNpcSpawnConfig.\u13e8 - (24652L ^ -4324034460265813765L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
            if (v20 == (29628 ^ 29629)) break;
            v20 = 373 ^ -231409184;
        }
        v21 = new PredictedSpawnConditionConfig();
        v22 = PredictNpcSpawnConfig.\u13e8;
        if (true) ** GOTO lbl129
        block52: while (true) {
            v22 = v23 / (2641408605292187904L >>> "\u0000\u0000".length());
lbl129:
            // 2 sources

            switch ((int)v22) {
                case -846659268: {
                    v23 = 19113L ^ -6032031748627428122L;
                    continue block52;
                }
                case -430027927: {
                    v23 = 8695L ^ -8350755342948693657L;
                    continue block52;
                }
                case 388733429: {
                    break block52;
                }
                case 559363548: {
                    v23 = 8344203567152884752L >>> "\u0000\u0000".length();
                    continue block52;
                }
            }
            break;
        }
        this.MAP_CHANGE_COND_CONFIG = v21;
        v24 = PredictNpcSpawnConfig.\u13e8;
        if (true) ** GOTO lbl146
        block53: while (true) {
            v24 = (-5713303425193615700L >>> "\u0000\u0000".length()) / (21028L ^ 881027997262943659L);
lbl146:
            // 2 sources

            switch ((int)v24) {
                case 170452406: {
                    continue block53;
                }
                case 388733429: {
                    break block53;
                }
            }
            break;
        }
        this.STAY_TILL_NEXT_MAP_PREDICTED_SPAWN_THRESHOLD = 17624 ^ -17625;
    }
}

