/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.config.types.Num
 *  com.github.manolo8.darkbot.config.types.Option
 */
package com.tawaret.tawaplugin.features.mapcyclemodule.configs;

import com.github.manolo8.darkbot.config.types.Num;
import com.github.manolo8.darkbot.config.types.Option;

public class ExtraSecondsOnRefreshableMapsConfig {
    @Option(value="Enable waiting extra seconds on refreshable maps")
    public boolean USE_EXTRA_REFRESH_SECONDS;
    @Option(value="Extra seconds on refreshable maps")
    @Num(min=0, max=20000, step=10)
    public int EXTRA_REFRESH_MAP_SECONDS;
    public static long \u13e8 = -8241578759965597768L;

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public ExtraSecondsOnRefreshableMapsConfig() {
        long l = \u13e8;
        boolean bl = true;
        block18: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x1CD2L ^ 0xA43683D99390E73AL);
            }
            switch ((int)l) {
                case -1747411016: {
                    break block18;
                }
                case -286161797: {
                    l2 = 0x62AAL ^ 0xAA1EEF2964F8743FL;
                    continue block18;
                }
                case -123852032: {
                    l2 = 0x3CDCL ^ 0x230C4F5C7F2ADDA6L;
                    continue block18;
                }
                case 34907189: {
                    l2 = 0x12CFL ^ 0x5CDF46E12795B715L;
                    continue block18;
                }
            }
            break;
        }
        int n = "".length() >>> "\u0000\u0000".length();
        long l3 = \u13e8;
        boolean bl2 = true;
        block19: while (true) {
            long l4;
            if (!bl2 || (bl2 = false) || !true) {
                l3 = l4 / (0x51EDL ^ 0xE04842F7C158FE73L);
            }
            switch ((int)l3) {
                case -1747411016: {
                    break block19;
                }
                case -945275528: {
                    l4 = 0x721CL ^ 0x8A44D4C9B9EBA5FDL;
                    continue block19;
                }
                case -809204864: {
                    l4 = 2902595502932760348L >>> "\u0000\u0000".length();
                    continue block19;
                }
                case 2107698430: {
                    l4 = 0x649EL ^ 0x39E024A742F8E7AAL;
                    continue block19;
                }
            }
            break;
        }
        this.USE_EXTRA_REFRESH_SECONDS = n;
        int n2 = 960 >>> "\u0000\u0000".length();
        long l5 = \u13e8;
        boolean bl3 = true;
        block20: while (true) {
            long l6;
            if (!bl3 || (bl3 = false) || !true) {
                l5 = l6 / (0x11DAL ^ 0x6229EC29DD7C66F8L);
            }
            switch ((int)l5) {
                case -2004644495: {
                    l6 = 0xF54L ^ 0xC433B661B3CA9418L;
                    continue block20;
                }
                case -1747411016: {
                    break block20;
                }
                case 331191666: {
                    l6 = 0x46B5L ^ 0xA49A31C081D0045EL;
                    continue block20;
                }
                case 470310105: {
                    l6 = 0x2E1FL ^ 0x8D64E3CFA5F1B7A9L;
                    continue block20;
                }
            }
            break;
        }
        this.EXTRA_REFRESH_MAP_SECONDS = n2;
    }
}

