/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.config.types.Num
 *  com.github.manolo8.darkbot.config.types.Option
 */
package com.tawaret.tawaplugin.features.mapcyclemodule.configs.conditionconfigs;

import com.github.manolo8.darkbot.config.types.Num;
import com.github.manolo8.darkbot.config.types.Option;

public class DeathCountConditionConfig {
    @Option(value="Change map after 'x' deaths on same map", description="'0' for no switch death")
    @Num(min=0, max=20000, step=1)
    public int MAX_MAP_DEATHS_BEFORE_SWITCH;
    static long \u13e8 = -8802809020458360344L;

    /*
     * Unable to fully structure code
     */
    public DeathCountConditionConfig() {
        while (true) {
            if ((v0 = (cfr_temp_0 = DeathCountConditionConfig.\u13e8 - (16114L ^ 5690320469712565003L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (31736 ^ -31737)) break;
            v0 = 11286 ^ -577332387;
        }
        super();
        v1 = "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        v2 = DeathCountConditionConfig.\u13e8;
        if (true) ** GOTO lbl12
        block6: while (true) {
            v2 = v3 / (18820L ^ -2855973430112616567L);
lbl12:
            // 2 sources

            switch ((int)v2) {
                case -2006373572: {
                    v3 = -2945951635258220244L >>> "\u0000\u0000".length();
                    continue block6;
                }
                case -839278104: {
                    break block6;
                }
                case -549752539: {
                    v3 = 18027L ^ 418282355601394223L;
                    continue block6;
                }
            }
            break;
        }
        this.MAX_MAP_DEATHS_BEFORE_SWITCH = v1;
    }
}

