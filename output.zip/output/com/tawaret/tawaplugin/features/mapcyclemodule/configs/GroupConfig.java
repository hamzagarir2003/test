/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.config.types.Num
 *  com.github.manolo8.darkbot.config.types.Option
 */
package com.tawaret.tawaplugin.features.mapcyclemodule.configs;

import com.github.manolo8.darkbot.config.types.Num;
import com.github.manolo8.darkbot.config.types.Option;

public class GroupConfig {
    @Option(value="Wait for group member count", description="Waits in safety until at least this many people in group on the same map as you, 0 to disable")
    @Num(min=0, max=7, step=1)
    public int WAIT_FOR_GROUP_MEMBER_COUNT;
    @Option(value="Wait to be in group", description="If group member count is > 0, then if bot has no group wait in safety, otherwise continue")
    public boolean WAIT_TO_BE_IN_GROUP;
    private static long \u13e8 = -4799136206147254565L;

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public GroupConfig() {
        long l = \u13e8;
        boolean bl = true;
        block6: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x1FA7L ^ 0x9F0BF32EBD53EED4L);
            }
            switch ((int)l) {
                case -726455959: {
                    l2 = -6146310823596276424L >>> "\u0000\u0000".length();
                    continue block6;
                }
                case -29835410: {
                    l2 = 0x1213L ^ 0x9111509A449DA582L;
                    continue block6;
                }
                case 601917147: {
                    break block6;
                }
                case 1994634152: {
                    l2 = 0x54E0L ^ 0x64705B0B8F6197C6L;
                    continue block6;
                }
            }
            break;
        }
        int n = "".length() >>> "\u0000\u0000".length();
        while (true) {
            long l3;
            long l4;
            if ((l4 = (l3 = \u13e8 - (0x1C5L ^ 0xA1B32B45F37032CFL)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) continue;
            if (l4 == (0x584F ^ 0x584E)) break;
            l4 = 0x3665 ^ 0x60D02F43;
        }
        this.WAIT_FOR_GROUP_MEMBER_COUNT = n;
        while (true) {
            long l5;
            long l6;
            if ((l6 = (l5 = \u13e8 - (0x535CL ^ 0x84AEE798AFD9A930L)) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) continue;
            if (l6 == (0x41F3 ^ 0x41F2)) {
                this.WAIT_TO_BE_IN_GROUP = 0x13F1 ^ 0x13F0;
                return;
            }
            l6 = 0x2FC5 ^ 0x6C9476CE;
        }
    }
}

