/*
 * Decompiled with CFR 0.152.
 */
package com.tawaret.tawaplugin.services;

import com.tawaret.tawaplugin.logging.ILoggable;

public class UserLogs {
    public static long \u13e8 = 1677258460410895834L;

    public UserLogs() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x1849L ^ 0xEFE5E32CB066688AL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x6721 ^ 0x6720)) break;
            l2 = 0xB79 ^ 0x55834D32;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void LogLicenseExpirey(ILoggable loggable, String at) {
        byte[] byArray = new byte[0x61F3 ^ 0x61E5];
        byArray[0x7853 ^ 0x7855] = 352 >>> "\u0000\u0000".length();
        byArray[0xC2E ^ 0xC28] = 404 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 480 >>> "\u0000\u0000".length();
        byArray["".length() >>> "\u0000\u0000".length()] = 304 >>> "\u0000\u0000".length();
        byArray[0x5AD3 ^ 0x5AD8] = 0x57B4 ^ 0x57DD;
        byArray[0x28A3 ^ 0x28A2] = 0x277C ^ 0x2715;
        byArray[0x688D ^ 0x688A] = 128 >>> "\u0000\u0000".length();
        byArray[0x4AA1 ^ 0x4AB5] = 148 >>> "\u0000\u0000".length();
        byArray[0xB43 ^ 0xB53] = 444 >>> "\u0000\u0000".length();
        byArray[0x7025 ^ 0x7028] = 0x6A14 ^ 0x6A71;
        byArray[0x1A5A ^ 0x1A4F] = 0x2C9C ^ 0x2CEF;
        byArray[0x2894 ^ 0x289C] = 404 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x60EB ^ 0x6085;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x334E ^ 0x333C;
        byArray[0x14B4 ^ 0x14A7] = 128 >>> "\u0000\u0000".length();
        byArray[0x76DC ^ 0x76DF] = 404 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x188F ^ 0x18E1;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 460 >>> "\u0000\u0000".length();
        byArray[0x177E ^ 0x176C] = 0x5106 ^ 0x513C;
        byArray[0x348B ^ 0x3489] = 396 >>> "\u0000\u0000".length();
        byArray[0x5E74 ^ 0x5E71] = 460 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 448 >>> "\u0000\u0000".length();
        byArray[0x1D4C ^ 0x1D43] = 0x3916 ^ 0x3936;
        String string = new String(byArray);
        Object[] objectArray = new Object[0x2BB8 ^ 0x2BB9];
        objectArray["".length() >>> "\u0000\u0000".length()] = at;
        long l = \u13e8;
        block4: while (true) {
            switch ((int)l) {
                case -1032594981: {
                    l = (0x940L ^ 0x526BE202CAEC9514L) / (0x4D38L ^ 0xBEF58F4630E8229AL);
                    continue block4;
                }
                case -380674598: {
                    break block4;
                }
            }
            break;
        }
        String string2 = String.format(string, objectArray);
        while (true) {
            long l2;
            long l3;
            if ((l3 = (l2 = \u13e8 - (0x6FA1L ^ 0xA5DB76DA5312726FL)) == 0L ? 0 : (l2 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l3 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                loggable.log(string2);
                return;
            }
            l3 = 0x5C3 ^ 0x72B5A347;
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public static void LogKeepSessionParams(ILoggable loggable, Long userId, String key) {
        byte[] byArray = new byte["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
        byArray[0x71D5 ^ 0x71DF] = "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x7923 ^ 0x794D;
        byArray[0x377C ^ 0x376F] = 460 >>> "\u0000\u0000".length();
        byArray["".length() >>> "\u0000\u0000".length()] = 300 >>> "\u0000\u0000".length();
        byArray[0x3F74 ^ 0x3F73] = 0x3165 ^ 0x3116;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 388 >>> "\u0000\u0000".length();
        byArray[0x7B0B ^ 0x7B1C] = 0x3F03 ^ 0x3F68;
        byArray[0x1A2B ^ 0x1A26] = 0x5550 ^ 0x5534;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x6A07 ^ 0x6A27;
        byArray[0x5A8E ^ 0x5A86] = 0x4379 ^ 0x4310;
        byArray[0x6732 ^ 0x6731] = 0x614F ^ 0x613F;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 464 >>> "\u0000\u0000".length();
        byArray[0x2AD0 ^ 0x2ADB] = 0x437E ^ 0x4344;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 460 >>> "\u0000\u0000".length();
        byArray[0x383 ^ 0x398] = 0x5E0B ^ 0x5E2E;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 404 >>> "\u0000\u0000".length();
        byArray[0x56A5 ^ 0x56AC] = 0x6412 ^ 0x647D;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x7439 ^ 0x7445;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x3C4 ^ 0x3BD;
        byArray[0xBC6 ^ 0xBC2] = 0x2EB ^ 0x2B8;
        byArray[0x6867 ^ 0x687D] = 0x146E ^ 0x1453;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 244 >>> "\u0000\u0000".length();
        byArray[0xA7F ^ 0xA69] = 0x27C8 ^ 0x27E8;
        byArray[0x4C5A ^ 0x4C5B] = 0x35DB ^ 0x35BE;
        byArray[0x5396 ^ 0x5394] = 0x33DC ^ 0x33B9;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x544F ^ 0x543C;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x6413 ^ 0x6476;
        byArray[0x3B96 ^ 0x3B86] = 0x7B76 ^ 0x7B17;
        byArray[0xE6 ^ 0xF4] = 148 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 128 >>> "\u0000\u0000".length();
        String string = new String(byArray);
        Object[] objectArray = new Object[0x6240 ^ 0x6242];
        objectArray[0x5EB5 ^ 0x5EB5] = userId;
        objectArray[0x2D86 ^ 0x2D87] = key;
        long l = \u13e8;
        boolean bl = true;
        block9: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x5F78L ^ 0x827DB62E2F3F20EBL);
            }
            switch ((int)l) {
                case -380674598: {
                    break block9;
                }
                case -228768031: {
                    l2 = 868969373328548016L >>> "\u0000\u0000".length();
                    continue block9;
                }
                case 1235512445: {
                    l2 = 0x1F48L ^ 0x9571F530CDCAB66L;
                    continue block9;
                }
            }
            break;
        }
        String string2 = String.format(string, objectArray);
        long l3 = \u13e8;
        block10: while (true) {
            switch ((int)l3) {
                case -1046921645: {
                    l3 = (-5531938709985006892L >>> "\u0000\u0000".length()) / (0x4F70L ^ 0x39866350EB769B11L);
                    continue block10;
                }
                case -380674598: {
                    break block10;
                }
            }
            break;
        }
        loggable.log(string2);
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public static void LogStartSessionParams(ILoggable loggable, Long userId) {
        byte[] byArray = new byte[0x3C55 ^ 0x3C45];
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x3128 ^ 0x3151;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x641E ^ 0x647B;
        byArray[0x1C57 ^ 0x1C53] = 464 >>> "\u0000\u0000".length();
        byArray[0x196C ^ 0x1960] = 232 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x4AC1 ^ 0x4AA0;
        byArray["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 464 >>> "\u0000\u0000".length();
        byArray[0x5274 ^ 0x5271] = 332 >>> "\u0000\u0000".length();
        byArray[0x52B9 ^ 0x52B4] = 0x5BC3 ^ 0x5BE3;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x25F ^ 0x230;
        byArray["".length() >>> "\u0000\u0000".length()] = 0x1BB2 ^ 0x1BE1;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 148 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x6CD7 ^ 0x6CA5;
        byArray[0x1002 ^ 0x100D] = 0x1CE7 ^ 0x1C83;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0xD33 ^ 0xD5A;
        byArray[0x2254 ^ 0x2253] = 460 >>> "\u0000\u0000".length();
        byArray[0x4A6B ^ 0x4A60] = 0x3C23 ^ 0x3C4D;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 460 >>> "\u0000\u0000".length();
        String string = new String(byArray);
        Object[] objectArray = new Object["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
        objectArray["".length() >>> "\u0000\u0000".length()] = userId;
        long l = \u13e8;
        boolean bl = true;
        block6: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x5FB1L ^ 0x6382196D9546EA1AL);
            }
            switch ((int)l) {
                case -380674598: {
                    break block6;
                }
                case -137070110: {
                    l2 = 0x7B0CL ^ 0xF541DE18D7487E4AL;
                    continue block6;
                }
                case -117330023: {
                    l2 = 0x2BL ^ 0xA604A004537239EFL;
                    continue block6;
                }
                case 2018947976: {
                    l2 = 0x3AL ^ 0x5DB3004C025A951EL;
                    continue block6;
                }
            }
            break;
        }
        String string2 = String.format(string, objectArray);
        while (true) {
            long l3;
            long l4;
            if ((l4 = (l3 = \u13e8 - (0x1797L ^ 0x4DE84B6D26548FDAL)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l4 == (0x75CF ^ 0xFFFF8A30)) {
                loggable.log(string2);
                return;
            }
            l4 = -273369132 >>> "\u0000\u0000".length();
        }
    }

    public static void LogVerifyLicenseCheck(ILoggable loggable, Long userId) {
        byte[] byArray = new byte[0x2249 ^ 0x2258];
        byArray[0x5925 ^ 0x5929] = 0x2900 ^ 0xFFFFD685;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 404 >>> "\u0000\u0000".length();
        byArray[0x1FA4 ^ 0x1FA3] = 0x52FC ^ 0x5295;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x7670 ^ 0x7615;
        byArray[0x10D3 ^ 0x10D6] = 484 >>> "\u0000\u0000".length();
        byArray[0x2A2F ^ 0x2A22] = 0x399D ^ 0x39A7;
        byArray[0x5CC5 ^ 0x5CC7] = 456 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 404 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x6B57 ^ 0x6B33;
        byArray[0x7BF9 ^ 0x7BF2] = 460 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x1EDA ^ 0x1E96;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 420 >>> "\u0000\u0000".length();
        byArray[0x1183 ^ 0x118C] = 0x4860 ^ 0x4845;
        byArray[0xC50 ^ 0xC50] = 0x2D55 ^ 0x2D03;
        byArray[0x599C ^ 0x5994] = 396 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 128 >>> "\u0000\u0000".length();
        byArray[0x5F1 ^ 0x5FB] = 0x4670 ^ 0x461E;
        byArray[0x7631 ^ 0x7635] = 0x1D6A ^ 0x1D0C;
        String string = new String(byArray);
        Object[] objectArray = new Object[0x4E12 ^ 0x4E13];
        objectArray["".length() >>> "\u0000\u0000".length()] = userId;
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x3187L ^ 0x5EBC8ABDA242D02FL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x6669 ^ 0xFFFF9996)) break;
            l2 = 0x68E5 ^ 0x89D28CF3;
        }
        String string2 = String.format(string, objectArray);
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = \u13e8 - (0x1C8CL ^ 0x93DA0DC4A25D498AL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l3 == (0x6477 ^ 0x6476)) break;
            l3 = 612242528 >>> "\u0000\u0000".length();
        }
        loggable.log(string2);
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public static void LogVerifyLicenseCheck(ILoggable loggable) {
        byte[] byArray = new byte[0x54A6 ^ 0x54AB];
        byArray["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x609E ^ 0xFFFF9F64;
        byArray["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 404 >>> "\u0000\u0000".length();
        byArray[0x670E ^ 0x6702] = 0x2E40 ^ 0x2E25;
        byArray[0x3FD0 ^ 0x3FD4] = 0x5CD4 ^ 0x5CB2;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x2ADB ^ 0x2AA9;
        byArray[0x6F0E ^ 0x6F09] = 0x162C ^ 0x1645;
        byArray[0x1893 ^ 0x1896] = 0x3AA7 ^ 0x3ADE;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x6DEE ^ 0x6DA2;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 420 >>> "\u0000\u0000".length();
        byArray[0x35E8 ^ 0x35E3] = 0x5D3A ^ 0x5D49;
        byArray[0xBA7 ^ 0xBA7] = 0x7016 ^ 0x7040;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x1F9A ^ 0x1FFF;
        byArray[0x4AFF ^ 0x4AF5] = 440 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 396 >>> "\u0000\u0000".length();
        String string = new String(byArray);
        long l = \u13e8;
        boolean bl = true;
        block6: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x1123L ^ 0x470479C97AC94ED1L);
            }
            switch ((int)l) {
                case -380674598: {
                    break block6;
                }
                case 332828944: {
                    l2 = 0x5212L ^ 0x9BE90BEB6443112AL;
                    continue block6;
                }
                case 842870337: {
                    l2 = 0x2DBFL ^ 0xC1042ED15F7A8DEDL;
                    continue block6;
                }
                case 1877579562: {
                    l2 = 6552070625109876288L >>> "\u0000\u0000".length();
                    continue block6;
                }
            }
            break;
        }
        loggable.log(string);
    }
}

