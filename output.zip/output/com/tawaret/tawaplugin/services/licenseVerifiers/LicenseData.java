/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.utils.AuthAPI
 */
package com.tawaret.tawaplugin.services.licenseVerifiers;

import com.github.manolo8.darkbot.utils.AuthAPI;
import com.tawaret.tawaplugin.utils.AuthApi.AuthApiExtensions;

public class LicenseData {
    public static long \u13e8 = 5653888397197325878L;

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public LicenseData() {
        long l = \u13e8;
        boolean bl = true;
        block6: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x36A0L ^ 0xA5FA61B1900B9CA6L);
            }
            switch ((int)l) {
                case -1431947722: {
                    break block6;
                }
                case -1349871296: {
                    l2 = 0x336EL ^ 0x3D014AC1D12F4EC1L;
                    continue block6;
                }
                case -683961911: {
                    l2 = 0x2806L ^ 0x63D093691B965567L;
                    continue block6;
                }
                case 521322872: {
                    l2 = 0x93BL ^ 0xCD88133F0E1CDE57L;
                    continue block6;
                }
            }
            break;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public static Long getDiscordUserId(AuthAPI authAPI) {
        long l = \u13e8;
        block4: while (true) {
            switch ((int)l) {
                case -1431947722: {
                    return AuthApiExtensions.GetDiscordId(authAPI);
                }
                case 1192057036: {
                    l = (0x1B30L ^ 0x76BCB36B62018165L) / (0x399L ^ 0xD7335070591E1B2CL);
                    continue block4;
                }
            }
            break;
        }
        return AuthApiExtensions.GetDiscordId(authAPI);
    }
}

