/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.utils.AuthAPI
 */
package com.tawaret.tawaplugin.services.licenseVerifiers;

import com.github.manolo8.darkbot.utils.AuthAPI;

public interface ITwLicenseVerifier {
    public boolean Verify(AuthAPI var1);
}

