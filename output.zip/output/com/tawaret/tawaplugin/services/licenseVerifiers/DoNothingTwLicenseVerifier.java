/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.utils.AuthAPI
 */
package com.tawaret.tawaplugin.services.licenseVerifiers;

import com.github.manolo8.darkbot.utils.AuthAPI;
import com.tawaret.tawaplugin.logging.ILoggable;
import com.tawaret.tawaplugin.services.UserLogs;
import com.tawaret.tawaplugin.services.licenseVerifiers.ITwLicenseVerifier;

public class DoNothingTwLicenseVerifier
implements ITwLicenseVerifier,
ILoggable {
    private static long \u13e8 = -6927989533360040816L;

    public DoNothingTwLicenseVerifier() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x65DDL ^ 0x7B4FAA7BEF233C80L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x39F ^ 0xFFFFFC60)) break;
            l2 = 0x7912 ^ 0xC42746DF;
        }
    }

    @Override
    public boolean Verify(AuthAPI authAPI) {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x720CL ^ 0x2F7AFAD8E6E014CDL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x5036 ^ 0xFFFFAFC9)) break;
            l2 = 0x79C2 ^ 0x84885A34;
        }
        UserLogs.LogVerifyLicenseCheck(this);
        return (0x45CF ^ 0x45CE) != 0;
    }
}

