/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.utils.AuthAPI
 */
package com.tawaret.tawaplugin.services.licenseVerifiers;

import com.github.manolo8.darkbot.utils.AuthAPI;
import com.tawaret.tawaplugin.services.licenseVerifiers.ITwLicenseVerifier;

public class RateLimitedTwLicenseVerifier
implements ITwLicenseVerifier {
    private final ITwLicenseVerifier licenseVerifier;
    private final long rateLimitMs;
    private long timeStampMs;
    private Boolean cachedValidResponse;
    static long \u13e8 = -7439270201675240918L;

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public RateLimitedTwLicenseVerifier(ITwLicenseVerifier licenseVerifier, long rateLimitMs) {
        long l = \u13e8;
        block10: while (true) {
            switch ((int)l) {
                case -1593857494: {
                    break block10;
                }
                case 1620905825: {
                    l = (0x795FL ^ 0xCE0F045AA23612E5L) / (0x543BL ^ 0x4E59BE0EE34A66CCL);
                    continue block10;
                }
            }
            break;
        }
        long l2 = 0L >>> "\u0000\u0000".length();
        long l3 = \u13e8;
        boolean bl = true;
        block11: while (true) {
            long l4;
            if (!bl || (bl = false) || !true) {
                l3 = l4 / (0x75CBL ^ 0x8C8F2DE47B661E14L);
            }
            switch ((int)l3) {
                case -1902131003: {
                    l4 = 0x345AL ^ 0xB53D193F8C62D18DL;
                    continue block11;
                }
                case -1593857494: {
                    break block11;
                }
                case -1393121095: {
                    l4 = 0x2B4DL ^ 0xE2791960C274A7D3L;
                    continue block11;
                }
                case -320057796: {
                    l4 = 0x756DL ^ 0x6E4D9D1EF0F49745L;
                    continue block11;
                }
            }
            break;
        }
        this.timeStampMs = l2;
        while (true) {
            long l5;
            long l6;
            if ((l6 = (l5 = \u13e8 - (0x7FE1L ^ 0xA6C45DB77125AB88L)) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) continue;
            if (l6 == (0x4728 ^ 0xFFFFB8D7)) break;
            l6 = 0x69A6 ^ 0xE33F0050;
        }
        this.cachedValidResponse = null;
        while (true) {
            long l7;
            long l8;
            if ((l8 = (l7 = \u13e8 - (0x3591L ^ 0xBC6037B2BD9059D2L)) == 0L ? 0 : (l7 < 0L ? -1 : 1)) == false) continue;
            if (l8 == (0x72EA ^ 0xFFFF8D15)) break;
            l8 = 0x290F ^ 0xD1D7DCCE;
        }
        this.licenseVerifier = licenseVerifier;
        while (true) {
            long l9;
            long l10;
            if ((l10 = (l9 = \u13e8 - (-5315850384189855108L >>> "\u0000\u0000".length())) == 0L ? 0 : (l9 < 0L ? -1 : 1)) == false) continue;
            if (l10 == (0x7E41 ^ 0xFFFF81BE)) {
                this.rateLimitMs = rateLimitMs;
                return;
            }
            l10 = 1722828176 >>> "\u0000\u0000".length();
        }
    }

    /*
     * Exception decompiling
     */
    @Override
    public boolean Verify(AuthAPI authAPI) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * java.lang.UnsupportedOperationException
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.considerAsDoLoopStart(LoopIdentifier.java:383)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.identifyLoops1(LoopIdentifier.java:65)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:681)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }
}

