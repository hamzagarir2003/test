/*
 * Decompiled with CFR 0.152.
 */
package com.tawaret.tawaplugin.services.licenseVerifiers;

import com.tawaret.tawaplugin.services.licenseVerifiers.DoNothingTwLicenseVerifier;
import com.tawaret.tawaplugin.services.licenseVerifiers.ITwLicenseVerifier;
import com.tawaret.tawaplugin.services.licenseVerifiers.RateLimitedTwLicenseVerifier;
import com.tawaret.tawaplugin.services.licenseVerifiers.TwLicenseVerifier;
import com.tawaret.tawaplugin.utils.Compilation.CompilationFlags;
import com.tawaret.tawaplugin.utils.HttpClients.HttpClient;

public class TwLicenseVerifierFactory {
    private static long \u13e8 = 532428752740343036L;

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public TwLicenseVerifierFactory() {
        long l = \u13e8;
        boolean bl = true;
        block5: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x782FL ^ 0xBBD1239799601AE2L);
            }
            switch ((int)l) {
                case -2014257930: {
                    l2 = 8283658722863105088L >>> "\u0000\u0000".length();
                    continue block5;
                }
                case 446267418: {
                    l2 = -702718346756472176L >>> "\u0000\u0000".length();
                    continue block5;
                }
                case 860544252: {
                    break block5;
                }
            }
            break;
        }
    }

    /*
     * Unable to fully structure code
     */
    private static ITwLicenseVerifier Prod() {
        v0 = TwLicenseVerifierFactory.\u13e8;
        if (true) ** GOTO lbl5
        block17: while (true) {
            v0 = v1 / (7528326264580184748L >>> "\u0000\u0000".length());
lbl5:
            // 2 sources

            switch ((int)v0) {
                case -1145622644: {
                    v1 = 26067L ^ 9176700299934300444L;
                    continue block17;
                }
                case -294562877: {
                    v1 = 16892L ^ 2491575810637726895L;
                    continue block17;
                }
                case -222115238: {
                    v1 = 17160L ^ 7803599155578000330L;
                    continue block17;
                }
                case 860544252: {
                    break block17;
                }
            }
            break;
        }
        while (true) {
            if ((v2 = (cfr_temp_0 = TwLicenseVerifierFactory.\u13e8 - (15923L ^ -2826352235464936551L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v2 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v2 = 19401 ^ 1932968457;
        }
        while (true) {
            if ((v3 = (cfr_temp_1 = TwLicenseVerifierFactory.\u13e8 - (8245L ^ -1593223943455817647L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v3 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v3 = 21047 ^ 866491291;
        }
        v4 = new HttpClient();
        v5 = TwLicenseVerifierFactory.\u13e8;
        if (true) ** GOTO lbl32
        block20: while (true) {
            v5 = v6 / (-6921829844236719772L >>> "\u0000\u0000".length());
lbl32:
            // 2 sources

            switch ((int)v5) {
                case -1591154530: {
                    v6 = 16639L ^ -3323322171169639031L;
                    continue block20;
                }
                case 860544252: {
                    break block20;
                }
                case 1481245044: {
                    v6 = 12474L ^ -6106852075310396453L;
                    continue block20;
                }
                case 1890614701: {
                    v6 = -5101767555713811640L >>> "\u0000\u0000".length();
                    continue block20;
                }
            }
            break;
        }
        v7 = new TwLicenseVerifier(v4, (boolean)(3898 ^ 3898));
        v8 = TwLicenseVerifierFactory.\u13e8;
        if (true) ** GOTO lbl49
        block21: while (true) {
            v8 = v9 / (1747923104485784088L >>> "\u0000\u0000".length());
lbl49:
            // 2 sources

            switch ((int)v8) {
                case -68711186: {
                    v9 = 28251L ^ -5279293337142234315L;
                    continue block21;
                }
                case 693686469: {
                    v9 = 12423L ^ 8461737171357619484L;
                    continue block21;
                }
                case 860544252: {
                    break block21;
                }
            }
            break;
        }
        return TwLicenseVerifierFactory.RateLimited(v7);
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private static ITwLicenseVerifier WebDev() {
        long l = \u13e8;
        boolean bl = true;
        block9: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x28E1L ^ 0x5707549F1AA502D6L);
            }
            switch ((int)l) {
                case -1820915272: {
                    l2 = 0x49DL ^ 0x74B418C2CC341CDL;
                    continue block9;
                }
                case -709699064: {
                    l2 = 0x6F6L ^ 0x56080F88C629BC9FL;
                    continue block9;
                }
                case 860544252: {
                    break block9;
                }
            }
            break;
        }
        while (true) {
            long l3;
            long l4;
            if ((l4 = (l3 = \u13e8 - (0x2F97L ^ 0x793785B2A7CB0667L)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) continue;
            if (l4 == (0x17CB ^ 0xFFFFE834)) break;
            l4 = 0xA98 ^ 0xCC3D6914;
        }
        while (true) {
            long l5;
            long l6;
            if ((l6 = (l5 = \u13e8 - (-1825499626018072680L >>> "\u0000\u0000".length())) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) continue;
            if (l6 == (0x431F ^ 0xFFFFBCE0)) break;
            l6 = 0x29A1 ^ 0x665B346E;
        }
        HttpClient httpClient = new HttpClient();
        boolean bl2 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        long l7 = \u13e8;
        block12: while (true) {
            switch ((int)l7) {
                case -808682094: {
                    l7 = (0x2C10L ^ 0xD59D3DA49062A9C0L) / (0x79FFL ^ 0xA9FEEDFEF28C03A1L);
                    continue block12;
                }
                case 860544252: {
                    break block12;
                }
            }
            break;
        }
        TwLicenseVerifier twLicenseVerifier = new TwLicenseVerifier(httpClient, bl2);
        while (true) {
            long l8;
            long l9;
            if ((l9 = (l8 = \u13e8 - (0x4588L ^ 0x8351C905682424FFL)) == 0L ? 0 : (l8 < 0L ? -1 : 1)) == false) continue;
            if (l9 == (0x249B ^ 0x249A)) {
                return TwLicenseVerifierFactory.RateLimited(twLicenseVerifier);
            }
            l9 = 0x5FC4 ^ 0x800EB499;
        }
    }

    /*
     * Unable to fully structure code
     */
    private static ITwLicenseVerifier None() {
        while (true) {
            if ((v0 = (cfr_temp_0 = TwLicenseVerifierFactory.\u13e8 - (20409L ^ 6152378045547920522L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v0 == (12845 ^ -12846)) break;
            v0 = 11547 ^ 2029651663;
        }
        v1 = TwLicenseVerifierFactory.\u13e8;
        if (true) ** GOTO lbl11
        block6: while (true) {
            v1 = v2 / (2497L ^ -3648604853404035684L);
lbl11:
            // 2 sources

            switch ((int)v1) {
                case 496531926: {
                    v2 = 27579L ^ -6627754811811409312L;
                    continue block6;
                }
                case 591543346: {
                    v2 = 17732L ^ 2801183926456926524L;
                    continue block6;
                }
                case 860544252: {
                    break block6;
                }
            }
            break;
        }
        v3 = new DoNothingTwLicenseVerifier();
        while (true) {
            if ((v4 = (cfr_temp_1 = TwLicenseVerifierFactory.\u13e8 - (30910L ^ 1247670939773579752L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v4 == (29003 ^ -29004)) break;
            v4 = 31968 ^ 789501480;
        }
        return TwLicenseVerifierFactory.RateLimited(v3);
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private static ITwLicenseVerifier RateLimited(ITwLicenseVerifier verifier) {
        long l = \u13e8;
        block10: while (true) {
            switch ((int)l) {
                case -427340237: {
                    l = (0x51C9L ^ 0xD650FB03159BA673L) / (0x2FC7L ^ 0xCFEB9F9789ACB912L);
                    continue block10;
                }
                case 860544252: {
                    break block10;
                }
            }
            break;
        }
        long l2 = 144000000L >>> "\u0000\u0000".length();
        long l3 = \u13e8;
        boolean bl = true;
        block11: while (true) {
            long l4;
            if (!bl || (bl = false) || !true) {
                l3 = l4 / (0x5DEDL ^ 0x3AC27D62BB87EECEL);
            }
            switch ((int)l3) {
                case -1290107062: {
                    l4 = 0x5282L ^ 0xCAE28576F6DD75ABL;
                    continue block11;
                }
                case 860544252: {
                    return new RateLimitedTwLicenseVerifier(verifier, l2);
                }
                case 1268789075: {
                    l4 = -931092210925510964L >>> "\u0000\u0000".length();
                    continue block11;
                }
                case 1476521499: {
                    l4 = 0x65L ^ 0x9DB1BCC3F771C140L;
                    continue block11;
                }
            }
            break;
        }
        return new RateLimitedTwLicenseVerifier(verifier, l2);
    }

    /*
     * Unable to fully structure code
     */
    public static ITwLicenseVerifier CompilationMode() {
        v0 = TwLicenseVerifierFactory.\u13e8;
        if (true) ** GOTO lbl5
        block27: while (true) {
            v0 = v1 / (29418L ^ -8235592874532458176L);
lbl5:
            // 2 sources

            switch ((int)v0) {
                case 665222513: {
                    v1 = 3426805813815622048L >>> "\u0000\u0000".length();
                    continue block27;
                }
                case 860544252: {
                    break block27;
                }
                case 1664063989: {
                    v1 = 28109L ^ -5292474086381634302L;
                    continue block27;
                }
            }
            break;
        }
        while (true) {
            if ((v2 = (cfr_temp_0 = TwLicenseVerifierFactory.\u13e8 - (12311L ^ -6962882062305593084L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v2 == (10569 ^ 10568)) break;
            v2 = 8498 ^ -1018674344;
        }
        v3 = TwLicenseVerifierFactory.\u13e8;
        if (true) ** GOTO lbl24
        block29: while (true) {
            v3 = v4 / (30859L ^ -8647923252416040331L);
lbl24:
            // 2 sources

            switch ((int)v3) {
                case -504044406: {
                    v4 = 29050L ^ -6975974528418015571L;
                    continue block29;
                }
                case 860544252: {
                    break block29;
                }
                case 1663895305: {
                    v4 = 3758L ^ -9111365950405961085L;
                    continue block29;
                }
            }
            break;
        }
        switch (1.$SwitchMap$com$tawaret$tawaplugin$utils$Compilation$ExecutionMode[CompilationFlags.EXECUTION_MODE.ordinal()]) {
            case 1: {
                v5 = TwLicenseVerifierFactory.\u13e8;
                if (true) ** GOTO lbl39
                block30: while (true) {
                    v5 = v6 / (22362L ^ -4288064327735511850L);
lbl39:
                    // 2 sources

                    switch ((int)v5) {
                        case -901256644: {
                            v6 = 18907L ^ 8613044825768436508L;
                            continue block30;
                        }
                        case 860544252: {
                            break block30;
                        }
                        case 1479556616: {
                            v6 = 31803L ^ 894611901270076634L;
                            continue block30;
                        }
                        case 1879987891: {
                            v6 = 28028L ^ 2434084734152315859L;
                            continue block30;
                        }
                    }
                    break;
                }
                return TwLicenseVerifierFactory.None();
            }
            case 2: {
                v7 = TwLicenseVerifierFactory.\u13e8;
                if (true) ** GOTO lbl57
                block31: while (true) {
                    v7 = v8 / (11902L ^ -5102838575241836473L);
lbl57:
                    // 2 sources

                    switch ((int)v7) {
                        case 67066505: {
                            v8 = 25914L ^ -5275800049575538319L;
                            continue block31;
                        }
                        case 714821508: {
                            v8 = 23248L ^ -9090110389272574338L;
                            continue block31;
                        }
                        case 750450197: {
                            v8 = 31239L ^ -5184152363099260109L;
                            continue block31;
                        }
                        case 860544252: {
                            break block31;
                        }
                    }
                    break;
                }
                return TwLicenseVerifierFactory.WebDev();
            }
            case 3: {
                while (true) {
                    if ((v9 = (cfr_temp_1 = TwLicenseVerifierFactory.\u13e8 - (11704L ^ 9007737951045305222L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) {
                        continue;
                    }
                    if (v9 == (11874 ^ -11875)) break;
                    v9 = 19857 ^ -892273431;
                }
                return TwLicenseVerifierFactory.Prod();
            }
        }
        while (true) {
            if ((v10 = (cfr_temp_2 = TwLicenseVerifierFactory.\u13e8 - (3453L ^ -4837086725022026581L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v10 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v10 = 7295 ^ -1019871628;
        }
        while (true) {
            if ((v11 = (cfr_temp_3 = TwLicenseVerifierFactory.\u13e8 - (5042L ^ -6725233102986304875L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v11 == (19970 ^ 19971)) break;
            v11 = 25823 ^ 1283948122;
        }
        throw new RuntimeException();
    }
}

