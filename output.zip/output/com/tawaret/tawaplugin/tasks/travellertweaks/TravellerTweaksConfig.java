/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.config.types.Num
 *  com.github.manolo8.darkbot.config.types.Option
 */
package com.tawaret.tawaplugin.tasks.travellertweaks;

import com.github.manolo8.darkbot.config.types.Num;
import com.github.manolo8.darkbot.config.types.Option;

public class TravellerTweaksConfig {
    @Option(value="Only use rad zone if hp above (%)", description="-1 to disable")
    @Num(min=-1, max=100, step=5)
    public int CONTROL_RAD_ZONE_PERCENTAGE;
    private static long \u13e8 = -2978748187804956441L;

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public TravellerTweaksConfig() {
        long l = \u13e8;
        boolean bl = true;
        block10: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x6DB5L ^ 0xD0D4009F1184246DL);
            }
            switch ((int)l) {
                case -1941460219: {
                    l2 = 0x19E3L ^ 0x5C736AEC8D3BAC5DL;
                    continue block10;
                }
                case -1322064874: {
                    l2 = 0x4802L ^ 0xA83FCCDE3045CDFCL;
                    continue block10;
                }
                case -489925108: {
                    l2 = 0x44FL ^ 0xA5FCB3D8A384B355L;
                    continue block10;
                }
                case 646711527: {
                    break block10;
                }
            }
            break;
        }
        int n = 160 >>> "\u0000\u0000".length();
        long l3 = \u13e8;
        block11: while (true) {
            switch ((int)l3) {
                case -234535965: {
                    l3 = (0x5C34L ^ 0x2358A98F37BC8057L) / (0x5149L ^ 0xC0126D8AF415EE90L);
                    continue block11;
                }
                case 646711527: {
                    break block11;
                }
            }
            break;
        }
        this.CONTROL_RAD_ZONE_PERCENTAGE = n;
    }
}

