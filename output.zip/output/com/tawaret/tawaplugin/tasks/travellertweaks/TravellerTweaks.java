/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.Main
 *  com.github.manolo8.darkbot.core.itf.Configurable
 *  com.github.manolo8.darkbot.core.itf.Task
 *  com.github.manolo8.darkbot.extensions.features.Feature
 *  eu.darkbot.api.config.ConfigSetting
 *  eu.darkbot.api.managers.ConfigAPI
 */
package com.tawaret.tawaplugin.tasks.travellertweaks;

import com.github.manolo8.darkbot.Main;
import com.github.manolo8.darkbot.core.itf.Configurable;
import com.github.manolo8.darkbot.core.itf.Task;
import com.github.manolo8.darkbot.extensions.features.Feature;
import com.tawaret.tawaplugin.tasks.travellertweaks.TravellerTweaksConfig;
import eu.darkbot.api.config.ConfigSetting;
import eu.darkbot.api.managers.ConfigAPI;

@Feature(name="Traveller Tweaks", description="Tweaks for travelling", enabledByDefault=false)
public class TravellerTweaks
implements Task,
Configurable<TravellerTweaksConfig> {
    private final ConfigAPI configAPI;
    private final ConfigSetting<Object> setting;
    private TravellerTweaksConfig config;
    private Main main;
    static long \u13e8 = 2048565658658274277L;

    /*
     * Unable to fully structure code
     */
    public TravellerTweaks(ConfigAPI configAPI) {
        while (true) {
            if ((v0 = (cfr_temp_0 = TravellerTweaks.\u13e8 - (16418L ^ -7408351645310707901L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v0 = 24444 ^ 1004437392;
        }
        super();
        v1 = TravellerTweaks.\u13e8;
        if (true) ** GOTO lbl11
        block10: while (true) {
            v1 = (12215L ^ -5971449828196144348L) / (13099L ^ 6260158282644627754L);
lbl11:
            // 2 sources

            switch ((int)v1) {
                case -1491897451: {
                    continue block10;
                }
                case -547095579: {
                    break block10;
                }
            }
            break;
        }
        this.configAPI = configAPI;
        var3_2 = new byte["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
        var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() ^ "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length()] = 14494 ^ -14524;
        var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 31703 ^ 31653;
        var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 444 >>> "\u0000\u0000".length();
        var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 11076 ^ 11047;
        var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 12948 ^ 13045;
        var3_2["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 29322 ^ 29411;
        var3_2[5102 ^ 5115] = 5087 ^ 5054;
        var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 440 >>> "\u0000\u0000".length();
        var3_2[23878 ^ 23886] = 440 >>> "\u0000\u0000".length();
        var3_2[9127 ^ 9128] = 24943 ^ 24857;
        var3_2[22583 ^ 22572] = 12542 ^ 12433;
        var3_2[2021 ^ 2017] = 404 >>> "\u0000\u0000".length();
        var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 444 >>> "\u0000\u0000".length();
        var3_2[31124 ^ 31107] = 27979 ^ 27938;
        var3_2[606 ^ 584] = 28598 ^ 28626;
        var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 460 >>> "\u0000\u0000".length();
        var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 8975 ^ 9040;
        var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 29909 ^ 29881;
        var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 21797 ^ 21833;
        var3_2["".length() >>> "\u0000\u0000".length()] = 436 >>> "\u0000\u0000".length();
        var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 420 >>> "\u0000\u0000".length();
        var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 460 >>> "\u0000\u0000".length();
        var3_2[15654 ^ 15661] = 468 >>> "\u0000\u0000".length();
        var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 420 >>> "\u0000\u0000".length();
        var3_2[30897 ^ 30902] = 16529 ^ 16624;
        var3_2[681 ^ 688] = 464 >>> "\u0000\u0000".length();
        var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 404 >>> "\u0000\u0000".length();
        var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 18849 ^ 18831;
        var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 10816 ^ 10785;
        var3_2[6510 ^ 6524] = 12592 ^ 12628;
        v2 = new String(var3_2);
        while (true) {
            if ((v3 = (cfr_temp_1 = TravellerTweaks.\u13e8 - (6734286097184048868L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v3 == (1257 ^ 1256)) break;
            v3 = 1540610916 >>> "\u0000\u0000".length();
        }
        v4 = configAPI.getConfig(v2);
        v5 = TravellerTweaks.\u13e8;
        if (true) ** GOTO lbl59
        block12: while (true) {
            v5 = v6 / (21723L ^ 7127428195678444727L);
lbl59:
            // 2 sources

            switch ((int)v5) {
                case -547095579: {
                    break block12;
                }
                case -428015458: {
                    v6 = 7809388532221810004L >>> "\u0000\u0000".length();
                    continue block12;
                }
                case 1771677862: {
                    v6 = 26697L ^ -4163587807580701902L;
                    continue block12;
                }
            }
            break;
        }
        this.setting = v4;
    }

    public void install(Main main) {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0xF71L ^ 0x779A4A0DFCCB7FL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l2 = 0x27F ^ 0x2C68892B;
        }
        this.main = main;
    }

    public void uninstall() {
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    private void tickRadZoneTweak() {
        block52: {
            while (true) {
                if ((v0 = (cfr_temp_0 = TravellerTweaks.\u13e8 - (29046L ^ -512672840870697743L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v0 == (7716 ^ 7717)) break;
                v0 = 3169 ^ 629890311;
            }
            v1 = TravellerTweaks.\u13e8;
            if (true) ** GOTO lbl10
            block38: while (true) {
                v1 = v2 / (31414L ^ -4661765399046507943L);
lbl10:
                // 2 sources

                switch ((int)v1) {
                    case -1168576279: {
                        v2 = 674694364118973100L >>> "\u0000\u0000".length();
                        continue block38;
                    }
                    case -547095579: {
                        break block38;
                    }
                    case 301209216: {
                        v2 = 1831L ^ 1676871770481448945L;
                        continue block38;
                    }
                    case 707264255: {
                        v2 = 13465L ^ 5675070359612639781L;
                        continue block38;
                    }
                }
                break;
            }
            thresh = this.config.CONTROL_RAD_ZONE_PERCENTAGE;
            if (thresh < 0) {
                return;
            }
            v3 = TravellerTweaks.\u13e8;
            if (true) ** GOTO lbl29
            block39: while (true) {
                v3 = v4 / (29369L ^ 3443998015290366443L);
lbl29:
                // 2 sources

                switch ((int)v3) {
                    case -547095579: {
                        break block39;
                    }
                    case -534466178: {
                        v4 = 15011L ^ -7051453291532228906L;
                        continue block39;
                    }
                    case 699418501: {
                        v4 = 9661L ^ -1537552134284441860L;
                        continue block39;
                    }
                }
                break;
            }
            v5 = TravellerTweaks.\u13e8;
            if (true) ** GOTO lbl42
            block40: while (true) {
                v5 = (4152670613634927336L >>> "\u0000\u0000".length()) / (11183L ^ -6802191844589455815L);
lbl42:
                // 2 sources

                switch ((int)v5) {
                    case -547095579: {
                        break block40;
                    }
                    case 204851236: {
                        continue block40;
                    }
                }
                break;
            }
            v6 = this.main.hero;
            while (true) {
                if ((v7 = (cfr_temp_1 = TravellerTweaks.\u13e8 - (11651L ^ -207839102527353460L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v7 == (657 ^ 656)) break;
                v7 = 19679 ^ -618173348;
            }
            v8 = v6.health;
            while (true) {
                if ((v9 = (cfr_temp_2 = TravellerTweaks.\u13e8 - (20342L ^ -5016923261848650639L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v9 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v9 = 27580 ^ 1765853385;
            }
            v10 = v8.hpPercent() * 100.0;
            while (true) {
                if ((v11 = (cfr_temp_3 = TravellerTweaks.\u13e8 - (21663L ^ 7774969619141050771L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v11 == (14715 ^ -14716)) break;
                v11 = 8460 ^ 872550001;
            }
            while (true) {
                if ((v12 = (cfr_temp_4 = TravellerTweaks.\u13e8 - (32200L ^ -7760862161417015086L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v12 == (9063 ^ 9062)) break;
                v12 = 18232 ^ -1875901143;
            }
            newValue = v10 <= (double)this.config.CONTROL_RAD_ZONE_PERCENTAGE ? "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length() : "".length() >>> "\u0000\u0000".length();
            v13 = TravellerTweaks.\u13e8;
            if (true) ** GOTO lbl75
            block45: while (true) {
                v13 = (29275L ^ 4851373147346559732L) / (31581L ^ -8056181023576978122L);
lbl75:
                // 2 sources

                switch ((int)v13) {
                    case -547095579: {
                        break block45;
                    }
                    case 776074917: {
                        continue block45;
                    }
                }
                break;
            }
            while (true) {
                if ((v14 = (cfr_temp_5 = TravellerTweaks.\u13e8 - (13123L ^ 7790469185711651108L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                if (v14 == (356 ^ -357)) break;
                v14 = 18926 ^ -82229226;
            }
            v15 = (Boolean)this.setting.getValue();
            while (true) {
                if ((v16 = (cfr_temp_6 = TravellerTweaks.\u13e8 - (615L ^ 6219149642227659737L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                if (v16 == (12952 ^ -12953)) break;
                v16 = 29665 ^ -28177474;
            }
            if (v15 == newValue) break block52;
            v17 = TravellerTweaks.\u13e8;
            if (true) ** GOTO lbl96
            block48: while (true) {
                v17 = v18 / (846L ^ 8941872963897654248L);
lbl96:
                // 2 sources

                switch ((int)v17) {
                    case -2041326276: {
                        v18 = 30524L ^ 7526797692301328695L;
                        continue block48;
                    }
                    case -547095579: {
                        break block48;
                    }
                    case -220586351: {
                        v18 = 28822L ^ -2132277255863922210L;
                        continue block48;
                    }
                    case 563904311: {
                        v18 = 1580L ^ -6658688135938715650L;
                        continue block48;
                    }
                }
                break;
            }
            v19 = TravellerTweaks.\u13e8;
            if (true) ** GOTO lbl112
            block49: while (true) {
                v19 = v20 / (-4691319294418207116L >>> "\u0000\u0000".length());
lbl112:
                // 2 sources

                switch ((int)v19) {
                    case -1888258831: {
                        v20 = 8812L ^ -2206525656359866959L;
                        continue block49;
                    }
                    case -1352424950: {
                        v20 = 28721L ^ 5687825107166038377L;
                        continue block49;
                    }
                    case -547095579: {
                        break block49;
                    }
                    case 1812955593: {
                        v20 = 7159L ^ 5235865411225184165L;
                        continue block49;
                    }
                }
                break;
            }
            v21 = newValue;
            v22 = TravellerTweaks.\u13e8;
            if (true) ** GOTO lbl129
            block50: while (true) {
                v22 = v23 / (22523L ^ -511659558318040648L);
lbl129:
                // 2 sources

                switch ((int)v22) {
                    case -601119385: {
                        v23 = -6684319286537209068L >>> "\u0000\u0000".length();
                        continue block50;
                    }
                    case -547095579: {
                        break block50;
                    }
                    case 782840739: {
                        v23 = 32228L ^ 4836372034566806066L;
                        continue block50;
                    }
                    case 2039294678: {
                        v23 = 31828L ^ -8646394052178276057L;
                        continue block50;
                    }
                }
                break;
            }
            this.setting.setValue((Object)v21);
        }
    }

    public void tickStopped() {
    }

    /*
     * Enabled aggressive block sorting
     */
    public void tick() {
        long l = \u13e8;
        block4: while (true) {
            switch ((int)l) {
                case -547095579: {
                    break block4;
                }
                case 703635353: {
                    l = (0x53CL ^ 0x6720CBA08D161D5L) / (0x221AL ^ 0xBC70AD6C7821A130L);
                    continue block4;
                }
            }
            break;
        }
        this.tickRadZoneTweak();
    }

    public void setConfig(TravellerTweaksConfig config) {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x6D06L ^ 0xC948F5CCD819B180L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x7F9 ^ 0x7F8)) break;
            l2 = 0x7438 ^ 0xFDF4C81B;
        }
        this.config = config;
    }
}

