/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  eu.darkbot.api.events.EventHandler
 *  eu.darkbot.api.events.Listener
 *  eu.darkbot.api.managers.EventBrokerAPI
 *  eu.darkbot.api.managers.GameLogAPI$LogMessageEvent
 */
package com.tawaret.tawaplugin.utils.logReaders;

import com.tawaret.tawaplugin.utils.logReaders.ILogsReader;
import eu.darkbot.api.events.EventHandler;
import eu.darkbot.api.events.Listener;
import eu.darkbot.api.managers.EventBrokerAPI;
import eu.darkbot.api.managers.GameLogAPI;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;

public class FlashLogReader
implements ILogsReader,
Listener {
    private final List<String> collectedLogs;
    private final EventBrokerAPI eventBrokerAPI;
    private final BooleanSupplier predicate;
    public static long \u13e8 = -8311440914123955136L;

    /*
     * Unable to fully structure code
     */
    public FlashLogReader(EventBrokerAPI eventBrokerAPI, BooleanSupplier predicate) {
        while (true) {
            if ((v0 = (cfr_temp_0 = FlashLogReader.\u13e8 - (27649L ^ 937301144646928671L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (13488 ^ -13489)) break;
            v0 = 30251 ^ -798732232;
        }
        super();
        v1 = FlashLogReader.\u13e8;
        if (true) ** GOTO lbl11
        block16: while (true) {
            v1 = (14560L ^ -548267064461832083L) / (27725L ^ -4449877882612171413L);
lbl11:
            // 2 sources

            switch ((int)v1) {
                case -991131652: {
                    continue block16;
                }
                case 1174299712: {
                    break block16;
                }
            }
            break;
        }
        this.eventBrokerAPI = eventBrokerAPI;
        v2 = FlashLogReader.\u13e8;
        if (true) ** GOTO lbl21
        block17: while (true) {
            v2 = v3 / (834689635439139616L >>> "\u0000\u0000".length());
lbl21:
            // 2 sources

            switch ((int)v2) {
                case -272463852: {
                    v3 = 5413L ^ -2972948216797981872L;
                    continue block17;
                }
                case 1174299712: {
                    break block17;
                }
                case 1222177155: {
                    v3 = 19686L ^ -444852457532855500L;
                    continue block17;
                }
            }
            break;
        }
        while (true) {
            if ((v4 = (cfr_temp_1 = FlashLogReader.\u13e8 - (5007639814605373096L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v4 == (15214 ^ -15215)) break;
            v4 = 21532 ^ -1015576663;
        }
        v5 = new ArrayList<String>();
        while (true) {
            if ((v6 = (cfr_temp_2 = FlashLogReader.\u13e8 - (23698L ^ -6731021448169291515L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v6 == (11126 ^ -11127)) break;
            v6 = 13135 ^ 1574546717;
        }
        this.collectedLogs = v5;
        v7 = FlashLogReader.\u13e8;
        if (true) ** GOTO lbl46
        block20: while (true) {
            v7 = v8 / (3550L ^ 1601972767233202586L);
lbl46:
            // 2 sources

            switch ((int)v7) {
                case -1697873238: {
                    v8 = 5928L ^ -8506810033194662212L;
                    continue block20;
                }
                case 1174299712: {
                    break block20;
                }
                case 1344605948: {
                    v8 = 24855L ^ -4238125268074725111L;
                    continue block20;
                }
                case 2017988220: {
                    v8 = -6600947702492365372L >>> "\u0000\u0000".length();
                    continue block20;
                }
            }
            break;
        }
        this.predicate = predicate;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public FlashLogReader(EventBrokerAPI eventBrokerAPI) {
        long l = \u13e8;
        boolean bl = true;
        block9: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x75ECL ^ 0x63DE41B7090F7559L);
            }
            switch ((int)l) {
                case -1384876731: {
                    l2 = 0x6695L ^ 0x619E5C8D98E9C0B5L;
                    continue block9;
                }
                case 1174299712: {
                    break block9;
                }
                case 1699114776: {
                    l2 = 0x6F9EL ^ 0x569325235B15B6A9L;
                    continue block9;
                }
            }
            break;
        }
        BooleanSupplier booleanSupplier = () -> "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        long l3 = \u13e8;
        block10: while (true) {
            switch ((int)l3) {
                case -932499722: {
                    l3 = (0x7125L ^ 0xE7A5FAADF94BD7D4L) / (0x49BL ^ 0x47016E8AC95C493CL);
                    continue block10;
                }
                case 1174299712: {
                    break block10;
                }
            }
            break;
        }
        this(eventBrokerAPI, booleanSupplier);
    }

    private void addLog(String log) {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x6905L ^ 0xF9EFD9BB4C6D4492L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x879 ^ 0xFFFFF786)) break;
            l2 = 0x656F ^ 0x791B8C98;
        }
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = \u13e8 - (0x3399L ^ 0x3E8674A04760CC48L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l3 == (0x795F ^ 0xFFFF86A0)) break;
            l3 = 0x7944 ^ 0xA2F40541;
        }
        this.collectedLogs.add(log);
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    @Override
    public List<String> getUnseenLogs() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x22C3L ^ 0x6569F4123B1B56C4L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x3EFA ^ 0xFFFFC105)) break;
            l2 = 0x3ABB ^ 0x3DAB8B87;
        }
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = \u13e8 - (0x542DL ^ 0x7E7C09A082EBA632L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l3 == (0x60C0 ^ 0xFFFF9F3F)) break;
            l3 = 1947582100 >>> "\u0000\u0000".length();
        }
        while (true) {
            long l;
            long l4;
            if ((l4 = (l = \u13e8 - (0x60EL ^ 0x80706C183DDD206FL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l4 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l4 = 0x4703 ^ 0x93C6D5B5;
        }
        ArrayList<String> ret = new ArrayList<String>(this.collectedLogs);
        long l = \u13e8;
        block13: while (true) {
            switch ((int)l) {
                case -1195279370: {
                    l = (0x7172L ^ 0x44A724845C098A94L) / (0x6105L ^ 0x48D6E073EA66FB78L);
                    continue block13;
                }
                case 1174299712: {
                    break block13;
                }
            }
            break;
        }
        long l5 = \u13e8;
        boolean bl = true;
        block14: while (true) {
            long l6;
            if (!bl || (bl = false) || !true) {
                l5 = l6 / (0x3FACL ^ 0xEF460DA47A251B03L);
            }
            switch ((int)l5) {
                case -1898942562: {
                    l6 = 0x1999L ^ 0x9108C9DF95F6DC60L;
                    continue block14;
                }
                case -1609762300: {
                    l6 = 0x197EL ^ 0x5A7A6FAB7B20E98DL;
                    continue block14;
                }
                case 1174299712: {
                    break block14;
                }
                case 1309274711: {
                    l6 = 0x2F64L ^ 0x8CD630F5EC94EF4CL;
                    continue block14;
                }
            }
            break;
        }
        this.collectedLogs.clear();
        return ret;
    }

    /*
     * Enabled aggressive block sorting
     */
    @EventHandler
    public void handle(GameLogAPI.LogMessageEvent logMessageEvent) {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (3762978121742224852L >>> "\u0000\u0000".length())) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == (0x56E5 ^ 0xFFFFA91A)) break;
            l2 = 0x5BE1 ^ 0xEC6E57CD;
        }
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = \u13e8 - (0x357DL ^ 0x1CD8CABFB292641EL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l3 == (0x5565 ^ 0xFFFFAA9A)) {
                if (!this.predicate.getAsBoolean()) {
                    return;
                }
                break;
            }
            l3 = 0x4412 ^ 0x54CEC7CA;
        }
        long l = \u13e8;
        block6: while (true) {
            switch ((int)l) {
                case -1386066011: {
                    l = (0x3625L ^ 0x66E503E2258C5BDAL) / (2203891563564291820L >>> "\u0000\u0000".length());
                    continue block6;
                }
                case 1174299712: {
                    break block6;
                }
            }
            break;
        }
        String string = logMessageEvent.getMessage();
        while (true) {
            long l4;
            long l5;
            if ((l5 = (l4 = \u13e8 - (0x3533L ^ 0x9A493179E20A22B8L)) == 0L ? 0 : (l4 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l5 == (0x3ED9 ^ 0xFFFFC126)) {
                this.addLog(string);
                return;
            }
            l5 = -697684868 >>> "\u0000\u0000".length();
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void close() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x6207L ^ 0x9C1F8EBA4C847891L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x306A ^ 0xFFFFCF95)) break;
            l2 = 0x25B5 ^ 0xC6B2FE9A;
        }
        long l = \u13e8;
        block5: while (true) {
            switch ((int)l) {
                case 1174299712: {
                    break block5;
                }
                case 1567503277: {
                    l = (0x5AF9L ^ 0x90160E238E6197E0L) / (0x24BDL ^ 0x3E643A30D6A5B1B7L);
                    continue block5;
                }
            }
            break;
        }
        this.eventBrokerAPI.unregisterListener((Listener)this);
    }

    @Override
    public void open() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x2208L ^ 0x403304EC9E1B2392L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x6496 ^ 0xFFFF9B69)) break;
            l2 = -425540116 >>> "\u0000\u0000".length();
        }
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = \u13e8 - (0x7D17L ^ 0x9F1947EBB3F2572AL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l3 == (0x185A ^ 0xFFFFE7A5)) break;
            l3 = 0x5A31 ^ 0xD43B71E7;
        }
        this.eventBrokerAPI.registerListener((Listener)this);
    }
}

