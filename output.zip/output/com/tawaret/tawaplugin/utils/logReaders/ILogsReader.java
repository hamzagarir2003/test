/*
 * Decompiled with CFR 0.152.
 */
package com.tawaret.tawaplugin.utils.logReaders;

import java.util.List;

public interface ILogsReader {
    public List<String> getUnseenLogs();

    public void close();

    public void open();
}

