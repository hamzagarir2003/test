/*
 * Decompiled with CFR 0.152.
 */
package com.tawaret.tawaplugin.utils.Compilation;

public final class ExecutionMode
extends Enum<ExecutionMode> {
    public static final /* enum */ ExecutionMode DEBUG;
    public static final /* enum */ ExecutionMode WEB_DEV;
    public static final /* enum */ ExecutionMode PROD;
    private static final /* synthetic */ ExecutionMode[] $VALUES;
    protected static long \u13e8 = -4471189507686775764L;

    public static ExecutionMode[] values() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x2001L ^ 0xD5C646504201E298L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == (0x24D3 ^ 0xFFFFDB2C)) break;
            l2 = 0x1E8D ^ 0xB042FF14;
        }
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = \u13e8 - (0x6E12L ^ 0xD543B75DDA9E33A9L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l3 == (0x64BB ^ 0xFFFF9B44)) break;
            l3 = 0x6753 ^ 0x3A84136C;
        }
        return (ExecutionMode[])$VALUES.clone();
    }

    public static ExecutionMode valueOf(String name) {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (-7612476948460104984L >>> "\u0000\u0000".length())) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == (0x499E ^ 0xFFFFB661)) break;
            l2 = 0x2EAB ^ 0x5CC9D2E4;
        }
        return Enum.valueOf(ExecutionMode.class, name);
    }

    /*
     * Enabled aggressive block sorting
     */
    private ExecutionMode() {
        long l = \u13e8;
        block4: while (true) {
            switch ((int)l) {
                case 115360812: {
                    break block4;
                }
                case 1408568532: {
                    l = (0x2B27L ^ 0xFB7B20BE5FE3F86CL) / (0x6242L ^ 0xE32683DF2D50C741L);
                    continue block4;
                }
            }
            break;
        }
    }

    private static /* synthetic */ ExecutionMode[] $values() {
        ExecutionMode[] executionModeArray = new ExecutionMode[0x6D61 ^ 0x6D62];
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (-8059607072419852484L >>> "\u0000\u0000".length())) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == (0x48C3 ^ 0xFFFFB73C)) break;
            l2 = "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() ^ 0x8967CE9C;
        }
        executionModeArray[0x5F30 ^ 0x5F30] = DEBUG;
        int n = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = \u13e8 - (0x697CL ^ 0xA52A3097ABCF7FB1L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l3 == (0x437D ^ 0x437C)) break;
            l3 = 0x4878 ^ 0xC3E77D21;
        }
        executionModeArray[n] = WEB_DEV;
        int n2 = "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        while (true) {
            long l;
            long l4;
            if ((l4 = (l = \u13e8 - (0x1BC3L ^ 0xCC82302876179D31L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l4 == (0x7257 ^ 0xFFFF8DA8)) break;
            l4 = 0x347E ^ 0xD8288B18;
        }
        executionModeArray[n2] = PROD;
        return executionModeArray;
    }

    /*
     * Unable to fully structure code
     */
    static {
        while (true) {
            if ((v0 = (cfr_temp_0 = ExecutionMode.\u13e8 - (16002L ^ -1704335022346603757L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (28671 ^ -28672)) break;
            v0 = 27157 ^ 1564197466;
        }
        var1 = new byte[659 ^ 662];
        var1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 5536 ^ -5583;
        var1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 29548 ^ 29497;
        var1[16266 ^ 16264] = 14210 ^ 14272;
        var1[10458 ^ 10458] = 272 >>> "\u0000\u0000".length();
        var1[7511 ^ 7507] = 28171 ^ 28236;
        var1["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 276 >>> "\u0000\u0000".length();
        v1 = new String(var1);
        while (true) {
            if ((v2 = (cfr_temp_1 = ExecutionMode.\u13e8 - (32669L ^ 3426032391528540744L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v2 == (6791 ^ -6792)) break;
            v2 = 24749 ^ 261503919;
        }
        v3 = new ExecutionMode();
        while (true) {
            if ((v4 = (cfr_temp_2 = ExecutionMode.\u13e8 - (29475L ^ -8595812642989497395L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v4 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v4 = 15516 ^ -314510721;
        }
        ExecutionMode.DEBUG = v3;
        while (true) {
            if ((v5 = (cfr_temp_3 = ExecutionMode.\u13e8 - (14099L ^ -2099615521622525714L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v5 == (32277 ^ -32278)) break;
            v5 = 14047 ^ 1416409544;
        }
        var1 = new byte[16648 ^ 16655];
        var1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 192 >>> "\u0000\u0000".length();
        var1[13847 ^ 13843] = 272 >>> "\u0000\u0000".length();
        var1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 344 >>> "\u0000\u0000".length();
        var1[10353 ^ 10354] = 380 >>> "\u0000\u0000".length();
        var1["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 9148 ^ 9209;
        var1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 264 >>> "\u0000\u0000".length();
        var1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 276 >>> "\u0000\u0000".length();
        var1[13630 ^ 13630] = 768 ^ 855;
        v6 = new String(var1);
        v7 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        while (true) {
            if ((v8 = (cfr_temp_4 = ExecutionMode.\u13e8 - (19411L ^ -3998365869267271418L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v8 == (26925 ^ -26926)) break;
            v8 = 3711 ^ -1158369302;
        }
        v9 = new ExecutionMode();
        v10 = ExecutionMode.\u13e8;
        if (true) ** GOTO lbl52
        block15: while (true) {
            v10 = (10330L ^ -2666174636034873824L) / (7800L ^ -2086143213974175022L);
lbl52:
            // 2 sources

            switch ((int)v10) {
                case -80511816: {
                    continue block15;
                }
                case 115360812: {
                    break block15;
                }
            }
            break;
        }
        ExecutionMode.WEB_DEV = v9;
        while (true) {
            if ((v11 = (cfr_temp_5 = ExecutionMode.\u13e8 - (29432L ^ 7325636222925188272L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
            if (v11 == (15573 ^ -15574)) break;
            v11 = 9493 ^ -710554255;
        }
        var1 = new byte[21488 ^ 21492];
        var1["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 3438 ^ -3331;
        var1["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 9063 ^ 9013;
        var1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 21806 ^ 21866;
        var1[12927 ^ 12925] = 8186 ^ 8117;
        var1["".length() >>> "\u0000\u0000".length()] = 2724 ^ 2804;
        v12 = new String(var1);
        v13 = "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        while (true) {
            if ((v14 = (cfr_temp_6 = ExecutionMode.\u13e8 - (8274485328618909116L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
            if (v14 == (29877 ^ -29878)) break;
            v14 = 16324 ^ -1594976447;
        }
        v15 = new ExecutionMode();
        while (true) {
            if ((v16 = (cfr_temp_7 = ExecutionMode.\u13e8 - (8383540607203685116L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
            if (v16 == (19330 ^ -19331)) break;
            v16 = 19563 ^ -1047413950;
        }
        ExecutionMode.PROD = v15;
        v17 = ExecutionMode.\u13e8;
        if (true) ** GOTO lbl87
        block19: while (true) {
            v17 = v18 / (27361L ^ 335581151421595468L);
lbl87:
            // 2 sources

            switch ((int)v17) {
                case -684040427: {
                    v18 = 14644L ^ 4918358457874543142L;
                    continue block19;
                }
                case 115360812: {
                    break block19;
                }
                case 389294971: {
                    v18 = 10073L ^ -8565034099104242672L;
                    continue block19;
                }
                case 2125940588: {
                    v18 = 30397L ^ -686718401112975621L;
                    continue block19;
                }
            }
            break;
        }
        v19 = ExecutionMode.$values();
        while (true) {
            if ((v20 = (cfr_temp_8 = ExecutionMode.\u13e8 - (15489L ^ -3173676957510815701L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
            if (v20 == (3390 ^ -3391)) break;
            v20 = 2048 ^ 1105327931;
        }
        ExecutionMode.$VALUES = v19;
    }
}

