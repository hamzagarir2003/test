/*
 * Decompiled with CFR 0.152.
 */
package com.tawaret.tawaplugin.utils.Compilation;

import com.tawaret.tawaplugin.utils.Compilation.ExecutionMode;

public class CompilationFlags {
    public static final ExecutionMode EXECUTION_MODE;
    public static long \u13e8 = 8096082749920725569L;

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public CompilationFlags() {
        long l = \u13e8;
        boolean bl = true;
        block5: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (979001173583040876L >>> "\u0000\u0000".length());
            }
            switch ((int)l) {
                case -1120843199: {
                    break block5;
                }
                case -420716819: {
                    l2 = 0x7DD7L ^ 0x96EDDA6817A2105L;
                    continue block5;
                }
                case 937238819: {
                    l2 = 0x294L ^ 0xA0E90E8CDDA559ACL;
                    continue block5;
                }
            }
            break;
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    static {
        long l = \u13e8;
        boolean bl = true;
        block12: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x6C3AL ^ 0xE9F1144CEC03D7DFL);
            }
            switch ((int)l) {
                case -1880426112: {
                    l2 = 0x7A64L ^ 0x9B5FC45572D9F512L;
                    continue block12;
                }
                case -1120843199: {
                    break block12;
                }
                case -910442239: {
                    l2 = 0x10F4L ^ 0x54027DC5A89B4AEAL;
                    continue block12;
                }
                case 1052167488: {
                    l2 = 0x5D00L ^ 0xCAA1942C06F155ABL;
                    continue block12;
                }
            }
            break;
        }
        long l3 = \u13e8;
        boolean bl2 = true;
        block13: while (true) {
            long l4;
            if (!bl2 || (bl2 = false) || !true) {
                l3 = l4 / (0x263EL ^ 0xFDDD43FB75789386L);
            }
            switch ((int)l3) {
                case -1275211859: {
                    l4 = 0x15B8L ^ 0xC6A265540CC4E08CL;
                    continue block13;
                }
                case -1120843199: {
                    break block13;
                }
                case -17306587: {
                    l4 = 0x235AL ^ 0xC6137895BCFB13FL;
                    continue block13;
                }
                case 1502903212: {
                    l4 = 0x603EL ^ 0xA155414A3D873D45L;
                    continue block13;
                }
            }
            break;
        }
        EXECUTION_MODE = ExecutionMode.PROD;
    }
}

