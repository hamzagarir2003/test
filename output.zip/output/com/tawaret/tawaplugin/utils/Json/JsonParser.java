/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 */
package com.tawaret.tawaplugin.utils.Json;

import com.google.gson.Gson;

public class JsonParser {
    public static long \u13e8 = -9049645016882592421L;

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public JsonParser() {
        long l = \u13e8;
        boolean bl = true;
        block5: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x2C7AL ^ 0x93165F8332C6A1C3L);
            }
            switch ((int)l) {
                case -1561911696: {
                    l2 = 0x26A2L ^ 0xF2465D52D7ACBEA4L;
                    continue block5;
                }
                case -1456850216: {
                    l2 = 0x2176L ^ 0xEEC26AC00185D5ECL;
                    continue block5;
                }
                case -514570917: {
                    break block5;
                }
            }
            break;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public static <T> T Parse(String text, Class<T> classT) {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x3EA5L ^ 0x75396B041D98C8CDL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x20CE ^ 0xFFFFDF31)) break;
            l2 = 0x3A3F ^ 0x8370A47F;
        }
        long l = \u13e8;
        block9: while (true) {
            switch ((int)l) {
                case -814154106: {
                    l = (0x2F5L ^ 0xEF8125F1FA8C4091L) / (0x4D95L ^ 0xEC875B13FB60F765L);
                    continue block9;
                }
                case -514570917: {
                    break block9;
                }
            }
            break;
        }
        Gson g = new Gson();
        long l3 = \u13e8;
        block10: while (true) {
            switch ((int)l3) {
                case -514570917: {
                    return (T)g.fromJson(text, classT);
                }
                case 472491854: {
                    l3 = (0x549FL ^ 0xBF0F67D83232282DL) / (0x5A90L ^ 0x4FCBA7EEDE21872EL);
                    continue block10;
                }
            }
            break;
        }
        return (T)g.fromJson(text, classT);
    }
}

