/*
 * Decompiled with CFR 0.152.
 */
package com.tawaret.tawaplugin.utils.HttpClients;

import com.tawaret.tawaplugin.utils.HttpClients.IHttpClient;
import java.util.Map;

public class HttpClient
implements IHttpClient {
    protected static long \u13e8 = -5991721211838660024L;

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public HttpClient() {
        long l = \u13e8;
        boolean bl = true;
        block6: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x4F2AL ^ 0x367E248C15F394A9L);
            }
            switch ((int)l) {
                case -1490091448: {
                    break block6;
                }
                case -1001113359: {
                    l2 = 0x7240L ^ 0x57B99929FBA417D4L;
                    continue block6;
                }
                case -961521219: {
                    l2 = 0x48CL ^ 0x18922DFE8E709CD3L;
                    continue block6;
                }
                case 1852054747: {
                    l2 = 0x132DL ^ 0xC78B5D771D95A1AL;
                    continue block6;
                }
            }
            break;
        }
    }

    /*
     * Exception decompiling
     */
    private <T> T Core(String method, String url, Map<String, String> dataKeyValuePairs, Class<T> responseJsonType) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * java.lang.UnsupportedOperationException
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.considerAsDoLoopStart(LoopIdentifier.java:383)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.identifyLoops1(LoopIdentifier.java:65)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:681)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    @Override
    public <T> T Post(String url, Map<String, String> dataKeyValuePairs, Class<T> responseJsonType) {
        byte[] byArray = new byte[0x691C ^ 0x6918];
        byArray["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x6BA5 ^ 0xFFFF945F;
        byArray["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 316 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 332 >>> "\u0000\u0000".length();
        byArray[0x761A ^ 0x761A] = 0x579E ^ 0x57CE;
        byArray[0x5439 ^ 0x543A] = 0x3E31 ^ 0x3E65;
        String string = new String(byArray);
        long l = \u13e8;
        boolean bl = true;
        block5: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x6ADCL ^ 0xA1C99D3E28DDD5ACL);
            }
            switch ((int)l) {
                case -1490091448: {
                    return this.Core(string, url, dataKeyValuePairs, responseJsonType);
                }
                case 1087783953: {
                    l2 = -8057165252818847924L >>> "\u0000\u0000".length();
                    continue block5;
                }
                case 1961269900: {
                    l2 = 0x147FL ^ 0xA5637D28585856C1L;
                    continue block5;
                }
            }
            break;
        }
        return this.Core(string, url, dataKeyValuePairs, responseJsonType);
    }

    @Override
    public <T> T Get(String url, Map<String, String> dataKeyValuePairs, Class<T> responseJsonType) {
        byte[] byArray = new byte["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
        byArray[0x582A ^ 0x582B] = 352 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x187A ^ 0x183F;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x40E2 ^ 0x40B6;
        byArray[0x19F9 ^ 0x19F9] = 284 >>> "\u0000\u0000".length();
        String string = new String(byArray);
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x38F7L ^ 0xAEE52524CF0C259CL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == (0xBD6 ^ 0xFFFFF429)) break;
            l2 = 0x1AE6 ^ 0xB6EE7A69;
        }
        return this.Core(string, url, dataKeyValuePairs, responseJsonType);
    }
}

