/*
 * Decompiled with CFR 0.152.
 */
package com.tawaret.tawaplugin.utils.HttpClients;

import java.util.Map;

public interface IHttpClient {
    public <T> T Post(String var1, Map<String, String> var2, Class<T> var3);

    public <T> T Get(String var1, Map<String, String> var2, Class<T> var3);
}

