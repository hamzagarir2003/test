/*
 * Decompiled with CFR 0.152.
 */
package com.tawaret.tawaplugin.utils.HttpClients;

import java.lang.invoke.LambdaMetafactory;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public final class HttpUtils {
    static long \u13e8 = -2870816643993688028L;

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public HttpUtils() {
        long l = \u13e8;
        boolean bl = true;
        block6: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x1307L ^ 0xC6936F47E7B9F153L);
            }
            switch ((int)l) {
                case -1721162675: {
                    l2 = 0x6C7BL ^ 0x8BCC85619E6F9588L;
                    continue block6;
                }
                case -744336642: {
                    l2 = 0x3D2L ^ 0xFDC230372B99B195L;
                    continue block6;
                }
                case -142989276: {
                    break block6;
                }
                case 29393961: {
                    l2 = 0x7A70L ^ 0xD36A6DFB4EF9320EL;
                    continue block6;
                }
            }
            break;
        }
    }

    /*
     * Unable to fully structure code
     */
    public static String ToRequestDataString(Map<String, String> keyValuePairs) {
        v0 = HttpUtils.\u13e8;
        if (true) ** GOTO lbl5
        block21: while (true) {
            v0 = v1 / (13442L ^ -7651626417023065532L);
lbl5:
            // 2 sources

            switch ((int)v0) {
                case -1725867405: {
                    v1 = 6276L ^ -5561519505657972129L;
                    continue block21;
                }
                case -142989276: {
                    break block21;
                }
                case 1385317877: {
                    v1 = -1078347304320199140L >>> "\u0000\u0000".length();
                    continue block21;
                }
            }
            break;
        }
        v2 = keyValuePairs.keySet();
        v3 = HttpUtils.\u13e8;
        if (true) ** GOTO lbl19
        block22: while (true) {
            v3 = v4 / (3165L ^ 7345990874997934588L);
lbl19:
            // 2 sources

            switch ((int)v3) {
                case -142989276: {
                    break block22;
                }
                case 463237003: {
                    v4 = -3549941100018868368L >>> "\u0000\u0000".length();
                    continue block22;
                }
                case 1514958042: {
                    v4 = 700L ^ -2856147290769786523L;
                    continue block22;
                }
                case 1581695682: {
                    v4 = 9358L ^ -4864476391127121755L;
                    continue block22;
                }
            }
            break;
        }
        v5 = v2.stream();
        while (true) {
            if ((v6 = (cfr_temp_0 = HttpUtils.\u13e8 - (25684L ^ -1287909678283531204L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v6 == (23360 ^ -23361)) break;
            v6 = 16010 ^ -1562704399;
        }
        v7 = (Function<String, String>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, lambda$ToRequestDataString$0(java.util.Map java.lang.String ), (Ljava/lang/String;)Ljava/lang/String;)(keyValuePairs);
        while (true) {
            if ((v8 = (cfr_temp_1 = HttpUtils.\u13e8 - (7340171442741433540L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v8 == (16961 ^ -16962)) break;
            v8 = 4753 ^ -920786174;
        }
        v9 = v5.map(v7);
        var2_1 = new byte["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
        var2_1["".length() >>> "\u0000\u0000".length()] = 460 >>> "\u0000\u0000".length();
        var2_1["".length() >>> "\u0000\u0000".length()] = 152 >>> "\u0000\u0000".length();
        v10 = new String(var2_1);
        v11 = HttpUtils.\u13e8;
        if (true) ** GOTO lbl52
        block25: while (true) {
            v11 = v12 / (-1493549356376131504L >>> "\u0000\u0000".length());
lbl52:
            // 2 sources

            switch ((int)v11) {
                case -1203469176: {
                    v12 = 6961L ^ -4615756857607697919L;
                    continue block25;
                }
                case -142989276: {
                    break block25;
                }
                case 674523746: {
                    v12 = 16304L ^ 3296589379519892387L;
                    continue block25;
                }
                case 1037412633: {
                    v12 = 12439L ^ -3559483955494094206L;
                    continue block25;
                }
            }
            break;
        }
        v13 = Collectors.joining(v10);
        v14 = HttpUtils.\u13e8;
        if (true) ** GOTO lbl69
        block26: while (true) {
            v14 = (8306L ^ -8110206048476566356L) / (10335L ^ -4277646192843551684L);
lbl69:
            // 2 sources

            switch ((int)v14) {
                case -142989276: {
                    break block26;
                }
                case 1437430014: {
                    continue block26;
                }
            }
            break;
        }
        return v9.collect(v13);
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private static /* synthetic */ String lambda$ToRequestDataString$0(Map keyValuePairs, String key) {
        byte[] byArray = new byte[0x48FA ^ 0x48FF];
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x4121 ^ 0x4104;
        byArray[0x27AC ^ 0x27AE] = 0x4FE2 ^ 0x4FDF;
        byArray["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x513D ^ 0x514E;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 460 >>> "\u0000\u0000".length();
        byArray[0xE58 ^ 0xE58] = 0xAA9 ^ 0xA8C;
        String string = new String(byArray);
        Object[] objectArray = new Object[0x270D ^ 0x270F];
        objectArray["".length() >>> "\u0000\u0000".length()] = key;
        long l = \u13e8;
        boolean bl = true;
        block5: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x62D2L ^ 0x80038A1FA25B54BBL);
            }
            switch ((int)l) {
                case -1436110163: {
                    l2 = 0xBA3L ^ 0x5EE28E0016E09842L;
                    continue block5;
                }
                case -142989276: {
                    break block5;
                }
                case 16819365: {
                    l2 = -8115422749559562812L >>> "\u0000\u0000".length();
                    continue block5;
                }
            }
            break;
        }
        objectArray[0x5073 ^ 0x5072] = keyValuePairs.get(key);
        while (true) {
            long l3;
            long l4;
            if ((l4 = (l3 = \u13e8 - (1834854616521200700L >>> "\u0000\u0000".length())) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l4 == (0x261D ^ 0xFFFFD9E2)) {
                return String.format(string, objectArray);
            }
            l4 = 0x1E50 ^ 0xEEE75B50;
        }
    }
}

