/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.core.itf.Module
 */
package com.tawaret.tawaplugin.utils.StatusProviders;

import com.github.manolo8.darkbot.core.itf.Module;

public interface IStatusProvider<T extends Module> {
    public String getStatusMsg(T var1);
}

