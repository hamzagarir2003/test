/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.config.ZoneInfo
 *  com.github.manolo8.darkbot.core.entities.Entity
 *  com.github.manolo8.darkbot.core.manager.MapManager
 *  com.github.manolo8.darkbot.core.objects.LocationInfo
 *  com.github.manolo8.darkbot.core.utils.Location
 */
package com.tawaret.tawaplugin.utils.mapmanager;

import com.github.manolo8.darkbot.config.ZoneInfo;
import com.github.manolo8.darkbot.core.entities.Entity;
import com.github.manolo8.darkbot.core.manager.MapManager;
import com.github.manolo8.darkbot.core.objects.LocationInfo;
import com.github.manolo8.darkbot.core.utils.Location;

public class MapManagerExtensions {
    static long \u13e8 = 3683211544994769332L;

    /*
     * Enabled aggressive block sorting
     */
    public MapManagerExtensions() {
        long l = \u13e8;
        block4: while (true) {
            switch ((int)l) {
                case -1757689352: {
                    l = (0x4B17L ^ 0xA25CD75D9793D8D3L) / (0x1F4AL ^ 0x772905BB2A3B3032L);
                    continue block4;
                }
                case -1140332108: {
                    break block4;
                }
            }
            break;
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public static boolean isInPreferredRegion(MapManager mapManager, Entity entity) {
        long l = \u13e8;
        boolean bl = true;
        block11: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (7330887854666365536L >>> "\u0000\u0000".length());
            }
            switch ((int)l) {
                case -1140332108: {
                    break block11;
                }
                case -753045540: {
                    l2 = 0x808L ^ 0x4DFFBDE73816E73CL;
                    continue block11;
                }
                case 670123797: {
                    l2 = 0x1BF4L ^ 0xB0B0C39FB04F7299L;
                    continue block11;
                }
                case 2103093021: {
                    l2 = 0x6A8EL ^ 0x44C9A4488CC4F7F4L;
                    continue block11;
                }
            }
            break;
        }
        ZoneInfo zoneInfo = mapManager.preferred;
        long l3 = \u13e8;
        boolean bl2 = true;
        block12: while (true) {
            long l4;
            if (!bl2 || (bl2 = false) || !true) {
                l3 = l4 / (0x91CL ^ 0x9E68FECECB7BC2D5L);
            }
            switch ((int)l3) {
                case -1140332108: {
                    break block12;
                }
                case 1241778406: {
                    l4 = 0x71D7L ^ 0x5FF87AD2D29BE3DCL;
                    continue block12;
                }
                case 1777792269: {
                    l4 = 5270727376252347016L >>> "\u0000\u0000".length();
                    continue block12;
                }
            }
            break;
        }
        LocationInfo locationInfo = entity.locationInfo;
        while (true) {
            long l5;
            long l6;
            if ((l6 = (l5 = \u13e8 - (0x7900L ^ 0xF375990D418CF490L)) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) continue;
            if (l6 == (0x3EFF ^ 0x3EFE)) break;
            l6 = 0x1FB2 ^ 0xCC999BA8;
        }
        Location location = locationInfo.now;
        while (true) {
            long l7;
            long l8;
            if ((l8 = (l7 = \u13e8 - (0x7828L ^ 0x170BB1767EC7CF1CL)) == 0L ? 0 : (l7 < 0L ? -1 : 1)) == false) continue;
            if (l8 == (0xF83 ^ 0xF82)) {
                return zoneInfo.contains(location);
            }
            l8 = 0x7C3A ^ 0xC543D296;
        }
    }
}

