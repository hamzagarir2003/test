/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.core.manager.HeroManager
 *  eu.darkbot.api.config.annotations.Dropdown$Options
 */
package com.tawaret.tawaplugin.utils.types;

import com.github.manolo8.darkbot.core.manager.HeroManager;
import eu.darkbot.api.config.annotations.Dropdown;
import java.util.List;

public class ConfigSupplier
implements Dropdown.Options<String> {
    protected static long \u13e8 = -7516924151330626169L;

    /*
     * Enabled aggressive block sorting
     */
    public ConfigSupplier() {
        long l = \u13e8;
        block4: while (true) {
            switch ((int)l) {
                case -1939724921: {
                    break block4;
                }
                case 1919830370: {
                    l = (0x470EL ^ 0xC281405035F42CA9L) / (595667312324715976L >>> "\u0000\u0000".length());
                    continue block4;
                }
            }
            break;
        }
    }

    /*
     * Unable to fully structure code
     */
    public List<String> options() {
        while (true) {
            if ((v0 = (cfr_temp_0 = ConfigSupplier.\u13e8 - (3812L ^ -164892295414996748L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v0 == (31533 ^ -31534)) break;
            v0 = 140 ^ 780093723;
        }
        v1 = ConfigSupplier.\u13e8;
        if (true) ** GOTO lbl11
        block13: while (true) {
            v1 = v2 / (26851L ^ 4939830652951950325L);
lbl11:
            // 2 sources

            switch ((int)v1) {
                case -1939724921: {
                    break block13;
                }
                case -1334986188: {
                    v2 = 17098L ^ 2340850882983692305L;
                    continue block13;
                }
                case 512282850: {
                    v2 = 32229L ^ -7496713661484161615L;
                    continue block13;
                }
                case 1886132598: {
                    v2 = 12787L ^ 4118387015644310389L;
                    continue block13;
                }
            }
            break;
        }
        v3 = HeroManager.instance.main;
        v4 = ConfigSupplier.\u13e8;
        if (true) ** GOTO lbl28
        block14: while (true) {
            v4 = v5 / (24028L ^ 6617869104860178673L);
lbl28:
            // 2 sources

            switch ((int)v4) {
                case -1939724921: {
                    break block14;
                }
                case 246003506: {
                    v5 = 23695L ^ 3412781839147678716L;
                    continue block14;
                }
                case 379191947: {
                    v5 = 8728L ^ -9097547045787831375L;
                    continue block14;
                }
                case 1606260777: {
                    v5 = 29192L ^ -6563633170079152965L;
                    continue block14;
                }
            }
            break;
        }
        v6 = v3.configManager;
        while (true) {
            if ((v7 = (cfr_temp_1 = ConfigSupplier.\u13e8 - (25915L ^ 7489855738214670585L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v7 == (13879 ^ -13880)) break;
            v7 = 10461 ^ -671916389;
        }
        return v6.getAvailableConfigs();
    }

    public String getText(String s) {
        return s;
    }
}

