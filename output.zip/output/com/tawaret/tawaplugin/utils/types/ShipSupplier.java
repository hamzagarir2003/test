/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.backpage.hangar.ShipInfo
 *  eu.darkbot.api.config.annotations.Dropdown$Options
 */
package com.tawaret.tawaplugin.utils.types;

import com.github.manolo8.darkbot.backpage.hangar.ShipInfo;
import eu.darkbot.api.config.annotations.Dropdown;
import java.lang.invoke.LambdaMetafactory;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class ShipSupplier
implements Dropdown.Options<Integer> {
    private static Map<Integer, ShipInfo> HANGARS;
    static long \u13e8 = 4317142891269086145L;

    public ShipSupplier() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x2ADEL ^ 0xB1A2524D4C2570A0L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l2 = -1333930260 >>> "\u0000\u0000".length();
        }
    }

    /*
     * Unable to fully structure code
     */
    public static boolean updateOwnedShips(List<ShipInfo> shipInfos) {
        block34: {
            block33: {
                if (shipInfos == null) break block33;
                v0 = ShipSupplier.\u13e8;
                if (true) ** GOTO lbl6
                block20: while (true) {
                    v0 = v1 / (806814293897444116L >>> "\u0000\u0000".length());
lbl6:
                    // 2 sources

                    switch ((int)v0) {
                        case -1738580766: {
                            v1 = 31805L ^ -8405233070256318171L;
                            continue block20;
                        }
                        case 515005377: {
                            break block20;
                        }
                        case 1759762230: {
                            v1 = 18213L ^ -316305290571913760L;
                            continue block20;
                        }
                        case 1851805183: {
                            v1 = 29775L ^ 2166047510513015952L;
                            continue block20;
                        }
                    }
                    break;
                }
                if (!shipInfos.isEmpty()) break block34;
            }
            return "".length() >>> "\u0000\u0000".length();
        }
        while (true) {
            if ((v2 = (cfr_temp_0 = ShipSupplier.\u13e8 - (3178154408478690528L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v2 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v2 = 10625 ^ 1610849650;
        }
        v3 = shipInfos.stream();
        v4 = ShipSupplier.\u13e8;
        if (true) ** GOTO lbl32
        block22: while (true) {
            v4 = (27045L ^ 1006534216614071700L) / (8099L ^ -3212292858619189851L);
lbl32:
            // 2 sources

            switch ((int)v4) {
                case 253191260: {
                    continue block22;
                }
                case 515005377: {
                    break block22;
                }
            }
            break;
        }
        v5 = (Predicate<ShipInfo>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Z, lambda$updateOwnedShips$0(com.github.manolo8.darkbot.backpage.hangar.ShipInfo ), (Lcom/github/manolo8/darkbot/backpage/hangar/ShipInfo;)Z)();
        v6 = ShipSupplier.\u13e8;
        if (true) ** GOTO lbl42
        block23: while (true) {
            v6 = (15741L ^ -4061164581993115102L) / (24287L ^ 5462269290534444362L);
lbl42:
            // 2 sources

            switch ((int)v6) {
                case 415454955: {
                    continue block23;
                }
                case 515005377: {
                    break block23;
                }
            }
            break;
        }
        v7 = v3.filter(v5);
        while (true) {
            if ((v8 = (cfr_temp_1 = ShipSupplier.\u13e8 - (-8969126305927284964L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v8 == (6418 ^ 6419)) break;
            v8 = 418155444 >>> "\u0000\u0000".length();
        }
        v9 = (Function<ShipInfo, Integer>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Ljava/lang/Object;, getHangarId(), (Lcom/github/manolo8/darkbot/backpage/hangar/ShipInfo;)Ljava/lang/Integer;)();
        while (true) {
            if ((v10 = (cfr_temp_2 = ShipSupplier.\u13e8 - (13153L ^ -7876188415463148731L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v10 == (2750 ^ 2751)) break;
            v10 = 7784448 >>> "\u0000\u0000".length();
        }
        v11 = Function.identity();
        while (true) {
            if ((v12 = (cfr_temp_3 = ShipSupplier.\u13e8 - (18518L ^ -5716972583973291328L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v12 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v12 = 20484 ^ -103752248;
        }
        v13 = Collectors.toMap(v9, v11);
        while (true) {
            if ((v14 = (cfr_temp_4 = ShipSupplier.\u13e8 - (30058L ^ 115794566571746199L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v14 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v14 = 1273 ^ 1876135061;
        }
        while (true) {
            if ((v15 = (cfr_temp_5 = ShipSupplier.\u13e8 - (31031L ^ 1902638776007932008L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
            if (v15 == (9191 ^ 9190)) break;
            v15 = 5958 ^ -1339228997;
        }
        ShipSupplier.HANGARS = v7.collect(v13);
        while (true) {
            if ((v16 = (cfr_temp_6 = ShipSupplier.\u13e8 - (5076L ^ -5710130259981242916L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
            if (v16 == (16973 ^ 16972)) break;
            v16 = 2991 ^ -501482676;
        }
        v17 = ShipSupplier.\u13e8;
        if (true) ** GOTO lbl86
        block30: while (true) {
            v17 = v18 / (9235L ^ -1025697831092554079L);
lbl86:
            // 2 sources

            switch ((int)v17) {
                case -1451187820: {
                    v18 = 1814L ^ -8849093938466898094L;
                    continue block30;
                }
                case -845373900: {
                    v18 = 7609L ^ -6021003431450538228L;
                    continue block30;
                }
                case -817613084: {
                    v18 = 8233844624604025088L >>> "\u0000\u0000".length();
                    continue block30;
                }
                case 515005377: {
                    break block30;
                }
            }
            break;
        }
        return (boolean)(ShipSupplier.HANGARS.size() > 0 ? "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length() : 31311 ^ 31311);
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private static String toShipName(ShipInfo ship) {
        long l = \u13e8;
        boolean bl = true;
        block10: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x752AL ^ 0x33F11EEE1A82AE23L);
            }
            switch ((int)l) {
                case -1347752904: {
                    l2 = 0xDA6L ^ 0xFF0E0BD571FBF5C5L;
                    continue block10;
                }
                case -270248052: {
                    l2 = 0x43BDL ^ 0x703897BCE3FC765EL;
                    continue block10;
                }
                case 515005377: {
                    break block10;
                }
                case 823798101: {
                    l2 = 0x6B13L ^ 0x75B883E7543DD7C9L;
                    continue block10;
                }
            }
            break;
        }
        String string = ship.getLootId();
        byte[] byArray = new byte["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x585F ^ 0xFFFFA7D7;
        byArray[0x4C6A ^ 0x4C6E] = 0x1134 ^ 0x116B;
        byArray[0x1F94 ^ 0x1F96] = 420 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x2917 ^ 0x2967;
        byArray[0x66C ^ 0x66C] = 0x302B ^ 0x3058;
        byArray["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x25AF ^ 0x25C7;
        String string2 = new String(byArray);
        byArray = new byte[0x50FA ^ 0x50FA];
        String string3 = new String(byArray);
        long l3 = \u13e8;
        block11: while (true) {
            switch ((int)l3) {
                case -2103428858: {
                    l3 = (-9218259321583328348L >>> "\u0000\u0000".length()) / (0x4D01L ^ 0xDA952C63EBD4F477L);
                    continue block11;
                }
                case 515005377: {
                    return string.replace(string2, string3);
                }
            }
            break;
        }
        return string.replace(string2, string3);
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public String getText(Integer id) {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x3EF2L ^ 0xBA97CDAA5DE697F0L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l2 = 0x77EF ^ 0xE20D97FE;
        }
        long l = \u13e8;
        block10: while (true) {
            switch ((int)l) {
                case -1710314994: {
                    l = (0x786DL ^ 0x16E92D411448BA1CL) / (0x197L ^ 0xE0DD0137BB5A52E1L);
                    continue block10;
                }
                case 515005377: {
                    break block10;
                }
            }
            break;
        }
        ShipInfo sh = HANGARS.get(id);
        if (sh == null) {
            return null;
        }
        long l3 = \u13e8;
        boolean bl = true;
        block11: while (true) {
            long l4;
            if (!bl || (bl = false) || !true) {
                l3 = l4 / (0x78E2L ^ 0xD24AA5AC18F5C94EL);
            }
            switch ((int)l3) {
                case 515005377: {
                    break block11;
                }
                case 560748269: {
                    l4 = 0x3B8DL ^ 0x4395ECC24C55FB82L;
                    continue block11;
                }
                case 1512004331: {
                    l4 = 0x1FF8L ^ 0x119542712B151F2DL;
                    continue block11;
                }
            }
            break;
        }
        String string = ShipSupplier.toShipName(sh);
        return string;
    }

    /*
     * Unable to fully structure code
     */
    public List<Integer> options() {
        while (true) {
            if ((v0 = (cfr_temp_0 = ShipSupplier.\u13e8 - (23018L ^ -7562191864272110042L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (10803 ^ 10802)) break;
            v0 = 5362 ^ -26531244;
        }
        while (true) {
            if ((v1 = (cfr_temp_1 = ShipSupplier.\u13e8 - (13482L ^ 3789769016986399045L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v1 == (21196 ^ 21197)) break;
            v1 = 14373 ^ 255818477;
        }
        v2 = ShipSupplier.HANGARS.keySet();
        v3 = ShipSupplier.\u13e8;
        if (true) ** GOTO lbl16
        block7: while (true) {
            v3 = v4 / (31907L ^ -5015198252806445253L);
lbl16:
            // 2 sources

            switch ((int)v3) {
                case -1790817999: {
                    v4 = 21006L ^ 295124507549357764L;
                    continue block7;
                }
                case -979097251: {
                    v4 = 2610L ^ 6374983301818354974L;
                    continue block7;
                }
                case 515005377: {
                    break block7;
                }
            }
            break;
        }
        v5 = v2.stream();
        while (true) {
            if ((v6 = (cfr_temp_2 = ShipSupplier.\u13e8 - (25422L ^ 4227255940329076676L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v6 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v6 = 13206 ^ 1039968529;
        }
        v7 = Collectors.toList();
        while (true) {
            if ((v8 = (cfr_temp_3 = ShipSupplier.\u13e8 - (12108L ^ -1999179434460805722L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v8 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v8 = 16542 ^ -331566113;
        }
        return v5.collect(v7);
    }

    private static /* synthetic */ boolean lambda$updateOwnedShips$0(ShipInfo sh) {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x323DL ^ 0x8F6C8FB2FC4D79DFL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l2 = 0x543E ^ 0xF9E26F81;
        }
        return (sh.getOwned() == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length() ? "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length() : 0x4178 ^ 0x4178) != 0;
    }

    /*
     * Unable to fully structure code
     */
    static {
        while (true) {
            if ((v0 = (cfr_temp_0 = ShipSupplier.\u13e8 - (19233L ^ 2706496448272572014L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (8285 ^ 8284)) break;
            v0 = 5892 ^ 1247088943;
        }
        v1 = ShipSupplier.\u13e8;
        if (true) ** GOTO lbl10
        block7: while (true) {
            v1 = v2 / (1838L ^ 4313581534767283798L);
lbl10:
            // 2 sources

            switch ((int)v1) {
                case -473916329: {
                    v2 = 2945L ^ -4688315915746803030L;
                    continue block7;
                }
                case 74884000: {
                    v2 = 20972L ^ 7530162447070539068L;
                    continue block7;
                }
                case 515005377: {
                    break block7;
                }
                case 1147962581: {
                    v2 = 23771L ^ -284796874875803539L;
                    continue block7;
                }
            }
            break;
        }
        v3 = new HashMap<Integer, ShipInfo>();
        while (true) {
            if ((v4 = (cfr_temp_1 = ShipSupplier.\u13e8 - (13790L ^ -8095201040968747283L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v4 == (22553 ^ 22552)) break;
            v4 = 421 ^ 1751891339;
        }
        ShipSupplier.HANGARS = v3;
    }
}

