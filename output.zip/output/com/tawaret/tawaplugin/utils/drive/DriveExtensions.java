/*
 * Decompiled with CFR 0.152.
 */
package com.tawaret.tawaplugin.utils.drive;

public class DriveExtensions {
    public static long \u13e8 = -6987498745976955635L;

    public DriveExtensions() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x2B8FL ^ 0x2FD11FEA2B40B928L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x3D87 ^ 0xFFFFC278)) break;
            l2 = 0x75E ^ 0xC3396813;
        }
    }
}

