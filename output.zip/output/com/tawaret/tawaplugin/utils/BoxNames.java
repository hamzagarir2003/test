/*
 * Decompiled with CFR 0.152.
 */
package com.tawaret.tawaplugin.utils;

public class BoxNames {
    public static final String BEHEMOTH;
    public static long \u13e8 = -4478329220371566323L;

    public BoxNames() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x7E74L ^ 0xAF8B2BC3B5430BD3L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l2 = 0x767F ^ 0x74E6D7CA;
        }
    }

    static {
        byte[] byArray = new byte[0x57D2 ^ 0x57D9];
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x205C ^ 0xFFFFDFCC;
        byArray[0x786B ^ 0x786D] = 0x2445 ^ 0x2406;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 380 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x131A ^ 0x135B;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x2A5F ^ 0x2A1E;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x69E3 ^ 0x69AB;
        byArray[0xEA5 ^ 0xEA2] = 0x578C ^ 0x57C0;
        byArray["".length() >>> "\u0000\u0000".length()] = 0x3D89 ^ 0x3DDA;
        byArray[0x4CD6 ^ 0x4CD2] = 328 >>> "\u0000\u0000".length();
        byArray[0x10A3 ^ 0x10A1] = 0x3EAF ^ 0x3EE3;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x5607 ^ 0x5654;
        byArray["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x2836 ^ 0x2879;
        BEHEMOTH = new String(byArray);
    }
}

