/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.Main
 *  com.github.manolo8.darkbot.core.IDarkBotAPI
 */
package com.tawaret.tawaplugin.utils.Api;

import com.github.manolo8.darkbot.Main;
import com.github.manolo8.darkbot.core.IDarkBotAPI;

public class ApiExtensions {
    private static final IDarkBotAPI instance;
    private static long \u13e8 = -1730082361228438948L;

    public ApiExtensions() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x5751L ^ 0x767A1D74BCB3C9CAL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x644F ^ 0xFFFF9BB0)) break;
            l2 = 0x484 ^ 0xDD4E7969;
        }
    }

    /*
     * Unable to fully structure code
     */
    public static void refreshBot() {
        while (true) {
            if ((v0 = (cfr_temp_0 = ApiExtensions.\u13e8 - (9188314743377026644L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v0 == (24700 ^ -24701)) break;
            v0 = 23728 ^ 924080188;
        }
        v1 = ApiExtensions.\u13e8;
        if (true) ** GOTO lbl11
        block7: while (true) {
            v1 = v2 / (25791L ^ 3369090173854171483L);
lbl11:
            // 2 sources

            switch ((int)v1) {
                case 358153464: {
                    v2 = 16294L ^ -6994167388854542277L;
                    continue block7;
                }
                case 916028836: {
                    v2 = 21462L ^ 6099781371697279532L;
                    continue block7;
                }
                case 1092514190: {
                    v2 = 20720L ^ -742981261018291896L;
                    continue block7;
                }
                case 1120883292: {
                    break block7;
                }
            }
            break;
        }
        ApiExtensions.refreshBot(ApiExtensions.instance);
    }

    public static void refreshBot(IDarkBotAPI api) {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x6A9DL ^ 0x5A2D6C5E5B5C46D5L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x2383 ^ 0xFFFFDC7C)) break;
            l2 = 0x566E ^ 0xD9FED884;
        }
        api.handleRefresh();
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void keyboardClick(Character key) {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x1F3AL ^ 0xA984DF3B0F3BC8D1L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l2 = 0x1DD1 ^ 0x1A419779;
        }
        long l = \u13e8;
        block5: while (true) {
            switch ((int)l) {
                case 724001008: {
                    l = (0x2274L ^ 0x8629396FD9ADEF6L) / (0x32E5L ^ 0x930B114AA7594352L);
                    continue block5;
                }
                case 1120883292: {
                    break block5;
                }
            }
            break;
        }
        ApiExtensions.keyboardClick(instance, key);
    }

    public static void keyboardClick(IDarkBotAPI api, Character key) {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x61FDL ^ 0xB0A2DE2EE1557C4BL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l2 = 0x3C4D ^ 0x7CDFAAF6;
        }
        api.keyboardClick(key);
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    static {
        long l = \u13e8;
        boolean bl = true;
        block10: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x4FAL ^ 0xF414CED917ED7BC3L);
            }
            switch ((int)l) {
                case -1384395844: {
                    l2 = 4565660887743094408L >>> "\u0000\u0000".length();
                    continue block10;
                }
                case 999044758: {
                    l2 = 0x2E72L ^ 0x8355B2789450682BL;
                    continue block10;
                }
                case 1120883292: {
                    break block10;
                }
                case 1976509363: {
                    l2 = 0x7529L ^ 0x6B4876781E3B5EEEL;
                    continue block10;
                }
            }
            break;
        }
        long l3 = \u13e8;
        block11: while (true) {
            switch ((int)l3) {
                case 1120883292: {
                    break block11;
                }
                case 1472089503: {
                    l3 = (0x3DB8L ^ 0x5152020563E71690L) / (0x24E0L ^ 0xBEE5D1C3B3A2621AL);
                    continue block11;
                }
            }
            break;
        }
        instance = Main.API;
    }
}

