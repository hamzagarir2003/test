/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  eu.darkbot.api.extensions.ExtraMenus
 *  eu.darkbot.util.Popups
 *  eu.darkbot.util.Popups$Builder
 */
package com.tawaret.tawaplugin.utils;

import eu.darkbot.api.extensions.ExtraMenus;
import eu.darkbot.util.Popups;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.invoke.LambdaMetafactory;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

public class ExtraMenuExtensions {
    static long \u13e8 = -6984979286036566488L;

    public ExtraMenuExtensions() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x5FD1L ^ 0x6E85C1FB86BC7BBAL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x95 ^ 0xFFFFFF6A)) break;
            l2 = 0x5427 ^ 0xCC21281C;
        }
    }

    /*
     * Unable to fully structure code
     */
    public static Collection<JComponent> MapCycleFirstMenu(ExtraMenus extraMenus, String displayName, JLabel ... labels) {
        v0 = new JComponent["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
        v1 = "".length() >>> "\u0000\u0000".length();
        var4_3 = new byte[16915 ^ 16922];
        var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 404 >>> "\u0000\u0000".length();
        var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 484 >>> "\u0000\u0000".length();
        var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 268 >>> "\u0000\u0000".length();
        var4_3[14032 ^ 14035] = 21956 ^ 21988;
        var4_3[14818 ^ 14818] = 19447 ^ 19386;
        var4_3[26631 ^ 26625] = 396 >>> "\u0000\u0000".length();
        var4_3[3987 ^ 3988] = 1528 ^ 1428;
        var4_3[31639 ^ 31637] = 20851 ^ 20739;
        var4_3[22860 ^ 22861] = 11531 ^ 11626;
        v2 = new String(var4_3);
        while (true) {
            if ((v3 = (cfr_temp_0 = ExtraMenuExtensions.\u13e8 - (1770L ^ -6125844631552952185L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v3 == (19357 ^ -19358)) break;
            v3 = 17403 ^ -711751857;
        }
        v0[v1] = extraMenus.createSeparator(v2);
        v4 = ExtraMenuExtensions.\u13e8;
        if (true) ** GOTO lbl26
        block16: while (true) {
            v4 = v5 / (4737L ^ 1679413272901099615L);
lbl26:
            // 2 sources

            switch ((int)v4) {
                case -625716320: {
                    v5 = 10065L ^ -6187482075607435065L;
                    continue block16;
                }
                case -330027480: {
                    break block16;
                }
                case 1324085671: {
                    v5 = 22316L ^ 7087236506778691730L;
                    continue block16;
                }
            }
            break;
        }
        v6 = (ActionListener)LambdaMetafactory.metafactory(null, null, null, (Ljava/awt/event/ActionEvent;)V, lambda$MapCycleFirstMenu$0(java.lang.String javax.swing.JLabel[] java.awt.event.ActionEvent ), (Ljava/awt/event/ActionEvent;)V)((String)displayName, (JLabel[])labels);
        v7 = ExtraMenuExtensions.\u13e8;
        if (true) ** GOTO lbl40
        block17: while (true) {
            v7 = v8 / (32176L ^ 8397533806747162066L);
lbl40:
            // 2 sources

            switch ((int)v7) {
                case -995445490: {
                    v8 = 7269L ^ -8895686866464647798L;
                    continue block17;
                }
                case -330027480: {
                    break block17;
                }
                case 166208441: {
                    v8 = 18975L ^ -5092971966637246141L;
                    continue block17;
                }
                case 783991629: {
                    v8 = 4029L ^ -15110011593587194L;
                    continue block17;
                }
            }
            break;
        }
        v0[25498 ^ 25499] = extraMenus.create(displayName, v6);
        v9 = ExtraMenuExtensions.\u13e8;
        if (true) ** GOTO lbl57
        block18: while (true) {
            v9 = (10870L ^ -3671398734239531398L) / (22242L ^ -2432971276246658090L);
lbl57:
            // 2 sources

            switch ((int)v9) {
                case -330027480: {
                    break block18;
                }
                case 887951739: {
                    continue block18;
                }
            }
            break;
        }
        return Arrays.asList(v0);
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public static Collection<JComponent> MapCycleExtraMenu(ExtraMenus extraMenus, String displayName, JLabel ... labels) {
        long l = \u13e8;
        boolean bl = true;
        block6: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x43E7L ^ 0xE02038FD3B56EC8DL);
            }
            switch ((int)l) {
                case -2116050824: {
                    l2 = 2648020639362612060L >>> "\u0000\u0000".length();
                    continue block6;
                }
                case -330027480: {
                    break block6;
                }
                case 793652377: {
                    l2 = 0x10C5L ^ 0x2762CF9365F4F677L;
                    continue block6;
                }
                case 1944126710: {
                    l2 = 0x6A79L ^ 0x9447684CE4C95572L;
                    continue block6;
                }
            }
            break;
        }
        ActionListener actionListener = ignored -> {
            byte[] byArray = new byte[0x3FA2 ^ 0x3FAB];
            byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x62C5 ^ 0xFFFF9D77;
            byArray[0x66A9 ^ 0x66AB] = 0x6EEE ^ 0x6ECE;
            byArray[0x4D3B ^ 0x4D3F] = 464 >>> "\u0000\u0000".length();
            byArray[0x7C4C ^ 0x7C49] = 388 >>> "\u0000\u0000".length();
            byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 468 >>> "\u0000\u0000".length();
            byArray[0x2015 ^ 0x2013] = 464 >>> "\u0000\u0000".length();
            byArray["".length() >>> "\u0000\u0000".length()] = 0x30F1 ^ 0x30D4;
            byArray[0x3B96 ^ 0x3B95] = 332 >>> "\u0000\u0000".length();
            byArray["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 460 >>> "\u0000\u0000".length();
            byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x2631 ^ 0x2642;
            String string = new String(byArray);
            Object[] objectArray = new Object["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
            objectArray["".length() >>> "\u0000\u0000".length()] = displayName;
            long l = \u13e8;
            block17: while (true) {
                switch ((int)l) {
                    case -330027480: {
                        break block17;
                    }
                    case 1957907787: {
                        l = (0x5BD0L ^ 0xD4FFACB8D6248ED5L) / (0x4B5AL ^ 0x528BE875137ABE33L);
                        continue block17;
                    }
                }
                break;
            }
            String string2 = String.format(string, objectArray);
            while (true) {
                long l2;
                long l3;
                if ((l3 = (l2 = \u13e8 - (0x7360L ^ 0x22F911298663B601L)) == 0L ? 0 : (l2 < 0L ? -1 : 1)) == false) continue;
                if (l3 == (0x3C43 ^ 0xFFFFC3BC)) break;
                l3 = -1523464416 >>> "\u0000\u0000".length();
            }
            long l4 = \u13e8;
            block19: while (true) {
                switch ((int)l4) {
                    case -330027480: {
                        break block19;
                    }
                    case 1187718026: {
                        l4 = (0x1F90L ^ 0xACA3FB66ED7CC782L) / (5186677685238684552L >>> "\u0000\u0000".length());
                        continue block19;
                    }
                }
                break;
            }
            JOptionPane jOptionPane = new JOptionPane(labels);
            long l5 = \u13e8;
            boolean bl = true;
            block20: while (true) {
                long l6;
                if (!bl || (bl = false) || !true) {
                    l5 = l6 / (0xA77L ^ 0x79C9839B0CA49A67L);
                }
                switch ((int)l5) {
                    case -330027480: {
                        break block20;
                    }
                    case 274454386: {
                        l6 = 0x16C1L ^ 0xC6184B0935A21E78L;
                        continue block20;
                    }
                    case 1272381666: {
                        l6 = 0x6EF3L ^ 0x8C638B3950E469E0L;
                        continue block20;
                    }
                }
                break;
            }
            Popups.Builder builder = Popups.of((String)string2, (JOptionPane)jOptionPane);
            long l7 = \u13e8;
            block21: while (true) {
                switch ((int)l7) {
                    case -330027480: {
                        break block21;
                    }
                    case 385416516: {
                        l7 = (0x2C49L ^ 0x8E4421DF8C7DBA74L) / (0x7247L ^ 0xCA629FF8B62D0786L);
                        continue block21;
                    }
                }
                break;
            }
            builder.showAsync();
        };
        while (true) {
            long l3;
            long l4;
            if ((l4 = (l3 = \u13e8 - (0x62EAL ^ 0xB22371FF60232AE8L)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) continue;
            if (l4 == (0x21C9 ^ 0xFFFFDE36)) break;
            l4 = 0x12E5 ^ 0x8F1AC1C6;
        }
        JMenuItem jMenuItem = extraMenus.create(displayName, actionListener);
        while (true) {
            long l5;
            long l6;
            if ((l6 = (l5 = \u13e8 - (0x737BL ^ 0xF696E64582C61559L)) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) continue;
            if (l6 == (0x3D56 ^ 0xFFFFC2A9)) {
                return Collections.singletonList(jMenuItem);
            }
            l6 = 0x4085 ^ 0x41082948;
        }
    }

    /*
     * Unable to fully structure code
     */
    private static /* synthetic */ void lambda$MapCycleFirstMenu$0(String displayName, JLabel[] labels, ActionEvent ignored) {
        var4_3 = new byte["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
        var4_3["".length() >>> "\u0000\u0000".length()] = 12567 ^ -12567;
        var4_3[28617 ^ 28617] = 27764 ^ 27729;
        var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 5638 ^ 5747;
        var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 388 >>> "\u0000\u0000".length();
        var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 460 >>> "\u0000\u0000".length();
        var4_3[22700 ^ 22702] = 128 >>> "\u0000\u0000".length();
        var4_3[1343 ^ 1339] = 24795 ^ 24751;
        var4_3[4287 ^ 4281] = 31002 ^ 31086;
        var4_3[18677 ^ 18676] = 460 >>> "\u0000\u0000".length();
        var4_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 27346 ^ 27265;
        v0 = new String(var4_3);
        v1 = new Object[30029 ^ 30028];
        v1["".length() >>> "\u0000\u0000".length()] = displayName;
        while (true) {
            if ((v2 = (cfr_temp_0 = ExtraMenuExtensions.\u13e8 - (24113L ^ -5407677800107791377L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v2 == (15766 ^ -15767)) break;
            v2 = 22056 ^ 1749764004;
        }
        v3 = String.format(v0, v1);
        v4 = ExtraMenuExtensions.\u13e8;
        if (true) ** GOTO lbl25
        block24: while (true) {
            v4 = v5 / (11440L ^ -8519422966336258972L);
lbl25:
            // 2 sources

            switch ((int)v4) {
                case -1431889894: {
                    v5 = 24365L ^ -1087449862157389816L;
                    continue block24;
                }
                case -330027480: {
                    break block24;
                }
                case 1589143477: {
                    v5 = 25695L ^ -723281918156294723L;
                    continue block24;
                }
                case 1657662353: {
                    v5 = 29868L ^ 6696053368391908418L;
                    continue block24;
                }
            }
            break;
        }
        v6 = ExtraMenuExtensions.\u13e8;
        if (true) ** GOTO lbl41
        block25: while (true) {
            v6 = v7 / (6089L ^ -4629780696967780638L);
lbl41:
            // 2 sources

            switch ((int)v6) {
                case -1710458800: {
                    v7 = 20782L ^ -194842635757263288L;
                    continue block25;
                }
                case -798371231: {
                    v7 = 7061L ^ -8792694853049466170L;
                    continue block25;
                }
                case -330027480: {
                    break block25;
                }
            }
            break;
        }
        v8 = new JOptionPane(labels);
        v9 = ExtraMenuExtensions.\u13e8;
        if (true) ** GOTO lbl55
        block26: while (true) {
            v9 = v10 / (427L ^ -6689818875703044720L);
lbl55:
            // 2 sources

            switch ((int)v9) {
                case -449131766: {
                    v10 = 6296L ^ -3886789097751241727L;
                    continue block26;
                }
                case -330027480: {
                    break block26;
                }
                case 393675417: {
                    v10 = 8995502688318981016L >>> "\u0000\u0000".length();
                    continue block26;
                }
                case 805892341: {
                    v10 = 6617L ^ 3461520606793837177L;
                    continue block26;
                }
            }
            break;
        }
        v11 = Popups.of((String)v3, (JOptionPane)v8);
        v12 = ExtraMenuExtensions.\u13e8;
        if (true) ** GOTO lbl72
        block27: while (true) {
            v12 = v13 / (10662L ^ 8128226185796404044L);
lbl72:
            // 2 sources

            switch ((int)v12) {
                case -330027480: {
                    break block27;
                }
                case 458153569: {
                    v13 = 3818747586155147048L >>> "\u0000\u0000".length();
                    continue block27;
                }
                case 831282463: {
                    v13 = 9605L ^ 5851457375636035226L;
                    continue block27;
                }
                case 1906730362: {
                    v13 = 7450L ^ 6732123693129308166L;
                    continue block27;
                }
            }
            break;
        }
        v11.showAsync();
    }
}

