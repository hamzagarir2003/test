/*
 * Decompiled with CFR 0.152.
 */
package com.tawaret.tawaplugin.utils.time;

import java.time.LocalDateTime;

public class TimeUtils {
    private static long \u13e8 = -5536173071939208271L;

    public TimeUtils() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (-5271371606734089328L >>> "\u0000\u0000".length())) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x156E ^ 0xFFFFEA91)) break;
            l2 = 0x31E3 ^ 0x2DBD65E1;
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public static int Get24HourNow() {
        long l = \u13e8;
        boolean bl = true;
        block11: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x37CFL ^ 0x5D8DA25B44369C7EL);
            }
            switch ((int)l) {
                case -458367178: {
                    l2 = 0x6FDDL ^ 0x567F1A27E26CBBB5L;
                    continue block11;
                }
                case 1207630769: {
                    break block11;
                }
                case 2052433321: {
                    l2 = -1773730644463022300L >>> "\u0000\u0000".length();
                    continue block11;
                }
            }
            break;
        }
        LocalDateTime localDateTime = LocalDateTime.now();
        long l3 = \u13e8;
        boolean bl2 = true;
        block12: while (true) {
            long l4;
            if (!bl2 || (bl2 = false) || !true) {
                l3 = l4 / (7615472246349294216L >>> "\u0000\u0000".length());
            }
            switch ((int)l3) {
                case -1880614973: {
                    l4 = 0x1F6DL ^ 0xD07620B29A2B4520L;
                    continue block12;
                }
                case -1831337125: {
                    l4 = 0x7045L ^ 0x985E0F3307FF6FCCL;
                    continue block12;
                }
                case 521941389: {
                    l4 = 0x4F46L ^ 0xFC4E6BAF20663E3DL;
                    continue block12;
                }
                case 1207630769: {
                    return localDateTime.getHour();
                }
            }
            break;
        }
        return localDateTime.getHour();
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public static boolean IsHourNowBetween(int start, int end) {
        int n;
        long l = \u13e8;
        boolean bl = true;
        block6: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x7CE4L ^ 0x3887D0E7F481478L);
            }
            switch ((int)l) {
                case -1965637637: {
                    l2 = 0x301AL ^ 0xB8E36368C9F86FFBL;
                    continue block6;
                }
                case -1665082099: {
                    l2 = 0x429DL ^ 0xFDF636EB6C8CF86EL;
                    continue block6;
                }
                case -1298420364: {
                    l2 = 6687565600531066992L >>> "\u0000\u0000".length();
                    continue block6;
                }
                case 1207630769: {
                    break block6;
                }
            }
            break;
        }
        int x = TimeUtils.Get24HourNow();
        if (start > end) {
            int n2;
            if (x < start && end <= x) {
                n2 = "".length() >>> "\u0000\u0000".length();
                return n2 != 0;
            }
            n2 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
            return n2 != 0;
        }
        if (start == end) {
            boolean bl2;
            if (x == start) {
                bl2 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
                return bl2;
            }
            bl2 = "".length() >>> "\u0000\u0000".length();
            return bl2;
        }
        if (x >= start && x < end) {
            n = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
            return n != 0;
        }
        n = 0x4C8F ^ 0x4C8F;
        return n != 0;
    }
}

