/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.utils.AuthAPI
 */
package com.tawaret.tawaplugin.utils.AuthApi;

import com.github.manolo8.darkbot.utils.AuthAPI;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AuthApiExtensions {
    private static final Pattern DiscordIdRegex;
    static long \u13e8 = 1861787238165637064L;

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public AuthApiExtensions() {
        long l = \u13e8;
        boolean bl = true;
        block6: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x4872L ^ 0xBD521C2CBB31481L);
            }
            switch ((int)l) {
                case -587904552: {
                    l2 = 0x2D26L ^ 0xB21DF67FB755E508L;
                    continue block6;
                }
                case 37218248: {
                    break block6;
                }
                case 316698474: {
                    l2 = 0x789DL ^ 0xAF95F8690C3DE062L;
                    continue block6;
                }
                case 1092942935: {
                    l2 = 0x23F4L ^ 0xD486F803EFF39673L;
                    continue block6;
                }
            }
            break;
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public static Long GetDiscordId(AuthAPI authAPI) {
        long l = \u13e8;
        boolean bl = true;
        block11: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x19C2L ^ 0xB2C3B04FED0533D5L);
            }
            switch ((int)l) {
                case 37218248: {
                    break block11;
                }
                case 657000797: {
                    l2 = 0x31E3L ^ 0x8D548591D7C7641BL;
                    continue block11;
                }
                case 688536781: {
                    l2 = 0x548L ^ 0xD289E522438C70ACL;
                    continue block11;
                }
                case 1678266063: {
                    l2 = 0x41BCL ^ 0x5544841FE27C2497L;
                    continue block11;
                }
            }
            break;
        }
        String authId = authAPI.getAuthId();
        long l3 = \u13e8;
        boolean bl2 = true;
        block12: while (true) {
            long l4;
            if (!bl2 || (bl2 = false) || !true) {
                l3 = l4 / (0x14D1L ^ 0x906F4E4B529401E1L);
            }
            switch ((int)l3) {
                case -1308821733: {
                    l4 = 0x19DCL ^ 0x4A8FFF70E761F805L;
                    continue block12;
                }
                case 37218248: {
                    break block12;
                }
                case 263397828: {
                    l4 = 0x156AL ^ 0x886CCA58DE95E19BL;
                    continue block12;
                }
            }
            break;
        }
        while (true) {
            long l5;
            long l6;
            if ((l6 = (l5 = \u13e8 - (0x7428L ^ 0x1302A8B998EBDB56L)) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) continue;
            if (l6 == (0x67DB ^ 0x67DA)) break;
            l6 = -1745660832 >>> "\u0000\u0000".length();
        }
        Matcher matcher = DiscordIdRegex.matcher(authId);
        while (true) {
            long l7;
            long l8;
            if ((l8 = (l7 = \u13e8 - (0x5C1AL ^ 0xDCB53385A059A6DBL)) == 0L ? 0 : (l7 < 0L ? -1 : 1)) == false) continue;
            if (l8 == (0x3E8C ^ 0x3E8D)) break;
            l8 = 0x6349 ^ 0x47D9DF01;
        }
        if (!matcher.find()) return null;
        int n = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        while (true) {
            long l9;
            long l10;
            if ((l10 = (l9 = \u13e8 - (0x9CAL ^ 0xDD7BCFE43F6C9B69L)) == 0L ? 0 : (l9 < 0L ? -1 : 1)) == false) continue;
            if (l10 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l10 = 0x6FA8 ^ 0xA92619E7;
        }
        String string = matcher.group(n);
        while (true) {
            long l11;
            long l12;
            if ((l12 = (l11 = \u13e8 - (0x5B34L ^ 0x59CE60C5F2D633DFL)) == 0L ? 0 : (l11 < 0L ? -1 : 1)) == false) continue;
            if (l12 == (0x418F ^ 0xFFFFBE70)) break;
            l12 = 0x7A16 ^ 0x7FF7CF48;
        }
        long l13 = Long.parseLong(string);
        while (true) {
            long l14;
            long l15;
            if ((l15 = (l14 = \u13e8 - (0x5460L ^ 0x190925876E41252EL)) == 0L ? 0 : (l14 < 0L ? -1 : 1)) == false) continue;
            if (l15 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                return l13;
            }
            l15 = 0x5EDB ^ 0x9A8EE817;
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    static {
        byte[] byArray = new byte["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 296 >>> "\u0000\u0000".length();
        byArray[0x82E ^ 0x83E] = 180 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x3CA5 ^ 0x3C8D;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x4637 ^ 0x461A;
        byArray[0x7703 ^ 0x7709] = 192 >>> "\u0000\u0000".length();
        byArray[0x5B31 ^ 0x5B33] = 460 >>> "\u0000\u0000".length();
        byArray[0x67E1 ^ 0x67E8] = 364 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x36AA ^ 0x3693;
        byArray[0x6057 ^ 0x6057] = 400 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() ^ "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length()] = 0x984 ^ 0x9ED;
        byArray[0x4A7D ^ 0x4A72] = 164 >>> "\u0000\u0000".length();
        byArray[0x17EF ^ 0x17EA] = 0x8B6 ^ 0x8C4;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 180 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() ^ "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length()] = 0x6C6D ^ 0x6C30;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 400 >>> "\u0000\u0000".length();
        byArray[0x72B9 ^ 0x72BD] = 0x7EB ^ 0x784;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x3816 ^ 0x3875;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 172 >>> "\u0000\u0000".length();
        String string = new String(byArray);
        long l = \u13e8;
        boolean bl = true;
        block9: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x6C97L ^ 0xF99DF33381285D0EL);
            }
            switch ((int)l) {
                case -1188895330: {
                    l2 = 0x7F6FL ^ 0x42762289ADCDEB93L;
                    continue block9;
                }
                case 37218248: {
                    break block9;
                }
                case 1444964823: {
                    l2 = 0x6020L ^ 0xD598E255D0A923B3L;
                    continue block9;
                }
            }
            break;
        }
        Pattern pattern = Pattern.compile(string);
        long l3 = \u13e8;
        block10: while (true) {
            switch ((int)l3) {
                case 37218248: {
                    break block10;
                }
                case 1894106351: {
                    l3 = (0x12FDL ^ 0x8D48221E80325A01L) / (0x5EC2L ^ 0x2F7636C28D9281ACL);
                    continue block10;
                }
            }
            break;
        }
        DiscordIdRegex = pattern;
    }
}

