/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.core.manager.HeroManager
 */
package com.tawaret.tawaplugin.utils.hero;

import com.github.manolo8.darkbot.core.manager.HeroManager;

public class HeroExtensions {
    static long \u13e8 = -1739859715955866113L;

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public HeroExtensions() {
        long l = \u13e8;
        boolean bl = true;
        block6: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (1734952686508255496L >>> "\u0000\u0000".length());
            }
            switch ((int)l) {
                case -1245963941: {
                    l2 = 0x488EL ^ 0x2F1758F8E6926130L;
                    continue block6;
                }
                case 653102129: {
                    l2 = 0x3506L ^ 0x98365C601FE447C0L;
                    continue block6;
                }
                case 2003846655: {
                    break block6;
                }
                case 2086110230: {
                    l2 = 0x2EF5L ^ 0x6A1F2BAE07C5958CL;
                    continue block6;
                }
            }
            break;
        }
    }

    /*
     * Unable to fully structure code
     */
    public static boolean IsInRadiationZone(HeroManager heroManager) {
        while (true) {
            if ((v0 = (cfr_temp_0 = HeroExtensions.\u13e8 - (20162L ^ -5809387544638198141L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v0 = 11187 ^ 1902231920;
        }
        v1 = heroManager.locationInfo;
        v2 = HeroExtensions.\u13e8;
        if (true) ** GOTO lbl11
        block11: while (true) {
            v2 = v3 / (20814L ^ -1916607622966573193L);
lbl11:
            // 2 sources

            switch ((int)v2) {
                case -849011007: {
                    v3 = 4254L ^ 5615955111447738547L;
                    continue block11;
                }
                case 118031151: {
                    v3 = 1262L ^ -4159497430042651457L;
                    continue block11;
                }
                case 334485257: {
                    v3 = 27863L ^ -2588783107878387724L;
                    continue block11;
                }
                case 2003846655: {
                    break block11;
                }
            }
            break;
        }
        heroPos = v1.now;
        v4 = HeroExtensions.\u13e8;
        if (true) ** GOTO lbl28
        block12: while (true) {
            v4 = (22863L ^ -2035162599821440521L) / (4764L ^ -6673089350130893066L);
lbl28:
            // 2 sources

            switch ((int)v4) {
                case 1780907024: {
                    continue block12;
                }
                case 2003846655: {
                    break block12;
                }
            }
            break;
        }
        if (heroPos.x < 0.0) ** GOTO lbl-1000
        while (true) {
            if ((v5 = (cfr_temp_1 = HeroExtensions.\u13e8 - (21969L ^ 7405662720952054117L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v5 == (28895 ^ -28896)) break;
            v5 = 1115 ^ -929516671;
        }
        if (heroPos.y < 0.0) lbl-1000:
        // 2 sources

        {
            v6 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        } else {
            v6 = "".length() >>> "\u0000\u0000".length();
        }
        return (boolean)v6;
    }
}

