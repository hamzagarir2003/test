/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.core.manager.GroupManager
 *  com.github.manolo8.darkbot.core.objects.group.Group
 *  com.github.manolo8.darkbot.core.objects.group.GroupMember
 */
package com.tawaret.tawaplugin.utils.GroupManager;

import com.github.manolo8.darkbot.core.manager.GroupManager;
import com.github.manolo8.darkbot.core.objects.group.Group;
import com.github.manolo8.darkbot.core.objects.group.GroupMember;
import java.lang.invoke.LambdaMetafactory;
import java.util.List;
import java.util.function.Predicate;

public class GroupManagerExtensions {
    static long \u13e8 = -3681665292577445246L;

    /*
     * Enabled aggressive block sorting
     */
    public GroupManagerExtensions() {
        long l = \u13e8;
        block4: while (true) {
            switch ((int)l) {
                case -922619686: {
                    l = (0xB02L ^ 0x8E0BB464A228483FL) / (0x3C63L ^ 0x47BB44ADB5617691L);
                    continue block4;
                }
                case 906586754: {
                    break block4;
                }
            }
            break;
        }
    }

    private static List<GroupMember> groupMembers(GroupManager groupManager) {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x6DD7L ^ 0xCE5148AB2B100E2L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x2F95 ^ 0xFFFFD06A)) break;
            l2 = 0x460A ^ 0x6D1B9374;
        }
        Group group = groupManager.group;
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = \u13e8 - (0x46AFL ^ 0x1A5A00337497516L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l3 == (0x6EDF ^ 0xFFFF9120)) break;
            l3 = 0x7F5B ^ 0x7FC60529;
        }
        return group.members;
    }

    /*
     * Unable to fully structure code
     */
    private static long countGroupMembersOnMap(GroupManager groupManager, int mapId) {
        while (true) {
            if ((v0 = (cfr_temp_0 = GroupManagerExtensions.\u13e8 - (12749L ^ 6876593458483976001L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (14321 ^ -14322)) break;
            v0 = 20326 ^ -1971240408;
        }
        v1 = GroupManagerExtensions.groupMembers(groupManager);
        v2 = GroupManagerExtensions.\u13e8;
        if (true) ** GOTO lbl11
        block17: while (true) {
            v2 = v3 / (29972L ^ 6793441674211944038L);
lbl11:
            // 2 sources

            switch ((int)v2) {
                case -1920963451: {
                    v3 = 930L ^ -3094570378628140828L;
                    continue block17;
                }
                case -1377098674: {
                    v3 = 26644L ^ 4690175464207928999L;
                    continue block17;
                }
                case 906586754: {
                    break block17;
                }
                case 1514735922: {
                    v3 = 4164L ^ -5709018594118486489L;
                    continue block17;
                }
            }
            break;
        }
        v4 = v1.stream();
        v5 = GroupManagerExtensions.\u13e8;
        if (true) ** GOTO lbl28
        block18: while (true) {
            v5 = v6 / (7802L ^ 3632316072729013367L);
lbl28:
            // 2 sources

            switch ((int)v5) {
                case -756051190: {
                    v6 = 22052L ^ -2610841430673312031L;
                    continue block18;
                }
                case 812352045: {
                    v6 = -4087898356906234252L >>> "\u0000\u0000".length();
                    continue block18;
                }
                case 906586754: {
                    break block18;
                }
                case 1070679663: {
                    v6 = 3400L ^ -7191709307659062877L;
                    continue block18;
                }
            }
            break;
        }
        v7 = (Predicate<GroupMember>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)Z, lambda$countGroupMembersOnMap$0(int com.github.manolo8.darkbot.core.objects.group.GroupMember ), (Lcom/github/manolo8/darkbot/core/objects/group/GroupMember;)Z)((int)mapId);
        v8 = GroupManagerExtensions.\u13e8;
        if (true) ** GOTO lbl45
        block19: while (true) {
            v8 = (-8640089939932229192L >>> "\u0000\u0000".length()) / (30842L ^ 7493046392406580156L);
lbl45:
            // 2 sources

            switch ((int)v8) {
                case -301217609: {
                    continue block19;
                }
                case 906586754: {
                    break block19;
                }
            }
            break;
        }
        v9 = v4.filter(v7);
        while (true) {
            if ((v10 = (cfr_temp_1 = GroupManagerExtensions.\u13e8 - (8930387731120123784L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v10 == (10402 ^ -10403)) break;
            v10 = 13437 ^ 1662482778;
        }
        return v9.count();
    }

    public static boolean LessThanCountOnMap(GroupManager groupManager, int mapId, long x) {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (8148492076443833252L >>> "\u0000\u0000".length())) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == (0x6028 ^ 0xFFFF9FD7)) break;
            l2 = 0x2C72 ^ 0xAF15F0A3;
        }
        return (GroupManagerExtensions.countGroupMembersOnMap(groupManager, mapId) < x ? 0x76DC ^ 0x76DD : 0x401D ^ 0x401D) != 0;
    }

    public static boolean HasGroup(GroupManager groupManager) {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x30CL ^ 0x5BA714F7D031B577L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x5728 ^ 0xFFFFA8D7)) break;
            l2 = 0x63F2 ^ 0xE775CCBC;
        }
        List<GroupMember> list = GroupManagerExtensions.groupMembers(groupManager);
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = \u13e8 - (0x5B78L ^ 0x4D5981F7BAB78AAFL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l3 == (0x20AC ^ 0xFFFFDF53)) break;
            l3 = 0x741D ^ 0xD50EB166;
        }
        return (long)list.size() > 0L >>> "\u0000\u0000".length() ? "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length() : "".length() >>> "\u0000\u0000".length();
    }

    private static /* synthetic */ boolean lambda$countGroupMembersOnMap$0(int mapId, GroupMember member) {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x7707L ^ 0x6C976139C686E55AL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == (0x3FAA ^ 0xFFFFC055)) break;
            l2 = 0x27A3 ^ 0xA33E61C9;
        }
        return member.mapId == mapId ? "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length() : "".length() >>> "\u0000\u0000".length();
    }
}

