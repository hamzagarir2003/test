/*
 * Decompiled with CFR 0.152.
 */
package com.tawaret.tawaplugin.utils.ScheduledActionManager;

import com.tawaret.tawaplugin.utils.ScheduledActionManager.IAction;

public interface IScheduledAction
extends IAction {
    public long getScheduledAtMs();
}

