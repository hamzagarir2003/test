/*
 * Decompiled with CFR 0.152.
 */
package com.tawaret.tawaplugin.utils.ScheduledActionManager;

import com.tawaret.tawaplugin.utils.ScheduledActionManager.IAction;
import com.tawaret.tawaplugin.utils.ScheduledActionManager.IScheduledAction;
import com.tawaret.tawaplugin.utils.ScheduledActionManager.IScheduledActionManager;
import com.tawaret.tawaplugin.utils.ScheduledActionManager.ScheduledAction;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class ScheduledActionManager
implements IScheduledActionManager {
    private final List<IScheduledAction> scheduledActions;
    private final Lock lock;
    static long \u13e8 = -9026651391989480396L;

    /*
     * Unable to fully structure code
     */
    public ScheduledActionManager() {
        while (true) {
            if ((v0 = (cfr_temp_0 = ScheduledActionManager.\u13e8 - (11125L ^ -6931646171314999834L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (30021 ^ -30022)) break;
            v0 = 1007416448 >>> "\u0000\u0000".length();
        }
        super();
        while (true) {
            if ((v1 = (cfr_temp_1 = ScheduledActionManager.\u13e8 - (22468L ^ 3471038593868254200L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v1 == (30877 ^ -30878)) break;
            v1 = 3064 ^ 542754308;
        }
        while (true) {
            if ((v2 = (cfr_temp_2 = ScheduledActionManager.\u13e8 - (30359L ^ -1187147713370756114L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v2 == (28745 ^ -28746)) break;
            v2 = 11004 ^ 470315767;
        }
        v3 = new ArrayList<IScheduledAction>();
        while (true) {
            if ((v4 = (cfr_temp_3 = ScheduledActionManager.\u13e8 - (3152L ^ 8435588656946278632L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v4 == (27940 ^ -27941)) break;
            v4 = 29593 ^ -873784518;
        }
        this.scheduledActions = v3;
        v5 = ScheduledActionManager.\u13e8;
        if (true) ** GOTO lbl28
        block14: while (true) {
            v5 = v6 / (2422L ^ -5267062112635691785L);
lbl28:
            // 2 sources

            switch ((int)v5) {
                case -1051344452: {
                    v6 = 21366L ^ 3852954724387246593L;
                    continue block14;
                }
                case -167490520: {
                    v6 = 22020L ^ 7111069718742121162L;
                    continue block14;
                }
                case 1563329588: {
                    break block14;
                }
            }
            break;
        }
        v7 = ScheduledActionManager.\u13e8;
        if (true) ** GOTO lbl41
        block15: while (true) {
            v7 = v8 / (14697L ^ -3121056699203320196L);
lbl41:
            // 2 sources

            switch ((int)v7) {
                case -396192404: {
                    v8 = 18188L ^ -8549722702897622449L;
                    continue block15;
                }
                case 1563329588: {
                    break block15;
                }
                case 1971373494: {
                    v8 = 5220L ^ -5844479000841607647L;
                    continue block15;
                }
            }
            break;
        }
        v9 = new ReentrantLock();
        while (true) {
            if ((v10 = (cfr_temp_4 = ScheduledActionManager.\u13e8 - (6625L ^ 6532524073585741368L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v10 == (30761 ^ -30762)) break;
            v10 = -244889820 >>> "\u0000\u0000".length();
        }
        this.lock = v9;
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public void add(long msFromNow, IAction action) {
        v0 = ScheduledActionManager.\u13e8;
        if (true) ** GOTO lbl5
        block31: while (true) {
            v0 = v1 / (29761L ^ -9105111790025103810L);
lbl5:
            // 2 sources

            switch ((int)v0) {
                case -531801503: {
                    v1 = 23921L ^ -7494818178510616192L;
                    continue block31;
                }
                case 167911405: {
                    v1 = 3239L ^ -137948636776448344L;
                    continue block31;
                }
                case 1563329588: {
                    break block31;
                }
            }
            break;
        }
        v2 = ScheduledActionManager.\u13e8;
        if (true) ** GOTO lbl18
        block32: while (true) {
            v2 = v3 / (-5490123902559827532L >>> "\u0000\u0000".length());
lbl18:
            // 2 sources

            switch ((int)v2) {
                case 528991523: {
                    v3 = 17873L ^ -3211352376996715921L;
                    continue block32;
                }
                case 1202322102: {
                    v3 = 7700L ^ 5413362799821125705L;
                    continue block32;
                }
                case 1563329588: {
                    break block32;
                }
            }
            break;
        }
        this.lock.lock();
        v4 = ScheduledActionManager.\u13e8;
        if (true) ** GOTO lbl32
        block33: while (true) {
            v4 = v5 / (581L ^ 6102648416360875736L);
lbl32:
            // 2 sources

            switch ((int)v4) {
                case -645721541: {
                    v5 = 8031130267384253860L >>> "\u0000\u0000".length();
                    continue block33;
                }
                case 1038129642: {
                    v5 = 31539L ^ -5191525987378637698L;
                    continue block33;
                }
                case 1563329588: {
                    break block33;
                }
            }
            break;
        }
        while (true) {
            if ((v6 = (cfr_temp_0 = ScheduledActionManager.\u13e8 - (10619L ^ -8536059728843013599L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v6 == (22731 ^ -22732)) break;
            v6 = 9518 ^ -625888068;
        }
        while (true) {
            if ((v7 = (cfr_temp_1 = ScheduledActionManager.\u13e8 - (676L ^ 1104313735998391556L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v7 == (3369 ^ -3370)) break;
            v7 = 4651 ^ 1694839057;
        }
        v8 = System.currentTimeMillis() + msFromNow;
        v9 = ScheduledActionManager.\u13e8;
        if (true) ** GOTO lbl56
        block36: while (true) {
            v9 = v10 / (13674L ^ -6081171517201322050L);
lbl56:
            // 2 sources

            switch ((int)v9) {
                case -1678827603: {
                    v10 = 21016L ^ -2233421267350930558L;
                    continue block36;
                }
                case -674214213: {
                    v10 = 18358L ^ 2878013248237738374L;
                    continue block36;
                }
                case 1389981187: {
                    v10 = 18687L ^ 5712582017035010082L;
                    continue block36;
                }
                case 1563329588: {
                    break block36;
                }
            }
            break;
        }
        v11 = new ScheduledAction(action, v8);
        v12 = ScheduledActionManager.\u13e8;
        if (true) ** GOTO lbl73
        block37: while (true) {
            v12 = v13 / (25579L ^ -1944542460569764933L);
lbl73:
            // 2 sources

            switch ((int)v12) {
                case -538857413: {
                    v13 = 22379L ^ -5674331446250177845L;
                    continue block37;
                }
                case -105051401: {
                    v13 = 27853L ^ 9040179487830634090L;
                    continue block37;
                }
                case 1563329588: {
                    break block37;
                }
            }
            break;
        }
        this.scheduledActions.add(v11);
        v14 = ScheduledActionManager.\u13e8;
        if (true) ** GOTO lbl88
        block38: while (true) {
            v14 = v15 / (3768L ^ 8663436846040771690L);
lbl88:
            // 2 sources

            switch ((int)v14) {
                case -2030226699: {
                    v15 = -1153729218198109848L >>> "\u0000\u0000".length();
                    continue block38;
                }
                case 269579412: {
                    v15 = 22024L ^ -770641433032677273L;
                    continue block38;
                }
                case 1563329588: {
                    break block38;
                }
            }
            break;
        }
        while (true) {
            if ((v16 = (cfr_temp_2 = ScheduledActionManager.\u13e8 - (7902909130389660088L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v16 == (11274 ^ -11275)) break;
            v16 = 14180 ^ -566893760;
        }
        this.lock.unlock();
    }

    @Override
    public void add(IAction action) {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x23E5L ^ 0x69F7558AE9C5F7F9L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0xAF8 ^ 0xFFFFF507)) break;
            l2 = -1838925404 >>> "\u0000\u0000".length();
        }
        this.add(0x313L ^ 0x313L, action);
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public void check() {
        v0 = ScheduledActionManager.\u13e8;
        if (true) ** GOTO lbl5
        block83: while (true) {
            v0 = v1 / (967L ^ -1648678145480921995L);
lbl5:
            // 2 sources

            switch ((int)v0) {
                case -1447415867: {
                    v1 = 2027L ^ -2232367980362268969L;
                    continue block83;
                }
                case -1099493506: {
                    v1 = 21395L ^ 8160780521428690365L;
                    continue block83;
                }
                case 1563329588: {
                    break block83;
                }
            }
            break;
        }
        while (true) {
            if ((v2 = (cfr_temp_0 = ScheduledActionManager.\u13e8 - (17087L ^ 2003480655150597285L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v2 == (14667 ^ -14668)) break;
            v2 = 763 ^ 1493085627;
        }
        this.lock.lock();
        v3 = ScheduledActionManager.\u13e8;
        if (true) ** GOTO lbl24
        block85: while (true) {
            v3 = (32579L ^ 7406116414068800316L) / (25074L ^ 8987354028986565736L);
lbl24:
            // 2 sources

            switch ((int)v3) {
                case 1563329588: {
                    break block85;
                }
                case 1806506967: {
                    continue block85;
                }
            }
            break;
        }
        while (true) {
            if ((v4 = (cfr_temp_1 = ScheduledActionManager.\u13e8 - (11076L ^ 3121039907803849122L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v4 == (30926 ^ -30927)) break;
            v4 = 16912 ^ -1562148336;
        }
        while (true) {
            if ((v5 = (cfr_temp_2 = ScheduledActionManager.\u13e8 - (-429602578755714212L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v5 == (2465 ^ -2466)) break;
            v5 = 10196 ^ 1183083322;
        }
        scheduledActionsCpy = new ArrayList<IScheduledAction>(this.scheduledActions);
        v6 = ScheduledActionManager.\u13e8;
        if (true) ** GOTO lbl44
        block88: while (true) {
            v6 = v7 / (13450L ^ 2237239448836224174L);
lbl44:
            // 2 sources

            switch ((int)v6) {
                case -478399417: {
                    v7 = 5780L ^ -1032684738307938851L;
                    continue block88;
                }
                case 876142590: {
                    v7 = 3364L ^ -5169393367948837830L;
                    continue block88;
                }
                case 1563329588: {
                    break block88;
                }
            }
            break;
        }
        v8 = ScheduledActionManager.\u13e8;
        if (true) ** GOTO lbl57
        block89: while (true) {
            v8 = v9 / (12361L ^ 3056839901395255223L);
lbl57:
            // 2 sources

            switch ((int)v8) {
                case 670539923: {
                    v9 = 3851879406801676232L >>> "\u0000\u0000".length();
                    continue block89;
                }
                case 822360238: {
                    v9 = 31408L ^ -4335692012046646534L;
                    continue block89;
                }
                case 1563329588: {
                    break block89;
                }
                case 1863117483: {
                    v9 = 22150L ^ -4021379299124760815L;
                    continue block89;
                }
            }
            break;
        }
        this.lock.unlock();
        while (true) {
            if ((v10 = (cfr_temp_3 = ScheduledActionManager.\u13e8 - (27578L ^ -1924286715271930100L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v10 == (29484 ^ -29485)) break;
            v10 = 22782 ^ -1319837944;
        }
        if (scheduledActionsCpy.isEmpty()) {
            return;
        }
        v11 = ScheduledActionManager.\u13e8;
        if (true) ** GOTO lbl81
        block91: while (true) {
            v11 = v12 / (2163L ^ -7173874532258696834L);
lbl81:
            // 2 sources

            switch ((int)v11) {
                case 338632616: {
                    v12 = 141L ^ 2339899022157248334L;
                    continue block91;
                }
                case 1563329588: {
                    break block91;
                }
                case 1749776501: {
                    v12 = -4970612860403443244L >>> "\u0000\u0000".length();
                    continue block91;
                }
            }
            break;
        }
        msNow = System.currentTimeMillis();
        v13 = ScheduledActionManager.\u13e8;
        if (true) ** GOTO lbl95
        block92: while (true) {
            v13 = v14 / (28851L ^ -7835124053173714256L);
lbl95:
            // 2 sources

            switch ((int)v13) {
                case -1683655333: {
                    v14 = 3808L ^ 1848515618675995521L;
                    continue block92;
                }
                case -1497789379: {
                    v14 = 20778L ^ 4775962612557621506L;
                    continue block92;
                }
                case 1319933884: {
                    v14 = 4790L ^ -4011807603932142914L;
                    continue block92;
                }
                case 1563329588: {
                    break block92;
                }
            }
            break;
        }
        v15 = ScheduledActionManager.\u13e8;
        if (true) ** GOTO lbl111
        block93: while (true) {
            v15 = v16 / (16136L ^ 5472870214241611146L);
lbl111:
            // 2 sources

            switch ((int)v15) {
                case -1179397566: {
                    v16 = 4898L ^ -2260611513446923176L;
                    continue block93;
                }
                case -565011916: {
                    v16 = 9932L ^ 3260920967081478912L;
                    continue block93;
                }
                case 1561124674: {
                    v16 = 441L ^ -9147572029854473068L;
                    continue block93;
                }
                case 1563329588: {
                    break block93;
                }
            }
            break;
        }
        futureActions = new ArrayList<IScheduledAction>();
        atleastOneRun = 9896 ^ 9896;
        while (true) {
            if ((v17 = (cfr_temp_4 = ScheduledActionManager.\u13e8 - (20962L ^ 277183434620425218L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v17 == (14917 ^ -14918)) break;
            v17 = 22286 ^ -1351537864;
        }
        var6_5 = scheduledActionsCpy.iterator();
        block95: while (true) {
            block119: {
                block118: {
                    v18 = ScheduledActionManager.\u13e8;
                    if (true) ** GOTO lbl136
                    block96: while (true) {
                        v18 = (11514L ^ 2708005620552774576L) / (-1802943439303882172L >>> "\u0000\u0000".length());
lbl136:
                        // 2 sources

                        switch ((int)v18) {
                            case -1215982952: {
                                continue block96;
                            }
                            case 1563329588: {
                                break block96;
                            }
                        }
                        break;
                    }
                    if (!var6_5.hasNext()) break;
                    v19 = ScheduledActionManager.\u13e8;
                    if (true) ** GOTO lbl146
                    block97: while (true) {
                        v19 = v20 / (26322L ^ 828607549398172357L);
lbl146:
                        // 2 sources

                        switch ((int)v19) {
                            case -559529550: {
                                v20 = 859L ^ -8607356451831941365L;
                                continue block97;
                            }
                            case 1286966975: {
                                v20 = 19425L ^ -6626145188138495804L;
                                continue block97;
                            }
                            case 1563329588: {
                                break block97;
                            }
                            case 1620286300: {
                                v20 = 15342L ^ -2722432752281297119L;
                                continue block97;
                            }
                        }
                        break;
                    }
                    scheduledAction = (IScheduledAction)var6_5.next();
                    while (true) {
                        if ((v21 = (cfr_temp_5 = ScheduledActionManager.\u13e8 - (7259800570483290556L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                        if (v21 == (30925 ^ -30926)) break;
                        v21 = 24333 ^ -457618450;
                    }
                    if (msNow < scheduledAction.getScheduledAtMs()) break block119;
                    try {
                        while (true) {
                            if ((v22 = (cfr_temp_6 = ScheduledActionManager.\u13e8 - (20194L ^ 8511805271712795918L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                            if (v22 == (32732 ^ -32733)) {
                                scheduledAction.run();
                                break block118;
                            }
                            v22 = 14175 ^ -240886371;
                        }
                    }
                    catch (Exception e) {
                        v23 = ScheduledActionManager.\u13e8;
                        if (true) ** GOTO lbl178
                    }
                    block100: while (true) {
                        v23 = v24 / (23429L ^ 9157752383966283591L);
lbl178:
                        // 2 sources

                        switch ((int)v23) {
                            case -1814671189: {
                                v24 = 25178L ^ 6520166451657734552L;
                                continue block100;
                            }
                            case -344395941: {
                                v24 = 23542L ^ 94295407108607404L;
                                continue block100;
                            }
                            case -173932838: {
                                v24 = 6843L ^ 5664396432037927124L;
                                continue block100;
                            }
                            case 1563329588: {
                                break block100;
                            }
                        }
                        break;
                    }
                    while (true) {
                        if ((v25 = (cfr_temp_7 = ScheduledActionManager.\u13e8 - (11683L ^ 7824883238481903863L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                        if (v25 == (4019 ^ -4020)) {
                            e.printStackTrace(System.out);
                            break;
                        }
                        v25 = 8346 ^ 124597288;
                    }
                }
                atleastOneRun = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
                continue;
            }
            while (true) {
                if ((v26 = (cfr_temp_8 = ScheduledActionManager.\u13e8 - (26093L ^ -8731915064705127527L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                if (v26 == (18574 ^ -18575)) {
                    futureActions.add(scheduledAction);
                    continue block95;
                }
                v26 = 22155 ^ 1233054128;
            }
            break;
        }
        if (atleastOneRun == 0) {
            return;
        }
        v27 = ScheduledActionManager.\u13e8;
        if (true) ** GOTO lbl214
        block103: while (true) {
            v27 = v28 / (24983L ^ 5151865564911406580L);
lbl214:
            // 2 sources

            switch ((int)v27) {
                case 200008647: {
                    v28 = 1338352733316163196L >>> "\u0000\u0000".length();
                    continue block103;
                }
                case 959458592: {
                    v28 = 19049L ^ 6527622103953983371L;
                    continue block103;
                }
                case 1563329588: {
                    break block103;
                }
                case 1777526109: {
                    v28 = 30036L ^ -2115556775563065617L;
                    continue block103;
                }
            }
            break;
        }
        while (true) {
            if ((v29 = (cfr_temp_9 = ScheduledActionManager.\u13e8 - (1488L ^ 7784314881590677336L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
            if (v29 == (19665 ^ -19666)) break;
            v29 = 1443 ^ 1769276695;
        }
        this.lock.lock();
        while (true) {
            if ((v30 = (cfr_temp_10 = ScheduledActionManager.\u13e8 - (15189L ^ 744806922481389475L)) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
            if (v30 == (3943 ^ -3944)) break;
            v30 = 1515 ^ -960310508;
        }
        v31 = "".length() >>> "\u0000\u0000".length();
        v32 = ScheduledActionManager.\u13e8;
        if (true) ** GOTO lbl242
        block106: while (true) {
            v32 = v33 / (6458L ^ -3684207618017287401L);
lbl242:
            // 2 sources

            switch ((int)v32) {
                case -1469410666: {
                    v33 = 22082L ^ -7146439711454115875L;
                    continue block106;
                }
                case -663580911: {
                    v33 = 5974636313421068452L >>> "\u0000\u0000".length();
                    continue block106;
                }
                case 1563329588: {
                    break block106;
                }
            }
            break;
        }
        v34 = scheduledActionsCpy.size();
        v35 = ScheduledActionManager.\u13e8;
        if (true) ** GOTO lbl256
        block107: while (true) {
            v35 = v36 / (7192L ^ -380626254308522809L);
lbl256:
            // 2 sources

            switch ((int)v35) {
                case -350094311: {
                    v36 = 479L ^ 3436771360471040411L;
                    continue block107;
                }
                case 1563329588: {
                    break block107;
                }
                case 2066054258: {
                    v36 = 8792L ^ -2488119041697797947L;
                    continue block107;
                }
            }
            break;
        }
        v37 = this.scheduledActions.subList(v31, v34);
        v38 = ScheduledActionManager.\u13e8;
        if (true) ** GOTO lbl270
        block108: while (true) {
            v38 = v39 / (4567L ^ -6855080787341232338L);
lbl270:
            // 2 sources

            switch ((int)v38) {
                case -623070765: {
                    v39 = 664L ^ 8946758768839008876L;
                    continue block108;
                }
                case 830479624: {
                    v39 = 20384L ^ 6034664601534805098L;
                    continue block108;
                }
                case 1563329588: {
                    break block108;
                }
                case 1929144932: {
                    v39 = 27391L ^ 5654532836402537753L;
                    continue block108;
                }
            }
            break;
        }
        v37.clear();
        while (true) {
            if ((v40 = (cfr_temp_11 = ScheduledActionManager.\u13e8 - (-6594320996468126380L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
            if (v40 == (4402 ^ -4403)) break;
            v40 = 11578 ^ -1642372105;
        }
        v41 = ScheduledActionManager.\u13e8;
        if (true) ** GOTO lbl292
        block110: while (true) {
            v41 = v42 / (43565930252127216L >>> "\u0000\u0000".length());
lbl292:
            // 2 sources

            switch ((int)v41) {
                case -2105792303: {
                    v42 = 24234L ^ -1481513851863079058L;
                    continue block110;
                }
                case -1800753857: {
                    v42 = 18201L ^ 1616068525781079649L;
                    continue block110;
                }
                case -905624743: {
                    v42 = 7777L ^ 1400668586744621793L;
                    continue block110;
                }
                case 1563329588: {
                    break block110;
                }
            }
            break;
        }
        this.scheduledActions.addAll(futureActions);
        while (true) {
            if ((v43 = (cfr_temp_12 = ScheduledActionManager.\u13e8 - (2128L ^ -1645782303406777223L)) == 0L ? 0 : (cfr_temp_12 < 0L ? -1 : 1)) == false) continue;
            if (v43 == (3720 ^ -3721)) break;
            v43 = 32480 ^ -917470607;
        }
        while (true) {
            if ((v44 = (cfr_temp_13 = ScheduledActionManager.\u13e8 - (30967L ^ 5796996267651656514L)) == 0L ? 0 : (cfr_temp_13 < 0L ? -1 : 1)) == false) continue;
            if (v44 == (31202 ^ -31203)) break;
            v44 = 30457 ^ -509232185;
        }
        this.lock.unlock();
    }
}

