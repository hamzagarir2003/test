/*
 * Decompiled with CFR 0.152.
 */
package com.tawaret.tawaplugin.utils.ScheduledActionManager;

import com.tawaret.tawaplugin.utils.ScheduledActionManager.IAction;

public interface IScheduledActionManager {
    public void add(long var1, IAction var3);

    public void add(IAction var1);

    public void check();
}

