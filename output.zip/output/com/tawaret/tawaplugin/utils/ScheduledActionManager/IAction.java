/*
 * Decompiled with CFR 0.152.
 */
package com.tawaret.tawaplugin.utils.ScheduledActionManager;

public interface IAction {
    public void run();
}

