/*
 * Decompiled with CFR 0.152.
 */
package com.tawaret.tawaplugin.utils.ScheduledActionManager;

import com.tawaret.tawaplugin.utils.ScheduledActionManager.IAction;
import com.tawaret.tawaplugin.utils.ScheduledActionManager.IScheduledAction;

public class ScheduledAction
implements IScheduledAction {
    private final IAction action;
    private final long scheduledAtMs;
    static long \u13e8 = 7185081676886901811L;

    /*
     * Enabled aggressive block sorting
     */
    public ScheduledAction(IAction action, long scheduledAtMs) {
        long l = \u13e8;
        block4: while (true) {
            switch ((int)l) {
                case -1996291021: {
                    break block4;
                }
                case -1519847040: {
                    l = (0xC93L ^ 0x89183EE1A0C713E3L) / (0x3D5CL ^ 0xFBC04EC49F38EF79L);
                    continue block4;
                }
            }
            break;
        }
        while (true) {
            long l2;
            long l3;
            if ((l3 = (l2 = \u13e8 - (0x40BEL ^ 0x75DE798040F11995L)) == 0L ? 0 : (l2 < 0L ? -1 : 1)) == false) continue;
            if (l3 == (0x6484 ^ 0xFFFF9B7B)) break;
            l3 = 0x48E5 ^ 0xE65C7B64;
        }
        this.action = action;
        while (true) {
            long l4;
            long l5;
            if ((l5 = (l4 = \u13e8 - (0xA57L ^ 0xEB46A49B48576540L)) == 0L ? 0 : (l4 < 0L ? -1 : 1)) == false) continue;
            if (l5 == (0x5BA3 ^ 0x5BA2)) {
                this.scheduledAtMs = scheduledAtMs;
                return;
            }
            l5 = 531194600 >>> "\u0000\u0000".length();
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    @Override
    public long getScheduledAtMs() {
        long l = \u13e8;
        boolean bl = true;
        block6: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x5D8CL ^ 0x34D13B8DFBA943DCL);
            }
            switch ((int)l) {
                case -1996291021: {
                    return this.scheduledAtMs;
                }
                case -966379539: {
                    l2 = 0x1EDL ^ 0xB3CD3DF89344B1B6L;
                    continue block6;
                }
                case -103768013: {
                    l2 = 5120653893497541388L >>> "\u0000\u0000".length();
                    continue block6;
                }
                case -8961946: {
                    l2 = 0x6702L ^ 0x7CE44561250455A9L;
                    continue block6;
                }
            }
            break;
        }
        return this.scheduledAtMs;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    @Override
    public void run() {
        long l = \u13e8;
        boolean bl = true;
        block6: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x2AFFL ^ 0x5714A68BF7107ED4L);
            }
            switch ((int)l) {
                case -1996291021: {
                    break block6;
                }
                case -367334988: {
                    l2 = 0x5B74L ^ 0x4A172A292E1E21E5L;
                    continue block6;
                }
                case 489932637: {
                    l2 = 5897819589754568904L >>> "\u0000\u0000".length();
                    continue block6;
                }
                case 1564598772: {
                    l2 = 0x3C8DL ^ 0x4C5BB9E2602EFC3AL;
                    continue block6;
                }
            }
            break;
        }
        while (true) {
            long l3;
            long l4;
            if ((l4 = (l3 = \u13e8 - (1882053101681130288L >>> "\u0000\u0000".length())) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l4 == (0x5F70 ^ 0x5F71)) {
                this.action.run();
                return;
            }
            l4 = 0x546F ^ 0x42AFAE9B;
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public int hashCode() {
        long l = \u13e8;
        block10: while (true) {
            switch ((int)l) {
                case -1996291021: {
                    break block10;
                }
                case 1169517261: {
                    l = (0x5271L ^ 0x57DAF1D17EA21C80L) / (0x5F21L ^ 0xB3B85A4BD8BA15E7L);
                    continue block10;
                }
            }
            break;
        }
        long l2 = \u13e8;
        boolean bl = true;
        block11: while (true) {
            long l3;
            if (!bl || (bl = false) || !true) {
                l2 = l3 / (0x78EDL ^ 0xD239372B7A5E840EL);
            }
            switch ((int)l2) {
                case -2065261160: {
                    l3 = 0x4BE7L ^ 0xEE79FE5029FBD1EAL;
                    continue block11;
                }
                case -1996291021: {
                    break block11;
                }
                case -407158132: {
                    l3 = 0x163CL ^ 0xBD82F0B875845EFCL;
                    continue block11;
                }
                case 285613688: {
                    l3 = 0x3F1L ^ 0x8F8BAE0F80FEA530L;
                    continue block11;
                }
            }
            break;
        }
        int n = this.action.hashCode();
        while (true) {
            long l4;
            long l5;
            if ((l5 = (l4 = \u13e8 - (0x19B6L ^ 0xDC1F41C8A1563DD3L)) == 0L ? 0 : (l4 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l5 == (0x265E ^ 0x265F)) {
                return n + (int)this.scheduledAtMs;
            }
            l5 = 0x70AD ^ 0xB05C38DE;
        }
    }

    /*
     * Unable to fully structure code
     */
    public boolean equals(Object obj) {
        block18: {
            if (!(obj instanceof ScheduledAction)) break block18;
            other = (ScheduledAction)obj;
            v0 = ScheduledAction.\u13e8;
            if (true) ** GOTO lbl7
            block10: while (true) {
                v0 = v1 / (11656L ^ 5836987765839352675L);
lbl7:
                // 2 sources

                switch ((int)v0) {
                    case -1996291021: {
                        break block10;
                    }
                    case 797177444: {
                        v1 = 11509L ^ 5928982502972922411L;
                        continue block10;
                    }
                    case 1036949509: {
                        v1 = 6187L ^ 7385419363178042250L;
                        continue block10;
                    }
                }
                break;
            }
            v2 = other.action;
            while (true) {
                if ((v3 = (cfr_temp_0 = ScheduledAction.\u13e8 - (2416L ^ -7765961259855038574L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v3 == (21802 ^ 21803)) break;
                v3 = 30930 ^ -1460462434;
            }
            if (v2 != this.action) ** GOTO lbl-1000
            while (true) {
                if ((v4 = (cfr_temp_1 = ScheduledAction.\u13e8 - (26005L ^ 6606290604860332799L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v4 == (29493 ^ 29492)) break;
                v4 = 27324 ^ 27600368;
            }
            v5 = other.scheduledAtMs;
            v6 = ScheduledAction.\u13e8;
            if (true) ** GOTO lbl33
            block13: while (true) {
                v6 = v7 / (12119L ^ 1779478766485483974L);
lbl33:
                // 2 sources

                switch ((int)v6) {
                    case -1996291021: {
                        break block13;
                    }
                    case 1160071001: {
                        v7 = 17467L ^ -9165515066235353321L;
                        continue block13;
                    }
                    case 1166236665: {
                        v7 = 20352L ^ 5307111319629047782L;
                        continue block13;
                    }
                }
                break;
            }
            if (v5 == this.scheduledAtMs) {
                v8 = 14668 ^ 14669;
            } else lbl-1000:
            // 2 sources

            {
                v8 = 31280 ^ 31280;
            }
            return (boolean)v8;
        }
        if (obj instanceof IAction) {
            while (true) {
                if ((v9 = (cfr_temp_2 = ScheduledAction.\u13e8 - (28432L ^ 435745488055539138L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v9 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v9 = 27204 ^ 1644421205;
            }
            return obj == this.action ? "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length() : "".length() >>> "\u0000\u0000".length();
        }
        return "".length() >>> "\u0000\u0000".length();
    }
}

