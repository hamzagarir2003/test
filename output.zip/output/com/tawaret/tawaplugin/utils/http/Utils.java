/*
 * Decompiled with CFR 0.152.
 */
package com.tawaret.tawaplugin.utils.http;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.List;
import java.util.Map;

public class Utils {
    public static long \u13e8 = 3433470041006675874L;

    public Utils() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x651CL ^ 0xDB1BC354D4661F20L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x25F8 ^ 0x25F9)) break;
            l2 = 0x5981 ^ 0x90F0CF79;
        }
    }

    /*
     * Unable to fully structure code
     */
    public static String FormatParams(List<Map.Entry<String, String>> params) throws UnsupportedEncodingException {
        while (true) {
            if ((v0 = (cfr_temp_0 = Utils.\u13e8 - (7727L ^ 1066084250273774444L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v0 = 30256 ^ -1050861989;
        }
        v1 = Utils.\u13e8;
        if (true) ** GOTO lbl10
        block38: while (true) {
            v1 = v2 / (-5367914403362847928L >>> "\u0000\u0000".length());
lbl10:
            // 2 sources

            switch ((int)v1) {
                case -1658447966: {
                    break block38;
                }
                case -550212609: {
                    v2 = 401L ^ 7686423924731056702L;
                    continue block38;
                }
                case 1767000135: {
                    v2 = 23172L ^ -5322649581658582723L;
                    continue block38;
                }
            }
            break;
        }
        result = new StringBuilder();
        first = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        while (true) {
            if ((v3 = (cfr_temp_1 = Utils.\u13e8 - (22193L ^ -1766292475345899167L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v3 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v3 = 32012 ^ -281017308;
        }
        var3_3 = params.iterator();
        block40: while (true) {
            v4 = Utils.\u13e8;
            if (true) ** GOTO lbl32
            block41: while (true) {
                v4 = v5 / (11578L ^ 7904691990034754284L);
lbl32:
                // 2 sources

                switch ((int)v4) {
                    case -1658447966: {
                        break block41;
                    }
                    case -321950047: {
                        v5 = 5301L ^ -1972744572916002959L;
                        continue block41;
                    }
                    case 1525316991: {
                        v5 = 14762L ^ -2598937803116863337L;
                        continue block41;
                    }
                    case 1662805291: {
                        v5 = 23881L ^ 782954472230328302L;
                        continue block41;
                    }
                }
                break;
            }
            if (!var3_3.hasNext()) break;
            v6 = Utils.\u13e8;
            if (true) ** GOTO lbl49
            block42: while (true) {
                v6 = v7 / (2911L ^ -756072225153360603L);
lbl49:
                // 2 sources

                switch ((int)v6) {
                    case -2095341840: {
                        v7 = 10139L ^ -2866417511053752933L;
                        continue block42;
                    }
                    case -1658447966: {
                        break block42;
                    }
                    case -1601611358: {
                        v7 = 19801L ^ 8096400367169489230L;
                        continue block42;
                    }
                }
                break;
            }
            entry = var3_3.next();
            if (first != 0) {
                first = "".length() >>> "\u0000\u0000".length();
            } else {
                var6_5 = new byte["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
                var6_5[19286 ^ 19286] = 316 >>> "\u0000\u0000".length();
                var6_5[28211 ^ 28211] = 26580 ^ 26610;
                v8 = new String(var6_5);
                while (true) {
                    if ((v9 = (cfr_temp_2 = Utils.\u13e8 - (21760L ^ 7736771730685415077L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                    if (v9 == (31217 ^ -31218)) {
                        result.append(v8);
                        break;
                    }
                    v9 = 10154 ^ -1480282518;
                }
            }
            v10 = Utils.\u13e8;
            if (true) ** GOTO lbl77
            block44: while (true) {
                v10 = (17236L ^ 6726786772854909388L) / (23296L ^ 4664329182714081763L);
lbl77:
                // 2 sources

                switch ((int)v10) {
                    case -1667249261: {
                        continue block44;
                    }
                    case -1658447966: {
                        break block44;
                    }
                }
                break;
            }
            var6_5 = new byte[1440 ^ 1445];
            var6_5[14648 ^ 14649] = "".length() >>> "\u0000\u0000".length();
            var6_5["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 15066 ^ 14990;
            var6_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 24621 ^ 24597;
            var6_5[25790 ^ 25789] = 180 >>> "\u0000\u0000".length();
            var6_5["".length() >>> "\u0000\u0000".length()] = 340 >>> "\u0000\u0000".length();
            var6_5[8189 ^ 8191] = 280 >>> "\u0000\u0000".length();
            v11 = new String(var6_5);
            v12 = Utils.\u13e8;
            if (true) ** GOTO lbl94
            block45: while (true) {
                v12 = v13 / (4082L ^ -759738891494602480L);
lbl94:
                // 2 sources

                switch ((int)v12) {
                    case -1658447966: {
                        break block45;
                    }
                    case -848578708: {
                        v13 = 1574L ^ -7487949151190257006L;
                        continue block45;
                    }
                    case 1238651188: {
                        v13 = 28833L ^ 5471025628564391759L;
                        continue block45;
                    }
                    case 1844886544: {
                        v13 = 15225L ^ -4823257626683105152L;
                        continue block45;
                    }
                }
                break;
            }
            v14 = URLEncoder.encode(entry.getKey(), v11);
            v15 = Utils.\u13e8;
            if (true) ** GOTO lbl111
            block46: while (true) {
                v15 = v16 / (22111L ^ 2367408631783305853L);
lbl111:
                // 2 sources

                switch ((int)v15) {
                    case -1658447966: {
                        break block46;
                    }
                    case -1271789101: {
                        v16 = -1999792570684604120L >>> "\u0000\u0000".length();
                        continue block46;
                    }
                    case 475804755: {
                        v16 = 5331L ^ -6801602634634636282L;
                        continue block46;
                    }
                    case 918755267: {
                        v16 = 25890L ^ 4384690760059403912L;
                        continue block46;
                    }
                }
                break;
            }
            result.append(v14);
            var6_5 = new byte["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
            var6_5["".length() >>> "\u0000\u0000".length()] = 21336 ^ -21282;
            var6_5["".length() >>> "\u0000\u0000".length()] = 244 >>> "\u0000\u0000".length();
            v17 = new String(var6_5);
            while (true) {
                if ((v18 = (cfr_temp_3 = Utils.\u13e8 - (6801L ^ 8575632389146799290L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v18 == (26932 ^ -26933)) break;
                v18 = 3143 ^ -1277365932;
            }
            result.append(v17);
            while (true) {
                if ((v19 = (cfr_temp_4 = Utils.\u13e8 - (31637L ^ -5709781085865786406L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v19 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v19 = 7425 ^ -1266059834;
            }
            var6_5 = new byte["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
            var6_5[7059 ^ 7056] = 5465 ^ -5472;
            var6_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 11959 ^ 11930;
            var6_5[20474 ^ 20475] = 4185 ^ 4109;
            var6_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 280 >>> "\u0000\u0000".length();
            var6_5[22102 ^ 22102] = 340 >>> "\u0000\u0000".length();
            var6_5[18607 ^ 18603] = 224 >>> "\u0000\u0000".length();
            v20 = new String(var6_5);
            while (true) {
                if ((v21 = (cfr_temp_5 = Utils.\u13e8 - (2447L ^ -2269033231085282414L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                if (v21 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v21 = 8421 ^ -419253843;
            }
            v22 = URLEncoder.encode(entry.getValue(), v20);
            while (true) {
                if ((v23 = (cfr_temp_6 = Utils.\u13e8 - (7955L ^ 3834459949749727331L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                if (v23 == (22794 ^ -22795)) {
                    result.append(v22);
                    continue block40;
                }
                v23 = 18123 ^ 350153904;
            }
            break;
        }
        v24 = Utils.\u13e8;
        if (true) ** GOTO lbl165
        block51: while (true) {
            v24 = v25 / (29421L ^ -3625516473161213279L);
lbl165:
            // 2 sources

            switch ((int)v24) {
                case -1658447966: {
                    break block51;
                }
                case -1253087035: {
                    v25 = 22517L ^ -5760819738913408463L;
                    continue block51;
                }
                case -129378129: {
                    v25 = -2778569676504084060L >>> "\u0000\u0000".length();
                    continue block51;
                }
            }
            break;
        }
        return result.toString();
    }
}

