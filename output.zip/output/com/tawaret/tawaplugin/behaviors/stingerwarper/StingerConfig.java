/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.config.types.Num
 *  com.github.manolo8.darkbot.config.types.Option
 *  eu.darkbot.api.config.annotations.Dropdown
 */
package com.tawaret.tawaplugin.behaviors.stingerwarper;

import com.github.manolo8.darkbot.config.types.Num;
import com.github.manolo8.darkbot.config.types.Option;
import com.tawaret.tawaplugin.utils.types.ConfigSupplier;
import eu.darkbot.api.config.annotations.Dropdown;

public class StingerConfig {
    @Option(value="Profile")
    @Dropdown(options=ConfigSupplier.class)
    public String PROFILE_NAME;
    @Option(value="Npc subname (case-insensitive)", description="Empty to disable")
    public String NPC_SUBNAME;
    @Option(value="Max time shooting npc subname (Seconds)", description="-1 for no maximum")
    @Num(min=-1, max=20000, step=10)
    public int MAX_TIME_SHOOTING_STINGER;
    @Option(value="Max time waiting for npc subname (Seconds)", description="-1 for no maximum")
    @Num(min=-1, max=20000, step=10)
    public int MAX_TIME_WAITING_FOR_STINGER;
    @Option(value="Max time on swapped config (Seconds)", description="-1 for no maximum, swap back once time elapsed")
    @Num(min=-1, max=20000, step=10)
    public int MAX_TIME_ON_STINGER_CONFIG;
    @Option(value="Max deaths on swap map", description="0 for infinite")
    @Num(min=0, max=10000, step=1)
    public int MAX_STINGER_MAP_DEATHS;
    static long \u13e8 = -4971071198041604857L;

    /*
     * Unable to fully structure code
     */
    public StingerConfig() {
        v0 = StingerConfig.\u13e8;
        if (true) ** GOTO lbl5
        block15: while (true) {
            v0 = v1 / (21787L ^ -5277899468027280917L);
lbl5:
            // 2 sources

            switch ((int)v0) {
                case -1250590012: {
                    v1 = 6850L ^ -6298543050026527666L;
                    continue block15;
                }
                case -546569571: {
                    v1 = 14543L ^ 2921515575743639640L;
                    continue block15;
                }
                case 1334705415: {
                    break block15;
                }
            }
            break;
        }
        super();
        while (true) {
            if ((v2 = (cfr_temp_0 = StingerConfig.\u13e8 - (28155L ^ 935775734659708395L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v2 == (13626 ^ -13627)) break;
            v2 = 23381 ^ -493672101;
        }
        this.PROFILE_NAME = null;
        var2_1 = new byte["".length() >>> "\u0000\u0000".length()];
        v3 = new String(var2_1);
        while (true) {
            if ((v4 = (cfr_temp_1 = StingerConfig.\u13e8 - (32459L ^ -317648826029505394L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v4 == (3964 ^ -3965)) break;
            v4 = 168 ^ 1351899841;
        }
        this.NPC_SUBNAME = v3;
        while (true) {
            if ((v5 = (cfr_temp_2 = StingerConfig.\u13e8 - (13439L ^ 20614638658099283L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v5 == (21636 ^ -21637)) break;
            v5 = 18309 ^ -196134010;
        }
        this.MAX_TIME_SHOOTING_STINGER = 140 ^ -141;
        v6 = StingerConfig.\u13e8;
        if (true) ** GOTO lbl39
        block19: while (true) {
            v6 = v7 / (32372L ^ -8640247618157824047L);
lbl39:
            // 2 sources

            switch ((int)v6) {
                case 777978071: {
                    v7 = 1424L ^ -3586375594366305378L;
                    continue block19;
                }
                case 1104560223: {
                    v7 = 13135L ^ -5287189758714183496L;
                    continue block19;
                }
                case 1334705415: {
                    break block19;
                }
            }
            break;
        }
        this.MAX_TIME_WAITING_FOR_STINGER = 24911 ^ -24912;
        v8 = StingerConfig.\u13e8;
        if (true) ** GOTO lbl53
        block20: while (true) {
            v8 = v9 / (6522L ^ -5878483984762566581L);
lbl53:
            // 2 sources

            switch ((int)v8) {
                case -1837914343: {
                    v9 = 447428553901709800L >>> "\u0000\u0000".length();
                    continue block20;
                }
                case 1334705415: {
                    break block20;
                }
                case 2132543932: {
                    v9 = 27506L ^ -9192801960617291661L;
                    continue block20;
                }
            }
            break;
        }
        this.MAX_TIME_ON_STINGER_CONFIG = 31986 ^ -31987;
        while (true) {
            if ((v10 = (cfr_temp_3 = StingerConfig.\u13e8 - (19652L ^ -3269902873200179682L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v10 == (22543 ^ -22544)) break;
            v10 = 26401 ^ 1441202478;
        }
        this.MAX_STINGER_MAP_DEATHS = 4908 ^ 4908;
    }
}

