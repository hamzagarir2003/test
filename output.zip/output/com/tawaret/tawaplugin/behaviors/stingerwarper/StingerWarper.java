/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.Main
 *  com.github.manolo8.darkbot.backpage.BackpageManager
 *  com.github.manolo8.darkbot.backpage.HangarManager
 *  com.github.manolo8.darkbot.config.Config
 *  com.github.manolo8.darkbot.config.Config$General
 *  com.github.manolo8.darkbot.config.ConfigManager
 *  com.github.manolo8.darkbot.core.itf.Behaviour
 *  com.github.manolo8.darkbot.core.itf.Configurable
 *  com.github.manolo8.darkbot.core.itf.Module
 *  com.github.manolo8.darkbot.core.manager.HeroManager
 *  com.github.manolo8.darkbot.core.manager.MapManager
 *  com.github.manolo8.darkbot.core.objects.Map
 *  com.github.manolo8.darkbot.modules.DisconnectModule
 *  com.github.manolo8.darkbot.utils.AuthAPI
 *  eu.darkbot.api.PluginAPI
 *  eu.darkbot.api.extensions.ExtraMenus
 *  eu.darkbot.api.managers.BotAPI
 *  eu.darkbot.api.managers.ConfigAPI
 */
package com.tawaret.tawaplugin.behaviors.stingerwarper;

import com.github.manolo8.darkbot.Main;
import com.github.manolo8.darkbot.backpage.BackpageManager;
import com.github.manolo8.darkbot.backpage.HangarManager;
import com.github.manolo8.darkbot.config.Config;
import com.github.manolo8.darkbot.config.ConfigManager;
import com.github.manolo8.darkbot.core.itf.Behaviour;
import com.github.manolo8.darkbot.core.itf.Configurable;
import com.github.manolo8.darkbot.core.itf.Module;
import com.github.manolo8.darkbot.core.manager.HeroManager;
import com.github.manolo8.darkbot.core.manager.MapManager;
import com.github.manolo8.darkbot.core.objects.Map;
import com.github.manolo8.darkbot.modules.DisconnectModule;
import com.github.manolo8.darkbot.utils.AuthAPI;
import com.tawaret.tawaplugin.behaviors.stingerwarper.HangarChangeConfig;
import com.tawaret.tawaplugin.behaviors.stingerwarper.PersistentState;
import com.tawaret.tawaplugin.behaviors.stingerwarper.StingerWarperConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.MapCycleModule;
import com.tawaret.tawaplugin.features.maptravellers.pathfinders.PersistantStoragePathFinder;
import com.tawaret.tawaplugin.features.maptravellers.pathfinders.PersistentStorage;
import com.tawaret.tawaplugin.logging.ILoggable;
import com.tawaret.tawaplugin.services.licenseVerifiers.ITwLicenseVerifier;
import com.tawaret.tawaplugin.services.licenseVerifiers.TwLicenseVerifierFactory;
import com.tawaret.tawaplugin.utils.Api.ApiExtensions;
import com.tawaret.tawaplugin.utils.Backpage.DoShop;
import com.tawaret.tawaplugin.utils.ExtraMenuExtensions;
import com.tawaret.tawaplugin.utils.time.TimeUtils;
import eu.darkbot.api.PluginAPI;
import eu.darkbot.api.extensions.ExtraMenus;
import eu.darkbot.api.managers.BotAPI;
import eu.darkbot.api.managers.ConfigAPI;
import java.util.Collection;
import java.util.concurrent.TimeUnit;
import javax.swing.JComponent;
import javax.swing.JLabel;

public class StingerWarper
implements Behaviour,
Configurable<StingerWarperConfig>,
ExtraMenus,
ILoggable {
    private final PluginAPI pluginApi;
    private final ConfigAPI configAPI;
    private final BotAPI botAPI;
    private StingerWarperConfig config;
    private HeroManager hero;
    private HangarManager hangarManager;
    private BackpageManager backpage;
    private Main main;
    private MapManager mapManager;
    private final ITwLicenseVerifier licenseVerifier;
    private boolean __cachedHasLicense;
    private int manualResetCount;
    private static long LAST_STINGER_CHECK_MS;
    private Long startStingerMapTimerMs;
    private Long startMaxShootingStingerTimerMs;
    private String switchBackReason;
    private Integer lastKnownDeaths;
    private int seenDeaths;
    private Long mapCycleSwapTimer;
    private boolean useNpcSpawnTimer;
    private Long startShootingStingerTimeMs;
    private boolean isSwitchingHangarsToStinger;
    private boolean isSwitchingHangarsBackToOriginal;
    private long lastFixRefreshBugTimeStampMs;
    private Object hangarSwitcher;
    private Integer lastNpcId;
    private boolean isAttackingNpcOfInterest;
    private boolean updateHangarList;
    private long nextCheck;
    private long lastLabelUpdate;
    private final JLabel statusLabel;
    private String status;
    private final JLabel nextCheckLabel;
    private final JLabel timeWaitingForStingerLabel;
    private final JLabel timeShootingStingerLabel;
    private final JLabel stingerDeathCountLabel;
    private final JLabel stingerMapMaxTimeLabel;
    protected static long \u13e8 = 2387294027437307716L;

    /*
     * Unable to fully structure code
     */
    public StingerWarper(PluginAPI pluginAPI, ConfigAPI configAPI, BotAPI botAPI) {
        while (true) {
            if ((v0 = (cfr_temp_0 = StingerWarper.\u13e8 - (16346L ^ -1293163998527498300L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (6063 ^ 6062)) break;
            v0 = 5569 ^ 2081861069;
        }
        super();
        v1 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl11
        block156: while (true) {
            v1 = v2 / (30604L ^ -6453147795605298360L);
lbl11:
            // 2 sources

            switch ((int)v1) {
                case -548282585: {
                    v2 = 8334L ^ 4989181360289894643L;
                    continue block156;
                }
                case -514923364: {
                    v2 = 9777L ^ 9085646028467664421L;
                    continue block156;
                }
                case -3147964: {
                    break block156;
                }
                case 912021137: {
                    v2 = 13265L ^ 2458167034921554489L;
                    continue block156;
                }
            }
            break;
        }
        this.__cachedHasLicense = 16734 ^ 16734;
        v3 = "".length() >>> "\u0000\u0000".length();
        v4 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl29
        block157: while (true) {
            v4 = v5 / (16518L ^ -1967358587345861133L);
lbl29:
            // 2 sources

            switch ((int)v4) {
                case -65896525: {
                    v5 = 32552L ^ 8652403858379690823L;
                    continue block157;
                }
                case -3147964: {
                    break block157;
                }
                case 871617141: {
                    v5 = 1493L ^ -1933171079379015406L;
                    continue block157;
                }
                case 1043563759: {
                    v5 = 3433L ^ -3040191800276360903L;
                    continue block157;
                }
            }
            break;
        }
        this.manualResetCount = v3;
        while (true) {
            if ((v6 = (cfr_temp_1 = StingerWarper.\u13e8 - (2635L ^ 8874188701337566743L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v6 == (25865 ^ -25866)) break;
            v6 = 18372 ^ 193046114;
        }
        this.startStingerMapTimerMs = null;
        v7 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl52
        block159: while (true) {
            v7 = (27386L ^ 3008891988686639450L) / (14733L ^ -154200016841963734L);
lbl52:
            // 2 sources

            switch ((int)v7) {
                case -1650548442: {
                    continue block159;
                }
                case -3147964: {
                    break block159;
                }
            }
            break;
        }
        this.startMaxShootingStingerTimerMs = null;
        var5_4 = new byte["".length() >>> "\u0000\u0000".length()];
        v8 = new String(var5_4);
        while (true) {
            if ((v9 = (cfr_temp_2 = StingerWarper.\u13e8 - (21429L ^ 7752323083993692324L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v9 == (14482 ^ -14483)) break;
            v9 = 14341 ^ -975899946;
        }
        this.switchBackReason = v8;
        while (true) {
            if ((v10 = (cfr_temp_3 = StingerWarper.\u13e8 - (15469L ^ -3356488365188395067L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v10 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v10 = 4430 ^ 308317459;
        }
        this.lastKnownDeaths = null;
        v11 = "".length() >>> "\u0000\u0000".length();
        v12 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl77
        block162: while (true) {
            v12 = v13 / (16280L ^ -3213455193741534215L);
lbl77:
            // 2 sources

            switch ((int)v12) {
                case -1597464817: {
                    v13 = 11781L ^ 8422421468667315507L;
                    continue block162;
                }
                case -3147964: {
                    break block162;
                }
                case 753466552: {
                    v13 = 9872L ^ 1520699813104837505L;
                    continue block162;
                }
            }
            break;
        }
        this.seenDeaths = v11;
        while (true) {
            if ((v14 = (cfr_temp_4 = StingerWarper.\u13e8 - (17405L ^ 7454261453397560738L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v14 == (25073 ^ -25074)) break;
            v14 = 16472 ^ 413522941;
        }
        this.mapCycleSwapTimer = null;
        v15 = "".length() >>> "\u0000\u0000".length();
        v16 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl98
        block164: while (true) {
            v16 = v17 / (8718L ^ 5531940298019479451L);
lbl98:
            // 2 sources

            switch ((int)v16) {
                case -1914355059: {
                    v17 = 1672L ^ -4200100457951788490L;
                    continue block164;
                }
                case -843697868: {
                    v17 = 14753L ^ -4239500152691043794L;
                    continue block164;
                }
                case -3147964: {
                    break block164;
                }
                case 73416756: {
                    v17 = 25653L ^ -5737315930195915839L;
                    continue block164;
                }
            }
            break;
        }
        this.useNpcSpawnTimer = v15;
        v18 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl115
        block165: while (true) {
            v18 = (11247L ^ 6175025869122934834L) / (8966L ^ 1787337271541251204L);
lbl115:
            // 2 sources

            switch ((int)v18) {
                case -933997223: {
                    continue block165;
                }
                case -3147964: {
                    break block165;
                }
            }
            break;
        }
        this.startShootingStingerTimeMs = null;
        v19 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl125
        block166: while (true) {
            v19 = (22584L ^ -2511175147384850032L) / (4694L ^ 7749200234118452082L);
lbl125:
            // 2 sources

            switch ((int)v19) {
                case -1345168704: {
                    continue block166;
                }
                case -3147964: {
                    break block166;
                }
            }
            break;
        }
        this.isSwitchingHangarsToStinger = 10959 ^ 10959;
        v20 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl135
        block167: while (true) {
            v20 = v21 / (11519L ^ -6636375959730744343L);
lbl135:
            // 2 sources

            switch ((int)v20) {
                case -2065939849: {
                    v21 = 3547L ^ -7400532206999512265L;
                    continue block167;
                }
                case -3147964: {
                    break block167;
                }
                case 1406684630: {
                    v21 = 28580L ^ -4149087102269150755L;
                    continue block167;
                }
            }
            break;
        }
        this.isSwitchingHangarsBackToOriginal = 6438 ^ 6438;
        v22 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl149
        block168: while (true) {
            v22 = v23 / (32511L ^ 8889410706502983651L);
lbl149:
            // 2 sources

            switch ((int)v22) {
                case -1720071589: {
                    v23 = 17620L ^ 6285606037400236804L;
                    continue block168;
                }
                case -1325002840: {
                    v23 = 21289L ^ 5104136351975521893L;
                    continue block168;
                }
                case -3147964: {
                    break block168;
                }
            }
            break;
        }
        v24 = System.currentTimeMillis();
        v25 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl163
        block169: while (true) {
            v25 = v26 / (67L ^ -5088279393292198001L);
lbl163:
            // 2 sources

            switch ((int)v25) {
                case -1356458652: {
                    v26 = 9380L ^ -4315350040246950243L;
                    continue block169;
                }
                case -3147964: {
                    break block169;
                }
                case 761644605: {
                    v26 = 29107L ^ 1372040931802743779L;
                    continue block169;
                }
            }
            break;
        }
        this.lastFixRefreshBugTimeStampMs = v24;
        v27 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl177
        block170: while (true) {
            v27 = v28 / (11565L ^ 733496581584826904L);
lbl177:
            // 2 sources

            switch ((int)v27) {
                case -12733696: {
                    v28 = 6830L ^ -3084043684063387999L;
                    continue block170;
                }
                case -3147964: {
                    break block170;
                }
                case 635034224: {
                    v28 = 18791L ^ 5932886501825515939L;
                    continue block170;
                }
            }
            break;
        }
        this.hangarSwitcher = null;
        while (true) {
            if ((v29 = (cfr_temp_5 = StingerWarper.\u13e8 - (13345L ^ 8623172951519520886L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
            if (v29 == (26275 ^ -26276)) break;
            v29 = 29811 ^ 2063630436;
        }
        this.lastNpcId = null;
        v30 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl197
        block172: while (true) {
            v30 = (5562892656419574748L >>> "\u0000\u0000".length()) / (19669L ^ -8163490518585463315L);
lbl197:
            // 2 sources

            switch ((int)v30) {
                case -624328264: {
                    continue block172;
                }
                case -3147964: {
                    break block172;
                }
            }
            break;
        }
        this.isAttackingNpcOfInterest = 21456 ^ 21456;
        v31 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        v32 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl208
        block173: while (true) {
            v32 = (3193L ^ 8643615806794970096L) / (15323L ^ 3282375705836963748L);
lbl208:
            // 2 sources

            switch ((int)v32) {
                case -374779485: {
                    continue block173;
                }
                case -3147964: {
                    break block173;
                }
            }
            break;
        }
        this.updateHangarList = v31;
        v33 = 0L >>> "\u0000\u0000".length();
        while (true) {
            if ((v34 = (cfr_temp_6 = StingerWarper.\u13e8 - (-1985088566668736008L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
            if (v34 == (20494 ^ -20495)) break;
            v34 = 27876 ^ -934470105;
        }
        this.nextCheck = v33;
        v35 = 0L >>> "\u0000\u0000".length();
        v36 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl226
        block175: while (true) {
            v36 = (8006L ^ 815001427485763728L) / (15165L ^ 4668600151670447790L);
lbl226:
            // 2 sources

            switch ((int)v36) {
                case -1083803917: {
                    continue block175;
                }
                case -3147964: {
                    break block175;
                }
            }
            break;
        }
        this.lastLabelUpdate = v35;
        v37 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl236
        block176: while (true) {
            v37 = (15390L ^ -7333335638650194052L) / (19426L ^ 4843640682863471667L);
lbl236:
            // 2 sources

            switch ((int)v37) {
                case -3147964: {
                    break block176;
                }
                case 1836326718: {
                    continue block176;
                }
            }
            break;
        }
        v38 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl245
        block177: while (true) {
            v38 = (8119L ^ 2475185093944318804L) / (30856L ^ 534593743913547146L);
lbl245:
            // 2 sources

            switch ((int)v38) {
                case -3147964: {
                    break block177;
                }
                case 1166902732: {
                    continue block177;
                }
            }
            break;
        }
        v39 = new JLabel();
        v40 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl255
        block178: while (true) {
            v40 = v41 / (19281L ^ -4552351954044922085L);
lbl255:
            // 2 sources

            switch ((int)v40) {
                case -1078850318: {
                    v41 = 8398L ^ -8111431464140037451L;
                    continue block178;
                }
                case -3147964: {
                    break block178;
                }
                case 465785226: {
                    v41 = 7738130999000134580L >>> "\u0000\u0000".length();
                    continue block178;
                }
                case 666029145: {
                    v41 = 10382L ^ -7232400805113353390L;
                    continue block178;
                }
            }
            break;
        }
        this.statusLabel = v39;
        var5_4 = new byte["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
        var5_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 21147 ^ 21183;
        var5_4[29566 ^ 29564] = 27553 ^ 27599;
        var5_4["".length() >>> "\u0000\u0000".length()] = 312 >>> "\u0000\u0000".length();
        var5_4[15076 ^ 15077] = 444 >>> "\u0000\u0000".length();
        var5_4[13725 ^ 13726] = 404 >>> "\u0000\u0000".length();
        v42 = new String(var5_4);
        v43 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl279
        block179: while (true) {
            v43 = v44 / (27352L ^ -500732268133631366L);
lbl279:
            // 2 sources

            switch ((int)v43) {
                case -91042537: {
                    v44 = 4563L ^ 1807561343788833909L;
                    continue block179;
                }
                case -3147964: {
                    break block179;
                }
                case 1943578437: {
                    v44 = 4242L ^ -3465532097531644368L;
                    continue block179;
                }
            }
            break;
        }
        this.status = v42;
        v45 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl293
        block180: while (true) {
            v45 = v46 / (24947L ^ -2347755366293713218L);
lbl293:
            // 2 sources

            switch ((int)v45) {
                case -3147964: {
                    break block180;
                }
                case 2073036223: {
                    v46 = 16332L ^ 3638789044053025548L;
                    continue block180;
                }
                case 2087614411: {
                    v46 = 28619L ^ 2239616515915309924L;
                    continue block180;
                }
            }
            break;
        }
        v47 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl306
        block181: while (true) {
            v47 = v48 / (15607L ^ 8707588989633729480L);
lbl306:
            // 2 sources

            switch ((int)v47) {
                case -429803040: {
                    v48 = 4219L ^ -3621448850756780520L;
                    continue block181;
                }
                case -3147964: {
                    break block181;
                }
                case 529876209: {
                    v48 = 1287L ^ 7074812159884387097L;
                    continue block181;
                }
                case 1456776042: {
                    v48 = 19040L ^ 7447350854130845996L;
                    continue block181;
                }
            }
            break;
        }
        v49 = new JLabel();
        v50 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl323
        block182: while (true) {
            v50 = v51 / (21419L ^ 9197020178883112141L);
lbl323:
            // 2 sources

            switch ((int)v50) {
                case -1278534324: {
                    v51 = 23039L ^ -4698973929197687511L;
                    continue block182;
                }
                case -3147964: {
                    break block182;
                }
                case 1021128224: {
                    v51 = 13833L ^ 51181005580361289L;
                    continue block182;
                }
            }
            break;
        }
        this.nextCheckLabel = v49;
        while (true) {
            if ((v52 = (cfr_temp_7 = StingerWarper.\u13e8 - (2849884463184873312L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
            if (v52 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v52 = 18718 ^ -1607839600;
        }
        v53 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl342
        block184: while (true) {
            v53 = v54 / (4674L ^ -9086731603390477070L);
lbl342:
            // 2 sources

            switch ((int)v53) {
                case -781697800: {
                    v54 = 14132L ^ -3911869042337098379L;
                    continue block184;
                }
                case -3147964: {
                    break block184;
                }
                case 1120891499: {
                    v54 = 2049L ^ 5751672927987160496L;
                    continue block184;
                }
            }
            break;
        }
        v55 = new JLabel();
        v56 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl356
        block185: while (true) {
            v56 = (30072L ^ -4852927713879328687L) / (32748L ^ -1256429667883672671L);
lbl356:
            // 2 sources

            switch ((int)v56) {
                case -3147964: {
                    break block185;
                }
                case 756254798: {
                    continue block185;
                }
            }
            break;
        }
        this.timeWaitingForStingerLabel = v55;
        while (true) {
            if ((v57 = (cfr_temp_8 = StingerWarper.\u13e8 - (27038L ^ -3202077478873835670L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
            if (v57 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v57 = 26473 ^ 212041309;
        }
        v58 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl371
        block187: while (true) {
            v58 = v59 / (30183L ^ 3067284013664707451L);
lbl371:
            // 2 sources

            switch ((int)v58) {
                case -1225340211: {
                    v59 = 21734L ^ 1973479961644071733L;
                    continue block187;
                }
                case -3147964: {
                    break block187;
                }
                case 491104204: {
                    v59 = 19400L ^ -8206916083292782977L;
                    continue block187;
                }
            }
            break;
        }
        v60 = new JLabel();
        while (true) {
            if ((v61 = (cfr_temp_9 = StingerWarper.\u13e8 - (20773L ^ -5643684602649787754L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
            if (v61 == (16565 ^ 16564)) break;
            v61 = 14463 ^ 892607195;
        }
        this.timeShootingStingerLabel = v60;
        v62 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl391
        block189: while (true) {
            v62 = v63 / (1101L ^ 871887008554579835L);
lbl391:
            // 2 sources

            switch ((int)v62) {
                case -751195266: {
                    v63 = 12375L ^ 2971657284415448838L;
                    continue block189;
                }
                case -276852971: {
                    v63 = -2451395641423059332L >>> "\u0000\u0000".length();
                    continue block189;
                }
                case -3147964: {
                    break block189;
                }
                case 438195851: {
                    v63 = 7612L ^ -5590775164639045657L;
                    continue block189;
                }
            }
            break;
        }
        v64 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl407
        block190: while (true) {
            v64 = v65 / (934L ^ -6381403779444394436L);
lbl407:
            // 2 sources

            switch ((int)v64) {
                case -636852124: {
                    v65 = 30670L ^ -744079960036207782L;
                    continue block190;
                }
                case -504547361: {
                    v65 = 24568L ^ 9045146080397902655L;
                    continue block190;
                }
                case -3147964: {
                    break block190;
                }
            }
            break;
        }
        v66 = new JLabel();
        while (true) {
            if ((v67 = (cfr_temp_10 = StingerWarper.\u13e8 - (19750L ^ -3068713837660925692L)) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
            if (v67 == (816 ^ 817)) break;
            v67 = 1510 ^ -868266760;
        }
        this.stingerDeathCountLabel = v66;
        v68 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl427
        block192: while (true) {
            v68 = v69 / (28121L ^ 3893734018008329823L);
lbl427:
            // 2 sources

            switch ((int)v68) {
                case -3147964: {
                    break block192;
                }
                case 698459911: {
                    v69 = 13570L ^ -16190197579880133L;
                    continue block192;
                }
                case 1063448305: {
                    v69 = 11974L ^ -919037080578953998L;
                    continue block192;
                }
                case 1182066165: {
                    v69 = 2117L ^ -4857638843015951997L;
                    continue block192;
                }
            }
            break;
        }
        while (true) {
            if ((v70 = (cfr_temp_11 = StingerWarper.\u13e8 - (9872L ^ -7663660078037090630L)) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
            if (v70 == (29971 ^ 29970)) break;
            v70 = 29632 ^ 598465120;
        }
        v71 = new JLabel();
        while (true) {
            if ((v72 = (cfr_temp_12 = StingerWarper.\u13e8 - (16L ^ 8708233303283642337L)) == 0L ? 0 : (cfr_temp_12 < 0L ? -1 : 1)) == false) continue;
            if (v72 == (12741 ^ -12742)) break;
            v72 = 9515 ^ -1202432610;
        }
        this.stingerMapMaxTimeLabel = v71;
        v73 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl455
        block195: while (true) {
            v73 = v74 / (27970L ^ -4295923001914452079L);
lbl455:
            // 2 sources

            switch ((int)v73) {
                case -1118858417: {
                    v74 = 27346L ^ 7079114083731876333L;
                    continue block195;
                }
                case -552705298: {
                    v74 = 24283L ^ 7003723805809938743L;
                    continue block195;
                }
                case -3147964: {
                    break block195;
                }
                case 1488755722: {
                    v74 = 13479L ^ -3740646083379044902L;
                    continue block195;
                }
            }
            break;
        }
        this.pluginApi = pluginAPI;
        v75 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl472
        block196: while (true) {
            v75 = (21625L ^ -3049074214301791136L) / (15507L ^ 6946341118666524920L);
lbl472:
            // 2 sources

            switch ((int)v75) {
                case -3147964: {
                    break block196;
                }
                case 298838267: {
                    continue block196;
                }
            }
            break;
        }
        this.configAPI = configAPI;
        v76 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl482
        block197: while (true) {
            v76 = v77 / (11821L ^ -526930632226685537L);
lbl482:
            // 2 sources

            switch ((int)v76) {
                case -1697129787: {
                    v77 = 29166L ^ -7815852938220150492L;
                    continue block197;
                }
                case -56950189: {
                    v77 = 11150L ^ -5917652566010504161L;
                    continue block197;
                }
                case -3147964: {
                    break block197;
                }
                case 1856532331: {
                    v77 = 11629L ^ 5687413253966025816L;
                    continue block197;
                }
            }
            break;
        }
        this.botAPI = botAPI;
        while (true) {
            if ((v78 = (cfr_temp_13 = StingerWarper.\u13e8 - (6966L ^ 1315643408191864412L)) == 0L ? 0 : (cfr_temp_13 < 0L ? -1 : 1)) == false) continue;
            if (v78 == (22822 ^ 22823)) break;
            v78 = 21019 ^ 1521396727;
        }
        v79 = TwLicenseVerifierFactory.CompilationMode();
        v80 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl505
        block199: while (true) {
            v80 = v81 / (28385L ^ 7471760019742238286L);
lbl505:
            // 2 sources

            switch ((int)v80) {
                case -1274795120: {
                    v81 = 23707L ^ -271023355991336966L;
                    continue block199;
                }
                case -3147964: {
                    break block199;
                }
                case 598712453: {
                    v81 = 10400L ^ -3204880191189890948L;
                    continue block199;
                }
                case 781322086: {
                    v81 = 2488L ^ 1919721813685014259L;
                    continue block199;
                }
            }
            break;
        }
        this.licenseVerifier = v79;
    }

    public void setConfig(StingerWarperConfig stingerWarperConfig) {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x2A4CL ^ 0xCEABF4CA75BF7956L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l2 = 0x1658 ^ 0x7ABDD838;
        }
        this.config = stingerWarperConfig;
    }

    /*
     * Unable to fully structure code
     */
    private boolean validConfig() {
        while (true) {
            if ((v0 = (cfr_temp_0 = StingerWarper.\u13e8 - (23638L ^ -7164641716366295989L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v0 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v0 = 23695 ^ -1209327621;
        }
        v1 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl11
        block16: while (true) {
            v1 = v2 / (-5542153217299168456L >>> "\u0000\u0000".length());
lbl11:
            // 2 sources

            switch ((int)v1) {
                case -3147964: {
                    break block16;
                }
                case 1901836705: {
                    v2 = 9970L ^ 4642529314141293069L;
                    continue block16;
                }
                case 1988402827: {
                    v2 = 1688272840165113284L >>> "\u0000\u0000".length();
                    continue block16;
                }
            }
            break;
        }
        if (this.config._AFTER_STINGER_CONFIG == null) ** GOTO lbl-1000
        v3 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl25
        block17: while (true) {
            v3 = v4 / (-8620090459844396892L >>> "\u0000\u0000".length());
lbl25:
            // 2 sources

            switch ((int)v3) {
                case -2035137853: {
                    v4 = 19150L ^ 8652115948904796063L;
                    continue block17;
                }
                case -3147964: {
                    break block17;
                }
                case 1336512333: {
                    v4 = 6554L ^ -1631661871724319934L;
                    continue block17;
                }
            }
            break;
        }
        while (true) {
            if ((v5 = (cfr_temp_1 = StingerWarper.\u13e8 - (13585L ^ -3720440904259651687L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v5 == (26730 ^ 26731)) break;
            v5 = 12113 ^ 1926686648;
        }
        if (this.config._STINGER_CONFIG == null) ** GOTO lbl-1000
        v6 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl45
        block19: while (true) {
            v6 = v7 / (27370L ^ -5090302573451860833L);
lbl45:
            // 2 sources

            switch ((int)v6) {
                case -1205105850: {
                    v7 = 1862L ^ -8818485273783803407L;
                    continue block19;
                }
                case -3147964: {
                    break block19;
                }
                case 529474906: {
                    v7 = 11992L ^ 6149009223081752234L;
                    continue block19;
                }
            }
            break;
        }
        if (this.validHangarIdConfig()) {
            v8 = 15708 ^ 15709;
        } else lbl-1000:
        // 3 sources

        {
            v8 = 23000 ^ 23000;
        }
        return (boolean)v8;
    }

    /*
     * Unable to fully structure code
     */
    private boolean validHangarIdConfig() {
        block122: {
            v0 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl5
            block89: while (true) {
                v0 = (3439L ^ 5076740343277619878L) / (31886L ^ -7620981543904815247L);
lbl5:
                // 2 sources

                switch ((int)v0) {
                    case -71169503: {
                        continue block89;
                    }
                    case -3147964: {
                        break block89;
                    }
                }
                break;
            }
            v1 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl14
            block90: while (true) {
                v1 = v2 / (-6397581190396140268L >>> "\u0000\u0000".length());
lbl14:
                // 2 sources

                switch ((int)v1) {
                    case -1471462620: {
                        v2 = 9282L ^ 9223364499310742943L;
                        continue block90;
                    }
                    case -774198815: {
                        v2 = 3939L ^ -620226960589333858L;
                        continue block90;
                    }
                    case -3147964: {
                        break block90;
                    }
                    case 2133339602: {
                        v2 = 31691L ^ 7670415853021228012L;
                        continue block90;
                    }
                }
                break;
            }
            v3 = this.config.HANGAR_CHANGE_CONFIG;
            while (true) {
                if ((v4 = (cfr_temp_0 = StingerWarper.\u13e8 - (892L ^ 6216080156337252813L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v4 == (30355 ^ -30356)) break;
                v4 = 2934 ^ -1629892428;
            }
            if (!v3.USE_HANGAR_CHANGE) break block122;
            v5 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl37
            block92: while (true) {
                v5 = v6 / (19234L ^ -3212710740910971080L);
lbl37:
                // 2 sources

                switch ((int)v5) {
                    case -1665612166: {
                        v6 = 1775L ^ -3261305725531615987L;
                        continue block92;
                    }
                    case -3147964: {
                        break block92;
                    }
                    case 1761274026: {
                        v6 = 13149L ^ -4031257575020362165L;
                        continue block92;
                    }
                    case 1969630966: {
                        v6 = 5595L ^ -3700006690282682030L;
                        continue block92;
                    }
                }
                break;
            }
            while (true) {
                if ((v7 = (cfr_temp_1 = StingerWarper.\u13e8 - (827600206918092100L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v7 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v7 = 16690 ^ -2007912254;
            }
            v8 = this.config.HANGAR_CHANGE_CONFIG;
            v9 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl59
            block94: while (true) {
                v9 = v10 / (26941L ^ -7292559317883554538L);
lbl59:
                // 2 sources

                switch ((int)v9) {
                    case -2067250286: {
                        v10 = 19357L ^ -7782044834255811562L;
                        continue block94;
                    }
                    case -3147964: {
                        break block94;
                    }
                    case 838225094: {
                        v10 = 31248L ^ -8143604078960191395L;
                        continue block94;
                    }
                }
                break;
            }
            if (v8.AFTER_STINGER_HANGAR_ID == null) ** GOTO lbl-1000
            while (true) {
                if ((v11 = (cfr_temp_2 = StingerWarper.\u13e8 - (16730L ^ 6745010266698541014L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v11 == (16897 ^ -16898)) break;
                v11 = 502 ^ 1425409056;
            }
            v12 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl78
            block96: while (true) {
                v12 = v13 / (16532L ^ 5697313131744140284L);
lbl78:
                // 2 sources

                switch ((int)v12) {
                    case -2038289940: {
                        v13 = 8901113385274224492L >>> "\u0000\u0000".length();
                        continue block96;
                    }
                    case -1814547291: {
                        v13 = 6008015512863553152L >>> "\u0000\u0000".length();
                        continue block96;
                    }
                    case -1290128930: {
                        v13 = 18869L ^ -3596248222172179945L;
                        continue block96;
                    }
                    case -3147964: {
                        break block96;
                    }
                }
                break;
            }
            v14 = this.config.HANGAR_CHANGE_CONFIG;
            v15 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl95
            block97: while (true) {
                v15 = v16 / (21782L ^ 4936044480847625740L);
lbl95:
                // 2 sources

                switch ((int)v15) {
                    case -1158646280: {
                        v16 = 32457L ^ 8786362136711641960L;
                        continue block97;
                    }
                    case -1114010808: {
                        v16 = 15018L ^ -3129651116323060735L;
                        continue block97;
                    }
                    case -3147964: {
                        break block97;
                    }
                    case 556239731: {
                        v16 = 2132L ^ -2849948119647343461L;
                        continue block97;
                    }
                }
                break;
            }
            v17 = v14.AFTER_STINGER_HANGAR_ID;
            while (true) {
                if ((v18 = (cfr_temp_3 = StingerWarper.\u13e8 - (4936514584297076348L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v18 == (24819 ^ 24818)) break;
                v18 = 7646 ^ 1479492893;
            }
            if (v17 <= 0) ** GOTO lbl-1000
            v19 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl118
            block99: while (true) {
                v19 = (7580L ^ -5386413228143858536L) / (27262L ^ -4632259788700800906L);
lbl118:
                // 2 sources

                switch ((int)v19) {
                    case -3147964: {
                        break block99;
                    }
                    case 862806240: {
                        continue block99;
                    }
                }
                break;
            }
            v20 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl127
            block100: while (true) {
                v20 = (15600L ^ 8990232856848716541L) / (6737L ^ -8806939736290270467L);
lbl127:
                // 2 sources

                switch ((int)v20) {
                    case -3147964: {
                        break block100;
                    }
                    case 324427849: {
                        continue block100;
                    }
                }
                break;
            }
            v21 = this.config.HANGAR_CHANGE_CONFIG;
            while (true) {
                if ((v22 = (cfr_temp_4 = StingerWarper.\u13e8 - (17403L ^ 5484548237802007696L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v22 == (6941 ^ -6942)) break;
                v22 = 20037 ^ -1379968493;
            }
            if (v21.STINGER_HANGAR_ID == null) ** GOTO lbl-1000
            while (true) {
                if ((v23 = (cfr_temp_5 = StingerWarper.\u13e8 - (-257932655438635600L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                if (v23 == (25732 ^ -25733)) break;
                v23 = 13816 ^ 1958658365;
            }
            v24 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl148
            block103: while (true) {
                v24 = (620L ^ 3653897384601152489L) / (5924L ^ 7593011583260947020L);
lbl148:
                // 2 sources

                switch ((int)v24) {
                    case -3147964: {
                        break block103;
                    }
                    case 242739396: {
                        continue block103;
                    }
                }
                break;
            }
            v25 = this.config.HANGAR_CHANGE_CONFIG;
            while (true) {
                if ((v26 = (cfr_temp_6 = StingerWarper.\u13e8 - (3602389010973135516L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                if (v26 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v26 = 15035 ^ 609510995;
            }
            v27 = v25.STINGER_HANGAR_ID;
            v28 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl164
            block105: while (true) {
                v28 = v29 / (1389L ^ -1338504666047768145L);
lbl164:
                // 2 sources

                switch ((int)v28) {
                    case -182844550: {
                        v29 = 22767L ^ 6791474714464990530L;
                        continue block105;
                    }
                    case -3147964: {
                        break block105;
                    }
                    case 337772202: {
                        v29 = 27529L ^ -2562023556986316276L;
                        continue block105;
                    }
                    case 1712358152: {
                        v29 = 13350L ^ -4118223918555428105L;
                        continue block105;
                    }
                }
                break;
            }
            if (v27 <= 0) ** GOTO lbl-1000
            while (true) {
                if ((v30 = (cfr_temp_7 = StingerWarper.\u13e8 - (6154411962708443076L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                if (v30 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v30 = 6935 ^ 439763520;
            }
            v31 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl186
            block107: while (true) {
                v31 = (29228L ^ -7890226672674938431L) / (2205L ^ 6615718425003238430L);
lbl186:
                // 2 sources

                switch ((int)v31) {
                    case -639858686: {
                        continue block107;
                    }
                    case -3147964: {
                        break block107;
                    }
                }
                break;
            }
            v32 = this.config.HANGAR_CHANGE_CONFIG;
            v33 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl196
            block108: while (true) {
                v33 = v34 / (13680L ^ 5740883615656437602L);
lbl196:
                // 2 sources

                switch ((int)v33) {
                    case -24630648: {
                        v34 = 29648L ^ 1312477559569766415L;
                        continue block108;
                    }
                    case -3147964: {
                        break block108;
                    }
                    case 1648550589: {
                        v34 = 13728L ^ -4429483794834391660L;
                        continue block108;
                    }
                }
                break;
            }
            v35 = v32.AFTER_STINGER_HANGAR_ID;
            while (true) {
                if ((v36 = (cfr_temp_8 = StingerWarper.\u13e8 - (13135L ^ -7534347442473679089L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                if (v36 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v36 = 28271 ^ -1593541156;
            }
            while (true) {
                if ((v37 = (cfr_temp_9 = StingerWarper.\u13e8 - (21977L ^ 6321749054703054391L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
                if (v37 == (5086 ^ -5087)) break;
                v37 = 6558 ^ -875426983;
            }
            v38 = this.config.HANGAR_CHANGE_CONFIG;
            v39 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl221
            block111: while (true) {
                v39 = v40 / (17074L ^ -3016608015273973875L);
lbl221:
                // 2 sources

                switch ((int)v39) {
                    case -3147964: {
                        break block111;
                    }
                    case 431559250: {
                        v40 = 14562L ^ -3473697913369757006L;
                        continue block111;
                    }
                    case 979991842: {
                        v40 = 19852L ^ 6600243897669650818L;
                        continue block111;
                    }
                }
                break;
            }
            v41 = v38.STINGER_HANGAR_ID;
            while (true) {
                if ((v42 = (cfr_temp_10 = StingerWarper.\u13e8 - (8352312254811386552L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
                if (v42 == (2483 ^ 2482)) break;
                v42 = -1426038540 >>> "\u0000\u0000".length();
            }
            if (v35.equals(v41)) ** GOTO lbl-1000
            v43 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl241
            block113: while (true) {
                v43 = (8803L ^ -297447454897549391L) / (4343L ^ -2316926588034538376L);
lbl241:
                // 2 sources

                switch ((int)v43) {
                    case -186789750: {
                        continue block113;
                    }
                    case -3147964: {
                        break block113;
                    }
                }
                break;
            }
            v44 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl250
            block114: while (true) {
                v44 = v45 / (3350L ^ -2224145075340665597L);
lbl250:
                // 2 sources

                switch ((int)v44) {
                    case -2022970671: {
                        v45 = 30166L ^ 955824542567344431L;
                        continue block114;
                    }
                    case -3147964: {
                        break block114;
                    }
                    case 96905776: {
                        v45 = 27329L ^ -506325695271266227L;
                        continue block114;
                    }
                    case 1359080787: {
                        v45 = 7510L ^ 8845416736846236153L;
                        continue block114;
                    }
                }
                break;
            }
            v46 = this.config._AFTER_STINGER_CONFIG;
            while (true) {
                if ((v47 = (cfr_temp_11 = StingerWarper.\u13e8 - (5332L ^ 3849595671322450929L)) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
                if (v47 == (29824 ^ -29825)) break;
                v47 = -411083084 >>> "\u0000\u0000".length();
            }
            v48 = v46.PROFILE_NAME;
            v49 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl273
            block116: while (true) {
                v49 = v50 / (10505L ^ 4858397048811115140L);
lbl273:
                // 2 sources

                switch ((int)v49) {
                    case -3147964: {
                        break block116;
                    }
                    case 174622838: {
                        v50 = 18725L ^ -7719839598578462010L;
                        continue block116;
                    }
                    case 649688298: {
                        v50 = 9852L ^ -7485915211423297631L;
                        continue block116;
                    }
                    case 2121453240: {
                        v50 = 62L ^ 2516216053410054305L;
                        continue block116;
                    }
                }
                break;
            }
            v51 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl289
            block117: while (true) {
                v51 = (26445L ^ 2624679152226622305L) / (21175L ^ 8554013462110895480L);
lbl289:
                // 2 sources

                switch ((int)v51) {
                    case -521153644: {
                        continue block117;
                    }
                    case -3147964: {
                        break block117;
                    }
                }
                break;
            }
            v52 = this.config._STINGER_CONFIG;
            while (true) {
                if ((v53 = (cfr_temp_12 = StingerWarper.\u13e8 - (15808L ^ 7981566180342596433L)) == 0L ? 0 : (cfr_temp_12 < 0L ? -1 : 1)) == false) continue;
                if (v53 == (23709 ^ -23710)) break;
                v53 = 31112 ^ -1978148995;
            }
            v54 = v52.PROFILE_NAME;
            v55 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl305
            block119: while (true) {
                v55 = (24481L ^ -5689549029491057783L) / (7157L ^ 12521328781499871L);
lbl305:
                // 2 sources

                switch ((int)v55) {
                    case -3147964: {
                        break block119;
                    }
                    case 823151266: {
                        continue block119;
                    }
                }
                break;
            }
            if (!v48.equals(v54)) {
                v56 = 4824 ^ 4825;
            } else lbl-1000:
            // 6 sources

            {
                v56 = "".length() >>> "\u0000\u0000".length();
            }
            return (boolean)v56;
        }
        return (boolean)(8409 ^ 8408);
    }

    /*
     * Unable to fully structure code
     */
    private boolean validDontCheckConfig() {
        while (true) {
            if ((v0 = (cfr_temp_0 = StingerWarper.\u13e8 - (18538L ^ -7386897789286922897L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (8017 ^ 8016)) break;
            v0 = 2002 ^ 1977297570;
        }
        v1 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl10
        block21: while (true) {
            v1 = v2 / (7097L ^ 2859996489888587406L);
lbl10:
            // 2 sources

            switch ((int)v1) {
                case -1267501722: {
                    v2 = 20644L ^ 6503752065034020672L;
                    continue block21;
                }
                case -3147964: {
                    break block21;
                }
                case 2022366654: {
                    v2 = 27572L ^ -4151269550730232332L;
                    continue block21;
                }
            }
            break;
        }
        v3 = this.config._AFTER_STINGER_CONFIG;
        v4 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl24
        block22: while (true) {
            v4 = v5 / (23198L ^ -6273413243135412902L);
lbl24:
            // 2 sources

            switch ((int)v4) {
                case -3147964: {
                    break block22;
                }
                case 299995912: {
                    v5 = 2949L ^ 1462342814854075639L;
                    continue block22;
                }
                case 2043757376: {
                    v5 = 7433L ^ -5022538414799233238L;
                    continue block22;
                }
            }
            break;
        }
        v6 = v3.DONT_CHECK;
        while (true) {
            if ((v7 = (cfr_temp_1 = StingerWarper.\u13e8 - (1903L ^ -413779650650793614L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v7 == (9429 ^ 9428)) break;
            v7 = 1513108104 >>> "\u0000\u0000".length();
        }
        if (v6.END_HOUR < 0) ** GOTO lbl-1000
        while (true) {
            if ((v8 = (cfr_temp_2 = StingerWarper.\u13e8 - (24961L ^ 6369462389629889230L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v8 == (6503 ^ -6504)) break;
            v8 = 17407 ^ -423787649;
        }
        v9 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl49
        block25: while (true) {
            v9 = v10 / (18957L ^ -1718359309031897401L);
lbl49:
            // 2 sources

            switch ((int)v9) {
                case -1541565673: {
                    v10 = 12193L ^ -2274275691311862377L;
                    continue block25;
                }
                case -461537449: {
                    v10 = 8801882025860714980L >>> "\u0000\u0000".length();
                    continue block25;
                }
                case -3147964: {
                    break block25;
                }
                case 244176325: {
                    v10 = 26465L ^ 5110741971434424016L;
                    continue block25;
                }
            }
            break;
        }
        v11 = this.config._AFTER_STINGER_CONFIG;
        while (true) {
            if ((v12 = (cfr_temp_3 = StingerWarper.\u13e8 - (7088L ^ 2152362256131970137L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v12 == (21893 ^ 21892)) break;
            v12 = 20253 ^ -74964140;
        }
        v13 = v11.DONT_CHECK;
        v14 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl72
        block27: while (true) {
            v14 = (14085L ^ -2876976689404257282L) / (10733L ^ 5081515204006364717L);
lbl72:
            // 2 sources

            switch ((int)v14) {
                case -87713872: {
                    continue block27;
                }
                case -3147964: {
                    break block27;
                }
            }
            break;
        }
        if (v13.START_HOUR >= 0) {
            v15 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        } else lbl-1000:
        // 2 sources

        {
            v15 = "".length() >>> "\u0000\u0000".length();
        }
        return (boolean)v15;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private void resetProfileStates() {
        long l = \u13e8;
        boolean bl = true;
        block10: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x301BL ^ 0xB41C86F375F0D507L);
            }
            switch ((int)l) {
                case -1851415751: {
                    l2 = 0x52A0L ^ 0xFC5ECCB5381B422DL;
                    continue block10;
                }
                case -573121999: {
                    l2 = 0x380DL ^ 0x53B0410720FC8A57L;
                    continue block10;
                }
                case -3147964: {
                    break block10;
                }
            }
            break;
        }
        this.resetStingerState();
        long l3 = \u13e8;
        boolean bl2 = true;
        block11: while (true) {
            long l4;
            if (!bl2 || (bl2 = false) || !true) {
                l3 = l4 / (0x34AFL ^ 0xDE3C04439A2545A5L);
            }
            switch ((int)l3) {
                case -3147964: {
                    break block11;
                }
                case 1175084115: {
                    l4 = 0x1B3AL ^ 0xAE5144C414D6395CL;
                    continue block11;
                }
                case 1580890526: {
                    l4 = 0x78EBL ^ 0x20452E52FD4C21F7L;
                    continue block11;
                }
            }
            break;
        }
        this.resetNonStingerState();
    }

    private void resetAllState() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x2430L ^ 0x4F1E217FD4F82CB8L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x4BE2 ^ 0xFFFFB41D)) break;
            l2 = 0x984 ^ 0xA53B148C;
        }
        this.resetProfileStates();
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = \u13e8 - (0x6557L ^ 0x933F98BA947C899CL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l3 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l3 = 0x6DCC ^ 0x6BC4D54A;
        }
        this.resetHangarSwitcherState();
        while (true) {
            long l;
            long l4;
            if ((l4 = (l = \u13e8 - (0x36D7L ^ 0x7B6EF4F02B2B3BF9L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l4 == (0x3FE7 ^ 0xFFFFC018)) break;
            l4 = 0x58CC ^ 0xF20CF7E7;
        }
        this.useNpcSpawnTimer = 0x5198 ^ 0x5198;
        while (true) {
            long l;
            long l5;
            if ((l5 = (l = \u13e8 - (0x5E5CL ^ 0x7D919FC8DD54D703L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l5 == (0x1FB7 ^ 0xFFFFE048)) break;
            l5 = 0x2DBF ^ 0x7A1F737A;
        }
        this.resetCrossStingerState();
    }

    /*
     * Enabled aggressive block sorting
     */
    private void resetCrossStingerState() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x4EAAL ^ 0x5BE6446EC61C680FL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x3A3C ^ 0xFFFFC5C3)) break;
            l2 = 0x7D50 ^ 0xECAA16FE;
        }
        this.startStingerMapTimerMs = null;
        long l = \u13e8;
        block5: while (true) {
            switch ((int)l) {
                case -3147964: {
                    break block5;
                }
                case 218413178: {
                    l = (0x7B1AL ^ 0x97E171F7DB0948CEL) / (-790524180489228692L >>> "\u0000\u0000".length());
                    continue block5;
                }
            }
            break;
        }
        this.resetCachedMapCycleModuleWaitSeconds();
    }

    private void resetHangarSwitcherState() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x57E2L ^ 0xED8119CEB776999CL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x5BE8 ^ 0x5BE9)) break;
            l2 = 0x517A ^ 0xAE5B4CAE;
        }
        this.hangarSwitcher = null;
    }

    private void resetNonStingerState() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0xD25L ^ 0x6187A380B6F1F220L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x41F9 ^ 0xFFFFBE06)) break;
            l2 = 0x3C65 ^ 0xA8FABE36;
        }
        long l = System.currentTimeMillis();
        while (true) {
            long l3;
            long l4;
            if ((l4 = (l3 = \u13e8 - (0x1590L ^ 0xB9EAE3218A61A562L)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) continue;
            if (l4 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l4 = 0x2DB5 ^ 0xF9226AA5;
        }
        LAST_STINGER_CHECK_MS = l;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void resetStingerState() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x36FDL ^ 0x6E534E85CB41DF11L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x6599 ^ 0xFFFF9A66)) break;
            l2 = 0x7A77 ^ 0x55B260CE;
        }
        this.startShootingStingerTimeMs = null;
        long l = \u13e8;
        block5: while (true) {
            switch ((int)l) {
                case -3147964: {
                    break block5;
                }
                case 533766415: {
                    l = (0x361FL ^ 0x84409E1FB248160DL) / (0xB34L ^ 0xF090A4C4317FD8ECL);
                    continue block5;
                }
            }
            break;
        }
        this.startMaxShootingStingerTimerMs = null;
        while (true) {
            long l3;
            long l4;
            if ((l4 = (l3 = \u13e8 - (0x3AA9L ^ 0xADF631FE14E09755L)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) continue;
            if (l4 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                this.resetStingerDeathState();
                return;
            }
            l4 = 0x3FBC ^ 0x8245EEF5;
        }
    }

    /*
     * Unable to fully structure code
     */
    private void tickLicenseCheck() {
        block30: {
            while (true) {
                if ((v0 = (cfr_temp_0 = StingerWarper.\u13e8 - (22577L ^ -3460370824515262160L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v0 == (9225 ^ 9224)) break;
                v0 = 24950 ^ -587521888;
            }
            v1 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl10
            block23: while (true) {
                v1 = v2 / (13454L ^ -8218647891979440087L);
lbl10:
                // 2 sources

                switch ((int)v1) {
                    case -1865029471: {
                        v2 = 7735933212832200228L >>> "\u0000\u0000".length();
                        continue block23;
                    }
                    case -3147964: {
                        break block23;
                    }
                    case 1750735526: {
                        v2 = 19192L ^ 6436471509445594270L;
                        continue block23;
                    }
                }
                break;
            }
            v3 = AuthAPI.getInstance();
            while (true) {
                if ((v4 = (cfr_temp_1 = StingerWarper.\u13e8 - (6812L ^ 9196903091413501015L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v4 == (13528 ^ -13529)) break;
                v4 = 5395 ^ 1747646161;
            }
            v5 = this.licenseVerifier.Verify(v3);
            while (true) {
                if ((v6 = (cfr_temp_2 = StingerWarper.\u13e8 - (13759L ^ -2849110112713385619L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v6 == (1449 ^ 1448)) break;
                v6 = 11681 ^ 1311233227;
            }
            this.__cachedHasLicense = v5;
            v7 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl36
            block26: while (true) {
                v7 = v8 / (1934L ^ -662353830490063063L);
lbl36:
                // 2 sources

                switch ((int)v7) {
                    case -74965549: {
                        v8 = 9608L ^ 6547100511870380548L;
                        continue block26;
                    }
                    case -3147964: {
                        break block26;
                    }
                    case 803259106: {
                        v8 = 29487L ^ -366593363043207703L;
                        continue block26;
                    }
                    case 1952414192: {
                        v8 = 2925L ^ -6484676119649924455L;
                        continue block26;
                    }
                }
                break;
            }
            if (this.__cachedHasLicense) break block30;
            v9 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl53
            block27: while (true) {
                v9 = v10 / (16642L ^ -9155697389839387173L);
lbl53:
                // 2 sources

                switch ((int)v9) {
                    case -1236224734: {
                        v10 = 11962L ^ -2238637069299671400L;
                        continue block27;
                    }
                    case -3147964: {
                        break block27;
                    }
                    case 565656432: {
                        v10 = 22315L ^ -5387506659157291810L;
                        continue block27;
                    }
                }
                break;
            }
            this.resetAllState();
            v11 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl67
            block28: while (true) {
                v11 = v12 / (24416L ^ -8563171240548730453L);
lbl67:
                // 2 sources

                switch ((int)v11) {
                    case -1952009543: {
                        v12 = 1191L ^ -2790212755465047510L;
                        continue block28;
                    }
                    case -271575974: {
                        v12 = 2613L ^ 9074611565378738697L;
                        continue block28;
                    }
                    case -3147964: {
                        break block28;
                    }
                    case 1168806443: {
                        v12 = 7463L ^ -329365925235945879L;
                        continue block28;
                    }
                }
                break;
            }
            var2_1 = new byte[2773 ^ 2755];
            var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 25429 ^ 25468;
            var2_1[10736 ^ 10740] = 420 >>> "\u0000\u0000".length();
            var2_1[23354 ^ 23350] = 8461 ^ 8575;
            var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 468 >>> "\u0000\u0000".length();
            var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 460 >>> "\u0000\u0000".length();
            var2_1[9304 ^ 9293] = 404 >>> "\u0000\u0000".length();
            var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 16034 ^ 16071;
            var2_1["".length() >>> "\u0000\u0000".length()] = 456 >>> "\u0000\u0000".length();
            var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 3791 ^ 3774;
            var2_1[14530 ^ 14546] = 14179 ^ 14090;
            var2_1[17885 ^ 17876] = 21545 ^ 21597;
            var2_1[7317 ^ 7323] = 17669 ^ 17701;
            var2_1[959 ^ 944] = 17729 ^ 17709;
            var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 5695 ^ 5722;
            var2_1[17853 ^ 17852] = 404 >>> "\u0000\u0000".length();
            var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 396 >>> "\u0000\u0000".length();
            var2_1[27201 ^ 27207] = 404 >>> "\u0000\u0000".length();
            var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 128 >>> "\u0000\u0000".length();
            var2_1[9345 ^ 9362] = 440 >>> "\u0000\u0000".length();
            var2_1[420 ^ 431] = 30897 ^ 30928;
            var2_1[508 ^ 505] = 14389 ^ 14407;
            var2_1[4615 ^ 4627] = 22590 ^ 22605;
            var2_1[25921 ^ 25931] = 476 >>> "\u0000\u0000".length();
            v13 = new String(var2_1);
            while (true) {
                if ((v14 = (cfr_temp_3 = StingerWarper.\u13e8 - (6996L ^ 2236842253356523666L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v14 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v14 = 4912 ^ 801584828;
            }
            throw new RuntimeException(v13);
        }
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    public void tick() {
        block189: {
            block188: {
                block187: {
                    block186: {
                        block185: {
                            block184: {
                                block183: {
                                    block182: {
                                        block181: {
                                            block180: {
                                                while (true) {
                                                    if ((v0 = (cfr_temp_0 = StingerWarper.\u13e8 - (-2543672915777397872L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                                                    if (v0 == (21852 ^ -21853)) break;
                                                    v0 = 13046 ^ 989232200;
                                                }
                                                v1 = StingerWarper.\u13e8;
                                                if (true) ** GOTO lbl10
                                                block122: while (true) {
                                                    v1 = (20207L ^ 4187069111462381992L) / (25505L ^ 4486393942723393951L);
lbl10:
                                                    // 2 sources

                                                    switch ((int)v1) {
                                                        case -328560609: {
                                                            continue block122;
                                                        }
                                                        case -3147964: {
                                                            break block122;
                                                        }
                                                    }
                                                    break;
                                                }
                                                while (true) {
                                                    if ((v2 = (cfr_temp_1 = StingerWarper.\u13e8 - (11366L ^ -8671344716102556287L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                                                    if (v2 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                                                    v2 = 25082 ^ 1249317031;
                                                }
                                                v3 = StingerWarper.\u13e8;
                                                if (true) ** GOTO lbl24
                                                block124: while (true) {
                                                    v3 = v4 / (-6027313749894110652L >>> "\u0000\u0000".length());
lbl24:
                                                    // 2 sources

                                                    switch ((int)v3) {
                                                        case -237758820: {
                                                            v4 = 15442L ^ -8164729021216715458L;
                                                            continue block124;
                                                        }
                                                        case -186760474: {
                                                            v4 = 23483L ^ 1137899329636081933L;
                                                            continue block124;
                                                        }
                                                        case -3147964: {
                                                            break block124;
                                                        }
                                                    }
                                                    break;
                                                }
                                                PersistantStoragePathFinder.getInstance(this.mapManager, this.configAPI, this.hero);
                                                v5 = StingerWarper.\u13e8;
                                                if (true) ** GOTO lbl39
                                                block125: while (true) {
                                                    v5 = v6 / (17176L ^ -1617656734706465058L);
lbl39:
                                                    // 2 sources

                                                    switch ((int)v5) {
                                                        case -1855451090: {
                                                            v6 = 30538L ^ 7154056465817123801L;
                                                            continue block125;
                                                        }
                                                        case -927996695: {
                                                            v6 = 3247308444025199276L >>> "\u0000\u0000".length();
                                                            continue block125;
                                                        }
                                                        case -3147964: {
                                                            break block125;
                                                        }
                                                        case 54980682: {
                                                            v6 = 14647L ^ 5744877424794555345L;
                                                            continue block125;
                                                        }
                                                    }
                                                    break;
                                                }
                                                this.tickLicenseCheck();
                                                while (true) {
                                                    if ((v7 = (cfr_temp_2 = StingerWarper.\u13e8 - (24787L ^ 4742295653131515440L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                                                    if (v7 == (3966 ^ -3967)) break;
                                                    v7 = 10228 ^ -637076910;
                                                }
                                                v8 = StingerWarper.\u13e8;
                                                if (true) ** GOTO lbl61
                                                block127: while (true) {
                                                    v8 = (-467128337938163740L >>> "\u0000\u0000".length()) / (-988540467682186660L >>> "\u0000\u0000".length());
lbl61:
                                                    // 2 sources

                                                    switch ((int)v8) {
                                                        case -1162767139: {
                                                            continue block127;
                                                        }
                                                        case -3147964: {
                                                            break block127;
                                                        }
                                                    }
                                                    break;
                                                }
                                                if (this.hero.getMap() == null) break block180;
                                                v9 = StingerWarper.\u13e8;
                                                if (true) ** GOTO lbl71
                                                block128: while (true) {
                                                    v9 = (14504L ^ -5742399050225306090L) / (-2087783471591688704L >>> "\u0000\u0000".length());
lbl71:
                                                    // 2 sources

                                                    switch ((int)v9) {
                                                        case -3147964: {
                                                            break block128;
                                                        }
                                                        case 1473723807: {
                                                            continue block128;
                                                        }
                                                    }
                                                    break;
                                                }
                                                while (true) {
                                                    if ((v10 = (cfr_temp_3 = StingerWarper.\u13e8 - (106L ^ -8668927661165379933L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                                                    if (v10 == (19974 ^ 19975)) break;
                                                    v10 = 6293 ^ -1652184293;
                                                }
                                                v11 = this.hero.getMap();
                                                while (true) {
                                                    if ((v12 = (cfr_temp_4 = StingerWarper.\u13e8 - (25486L ^ -5769048657142347995L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                                                    if (v12 == (26135 ^ 26134)) break;
                                                    v12 = 25380 ^ 1371626954;
                                                }
                                                if (v11.getId() > 0) break block181;
                                            }
                                            return;
                                        }
                                        while (true) {
                                            if ((v13 = (cfr_temp_5 = StingerWarper.\u13e8 - (1885068300793736152L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                                            if (v13 == (468 ^ 469)) break;
                                            v13 = 14404 ^ -1008516255;
                                        }
                                        this.tryUpdateHangarList();
                                        while (true) {
                                            if ((v14 = (cfr_temp_6 = StingerWarper.\u13e8 - (23354L ^ 7853863247854283311L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                                            if (v14 == (14369 ^ -14370)) break;
                                            v14 = 2098 ^ -570823262;
                                        }
                                        while (true) {
                                            if ((v15 = (cfr_temp_7 = StingerWarper.\u13e8 - (12192L ^ -4301945735733672554L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                                            if (v15 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                                            v15 = 29955 ^ -1546670103;
                                        }
                                        if (!this.config.FORCE_RESTART_CHECK_TIME) break block182;
                                        while (true) {
                                            if ((v16 = (cfr_temp_8 = StingerWarper.\u13e8 - (14150L ^ -5303641792665741283L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                                            if (v16 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                                            v16 = -1818702520 >>> "\u0000\u0000".length();
                                        }
                                        v17 = this.manualResetCount + ("\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length());
                                        v18 = StingerWarper.\u13e8;
                                        if (true) ** GOTO lbl118
                                        block135: while (true) {
                                            v18 = v19 / (15218L ^ -4268666654187890926L);
lbl118:
                                            // 2 sources

                                            switch ((int)v18) {
                                                case -1075540996: {
                                                    v19 = 8182L ^ -290947275666710225L;
                                                    continue block135;
                                                }
                                                case -838101834: {
                                                    v19 = 17697L ^ -6426414574499597620L;
                                                    continue block135;
                                                }
                                                case -3147964: {
                                                    break block135;
                                                }
                                            }
                                            break;
                                        }
                                        this.manualResetCount = v17;
                                        while (true) {
                                            if ((v20 = (cfr_temp_9 = StingerWarper.\u13e8 - (20062L ^ 1253463920293353503L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
                                            if (v20 == (9165 ^ 9164)) break;
                                            v20 = 385 ^ -1383282529;
                                        }
                                        this.resetAllState();
                                        while (true) {
                                            if ((v21 = (cfr_temp_10 = StingerWarper.\u13e8 - (22590L ^ -3734453384151289919L)) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
                                            if (v21 == (31792 ^ 31793)) break;
                                            v21 = 8118 ^ -589402434;
                                        }
                                        v22 = "".length() >>> "\u0000\u0000".length();
                                        while (true) {
                                            if ((v23 = (cfr_temp_11 = StingerWarper.\u13e8 - (2207L ^ 3279898526618310409L)) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
                                            if (v23 == (14185 ^ -14186)) {
                                                this.config.FORCE_RESTART_CHECK_TIME = v22;
                                                break;
                                            }
                                            v23 = 25024 ^ 1845974679;
                                        }
                                    }
                                    v24 = StingerWarper.\u13e8;
                                    if (true) ** GOTO lbl152
                                    block139: while (true) {
                                        v24 = v25 / (7801L ^ 6701233109670462505L);
lbl152:
                                        // 2 sources

                                        switch ((int)v24) {
                                            case -1367543778: {
                                                v25 = 17942L ^ -1560821180794160687L;
                                                continue block139;
                                            }
                                            case -1228056712: {
                                                v25 = 31039L ^ -6330820277212994414L;
                                                continue block139;
                                            }
                                            case -3147964: {
                                                break block139;
                                            }
                                            case 1561056909: {
                                                v25 = 20878L ^ 1052022904969856109L;
                                                continue block139;
                                            }
                                        }
                                        break;
                                    }
                                    v26 = StingerWarper.\u13e8;
                                    if (true) ** GOTO lbl168
                                    block140: while (true) {
                                        v26 = (18052L ^ 502492359305442439L) / (19814L ^ -1235228182992705211L);
lbl168:
                                        // 2 sources

                                        switch ((int)v26) {
                                            case -233279620: {
                                                continue block140;
                                            }
                                            case -3147964: {
                                                break block140;
                                            }
                                        }
                                        break;
                                    }
                                    if (!(this.main.getModule() instanceof DisconnectModule)) break block183;
                                    v27 = StingerWarper.\u13e8;
                                    if (true) ** GOTO lbl178
                                    block141: while (true) {
                                        v27 = (20180L ^ -9043692764877192421L) / (12514L ^ -7814411786352847680L);
lbl178:
                                        // 2 sources

                                        switch ((int)v27) {
                                            case -3147964: {
                                                break block141;
                                            }
                                            case 1855628451: {
                                                continue block141;
                                            }
                                        }
                                        break;
                                    }
                                    this.updateLabels();
                                    while (true) {
                                        if ((v28 = (cfr_temp_12 = StingerWarper.\u13e8 - (30869L ^ 7089925679138536283L)) == 0L ? 0 : (cfr_temp_12 < 0L ? -1 : 1)) == false) continue;
                                        if (v28 == (25236 ^ -25237)) break;
                                        v28 = 19526 ^ 56774817;
                                    }
                                    this.resetProfileStates();
                                    var2_1 = new byte["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
                                    var2_1["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 7597 ^ 7649;
                                    var2_1[31641 ^ 31640] = 19156 ^ 19133;
                                    var2_1[365 ^ 358] = 400 >>> "\u0000\u0000".length();
                                    var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 5759 ^ 5660;
                                    var2_1["".length() >>> "\u0000\u0000".length()] = 272 >>> "\u0000\u0000".length();
                                    var2_1[22844 ^ 22840] = 444 >>> "\u0000\u0000".length();
                                    var2_1[1574 ^ 1573] = 4482 ^ 4577;
                                    var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 12925 ^ 12824;
                                    var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 20477 ^ 20376;
                                    var2_1[14185 ^ 14188] = 17939 ^ 18045;
                                    var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 31891 ^ 31997;
                                    var2_1[23464 ^ 23466] = 460 >>> "\u0000\u0000".length();
                                    var2_1[18275 ^ 18282] = 464 >>> "\u0000\u0000".length();
                                    v29 = new String(var2_1);
                                    while (true) {
                                        if ((v30 = (cfr_temp_13 = StingerWarper.\u13e8 - (28043L ^ -3366872281940992965L)) == 0L ? 0 : (cfr_temp_13 < 0L ? -1 : 1)) == false) continue;
                                        if (v30 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                                        v30 = 25582 ^ 1841585476;
                                    }
                                    this.status = v29;
                                    return;
                                }
                                while (true) {
                                    if ((v31 = (cfr_temp_14 = StingerWarper.\u13e8 - (22519L ^ -5541534451445170666L)) == 0L ? 0 : (cfr_temp_14 < 0L ? -1 : 1)) == false) continue;
                                    if (v31 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                                    v31 = 21037 ^ -2077812771;
                                }
                                if (this.canLogoutAndSwitchBack()) break block184;
                                while (true) {
                                    if ((v32 = (cfr_temp_15 = StingerWarper.\u13e8 - (8156501647314233648L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_15 < 0L ? -1 : 1)) == false) continue;
                                    if (v32 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                                    v32 = 24809 ^ 2102105082;
                                }
                                this.updateLabels();
                                while (true) {
                                    if ((v33 = (cfr_temp_16 = StingerWarper.\u13e8 - (25880L ^ -444494517378979421L)) == 0L ? 0 : (cfr_temp_16 < 0L ? -1 : 1)) == false) continue;
                                    if (v33 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                                    v33 = 3644 ^ -2074827156;
                                }
                                this.resetAllState();
                                var2_2 = new byte["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
                                var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 31037 ^ 31031;
                                var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 128 >>> "\u0000\u0000".length();
                                var2_2[11263 ^ 11234] = 456 >>> "\u0000\u0000".length();
                                var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 20705 ^ 20622;
                                var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 6671 ^ 6752;
                                var2_2[1371 ^ 1359] = 464 >>> "\u0000\u0000".length();
                                var2_2[15318 ^ 15303] = 460 >>> "\u0000\u0000".length();
                                var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 25192 ^ 25160;
                                var2_2[32110 ^ 32102] = 444 >>> "\u0000\u0000".length();
                                var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 128 >>> "\u0000\u0000".length();
                                var2_2[16409 ^ 16406] = 28351 ^ 28365;
                                var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 464 >>> "\u0000\u0000".length();
                                var2_2[22965 ^ 22972] = 19778 ^ 19749;
                                var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 8002 ^ 7991;
                                var2_2[7303 ^ 7298] = 464 >>> "\u0000\u0000".length();
                                var2_2["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 388 >>> "\u0000\u0000".length();
                                var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 444 >>> "\u0000\u0000".length();
                                var2_2[5497 ^ 5474] = 412 >>> "\u0000\u0000".length();
                                var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 4139 ^ 4107;
                                var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 388 >>> "\u0000\u0000".length();
                                var2_2[5868 ^ 5868] = 2184 ^ 2251;
                                var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 5882 ^ 5780;
                                var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 460 >>> "\u0000\u0000".length();
                                var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 440 >>> "\u0000\u0000".length();
                                var2_2[18885 ^ 18899] = 18784 ^ 18696;
                                var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 420 >>> "\u0000\u0000".length();
                                var2_2[31954 ^ 31936] = 31877 ^ 31986;
                                var2_2[25833 ^ 25852] = 16387 ^ 16480;
                                var2_2[10735 ^ 10739] = 3276 ^ 3245;
                                var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 416 >>> "\u0000\u0000".length();
                                var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 432 >>> "\u0000\u0000".length();
                                var2_2[32286 ^ 32260] = 440 >>> "\u0000\u0000".length();
                                v34 = new String(var2_2);
                                v35 = StingerWarper.\u13e8;
                                if (true) ** GOTO lbl269
                                block147: while (true) {
                                    v35 = v36 / (31386L ^ -6967368406775963977L);
lbl269:
                                    // 2 sources

                                    switch ((int)v35) {
                                        case -3147964: {
                                            break block147;
                                        }
                                        case 261850932: {
                                            v36 = 8492L ^ 8388828941379918408L;
                                            continue block147;
                                        }
                                        case 1487941496: {
                                            v36 = 6331L ^ -9170567501740466633L;
                                            continue block147;
                                        }
                                    }
                                    break;
                                }
                                this.status = v34;
                                return;
                            }
                            v37 = StingerWarper.\u13e8;
                            if (true) ** GOTO lbl285
                            block148: while (true) {
                                v37 = v38 / (22462L ^ 6035783373074216126L);
lbl285:
                                // 2 sources

                                switch ((int)v37) {
                                    case -1087934056: {
                                        v38 = 11786L ^ 7240994622184072734L;
                                        continue block148;
                                    }
                                    case -926156931: {
                                        v38 = 32222L ^ 392204886811352724L;
                                        continue block148;
                                    }
                                    case -3147964: {
                                        break block148;
                                    }
                                    case 2030789659: {
                                        v38 = 587624374650865500L >>> "\u0000\u0000".length();
                                        continue block148;
                                    }
                                }
                                break;
                            }
                            if (this.validConfig()) break block185;
                            while (true) {
                                if ((v39 = (cfr_temp_17 = StingerWarper.\u13e8 - (6592L ^ 5304384073239321336L)) == 0L ? 0 : (cfr_temp_17 < 0L ? -1 : 1)) == false) continue;
                                if (v39 == (2405 ^ -2406)) break;
                                v39 = 26322 ^ 504461490;
                            }
                            this.updateLabels();
                            v40 = StingerWarper.\u13e8;
                            if (true) ** GOTO lbl308
                            block150: while (true) {
                                v40 = v41 / (29213L ^ 6532170992904463812L);
lbl308:
                                // 2 sources

                                switch ((int)v40) {
                                    case -2038174217: {
                                        v41 = 21692L ^ -7832950952152066433L;
                                        continue block150;
                                    }
                                    case -3147964: {
                                        break block150;
                                    }
                                    case 843386441: {
                                        v41 = 10307L ^ -6537665094713349372L;
                                        continue block150;
                                    }
                                    case 1612225835: {
                                        v41 = 16928L ^ 4612929931884326960L;
                                        continue block150;
                                    }
                                }
                                break;
                            }
                            this.resetAllState();
                            var2_3 = new byte["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
                            var2_3[9210 ^ 9211] = 15568 ^ -15581;
                            var2_3["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 440 >>> "\u0000\u0000".length();
                            var2_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 444 >>> "\u0000\u0000".length();
                            var2_3[12567 ^ 12572] = 408 >>> "\u0000\u0000".length();
                            var2_3["".length() >>> "\u0000\u0000".length()] = 17065 ^ 17120;
                            var2_3[28131 ^ 28137] = 440 >>> "\u0000\u0000".length();
                            var2_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 15491 ^ 15591;
                            var2_3[14469 ^ 14477] = 1358 ^ 1325;
                            var2_3[12316 ^ 12319] = 388 >>> "\u0000\u0000".length();
                            var2_3[13148 ^ 13137] = 412 >>> "\u0000\u0000".length();
                            var2_3[21443 ^ 21455] = 19761 ^ 19800;
                            var2_3[23661 ^ 23658] = 5307 ^ 5275;
                            var2_3[11088 ^ 11093] = 420 >>> "\u0000\u0000".length();
                            var2_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 1325 ^ 1345;
                            var2_3[27126 ^ 27124] = 472 >>> "\u0000\u0000".length();
                            v42 = new String(var2_3);
                            while (true) {
                                if ((v43 = (cfr_temp_18 = StingerWarper.\u13e8 - (4657L ^ -8345264711457890906L)) == 0L ? 0 : (cfr_temp_18 < 0L ? -1 : 1)) == false) continue;
                                if (v43 == (10707 ^ 10706)) break;
                                v43 = 19757 ^ 1345716227;
                            }
                            this.status = v42;
                            return;
                        }
                        v44 = StingerWarper.\u13e8;
                        if (true) ** GOTO lbl350
                        block152: while (true) {
                            v44 = (29076L ^ -1620347541027286241L) / (-2051920606778772516L >>> "\u0000\u0000".length());
lbl350:
                            // 2 sources

                            switch ((int)v44) {
                                case -3147964: {
                                    break block152;
                                }
                                case 81058440: {
                                    continue block152;
                                }
                            }
                            break;
                        }
                        if (!this.tickIsSwitchingHangarBackToOriginal()) break block186;
                        while (true) {
                            if ((v45 = (cfr_temp_19 = StingerWarper.\u13e8 - (308339456679017084L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_19 < 0L ? -1 : 1)) == false) continue;
                            if (v45 == (10404 ^ 10405)) break;
                            v45 = 19127 ^ -1479486283;
                        }
                        this.updateLabels();
                        v46 = StingerWarper.\u13e8;
                        if (true) ** GOTO lbl366
                        block154: while (true) {
                            v46 = v47 / (24121L ^ 7292133960727676561L);
lbl366:
                            // 2 sources

                            switch ((int)v46) {
                                case -3147964: {
                                    break block154;
                                }
                                case 222281284: {
                                    v47 = 6666L ^ -5867121408581784920L;
                                    continue block154;
                                }
                                case 1085963793: {
                                    v47 = 5343L ^ 7507254740276018978L;
                                    continue block154;
                                }
                            }
                            break;
                        }
                        this.resetProfileStates();
                        var2_4 = new byte["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
                        var2_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 14834 ^ -14800;
                        var2_4[17371 ^ 17363] = 412 >>> "\u0000\u0000".length();
                        var2_4[1250 ^ 1264] = 460 >>> "\u0000\u0000".length();
                        var2_4[25164 ^ 25165] = 476 >>> "\u0000\u0000".length();
                        var2_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 4934 ^ 4901;
                        var2_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 416 >>> "\u0000\u0000".length();
                        var2_4[17094 ^ 17101] = 388 >>> "\u0000\u0000".length();
                        var2_4[3621 ^ 3636] = 148 >>> "\u0000\u0000".length();
                        var2_4[28989 ^ 28976] = 19904 ^ 19883;
                        var2_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 396 >>> "\u0000\u0000".length();
                        var2_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 392 >>> "\u0000\u0000".length();
                        var2_4[10212 ^ 10212] = 332 >>> "\u0000\u0000".length();
                        var2_4[8417 ^ 8419] = 420 >>> "\u0000\u0000".length();
                        var2_4[2008 ^ 2001] = 128 >>> "\u0000\u0000".length();
                        var2_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 12157 ^ 12051;
                        var2_4[2072 ^ 2056] = 4510 ^ 4542;
                        var2_4[22394 ^ 22388] = 128 >>> "\u0000\u0000".length();
                        var2_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 180 >>> "\u0000\u0000".length();
                        var2_4[19867 ^ 19869] = 420 >>> "\u0000\u0000".length();
                        var2_4[9742 ^ 9741] = 6624 ^ 6548;
                        v48 = new String(var2_4);
                        v49 = new Object[5980 ^ 5981];
                        v50 = StingerWarper.\u13e8;
                        if (true) ** GOTO lbl403
                        block155: while (true) {
                            v50 = v51 / (9900L ^ 8903525118327357861L);
lbl403:
                            // 2 sources

                            switch ((int)v50) {
                                case -1268263866: {
                                    v51 = 5663L ^ -2407149150775948719L;
                                    continue block155;
                                }
                                case -516049263: {
                                    v51 = 27553L ^ 7601058743158143382L;
                                    continue block155;
                                }
                                case -3147964: {
                                    break block155;
                                }
                            }
                            break;
                        }
                        v49[32158 ^ 32158] = this.switchBackReason;
                        v52 = StingerWarper.\u13e8;
                        if (true) ** GOTO lbl417
                        block156: while (true) {
                            v52 = (-2357103793570104656L >>> "\u0000\u0000".length()) / (4521L ^ 5011660643822445363L);
lbl417:
                            // 2 sources

                            switch ((int)v52) {
                                case -3147964: {
                                    break block156;
                                }
                                case 1241900950: {
                                    continue block156;
                                }
                            }
                            break;
                        }
                        v53 = String.format(v48, v49);
                        while (true) {
                            if ((v54 = (cfr_temp_20 = StingerWarper.\u13e8 - (25706L ^ 6310763004249052220L)) == 0L ? 0 : (cfr_temp_20 < 0L ? -1 : 1)) == false) continue;
                            if (v54 == (10442 ^ -10443)) break;
                            v54 = 29327 ^ -55121872;
                        }
                        this.status = v53;
                        return;
                    }
                    v55 = StingerWarper.\u13e8;
                    if (true) ** GOTO lbl435
                    block158: while (true) {
                        v55 = v56 / (15537L ^ -2235243141310154641L);
lbl435:
                        // 2 sources

                        switch ((int)v55) {
                            case -3147964: {
                                break block158;
                            }
                            case 767870797: {
                                v56 = 8549L ^ -4486976820694890667L;
                                continue block158;
                            }
                            case 1224899476: {
                                v56 = 17253L ^ -8729241707211469302L;
                                continue block158;
                            }
                        }
                        break;
                    }
                    if (!this.tickIsSwitchingHangarToStinger()) break block187;
                    v57 = StingerWarper.\u13e8;
                    if (true) ** GOTO lbl449
                    block159: while (true) {
                        v57 = v58 / (15133L ^ -1022163351308128995L);
lbl449:
                        // 2 sources

                        switch ((int)v57) {
                            case -1929755727: {
                                v58 = 29852L ^ -5829158600422535415L;
                                continue block159;
                            }
                            case -537254481: {
                                v58 = 21778L ^ -2851293863898484636L;
                                continue block159;
                            }
                            case -500524043: {
                                v58 = 28651L ^ -7872953666471735191L;
                                continue block159;
                            }
                            case -3147964: {
                                break block159;
                            }
                        }
                        break;
                    }
                    this.updateLabels();
                    v59 = StingerWarper.\u13e8;
                    if (true) ** GOTO lbl466
                    block160: while (true) {
                        v59 = v60 / (31961L ^ -8273907667270990331L);
lbl466:
                        // 2 sources

                        switch ((int)v59) {
                            case -856323030: {
                                v60 = 3014L ^ 8148664560350891501L;
                                continue block160;
                            }
                            case -826534667: {
                                v60 = 18016L ^ -8252158120572874789L;
                                continue block160;
                            }
                            case -325126053: {
                                v60 = 31284L ^ -1943218833905135618L;
                                continue block160;
                            }
                            case -3147964: {
                                break block160;
                            }
                        }
                        break;
                    }
                    this.resetProfileStates();
                    var2_5 = new byte[3321 ^ 3304];
                    var2_5["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 14590 ^ -14496;
                    var2_5["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 476 >>> "\u0000\u0000".length();
                    var2_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 17661 ^ 17629;
                    var2_5["".length() >>> "\u0000\u0000".length()] = 332 >>> "\u0000\u0000".length();
                    var2_5[18224 ^ 18238] = 19347 ^ 19428;
                    var2_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 3042 ^ 2961;
                    var2_5[22079 ^ 22073] = 6864 ^ 6841;
                    var2_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 23276 ^ 23192;
                    var2_5[9881 ^ 9885] = 396 >>> "\u0000\u0000".length();
                    var2_5[11452 ^ 11443] = 7731 ^ 7762;
                    var2_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 18450 ^ 18557;
                    var2_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 7074 ^ 7042;
                    var2_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 420 >>> "\u0000\u0000".length();
                    var2_5[25059 ^ 25075] = 3096 ^ 3176;
                    var2_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 7319 ^ 7423;
                    var2_5[1146 ^ 1149] = 22911 ^ 22801;
                    var2_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 412 >>> "\u0000\u0000".length();
                    var2_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 15010 ^ 15062;
                    v61 = new String(var2_5);
                    while (true) {
                        if ((v62 = (cfr_temp_21 = StingerWarper.\u13e8 - (23225L ^ -5707968070056227652L)) == 0L ? 0 : (cfr_temp_21 < 0L ? -1 : 1)) == false) continue;
                        if (v62 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                        v62 = 29317 ^ -921101669;
                    }
                    this.status = v61;
                    return;
                }
                while (true) {
                    if ((v63 = (cfr_temp_22 = StingerWarper.\u13e8 - (25984L ^ 7348934262264563581L)) == 0L ? 0 : (cfr_temp_22 < 0L ? -1 : 1)) == false) continue;
                    if (v63 == (27913 ^ -27914)) break;
                    v63 = 22536 ^ -2001631707;
                }
                this.resetHangarSwitcherState();
                v64 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl517
                block163: while (true) {
                    v64 = v65 / (18120L ^ -1074123619176362364L);
lbl517:
                    // 2 sources

                    switch ((int)v64) {
                        case -788570414: {
                            v65 = 4527L ^ -361995790381358833L;
                            continue block163;
                        }
                        case -3147964: {
                            break block163;
                        }
                        case 758437496: {
                            v65 = 23131L ^ 535690054030879271L;
                            continue block163;
                        }
                        case 2046468152: {
                            v65 = 295L ^ 4929407469029010908L;
                            continue block163;
                        }
                    }
                    break;
                }
                if (!this.botIsUsingStingerConfig()) break block188;
                while (true) {
                    if ((v66 = (cfr_temp_23 = StingerWarper.\u13e8 - (26114L ^ 4798066963951473429L)) == 0L ? 0 : (cfr_temp_23 < 0L ? -1 : 1)) == false) continue;
                    if (v66 == (11207 ^ -11208)) break;
                    v66 = 22437 ^ 8137284;
                }
                this.updateLabels((boolean)(28473 ^ 28473), (boolean)(25639 ^ 25638));
                while (true) {
                    if ((v67 = (cfr_temp_24 = StingerWarper.\u13e8 - (16608L ^ 6583023582092836381L)) == 0L ? 0 : (cfr_temp_24 < 0L ? -1 : 1)) == false) continue;
                    if (v67 == (19491 ^ -19492)) break;
                    v67 = 21454 ^ -725044455;
                }
                this.resetNonStingerState();
                var2_6 = new byte["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
                var2_6[12068 ^ 12064] = 244 >>> "\u0000\u0000".length();
                var2_6[11721 ^ 11725] = 27309 ^ 27357;
                var2_6[16727 ^ 16726] = 476 >>> "\u0000\u0000".length();
                var2_6[8316 ^ 8319] = 30636 ^ 30684;
                var2_6["".length() >>> "\u0000\u0000".length()] = 332 >>> "\u0000\u0000".length();
                var2_6[7816 ^ 7821] = 25299 ^ 25270;
                var2_6["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 400 >>> "\u0000\u0000".length();
                var2_6[8667 ^ 8665] = 388 >>> "\u0000\u0000".length();
                v68 = new String(var2_6);
                while (true) {
                    if ((v69 = (cfr_temp_25 = StingerWarper.\u13e8 - (6889L ^ 4620846241953613871L)) == 0L ? 0 : (cfr_temp_25 < 0L ? -1 : 1)) == false) continue;
                    if (v69 == (22984 ^ -22985)) break;
                    v69 = 10345 ^ -1151785767;
                }
                this.status = v68;
                while (true) {
                    if ((v70 = (cfr_temp_26 = StingerWarper.\u13e8 - (9738L ^ 8311693504195252758L)) == 0L ? 0 : (cfr_temp_26 < 0L ? -1 : 1)) == false) continue;
                    if (v70 == (22552 ^ -22553)) break;
                    v70 = 14403 ^ 1173403349;
                }
                this.startMaxStingerTimer();
                v71 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl568
                block168: while (true) {
                    v71 = (23209L ^ 3652739732517328328L) / (10973L ^ -688181224353398879L);
lbl568:
                    // 2 sources

                    switch ((int)v71) {
                        case -457880463: {
                            continue block168;
                        }
                        case -3147964: {
                            break block168;
                        }
                    }
                    break;
                }
                this.startStingerMapTimer();
                v72 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl578
                block169: while (true) {
                    v72 = v73 / (17475L ^ -690001595288102768L);
lbl578:
                    // 2 sources

                    switch ((int)v72) {
                        case -138909931: {
                            v73 = 23340L ^ -8985454672306312245L;
                            continue block169;
                        }
                        case -3147964: {
                            break block169;
                        }
                        case 490370092: {
                            v73 = 8445L ^ -4746964612350514790L;
                            continue block169;
                        }
                        case 870693691: {
                            v73 = -6087222197188342388L >>> "\u0000\u0000".length();
                            continue block169;
                        }
                    }
                    break;
                }
                this.tickStinger();
                break block189;
            }
            v74 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
            v75 = "".length() >>> "\u0000\u0000".length();
            v76 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl599
            block170: while (true) {
                v76 = v77 / (29413L ^ 1673573087568709870L);
lbl599:
                // 2 sources

                switch ((int)v76) {
                    case -1866958481: {
                        v77 = 29505L ^ 7644656141726238918L;
                        continue block170;
                    }
                    case -504760681: {
                        v77 = -1346253693314371344L >>> "\u0000\u0000".length();
                        continue block170;
                    }
                    case -3147964: {
                        break block170;
                    }
                    case 656233228: {
                        v77 = 30799L ^ 5955625687227992852L;
                        continue block170;
                    }
                }
                break;
            }
            this.updateLabels(v74, v75);
            while (true) {
                if ((v78 = (cfr_temp_27 = StingerWarper.\u13e8 - (16919L ^ 7093003712543280250L)) == 0L ? 0 : (cfr_temp_27 < 0L ? -1 : 1)) == false) continue;
                if (v78 == (8756 ^ -8757)) break;
                v78 = 187 ^ -937049168;
            }
            this.resetStingerState();
            v79 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl622
            block172: while (true) {
                v79 = v80 / (4042843020735508920L >>> "\u0000\u0000".length());
lbl622:
                // 2 sources

                switch ((int)v79) {
                    case -1069300670: {
                        v80 = 20201L ^ 6694035087490030227L;
                        continue block172;
                    }
                    case -3147964: {
                        break block172;
                    }
                    case 1047912039: {
                        v80 = 5379L ^ 6291319504779522266L;
                        continue block172;
                    }
                }
                break;
            }
            this.resetCrossStingerState();
            var2_7 = new byte[23617 ^ 23622];
            var2_7[11685 ^ 11681] = 336 >>> "\u0000\u0000".length();
            var2_7["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 6050 ^ 6091;
            var2_7[22145 ^ 22151] = 412 >>> "\u0000\u0000".length();
            var2_7["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 7471 ^ 7502;
            var2_7[27414 ^ 27414] = 348 >>> "\u0000\u0000".length();
            var2_7["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 30404 ^ 30378;
            var2_7[10207 ^ 10205] = 420 >>> "\u0000\u0000".length();
            var2_7[20355 ^ 20352] = 27235 ^ 27159;
            v81 = new String(var2_7);
            while (true) {
                if ((v82 = (cfr_temp_28 = StingerWarper.\u13e8 - (23860L ^ 1504448739780308382L)) == 0L ? 0 : (cfr_temp_28 < 0L ? -1 : 1)) == false) continue;
                if (v82 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v82 = 29682 ^ -858211822;
            }
            this.status = v81;
            while (true) {
                if ((v83 = (cfr_temp_29 = StingerWarper.\u13e8 - (7331531883110281312L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_29 < 0L ? -1 : 1)) == false) continue;
                if (v83 == (15615 ^ 15614)) {
                    this.tickWaitStinger();
                    break;
                }
                v83 = -1587874044 >>> "\u0000\u0000".length();
            }
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private void startStingerMapTimer() {
        long l = \u13e8;
        boolean bl = true;
        block12: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x1208L ^ 0xF80A1C8FF644FFA2L);
            }
            switch ((int)l) {
                case -956124788: {
                    l2 = 0x515AL ^ 0xB6C9D13E7B947A2BL;
                    continue block12;
                }
                case -3147964: {
                    break block12;
                }
                case 23428951: {
                    l2 = 0x101EL ^ 0xDC01F64579FE5B67L;
                    continue block12;
                }
                case 1173180677: {
                    l2 = 0x7050L ^ 0x8106EA6CD7C99616L;
                    continue block12;
                }
            }
            break;
        }
        if (this.startStingerMapTimerMs != null) return;
        long l3 = \u13e8;
        boolean bl2 = true;
        block13: while (true) {
            long l4;
            if (!bl2 || (bl2 = false) || !true) {
                l3 = l4 / (0x7490L ^ 0xEF4EDA778846A30EL);
            }
            switch ((int)l3) {
                case -1280494636: {
                    l4 = 0xBD6L ^ 0x9CA090C8657AC818L;
                    continue block13;
                }
                case -3147964: {
                    break block13;
                }
                case 482989950: {
                    l4 = 0x3C7L ^ 0x233DBD5C28B732E0L;
                    continue block13;
                }
                case 1893531807: {
                    l4 = 0x41E4L ^ 0xD4A9790BC03B6A2BL;
                    continue block13;
                }
            }
            break;
        }
        long l5 = System.currentTimeMillis();
        while (true) {
            long l6;
            long l7;
            if ((l7 = (l6 = \u13e8 - (0x6625L ^ 0x66C8CE2DACB21F35L)) == 0L ? 0 : (l6 < 0L ? -1 : 1)) == false) continue;
            if (l7 == (0x7E7D ^ 0xFFFF8182)) break;
            l7 = 0x427D ^ 0xC9773386;
        }
        Long l8 = l5;
        while (true) {
            long l9;
            long l10;
            if ((l10 = (l9 = \u13e8 - (0x6033L ^ 0xB88B16D2C967C935L)) == 0L ? 0 : (l9 < 0L ? -1 : 1)) == false) continue;
            if (l10 == (0x2C10 ^ 0x2C11)) {
                this.startStingerMapTimerMs = l8;
                return;
            }
            l10 = 0x5A03 ^ 0xECCD98D;
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private void startMaxStingerTimer() {
        long l = \u13e8;
        boolean bl = true;
        block14: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x47E8L ^ 0x8AE0A2D594768F93L);
            }
            switch ((int)l) {
                case -1153986909: {
                    l2 = 0x1484L ^ 0x9DF0948DB8F8DCBCL;
                    continue block14;
                }
                case -3147964: {
                    break block14;
                }
                case 1419736915: {
                    l2 = 0x5AE3L ^ 0xEEC1E64E3254F462L;
                    continue block14;
                }
            }
            break;
        }
        if (this.startMaxShootingStingerTimerMs != null) return;
        long l3 = \u13e8;
        boolean bl2 = true;
        block15: while (true) {
            long l4;
            if (!bl2 || (bl2 = false) || !true) {
                l3 = l4 / (0x4571L ^ 0xB10081FC653126E4L);
            }
            switch ((int)l3) {
                case -1878853128: {
                    l4 = 0x75AAL ^ 0x44BD6C636912CCE3L;
                    continue block15;
                }
                case -3147964: {
                    break block15;
                }
                case 1625109196: {
                    l4 = 0x221CL ^ 0x9A7714DDE4DCD1BBL;
                    continue block15;
                }
            }
            break;
        }
        long l5 = System.currentTimeMillis();
        long l6 = \u13e8;
        block16: while (true) {
            switch ((int)l6) {
                case -3147964: {
                    break block16;
                }
                case 1540784217: {
                    l6 = (0x1D93L ^ 0x84FF321A9C4B61B0L) / (0x1B7EL ^ 0x71B5AF1B710842ECL);
                    continue block16;
                }
            }
            break;
        }
        Long l7 = l5;
        while (true) {
            long l8;
            long l9;
            if ((l9 = (l8 = \u13e8 - (0x7BAFL ^ 0x6989D50539F7FCC4L)) == 0L ? 0 : (l8 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l9 == (0x5971 ^ 0xFFFFA68E)) {
                this.startMaxShootingStingerTimerMs = l7;
                return;
            }
            l9 = 0x587E ^ 0x55544AD;
        }
    }

    /*
     * Unable to fully structure code
     */
    private boolean canLogoutAndSwitchBack() {
        while (true) {
            if ((v0 = (cfr_temp_0 = StingerWarper.\u13e8 - (31900L ^ -1691579238109779930L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v0 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v0 = 16215 ^ -1506661562;
        }
        v1 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl11
        block7: while (true) {
            v1 = v2 / (24716L ^ 7725891591555845585L);
lbl11:
            // 2 sources

            switch ((int)v1) {
                case -1068112348: {
                    v2 = -3197794779600466996L >>> "\u0000\u0000".length();
                    continue block7;
                }
                case -610890037: {
                    v2 = 27204L ^ -2823333722066941361L;
                    continue block7;
                }
                case -3147964: {
                    break block7;
                }
                case 2267080: {
                    v2 = 3160602508966922228L >>> "\u0000\u0000".length();
                    continue block7;
                }
            }
            break;
        }
        return this.backpage.isInstanceValid();
    }

    /*
     * Unable to fully structure code
     */
    private boolean isStingerComplete() {
        block38: {
            block37: {
                while (true) {
                    if ((v0 = (cfr_temp_0 = StingerWarper.\u13e8 - (18300L ^ 8287137445183447342L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                    if (v0 == (2596 ^ -2597)) break;
                    v0 = 11491 ^ -201690645;
                }
                if (!this.hasKilledNpcSubname()) break block37;
                var2_1 = new byte["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
                var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 4444 ^ 4411;
                var2_1[13370 ^ 13369] = 19317 ^ 19225;
                var2_1[29213 ^ 29201] = 31105 ^ 31220;
                var2_1[4932 ^ 4932] = 300 >>> "\u0000\u0000".length();
                var2_1[851 ^ 855] = 404 >>> "\u0000\u0000".length();
                var2_1[8852 ^ 8849] = 9383 ^ 9411;
                var2_1[27319 ^ 27324] = 460 >>> "\u0000\u0000".length();
                var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 11642 ^ 11610;
                var2_1[31183 ^ 31174] = 396 >>> "\u0000\u0000".length();
                var2_1[7191 ^ 7199] = 10642 ^ 10722;
                var2_1[24200 ^ 24197] = 392 >>> "\u0000\u0000".length();
                var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 19003 ^ 19031;
                var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 404 >>> "\u0000\u0000".length();
                var2_1[728 ^ 729] = 19030 ^ 19007;
                var2_1[26209 ^ 26223] = 27918 ^ 28000;
                var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 24725 ^ 24824;
                var2_1[12666 ^ 12669] = 440 >>> "\u0000\u0000".length();
                var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 128 >>> "\u0000\u0000".length();
                var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 388 >>> "\u0000\u0000".length();
                v1 = new String(var2_1);
                v2 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl32
                block22: while (true) {
                    v2 = v3 / (24259L ^ 6890845152864636741L);
lbl32:
                    // 2 sources

                    switch ((int)v2) {
                        case -3147964: {
                            break block22;
                        }
                        case 178138826: {
                            v3 = 2962L ^ 1896429994738899736L;
                            continue block22;
                        }
                        case 773298979: {
                            v3 = 28086L ^ 8197204543968117608L;
                            continue block22;
                        }
                        case 1916509854: {
                            v3 = 2905L ^ 3607862886799055682L;
                            continue block22;
                        }
                    }
                    break;
                }
                this.switchBackReason = v1;
                return "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
            }
            v4 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl51
            block23: while (true) {
                v4 = v5 / (8352L ^ -4418738751500971558L);
lbl51:
                // 2 sources

                switch ((int)v4) {
                    case -3147964: {
                        break block23;
                    }
                    case 486649731: {
                        v5 = 3108L ^ -8848366832453747619L;
                        continue block23;
                    }
                    case 1348984815: {
                        v5 = 7078L ^ 5209962186415532299L;
                        continue block23;
                    }
                }
                break;
            }
            if (this.maxStingerWaitTimeEllapsed()) {
                var2_2 = new byte[136 >>> "\u0000\u0000".length()];
                var2_2[19396 ^ 19405] = 7262 ^ 7273;
                var2_2[8184 ^ 8177] = 468 >>> "\u0000\u0000".length();
                var2_2[7743 ^ 7725] = 420 >>> "\u0000\u0000".length();
                var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 436 >>> "\u0000\u0000".length();
                var2_2[17331 ^ 17341] = 10476 ^ 10377;
                var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 2821 ^ 2930;
                var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 460 >>> "\u0000\u0000".length();
                var2_2[21308 ^ 21277] = 1076 ^ 1104;
                var2_2[24480 ^ 24483] = 25630 ^ 25662;
                var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 480 >>> "\u0000\u0000".length();
                var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() ^ "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length()] = 26256 ^ 26354;
                var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 464 >>> "\u0000\u0000".length();
                var2_2[29898 ^ 29918] = 31726 ^ 31694;
                var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 10397 ^ 10483;
                var2_2[7487 ^ 7457] = 10388 ^ 10468;
                var2_2["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 388 >>> "\u0000\u0000".length();
                var2_2[22251 ^ 22244] = 128 >>> "\u0000\u0000".length();
                var2_2[19229 ^ 19214] = 15204 ^ 15120;
                var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 388 >>> "\u0000\u0000".length();
                var2_2[2042 ^ 2029] = 15093 ^ 15000;
                var2_2[10459 ^ 10432] = 432 >>> "\u0000\u0000".length();
                var2_2[30739 ^ 30742] = 11522 ^ 11634;
                var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 18142 ^ 18107;
                var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 20514 ^ 20551;
                var2_2[4151 ^ 4119] = 4377 ^ 4476;
                var2_2[8965 ^ 8961] = 440 >>> "\u0000\u0000".length();
                var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 26436 ^ 26407;
                var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 128 >>> "\u0000\u0000".length();
                var2_2[8988 ^ 8988] = 22321 ^ 22396;
                var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 2817 ^ 2925;
                var2_2[7233 ^ 7238] = 128 >>> "\u0000\u0000".length();
                var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 388 >>> "\u0000\u0000".length();
                var2_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 388 >>> "\u0000\u0000".length();
                var2_2[28554 ^ 28565] = 460 >>> "\u0000\u0000".length();
                var2_2[1304 ^ 1294] = 1260 ^ 1157;
                v6 = new String(var2_2);
                while (true) {
                    if ((v7 = (cfr_temp_1 = StingerWarper.\u13e8 - (4037L ^ 6229684009786267371L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                    if (v7 == (26711 ^ -26712)) break;
                    v7 = 86115276 >>> "\u0000\u0000".length();
                }
                this.switchBackReason = v6;
                return "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
            }
            v8 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl109
            block25: while (true) {
                v8 = v9 / (26053L ^ 5608557145179761144L);
lbl109:
                // 2 sources

                switch ((int)v8) {
                    case -1567550175: {
                        v9 = 20273L ^ 3509092683180275600L;
                        continue block25;
                    }
                    case -3147964: {
                        break block25;
                    }
                    case 701291729: {
                        v9 = 7956L ^ -1195831235364609448L;
                        continue block25;
                    }
                }
                break;
            }
            if (this.maxTimeShootingStingerEllapsed()) {
                var2_3 = new byte[148 >>> "\u0000\u0000".length()];
                var2_3[19087 ^ 19083] = 2017 ^ -1950;
                var2_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 15343 ^ 15259;
                var2_3[28233 ^ 28241] = 21744 ^ 21650;
                var2_3[140 >>> "\u0000\u0000".length()] = 29128 ^ 29101;
                var2_3[25967 ^ 25972] = 8413 ^ 8368;
                var2_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 404 >>> "\u0000\u0000".length();
                var2_3[22089 ^ 22120] = 448 >>> "\u0000\u0000".length();
                var2_3[10292 ^ 10302] = 416 >>> "\u0000\u0000".length();
                var2_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 31189 ^ 31221;
                var2_3[22682 ^ 22677] = 440 >>> "\u0000\u0000".length();
                var2_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 23637 ^ 23610;
                var2_3[32117 ^ 32121] = 26021 ^ 26058;
                var2_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 28090 ^ 28105;
                var2_3["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 29763 ^ 29730;
                var2_3[16672 ^ 16691] = 9473 ^ 9585;
                var2_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 480 >>> "\u0000\u0000".length();
                var2_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 436 >>> "\u0000\u0000".length();
                var2_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 11553 ^ 11521;
                var2_3[12992 ^ 13000] = 27292 ^ 27324;
                var2_3[3129 ^ 3097] = 388 >>> "\u0000\u0000".length();
                var2_3[136 >>> "\u0000\u0000".length()] = 29992 ^ 30043;
                var2_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 396 >>> "\u0000\u0000".length();
                var2_3[9242 ^ 9247] = 420 >>> "\u0000\u0000".length();
                var2_3[21860 ^ 21873] = 128 >>> "\u0000\u0000".length();
                var2_3[20969 ^ 20969] = 308 >>> "\u0000\u0000".length();
                var2_3[29416 ^ 29429] = 128 >>> "\u0000\u0000".length();
                var2_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 404 >>> "\u0000\u0000".length();
                var2_3[21286 ^ 21297] = 13003 ^ 12990;
                var2_3[17487 ^ 17503] = 412 >>> "\u0000\u0000".length();
                var2_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 440 >>> "\u0000\u0000".length();
                var2_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 460 >>> "\u0000\u0000".length();
                var2_3[8818 ^ 8808] = 32729 ^ 32696;
                var2_3[25609 ^ 25604] = 23583 ^ 23659;
                var2_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 440 >>> "\u0000\u0000".length();
                var2_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 432 >>> "\u0000\u0000".length();
                var2_3[144 >>> "\u0000\u0000".length()] = 400 >>> "\u0000\u0000".length();
                var2_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 31029 ^ 31056;
                var2_3[5110 ^ 5112] = 9032 ^ 8993;
                v10 = new String(var2_3);
                while (true) {
                    if ((v11 = (cfr_temp_2 = StingerWarper.\u13e8 - (15419L ^ 6840676506146515652L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                    if (v11 == (11052 ^ -11053)) break;
                    v11 = 20561 ^ 1223257286;
                }
                this.switchBackReason = v10;
                return (boolean)(22317 ^ 22316);
            }
            while (true) {
                if ((v12 = (cfr_temp_3 = StingerWarper.\u13e8 - (27374L ^ -4807832697030295099L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v12 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v12 = 17660 ^ -166903065;
            }
            if (this.deathsMaxed()) {
                var2_4 = new byte[1915 ^ 1911];
                var2_4[9005 ^ 9004] = 7012 ^ -6915;
                var2_4["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 23838 ^ 23931;
                var2_4[18774 ^ 18771] = 13747 ^ 13760;
                var2_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 404 >>> "\u0000\u0000".length();
                var2_4[1130 ^ 1130] = 27229 ^ 27161;
                var2_4[6828 ^ 6830] = 388 >>> "\u0000\u0000".length();
                var2_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 22016 ^ 22125;
                var2_4[32626 ^ 32635] = 480 >>> "\u0000\u0000".length();
                var2_4[30889 ^ 30882] = 400 >>> "\u0000\u0000".length();
                var2_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 464 >>> "\u0000\u0000".length();
                var2_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 26462 ^ 26431;
                var2_4[21916 ^ 21914] = 128 >>> "\u0000\u0000".length();
                var2_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 416 >>> "\u0000\u0000".length();
                v13 = new String(var2_4);
                while (true) {
                    if ((v14 = (cfr_temp_4 = StingerWarper.\u13e8 - (-3274879811693925608L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                    if (v14 == (32536 ^ -32537)) break;
                    v14 = 13271 ^ -711138509;
                }
                this.switchBackReason = v13;
                return "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
            }
            while (true) {
                if ((v15 = (cfr_temp_5 = StingerWarper.\u13e8 - (25011L ^ 7502308330559180499L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                if (v15 == (30005 ^ -30006)) break;
                v15 = 14489 ^ -87063270;
            }
            if (this.botOnWrongStingerMap()) {
                var2_5 = new byte[3702 ^ 3681];
                var2_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 20981 ^ 20893;
                var2_5[5468 ^ 5462] = 128 >>> "\u0000\u0000".length();
                var2_5[19142 ^ 19145] = 1429 ^ 1526;
                var2_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 404 >>> "\u0000\u0000".length();
                var2_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 16279 ^ 16370;
                var2_5[14141 ^ 14132] = 22236 ^ 22194;
                var2_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 448 >>> "\u0000\u0000".length();
                var2_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 128 >>> "\u0000\u0000".length();
                var2_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 440 >>> "\u0000\u0000".length();
                var2_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 31094 ^ 30982;
                var2_5[28987 ^ 28976] = 404 >>> "\u0000\u0000".length();
                var2_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 18420 ^ 18304;
                var2_5[26455 ^ 26459] = 480 >>> "\u0000\u0000".length();
                var2_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 16930 ^ 16898;
                var2_5[1279 ^ 1263] = 464 >>> "\u0000\u0000".length();
                var2_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 388 >>> "\u0000\u0000".length();
                var2_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 10938 ^ 10958;
                var2_5[7447 ^ 7427] = 436 >>> "\u0000\u0000".length();
                var2_5["".length() >>> "\u0000\u0000".length()] = 264 >>> "\u0000\u0000".length();
                var2_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 24402 ^ 24381;
                var2_5[11978 ^ 11977] = 12206 ^ 12174;
                var2_5[30319 ^ 30314] = 3299 ^ 3212;
                var2_5[17653 ^ 17652] = 444 >>> "\u0000\u0000".length();
                var2_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 400 >>> "\u0000\u0000".length();
                v16 = new String(var2_5);
                while (true) {
                    if ((v17 = (cfr_temp_6 = StingerWarper.\u13e8 - (31434L ^ 8010886384564863714L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                    if (v17 == (27260 ^ -27261)) break;
                    v17 = 1063838512 >>> "\u0000\u0000".length();
                }
                this.switchBackReason = v16;
                return "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
            }
            while (true) {
                if ((v18 = (cfr_temp_7 = StingerWarper.\u13e8 - (16365L ^ 5645891639738017153L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                if (v18 == (3365 ^ -3366)) break;
                v18 = 903199120 >>> "\u0000\u0000".length();
            }
            if (!this.maxTimeOnStingerConfigEllapsed()) break block38;
            var2_6 = new byte[16256 ^ 16284];
            var2_6[12614 ^ 12613] = 148 >>> "\u0000\u0000".length();
            var2_6["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 23905 ^ 23873;
            var2_6["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 436 >>> "\u0000\u0000".length();
            var2_6["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 15735 ^ 15634;
            var2_6[22160 ^ 22147] = 448 >>> "\u0000\u0000".length();
            var2_6[3423 ^ 3405] = 20576 ^ 20481;
            var2_6["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 4408 ^ 4438;
            var2_6[9747 ^ 9754] = 444 >>> "\u0000\u0000".length();
            var2_6["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 400 >>> "\u0000\u0000".length();
            var2_6["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 29439 ^ 29320;
            var2_6[27861 ^ 27863] = 9635 ^ 9691;
            var2_6[562 ^ 551] = 5968 ^ 5941;
            var2_6[2866 ^ 2868] = 436 >>> "\u0000\u0000".length();
            var2_6[26768 ^ 26769] = 388 >>> "\u0000\u0000".length();
            var2_6["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 13241 ^ 13258;
            var2_6[15832 ^ 15816] = 25519 ^ 25487;
            var2_6["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 460 >>> "\u0000\u0000".length();
            var2_6["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 31781 ^ 31829;
            var2_6["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 388 >>> "\u0000\u0000".length();
            var2_6[7236 ^ 7236] = 308 >>> "\u0000\u0000".length();
            var2_6[13474 ^ 13484] = 388 >>> "\u0000\u0000".length();
            var2_6[13914 ^ 13918] = 29306 ^ 29198;
            var2_6["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 128 >>> "\u0000\u0000".length();
            var2_6[6493 ^ 6482] = 6955 ^ 7003;
            var2_6[21077 ^ 21057] = "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() ^ "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length();
            var2_6["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 13446 ^ 13551;
            var2_6["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 128 >>> "\u0000\u0000".length();
            var2_6[17480 ^ 17502] = 30652 ^ 30672;
            var2_6["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 23079 ^ 23106;
            v19 = new String(var2_6);
            v20 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl274
            block32: while (true) {
                v20 = v21 / (28716L ^ 2265632365395948659L);
lbl274:
                // 2 sources

                switch ((int)v20) {
                    case -984477750: {
                        v21 = 5481L ^ -2827948247163930393L;
                        continue block32;
                    }
                    case -3147964: {
                        break block32;
                    }
                    case 2108394109: {
                        v21 = 3476L ^ 1111016684053582670L;
                        continue block32;
                    }
                }
                break;
            }
            this.switchBackReason = v19;
            return "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        }
        return "".length() >>> "\u0000\u0000".length();
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private Long getMsSpentOnStingerConfig() {
        long l = \u13e8;
        boolean bl = true;
        block20: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x2CD9L ^ 0x626EA79B2CF51460L);
            }
            switch ((int)l) {
                case -3147964: {
                    break block20;
                }
                case 556783103: {
                    l2 = 0x29F0L ^ 0xDE2027E3EB8F91D8L;
                    continue block20;
                }
                case 1901290396: {
                    l2 = 0xC6EL ^ 0xEEB5A03A33D126E9L;
                    continue block20;
                }
            }
            break;
        }
        if (this.startStingerMapTimerMs == null) {
            return null;
        }
        long l3 = \u13e8;
        boolean bl2 = true;
        block21: while (true) {
            long l4;
            if (!bl2 || (bl2 = false) || !true) {
                l3 = l4 / (0x351FL ^ 0x8582F7E88CB29DC8L);
            }
            switch ((int)l3) {
                case -2043203243: {
                    l4 = -5175119802247957604L >>> "\u0000\u0000".length();
                    continue block21;
                }
                case -1976115057: {
                    l4 = 0x6DB7L ^ 0x5DC72016D0ED07E3L;
                    continue block21;
                }
                case -3147964: {
                    break block21;
                }
                case 1771373803: {
                    l4 = 0x59DDL ^ 0xCD4750555D3A5A8DL;
                    continue block21;
                }
            }
            break;
        }
        long l5 = System.currentTimeMillis();
        long l6 = \u13e8;
        block22: while (true) {
            switch ((int)l6) {
                case -3147964: {
                    break block22;
                }
                case 1421863680: {
                    l6 = (0x7552L ^ 0x1BB0C30BF75CF33DL) / (0x509CL ^ 0x2D18FC5F296F3E56L);
                    continue block22;
                }
            }
            break;
        }
        long l7 = \u13e8;
        boolean bl3 = true;
        block23: while (true) {
            long l8;
            if (!bl3 || (bl3 = false) || !true) {
                l7 = l8 / (0x1C85L ^ 0xB74C0748A801AC6FL);
            }
            switch ((int)l7) {
                case -1942217040: {
                    l8 = 0xFD9L ^ 0x5AA16AA7B7EC692CL;
                    continue block23;
                }
                case -1700130214: {
                    l8 = 0x23DL ^ 0xD3534E3CD08A8077L;
                    continue block23;
                }
                case -3147964: {
                    break block23;
                }
            }
            break;
        }
        long l9 = l5 - this.startStingerMapTimerMs;
        while (true) {
            long l10;
            long l11;
            if ((l11 = (l10 = \u13e8 - (0x41F7L ^ 0x809A347A3EB63473L)) == 0L ? 0 : (l10 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l11 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                return l9;
            }
            l11 = 0x1D76 ^ 0xFFDD22DA;
        }
    }

    private PersistentState getPersistentState() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x652DL ^ 0xBA4166559C57419BL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x6EF7 ^ 0x6EF6)) break;
            l2 = 0x45AA ^ 0x5148C265;
        }
        PersistantStoragePathFinder persistantStoragePathFinder = PersistantStoragePathFinder.getInstance();
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = \u13e8 - (0x44D0L ^ 0x7A84C91441EF2DD8L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l3 == (0x3435 ^ 0xFFFFCBCA)) break;
            l3 = 0x44FB ^ 0xAFCD707C;
        }
        PersistentStorage persistentStorage = persistantStoragePathFinder.getPersistentState();
        while (true) {
            long l;
            long l4;
            if ((l4 = (l = \u13e8 - (0x68FL ^ 0xE3F52CA1221C55DBL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l4 == (0x2F22 ^ 0x2F23)) break;
            l4 = 0x2A5A ^ 0x24E9FA40;
        }
        return persistentStorage.STINGER_WARPER;
    }

    /*
     * Unable to fully structure code
     */
    private com.tawaret.tawaplugin.features.mapcyclemodule.states.PersistentState getMapCyclePersistentState() {
        v0 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl5
        block10: while (true) {
            v0 = v1 / (20923L ^ -2263457318593956450L);
lbl5:
            // 2 sources

            switch ((int)v0) {
                case -557563323: {
                    v1 = 31060L ^ -6152009543338167942L;
                    continue block10;
                }
                case -3147964: {
                    break block10;
                }
                case 2026323207: {
                    v1 = 9487L ^ -1164375164044630949L;
                    continue block10;
                }
            }
            break;
        }
        v2 = PersistantStoragePathFinder.getInstance();
        while (true) {
            if ((v3 = (cfr_temp_0 = StingerWarper.\u13e8 - (5582L ^ 2537256614954466891L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v3 == (32427 ^ -32428)) break;
            v3 = 21478 ^ 1282090989;
        }
        v4 = v2.getPersistentState();
        v5 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl25
        block12: while (true) {
            v5 = v6 / (26149L ^ 7602976473832734126L);
lbl25:
            // 2 sources

            switch ((int)v5) {
                case -226714218: {
                    v6 = 24832L ^ -2138015238625362243L;
                    continue block12;
                }
                case -3147964: {
                    break block12;
                }
                case 2129199718: {
                    v6 = 17617L ^ 6065799516749284091L;
                    continue block12;
                }
            }
            break;
        }
        return v4.MAP_CYCLE;
    }

    /*
     * Unable to fully structure code
     */
    private int getMaximumTimeAllowedOnStingerConfig() {
        block70: {
            block72: {
                block71: {
                    v0 = StingerWarper.\u13e8;
                    if (true) ** GOTO lbl5
                    block52: while (true) {
                        v0 = (20373L ^ -47904728645073065L) / (20801L ^ -4744544996561315224L);
lbl5:
                        // 2 sources

                        switch ((int)v0) {
                            case -1803915052: {
                                continue block52;
                            }
                            case -3147964: {
                                break block52;
                            }
                        }
                        break;
                    }
                    v1 = StingerWarper.\u13e8;
                    if (true) ** GOTO lbl14
                    block53: while (true) {
                        v1 = v2 / (5476L ^ 9210289157018159825L);
lbl14:
                        // 2 sources

                        switch ((int)v1) {
                            case -3147964: {
                                break block53;
                            }
                            case 1966807960: {
                                v2 = 20566L ^ -2727525431691628821L;
                                continue block53;
                            }
                            case 2119243034: {
                                v2 = 10473L ^ -3279474202803584252L;
                                continue block53;
                            }
                        }
                        break;
                    }
                    v3 = this.config._STINGER_CONFIG;
                    while (true) {
                        if ((v4 = (cfr_temp_0 = StingerWarper.\u13e8 - (7524L ^ -4779659717720063189L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                        if (v4 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                        v4 = 18475 ^ 1998835111;
                    }
                    base = v3.MAX_TIME_ON_STINGER_CONFIG;
                    while (true) {
                        if ((v5 = (cfr_temp_1 = StingerWarper.\u13e8 - (14379L ^ 6445380789195065525L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                        if (v5 == (8154 ^ -8155)) break;
                        v5 = 29166 ^ -365148987;
                    }
                    v6 = StingerWarper.\u13e8;
                    if (true) ** GOTO lbl39
                    block56: while (true) {
                        v6 = v7 / (17897L ^ 8632917344379272102L);
lbl39:
                        // 2 sources

                        switch ((int)v6) {
                            case -1187315223: {
                                v7 = 28160L ^ -2860755887473216331L;
                                continue block56;
                            }
                            case -3147964: {
                                break block56;
                            }
                            case 1085053669: {
                                v7 = -746797339333191800L >>> "\u0000\u0000".length();
                                continue block56;
                            }
                        }
                        break;
                    }
                    v8 = this.config.MAP_CYCLE_LINK_CONFIG;
                    while (true) {
                        if ((v9 = (cfr_temp_2 = StingerWarper.\u13e8 - (7306L ^ -3993141269697368674L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                        if (v9 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                        v9 = 1438 ^ -1651346929;
                    }
                    if (!v8.LINK_TO_MAP_CYCLE) break block70;
                    v10 = StingerWarper.\u13e8;
                    if (true) ** GOTO lbl59
                    block58: while (true) {
                        v10 = v11 / (29423L ^ -7229480375309000549L);
lbl59:
                        // 2 sources

                        switch ((int)v10) {
                            case -1250709080: {
                                v11 = 6955L ^ 6162764331936475235L;
                                continue block58;
                            }
                            case -1042021945: {
                                v11 = 10613L ^ -7451257703059856905L;
                                continue block58;
                            }
                            case -3147964: {
                                break block58;
                            }
                            case 222767460: {
                                v11 = 3243L ^ -7975834488624959611L;
                                continue block58;
                            }
                        }
                        break;
                    }
                    v12 = this.getPersistentState();
                    v13 = StingerWarper.\u13e8;
                    if (true) ** GOTO lbl76
                    block59: while (true) {
                        v13 = (20313L ^ 5416909004407760220L) / (9275L ^ -6292150836217568348L);
lbl76:
                        // 2 sources

                        switch ((int)v13) {
                            case -1567488273: {
                                continue block59;
                            }
                            case -3147964: {
                                break block59;
                            }
                        }
                        break;
                    }
                    cachedMapCycleModuleWaitSeconds = v12.getCachedMapCycleWaitSeconds();
                    if (cachedMapCycleModuleWaitSeconds != null) break block71;
                    v14 = StingerWarper.\u13e8;
                    if (true) ** GOTO lbl87
                    block60: while (true) {
                        v14 = (16953L ^ 6211297072640619009L) / (26665L ^ 2866598560580480921L);
lbl87:
                        // 2 sources

                        switch ((int)v14) {
                            case -3147964: {
                                break block60;
                            }
                            case 1910541132: {
                                continue block60;
                            }
                        }
                        break;
                    }
                    v15 = StingerWarper.\u13e8;
                    if (true) ** GOTO lbl96
                    block61: while (true) {
                        v15 = (16115L ^ 7782966090734475446L) / (22197L ^ -3998388417518069022L);
lbl96:
                        // 2 sources

                        switch ((int)v15) {
                            case -2107197887: {
                                continue block61;
                            }
                            case -3147964: {
                                break block61;
                            }
                        }
                        break;
                    }
                    v16 = this.config.MAP_CYCLE_LINK_CONFIG;
                    while (true) {
                        if ((v17 = (cfr_temp_3 = StingerWarper.\u13e8 - (6174L ^ 8728499996512056699L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                        if (v17 == (19813 ^ -19814)) break;
                        v17 = 32109 ^ -881934293;
                    }
                    v18 = v16.WAIT_AFTER_KILL_PREDICTED_SPAWN_THRESH;
                    break block72;
                }
                while (true) {
                    if ((v19 = (cfr_temp_4 = StingerWarper.\u13e8 - (23781L ^ 6564918714506140958L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                    if (v19 == (2187 ^ -2188)) {
                        v18 = cachedMapCycleModuleWaitSeconds;
                        break;
                    }
                    v19 = 9008 ^ 1495897692;
                }
            }
            op = v18;
            v20 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl123
            block64: while (true) {
                v20 = (26117L ^ 6870967860343818506L) / (19106L ^ -8444849961575546900L);
lbl123:
                // 2 sources

                switch ((int)v20) {
                    case -3147964: {
                        break block64;
                    }
                    case 2026403403: {
                        continue block64;
                    }
                }
                break;
            }
            while (true) {
                if ((v21 = (cfr_temp_5 = StingerWarper.\u13e8 - (18509L ^ 7526854493486194900L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                if (v21 == (24433 ^ -24434)) break;
                v21 = 1096042676 >>> "\u0000\u0000".length();
            }
            v22 = this.config.MAP_CYCLE_LINK_CONFIG;
            v23 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl138
            block66: while (true) {
                v23 = v24 / (6666L ^ -8998486116644109140L);
lbl138:
                // 2 sources

                switch ((int)v23) {
                    case -1849177835: {
                        v24 = 2741L ^ -342871885679123899L;
                        continue block66;
                    }
                    case -3147964: {
                        break block66;
                    }
                    case 468611361: {
                        v24 = 12449L ^ -4626553921705106811L;
                        continue block66;
                    }
                    case 1452390899: {
                        v24 = 2152L ^ -1696956079025442688L;
                        continue block66;
                    }
                }
                break;
            }
            v25 = op - (long)v22.OFFSET_WAIT_AFTER_KILL_PREDICTED_SPAWN_THRESH;
            v26 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl155
            block67: while (true) {
                v26 = (277L ^ -4874126060468242204L) / (5450L ^ 6546242795438049721L);
lbl155:
                // 2 sources

                switch ((int)v26) {
                    case -1908466033: {
                        continue block67;
                    }
                    case -3147964: {
                        break block67;
                    }
                }
                break;
            }
            v27 = Math.max(19637L ^ 19637L, v25);
            v28 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl165
            block68: while (true) {
                v28 = v29 / (15198L ^ 7651374436575536945L);
lbl165:
                // 2 sources

                switch ((int)v28) {
                    case -816337036: {
                        v29 = 32066L ^ -5536989408344997902L;
                        continue block68;
                    }
                    case -233097923: {
                        v29 = 5138L ^ 1025881072108787847L;
                        continue block68;
                    }
                    case -3147964: {
                        break block68;
                    }
                    case 1366395789: {
                        v29 = 24747L ^ -3098468718756185703L;
                        continue block68;
                    }
                }
                break;
            }
            return Math.toIntExact(v27);
        }
        return base;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private boolean maxTimeOnStingerConfigEllapsed() {
        boolean bl;
        Long timeSpentOnStingerConfig;
        long l = \u13e8;
        boolean bl2 = true;
        block22: while (true) {
            long l2;
            if (!bl2 || (bl2 = false) || !true) {
                l = l2 / (0x33F4L ^ 0xFE1CBCF431730272L);
            }
            switch ((int)l) {
                case -227603925: {
                    l2 = 0x591EL ^ 0x70C7424F541E1F72L;
                    continue block22;
                }
                case -108357146: {
                    l2 = 0x338BL ^ 0x21550D7D7D4745D5L;
                    continue block22;
                }
                case -3147964: {
                    break block22;
                }
                case 1776686116: {
                    l2 = 0x4E65L ^ 0x3FEFEECEDDA7850L;
                    continue block22;
                }
            }
            break;
        }
        int maxTime = this.getMaximumTimeAllowedOnStingerConfig();
        if (maxTime < 0) {
            return "".length() >>> "\u0000\u0000".length();
        }
        while (true) {
            long l3;
            long l4;
            if ((l4 = (l3 = \u13e8 - (0x291L ^ 0xCCA048F85B2B7EDDL)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l4 == (0x5902 ^ 0x5903)) {
                timeSpentOnStingerConfig = this.getMsSpentOnStingerConfig();
                if (timeSpentOnStingerConfig == null) {
                    return "".length() >>> "\u0000\u0000".length() != 0;
                }
                break;
            }
            l4 = 0x56C5 ^ 0xCF94862E;
        }
        long l5 = \u13e8;
        boolean bl3 = true;
        block24: while (true) {
            long l6;
            if (!bl3 || (bl3 = false) || !true) {
                l5 = l6 / (0x7596L ^ 0x150969DA87D12257L);
            }
            switch ((int)l5) {
                case -3147964: {
                    break block24;
                }
                case 483504378: {
                    l6 = 0x4DAL ^ 0x4108FAE6481DE17FL;
                    continue block24;
                }
                case 1755573926: {
                    l6 = 0x1DD6L ^ 0x542B35BC55E0FC52L;
                    continue block24;
                }
            }
            break;
        }
        long l7 = timeSpentOnStingerConfig;
        long l8 = \u13e8;
        boolean bl4 = true;
        block25: while (true) {
            long l9;
            if (!bl4 || (bl4 = false) || !true) {
                l8 = l9 / (0x12FCL ^ 0x78308A45C6EF0BCEL);
            }
            switch ((int)l8) {
                case -1015068523: {
                    l9 = 0x6BC7L ^ 0x77AFA2DA0A7B8BCFL;
                    continue block25;
                }
                case -767694485: {
                    l9 = 0x4B04L ^ 0x562BA3F5B220F81FL;
                    continue block25;
                }
                case -3147964: {
                    break block25;
                }
            }
            break;
        }
        long l10 = maxTime;
        long l11 = \u13e8;
        boolean bl5 = true;
        block26: while (true) {
            long l12;
            if (!bl5 || (bl5 = false) || !true) {
                l11 = l12 / (0x3627L ^ 0xDCD284CD0D4CF7BBL);
            }
            switch ((int)l11) {
                case -3147964: {
                    break block26;
                }
                case 493304147: {
                    l12 = 0x6E49L ^ 0xB3884C046D95F2DFL;
                    continue block26;
                }
                case 1895826676: {
                    l12 = 0x1434L ^ 0x8F1A89C4FB4DEA5BL;
                    continue block26;
                }
                case 2141354603: {
                    l12 = 0x4E9CL ^ 0x8E850233ED21FBC8L;
                    continue block26;
                }
            }
            break;
        }
        if (l7 >= TimeUnit.SECONDS.toMillis(l10)) {
            bl = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
            return bl;
        }
        bl = "".length() >>> "\u0000\u0000".length();
        return bl;
    }

    /*
     * Unable to fully structure code
     */
    private boolean botOnWrongStingerMap() {
        block74: {
            while (true) {
                if ((v0 = (cfr_temp_0 = StingerWarper.\u13e8 - (2836872441555531892L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v0 == (2046 ^ 2047)) break;
                v0 = 11399 ^ 1050726580;
            }
            while (true) {
                if ((v1 = (cfr_temp_1 = StingerWarper.\u13e8 - (17591L ^ 7076504832675824909L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v1 == (1206 ^ -1207)) break;
                v1 = 27181 ^ 1056892654;
            }
            v2 = this.config.HANGAR_CHANGE_CONFIG;
            v3 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl16
            block61: while (true) {
                v3 = v4 / (23217L ^ 6310844440285808961L);
lbl16:
                // 2 sources

                switch ((int)v3) {
                    case -1636808532: {
                        v4 = 26566L ^ -2105944599581009417L;
                        continue block61;
                    }
                    case -3147964: {
                        break block61;
                    }
                    case 189922245: {
                        v4 = -8447030084695513672L >>> "\u0000\u0000".length();
                        continue block61;
                    }
                    case 1203198419: {
                        v4 = 5173L ^ -4394689721247960604L;
                        continue block61;
                    }
                }
                break;
            }
            if (!v2.USE_HANGAR_CHANGE) {
                return "".length() >>> "\u0000\u0000".length();
            }
            v5 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl34
            block62: while (true) {
                v5 = (18408L ^ 7841436264365397587L) / (19549L ^ -1650286746065206842L);
lbl34:
                // 2 sources

                switch ((int)v5) {
                    case -3147964: {
                        break block62;
                    }
                    case 660094755: {
                        continue block62;
                    }
                }
                break;
            }
            v6 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl43
            block63: while (true) {
                v6 = v7 / (21807L ^ 6274452147883507497L);
lbl43:
                // 2 sources

                switch ((int)v6) {
                    case -1129672088: {
                        v7 = 4692L ^ -4532691230507178380L;
                        continue block63;
                    }
                    case -3147964: {
                        break block63;
                    }
                    case 470413619: {
                        v7 = -5740758215847699804L >>> "\u0000\u0000".length();
                        continue block63;
                    }
                    case 1719761700: {
                        v7 = 9799L ^ -8394053698836594649L;
                        continue block63;
                    }
                }
                break;
            }
            v8 = this.config.HANGAR_CHANGE_CONFIG;
            while (true) {
                if ((v9 = (cfr_temp_2 = StingerWarper.\u13e8 - (8780L ^ -6156193769230031961L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v9 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v9 = 1494 ^ -169380010;
            }
            if (!v8.ENFORCE_STINGER_MAP) break block74;
            v10 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl66
            block65: while (true) {
                v10 = v11 / (2634L ^ 8722910038328619374L);
lbl66:
                // 2 sources

                switch ((int)v10) {
                    case -1038758323: {
                        v11 = 11803L ^ -6631945518451958379L;
                        continue block65;
                    }
                    case -3147964: {
                        break block65;
                    }
                    case 1332070187: {
                        v11 = 7882121093359056000L >>> "\u0000\u0000".length();
                        continue block65;
                    }
                }
                break;
            }
            v12 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl79
            block66: while (true) {
                v12 = v13 / (25124L ^ -200562937459348445L);
lbl79:
                // 2 sources

                switch ((int)v12) {
                    case -433768293: {
                        v13 = 4200L ^ 6944388494483708816L;
                        continue block66;
                    }
                    case -3147964: {
                        break block66;
                    }
                    case 234092135: {
                        v13 = 6742L ^ -8403866655878682301L;
                        continue block66;
                    }
                    case 1001454081: {
                        v13 = 30693L ^ 6656933874992833640L;
                        continue block66;
                    }
                }
                break;
            }
            v14 = this.config.HANGAR_CHANGE_CONFIG;
            v15 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl96
            block67: while (true) {
                v15 = v16 / (13110L ^ 4407523205463354695L);
lbl96:
                // 2 sources

                switch ((int)v15) {
                    case -1471302937: {
                        v16 = 14632L ^ -7468146403449044170L;
                        continue block67;
                    }
                    case -3147964: {
                        break block67;
                    }
                    case 1208908289: {
                        v16 = 2787343602057605484L >>> "\u0000\u0000".length();
                        continue block67;
                    }
                    case 1304081534: {
                        v16 = 1883L ^ 3083060006932757243L;
                        continue block67;
                    }
                }
                break;
            }
            expectedStingerMap = v14.STINGER_MAP;
            if (expectedStingerMap == null) break block74;
            v17 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl114
            block68: while (true) {
                v17 = v18 / (8796L ^ -2106439553962547387L);
lbl114:
                // 2 sources

                switch ((int)v17) {
                    case -1881256271: {
                        v18 = 29970L ^ 1416064141857142469L;
                        continue block68;
                    }
                    case -282037794: {
                        v18 = 7760266688662927212L >>> "\u0000\u0000".length();
                        continue block68;
                    }
                    case -3147964: {
                        break block68;
                    }
                    case 81924844: {
                        v18 = 18947L ^ 5403074147492631472L;
                        continue block68;
                    }
                }
                break;
            }
            if (expectedStingerMap < 0) break block74;
            v19 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl131
            block69: while (true) {
                v19 = v20 / (5927L ^ 5576363254099490682L);
lbl131:
                // 2 sources

                switch ((int)v19) {
                    case -1764073884: {
                        v20 = 24784L ^ 6958980243604960028L;
                        continue block69;
                    }
                    case -1493010010: {
                        v20 = 7312374504011385428L >>> "\u0000\u0000".length();
                        continue block69;
                    }
                    case -911686689: {
                        v20 = 6140L ^ -2983616757342234506L;
                        continue block69;
                    }
                    case -3147964: {
                        break block69;
                    }
                }
                break;
            }
            v21 = expectedStingerMap;
            v22 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl148
            block70: while (true) {
                v22 = v23 / (20482L ^ 1454184191972894421L);
lbl148:
                // 2 sources

                switch ((int)v22) {
                    case -673409957: {
                        v23 = -4461652615235121028L >>> "\u0000\u0000".length();
                        continue block70;
                    }
                    case -660886949: {
                        v23 = 2827614959928223300L >>> "\u0000\u0000".length();
                        continue block70;
                    }
                    case -3147964: {
                        break block70;
                    }
                }
                break;
            }
            v24 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl161
            block71: while (true) {
                v24 = (1174L ^ -5363660000115771955L) / (28695L ^ -2427967156830260072L);
lbl161:
                // 2 sources

                switch ((int)v24) {
                    case -3147964: {
                        break block71;
                    }
                    case 222534782: {
                        continue block71;
                    }
                }
                break;
            }
            v25 = this.hero.map;
            v26 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl171
            block72: while (true) {
                v26 = v27 / (28635L ^ -4561220080636087975L);
lbl171:
                // 2 sources

                switch ((int)v26) {
                    case -1699696088: {
                        v27 = 15978L ^ 6554098472970472995L;
                        continue block72;
                    }
                    case -3147964: {
                        break block72;
                    }
                    case 1653196338: {
                        v27 = -1500290909007402004L >>> "\u0000\u0000".length();
                        continue block72;
                    }
                }
                break;
            }
            return (boolean)(v21 != v25.id ? "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length() : 8282 ^ 8282);
        }
        return "".length() >>> "\u0000\u0000".length();
    }

    /*
     * Unable to fully structure code
     */
    private boolean deathsMaxed() {
        while (true) {
            if ((v0 = (cfr_temp_0 = StingerWarper.\u13e8 - (15679L ^ 5944350151972818574L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == ("\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() ^ -73)) break;
            v0 = 3923 ^ 1762202385;
        }
        v1 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl10
        block24: while (true) {
            v1 = v2 / (3831L ^ 6949318976385450827L);
lbl10:
            // 2 sources

            switch ((int)v1) {
                case -1104916832: {
                    v2 = 14566L ^ -5109035926942536280L;
                    continue block24;
                }
                case -922913036: {
                    v2 = 24707L ^ -8712467283117432162L;
                    continue block24;
                }
                case -921121730: {
                    v2 = 7018011275283899448L >>> "\u0000\u0000".length();
                    continue block24;
                }
                case -3147964: {
                    break block24;
                }
            }
            break;
        }
        v3 = this.config._STINGER_CONFIG;
        v4 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl27
        block25: while (true) {
            v4 = v5 / (25393L ^ -158433450140016298L);
lbl27:
            // 2 sources

            switch ((int)v4) {
                case -782176169: {
                    v5 = 5754L ^ 3877433050349749592L;
                    continue block25;
                }
                case -576559832: {
                    v5 = 1083L ^ 8096828192855856833L;
                    continue block25;
                }
                case -3147964: {
                    break block25;
                }
                case 1904664147: {
                    v5 = 10037L ^ 8192887855966385431L;
                    continue block25;
                }
            }
            break;
        }
        if (v3.MAX_STINGER_MAP_DEATHS <= 0) {
            return "".length() >>> "\u0000\u0000".length();
        }
        v6 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl45
        block26: while (true) {
            v6 = v7 / (31712L ^ -6139383050829272706L);
lbl45:
            // 2 sources

            switch ((int)v6) {
                case -3147964: {
                    break block26;
                }
                case 235804321: {
                    v7 = 21832L ^ 7287972810820079366L;
                    continue block26;
                }
                case 545450180: {
                    v7 = 26994L ^ -4921178067178406291L;
                    continue block26;
                }
            }
            break;
        }
        v8 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl58
        block27: while (true) {
            v8 = v9 / (20641L ^ 7282263711505813823L);
lbl58:
            // 2 sources

            switch ((int)v8) {
                case -654382306: {
                    v9 = 20532L ^ -585984973481132927L;
                    continue block27;
                }
                case -3147964: {
                    break block27;
                }
                case 362744534: {
                    v9 = 18612L ^ -7769735676977281168L;
                    continue block27;
                }
                case 1645181885: {
                    v9 = 23708L ^ 905204969722195607L;
                    continue block27;
                }
            }
            break;
        }
        while (true) {
            if ((v10 = (cfr_temp_1 = StingerWarper.\u13e8 - (9069L ^ -264536690197466369L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v10 == (26253 ^ 26252)) break;
            v10 = 29561 ^ -673728555;
        }
        v11 = this.config._STINGER_CONFIG;
        while (true) {
            if ((v12 = (cfr_temp_2 = StingerWarper.\u13e8 - (26752L ^ 2241003835621637955L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v12 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v12 = 19988 ^ -972777642;
        }
        return this.seenDeaths >= v11.MAX_STINGER_MAP_DEATHS ? "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length() : "".length() >>> "\u0000\u0000".length();
    }

    /*
     * Unable to fully structure code
     */
    private void updateKnownDeathsOnStingerMap() {
        block49: {
            while (true) {
                if ((v0 = (cfr_temp_0 = StingerWarper.\u13e8 - (15565L ^ -6767596053619133452L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (v0 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v0 = 30427 ^ 607113953;
            }
            v1 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl11
            block32: while (true) {
                v1 = v2 / (31842L ^ -8879005844402545815L);
lbl11:
                // 2 sources

                switch ((int)v1) {
                    case -1043984250: {
                        v2 = 24807L ^ 486531025512796262L;
                        continue block32;
                    }
                    case -688018109: {
                        v2 = 11037L ^ -1171655516993362679L;
                        continue block32;
                    }
                    case -3147964: {
                        break block32;
                    }
                    case 1170027008: {
                        v2 = 24133L ^ -2055375464147568533L;
                        continue block32;
                    }
                }
                break;
            }
            v3 = this.main.guiManager;
            while (true) {
                if ((v4 = (cfr_temp_1 = StingerWarper.\u13e8 - (2693L ^ -114427867634977299L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (v4 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v4 = -446143716 >>> "\u0000\u0000".length();
            }
            curDeaths = v3.deaths;
            v5 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl35
            block34: while (true) {
                v5 = v6 / (24242L ^ -2795716239179836120L);
lbl35:
                // 2 sources

                switch ((int)v5) {
                    case -999810646: {
                        v6 = 473L ^ 9128244792997723819L;
                        continue block34;
                    }
                    case -202220003: {
                        v6 = 23680L ^ 4765775374434258466L;
                        continue block34;
                    }
                    case -3147964: {
                        break block34;
                    }
                }
                break;
            }
            if (this.lastKnownDeaths == null) break block49;
            v7 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl49
            block35: while (true) {
                v7 = v8 / (7461L ^ 1270348623978118064L);
lbl49:
                // 2 sources

                switch ((int)v7) {
                    case -1757862308: {
                        v8 = 19270L ^ 7248728063297148548L;
                        continue block35;
                    }
                    case -3147964: {
                        break block35;
                    }
                    case 830703629: {
                        v8 = 28930L ^ -1980803957061291248L;
                        continue block35;
                    }
                    case 952079679: {
                        v8 = 20363L ^ -1273393600607358318L;
                        continue block35;
                    }
                }
                break;
            }
            while (true) {
                if ((v9 = (cfr_temp_2 = StingerWarper.\u13e8 - (6873L ^ -7694863906541348865L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (v9 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v9 = 18972 ^ -713258550;
            }
            if (this.lastKnownDeaths >= curDeaths) break block49;
            while (true) {
                if ((v10 = (cfr_temp_3 = StingerWarper.\u13e8 - (5059L ^ 5584730542549653038L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (v10 == (4519 ^ -4520)) break;
                v10 = 9997 ^ -1578389362;
            }
            while (true) {
                if ((v11 = (cfr_temp_4 = StingerWarper.\u13e8 - (20363L ^ -5206654710719854540L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (v11 == (14077 ^ 14076)) break;
                v11 = 28884 ^ -1377096812;
            }
            while (true) {
                if ((v12 = (cfr_temp_5 = StingerWarper.\u13e8 - (22647L ^ -4864437919650118554L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (v12 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v12 = 10274 ^ -1607502691;
            }
            v13 = this.seenDeaths + (curDeaths - this.lastKnownDeaths);
            v14 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl91
            block40: while (true) {
                v14 = v15 / (25061L ^ -194191790221533809L);
lbl91:
                // 2 sources

                switch ((int)v14) {
                    case -2129480164: {
                        v15 = 8596L ^ -2189642675813148254L;
                        continue block40;
                    }
                    case -3147964: {
                        break block40;
                    }
                    case 848251730: {
                        v15 = 26581L ^ -7537898790344910362L;
                        continue block40;
                    }
                }
                break;
            }
            this.seenDeaths = v13;
        }
        v16 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl106
        block41: while (true) {
            v16 = v17 / (32023L ^ -8886779897499153100L);
lbl106:
            // 2 sources

            switch ((int)v16) {
                case -793784566: {
                    v17 = 24056L ^ 5896988223312640051L;
                    continue block41;
                }
                case -3147964: {
                    break block41;
                }
                case 2111412284: {
                    v17 = 14773L ^ -3045049620899835799L;
                    continue block41;
                }
            }
            break;
        }
        v18 = curDeaths;
        v19 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl120
        block42: while (true) {
            v19 = (26291L ^ 2609855307728296344L) / (30714L ^ 9019422975948170480L);
lbl120:
            // 2 sources

            switch ((int)v19) {
                case -3147964: {
                    break block42;
                }
                case 1585809266: {
                    continue block42;
                }
            }
            break;
        }
        this.lastKnownDeaths = v18;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private void resetStingerDeathState() {
        int n = "".length() >>> "\u0000\u0000".length();
        long l = \u13e8;
        boolean bl = true;
        block6: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (8575552306973104400L >>> "\u0000\u0000".length());
            }
            switch ((int)l) {
                case -959499829: {
                    l2 = 0x3601L ^ 0x51683B07DFA29F2FL;
                    continue block6;
                }
                case -3147964: {
                    break block6;
                }
                case 1875440127: {
                    l2 = 4300178516590164528L >>> "\u0000\u0000".length();
                    continue block6;
                }
                case 2034783106: {
                    l2 = 0x7DDDL ^ 0xBC1874432E2A9CAEL;
                    continue block6;
                }
            }
            break;
        }
        this.seenDeaths = n;
        while (true) {
            long l3;
            long l4;
            if ((l4 = (l3 = \u13e8 - (0x3EA6L ^ 0xC0428B020B6C4103L)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l4 == (0x2B9D ^ 0x2B9C)) {
                this.lastKnownDeaths = null;
                return;
            }
            l4 = 1130388444 >>> "\u0000\u0000".length();
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private boolean shouldChangeToStinger() {
        int n;
        block38: {
            long l = \u13e8;
            boolean bl = true;
            block23: while (true) {
                long l2;
                if (!bl || (bl = false) || !true) {
                    l = l2 / (0x38L ^ 0x957BB9A0D88EFC69L);
                }
                switch ((int)l) {
                    case -1388925597: {
                        l2 = 0x7D5L ^ 0xC866CFA65715A7A0L;
                        continue block23;
                    }
                    case -3147964: {
                        break block23;
                    }
                    case 1945039748: {
                        l2 = 0x6532L ^ 0xDD3D75A9C7979694L;
                        continue block23;
                    }
                }
                break;
            }
            long l3 = \u13e8;
            block24: while (true) {
                switch ((int)l3) {
                    case -3147964: {
                        break block24;
                    }
                    case 426979264: {
                        l3 = (0x7861L ^ 0x7248C131960BB2B3L) / (0x4201L ^ 0x29A5ECB030C6EEB7L);
                        continue block24;
                    }
                }
                break;
            }
            Map map = this.hero.map;
            long l4 = \u13e8;
            boolean bl2 = true;
            block25: while (true) {
                long l5;
                if (!bl2 || (bl2 = false) || !true) {
                    l4 = l5 / (0x717FL ^ 0x98F843067DF8F983L);
                }
                switch ((int)l4) {
                    case -521800009: {
                        l5 = 0x39F4L ^ 0x65D27E947564F98FL;
                        continue block25;
                    }
                    case -3147964: {
                        break block25;
                    }
                    case 321166205: {
                        l5 = 0x6979L ^ 0xFA70CA725C53D3CAL;
                        continue block25;
                    }
                }
                break;
            }
            if (map.gg) {
                return "".length() >>> "\u0000\u0000".length();
            }
            long l6 = \u13e8;
            block26: while (true) {
                switch ((int)l6) {
                    case -3147964: {
                        break block26;
                    }
                    case 1665966538: {
                        l6 = (-6921090200364958864L >>> "\u0000\u0000".length()) / (0xEA6L ^ 0x869CEA06991BB07DL);
                        continue block26;
                    }
                }
                break;
            }
            if (this.getTimeTillNextSingerCheckMs() <= (0x6438L ^ 0x6438L)) {
                long l7 = \u13e8;
                boolean bl3 = true;
                block27: while (true) {
                    long l8;
                    if (!bl3 || (bl3 = false) || !true) {
                        l7 = l8 / (0x7D2FL ^ 0x3DC04BADF326DA48L);
                    }
                    switch ((int)l7) {
                        case -3147964: {
                            break block27;
                        }
                        case 516016466: {
                            l8 = 0x4D3EL ^ 0xF84E51B189D53D8DL;
                            continue block27;
                        }
                        case 1441514738: {
                            l8 = 0x3420L ^ 0x2588806E44AFF646L;
                            continue block27;
                        }
                    }
                    break;
                }
                if (this.mapCycleIsCurrentModule()) {
                    while (true) {
                        long l9;
                        long l10;
                        if ((l10 = (l9 = \u13e8 - (0x28E9L ^ 0xCDDD3E1C63F51027L)) == 0L ? 0 : (l9 < 0L ? -1 : 1)) == false) {
                            continue;
                        }
                        if (l10 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                            if (this.mapCycleModuleAllowsSwap()) {
                                break;
                            }
                            break block38;
                        }
                        l10 = 0x2FDF ^ 0xB68214F6;
                    }
                }
                n = 0x5EA4 ^ 0x5EA5;
                return n != 0;
            }
        }
        n = 0x2AC7 ^ 0x2AC7;
        return n != 0;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private boolean mapCycleModuleAllowsSwap() {
        int shouldChange;
        long l = \u13e8;
        boolean bl = true;
        block11: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x5C84L ^ 0x4CD3B1EA774D0320L);
            }
            switch ((int)l) {
                case -1689253601: {
                    l2 = 0x7ACDL ^ 0xD02DA5AD4EDF5E29L;
                    continue block11;
                }
                case -3147964: {
                    break block11;
                }
                case 1546173911: {
                    l2 = 0x7196L ^ 0x775B11BB6B30C5AEL;
                    continue block11;
                }
            }
            break;
        }
        int n = shouldChange = this.getMapCycleModuleWaitSeconds() != null ? "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length() : "".length() >>> "\u0000\u0000".length();
        if (shouldChange != 0) {
            long l3 = \u13e8;
            boolean bl2 = true;
            block12: while (true) {
                long l4;
                if (!bl2 || (bl2 = false) || !true) {
                    l3 = l4 / (0x439L ^ 0x213A1CCC4208CACDL);
                }
                switch ((int)l3) {
                    case -798342610: {
                        l4 = -6738810364569570856L >>> "\u0000\u0000".length();
                        continue block12;
                    }
                    case -3147964: {
                        break block12;
                    }
                    case 1342923412: {
                        l4 = 0x3E0FL ^ 0x9B71D88149A9DD7BL;
                        continue block12;
                    }
                    case 1975977229: {
                        l4 = 0x1EEAL ^ 0x147F06F14ABE825EL;
                        continue block12;
                    }
                }
                break;
            }
            this.tryStartMapCycleSwapTimer();
            while (true) {
                long l5;
                long l6;
                if ((l6 = (l5 = \u13e8 - (0x1B4AL ^ 0x51EF8167CA62B8F6L)) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (l6 == (0x33EF ^ 0xFFFFCC10)) {
                    return this.hasStartMapCycleSwapTimerComplete();
                }
                l6 = 0xE54 ^ 0x66AF9B70;
            }
        }
        while (true) {
            long l7;
            long l8;
            if ((l8 = (l7 = \u13e8 - (4572236282392501636L >>> "\u0000\u0000".length())) == 0L ? 0 : (l7 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l8 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                this.resetStartMapCycleSwapTimer();
                return (0x6B81 ^ 0x6B81) != 0;
            }
            l8 = 0x4220 ^ 0xE54A1135;
        }
    }

    private void tryStartMapCycleSwapTimer() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x2E8BL ^ 0x5A5D36808113D30DL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x4F77 ^ 0xFFFFB088)) break;
            l2 = 0x3D9B ^ 0xFFF0178B;
        }
        if (this.mapCycleSwapTimer != null) {
            return;
        }
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = \u13e8 - (0x1AEEL ^ 0xE4169676F533C746L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l3 == (0x4927 ^ 0x4926)) break;
            l3 = 921718872 >>> "\u0000\u0000".length();
        }
        long l = System.currentTimeMillis();
        while (true) {
            long l4;
            long l5;
            if ((l5 = (l4 = \u13e8 - (0x31F8L ^ 0x6E763770835357B7L)) == 0L ? 0 : (l4 < 0L ? -1 : 1)) == false) continue;
            if (l5 == (0x2F40 ^ 0xFFFFD0BF)) break;
            l5 = 0x4E61 ^ 0xD28B087E;
        }
        Long l6 = l;
        while (true) {
            long l7;
            long l8;
            if ((l8 = (l7 = \u13e8 - (0x74EAL ^ 0x4A5F484DE44E25F5L)) == 0L ? 0 : (l7 < 0L ? -1 : 1)) == false) continue;
            if (l8 == (0x5103 ^ 0xFFFFAEFC)) break;
            l8 = 0x73ED ^ 0xF3CA6A80;
        }
        this.mapCycleSwapTimer = l6;
    }

    private void resetStartMapCycleSwapTimer() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x37CAL ^ 0x7FE2D0798C4D0633L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x58A5 ^ 0xFFFFA75A)) break;
            l2 = -234288456 >>> "\u0000\u0000".length();
        }
        this.mapCycleSwapTimer = null;
    }

    /*
     * Unable to fully structure code
     */
    private boolean hasStartMapCycleSwapTimerComplete() {
        v0 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl5
        block13: while (true) {
            v0 = (7429L ^ 5703942378820815738L) / (29512L ^ -804071857526940194L);
lbl5:
            // 2 sources

            switch ((int)v0) {
                case -3147964: {
                    break block13;
                }
                case 1739375489: {
                    continue block13;
                }
            }
            break;
        }
        if (this.mapCycleSwapTimer == null) {
            return "".length() >>> "\u0000\u0000".length();
        }
        while (true) {
            if ((v1 = (cfr_temp_0 = StingerWarper.\u13e8 - (7373L ^ -3406960321636422120L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v1 == (29389 ^ 29388)) break;
            v1 = 8591 ^ 1026162743;
        }
        v2 = System.currentTimeMillis();
        while (true) {
            if ((v3 = (cfr_temp_1 = StingerWarper.\u13e8 - (12433L ^ 7861765794912598164L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v3 == (1730 ^ -1731)) break;
            v3 = 30864 ^ -424754317;
        }
        v4 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl27
        block16: while (true) {
            v4 = v5 / (-1208048386164320760L >>> "\u0000\u0000".length());
lbl27:
            // 2 sources

            switch ((int)v4) {
                case -826893993: {
                    v5 = 14121L ^ 7336755125032492839L;
                    continue block16;
                }
                case -3147964: {
                    break block16;
                }
                case 1138655075: {
                    v5 = 15788L ^ -8114930856126633253L;
                    continue block16;
                }
            }
            break;
        }
        v6 = v2 - this.mapCycleSwapTimer;
        while (true) {
            if ((v7 = (cfr_temp_2 = StingerWarper.\u13e8 - (25496L ^ -5460213576812296265L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v7 == (28402 ^ 28403)) break;
            v7 = 5268 ^ 1964905424;
        }
        v8 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl46
        block18: while (true) {
            v8 = (19071L ^ 6564096329979135500L) / (7753L ^ 2896610521341311693L);
lbl46:
            // 2 sources

            switch ((int)v8) {
                case -343641022: {
                    continue block18;
                }
                case -3147964: {
                    break block18;
                }
            }
            break;
        }
        v9 = ellapsed = v6 >= TimeUnit.SECONDS.toMillis(5244L ^ 5240L) ? "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length() : "".length() >>> "\u0000\u0000".length();
        if (ellapsed) {
            while (true) {
                if ((v10 = (cfr_temp_3 = StingerWarper.\u13e8 - (5480L ^ -1805494043628584387L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v10 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                    this.resetStartMapCycleSwapTimer();
                    break;
                }
                v10 = 30461 ^ 60166788;
            }
        }
        return ellapsed;
    }

    /*
     * Unable to fully structure code
     */
    private Long getMapCycleModuleWaitSeconds() {
        block53: {
            v0 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl5
            block31: while (true) {
                v0 = v1 / (3850L ^ 5341062145094976560L);
lbl5:
                // 2 sources

                switch ((int)v0) {
                    case -1693033653: {
                        v1 = 32526L ^ 2698050232715368550L;
                        continue block31;
                    }
                    case -1363067212: {
                        v1 = 491L ^ 4830750500608912201L;
                        continue block31;
                    }
                    case -3147964: {
                        break block31;
                    }
                }
                break;
            }
            v2 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl18
            block32: while (true) {
                v2 = v3 / (28042L ^ 7874148180238265167L);
lbl18:
                // 2 sources

                switch ((int)v2) {
                    case -3147964: {
                        break block32;
                    }
                    case 1009147: {
                        v3 = 8609L ^ 2364364159030349265L;
                        continue block32;
                    }
                    case 1272444529: {
                        v3 = 3051L ^ -1429951760303946481L;
                        continue block32;
                    }
                    case 2077625631: {
                        v3 = 26016L ^ 5915715432841312424L;
                        continue block32;
                    }
                }
                break;
            }
            v4 = this.config.MAP_CYCLE_LINK_CONFIG;
            while (true) {
                if ((v5 = (cfr_temp_0 = StingerWarper.\u13e8 - (30885L ^ -1569682386601892132L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v5 == (1904 ^ 1905)) break;
                v5 = 668 ^ -550728072;
            }
            if (!v4.LINK_TO_MAP_CYCLE) break block53;
            while (true) {
                if ((v6 = (cfr_temp_1 = StingerWarper.\u13e8 - (19074L ^ -4047917591895421042L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v6 == (31235 ^ 31234)) break;
                v6 = 5393 ^ -1481227230;
            }
            mapCycleModule = this.getMapCycleModule();
            if (mapCycleModule == null) break block53;
            while (true) {
                if ((v7 = (cfr_temp_2 = StingerWarper.\u13e8 - (18856L ^ -2692844019379189475L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v7 == (13071 ^ 13070)) break;
                v7 = 14614 ^ -1498364075;
            }
            if (!mapCycleModule.canLeavePreferredRegion()) {
                return null;
            }
            while (true) {
                if ((v8 = (cfr_temp_3 = StingerWarper.\u13e8 - (-4492268715350352336L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v8 == (16301 ^ -16302)) break;
                v8 = 3803 ^ 69576415;
            }
            if (!this.mapCycleCanDecideUsingPredictedSpawnTime(mapCycleModule)) break block53;
            v9 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl61
            block37: while (true) {
                v9 = v10 / (16870L ^ 1283814780894401297L);
lbl61:
                // 2 sources

                switch ((int)v9) {
                    case -170426737: {
                        v10 = 1861398417950696416L >>> "\u0000\u0000".length();
                        continue block37;
                    }
                    case -3147964: {
                        break block37;
                    }
                    case 76907254: {
                        v10 = 19804L ^ -3303335054733974154L;
                        continue block37;
                    }
                }
                break;
            }
            msSinceKilled = mapCycleModule.getMsSinceKilledNpc();
            while (true) {
                if ((v11 = (cfr_temp_4 = StingerWarper.\u13e8 - (459L ^ -8044887081986478896L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v11 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v11 = 10081 ^ -1348754695;
            }
            msTillWithinNPCSpawnPeriod = mapCycleModule.getMsTillWithinNPCSpawnPeriod();
            if (msSinceKilled == null || msTillWithinNPCSpawnPeriod == null) break block53;
            while (true) {
                if ((v12 = (cfr_temp_5 = StingerWarper.\u13e8 - (-6108137708375854796L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                if (v12 == (28153 ^ -28154)) break;
                v12 = 20582 ^ -1128994001;
            }
            v13 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl87
            block40: while (true) {
                v13 = v14 / (2022L ^ 775458425203059328L);
lbl87:
                // 2 sources

                switch ((int)v13) {
                    case -2067687436: {
                        v14 = 2723112999054630544L >>> "\u0000\u0000".length();
                        continue block40;
                    }
                    case -1214294916: {
                        v14 = 11216L ^ -6616214081788881547L;
                        continue block40;
                    }
                    case -615849600: {
                        v14 = 6906L ^ 3256171807841359638L;
                        continue block40;
                    }
                    case -3147964: {
                        break block40;
                    }
                }
                break;
            }
            v15 = msSinceKilled;
            while (true) {
                if ((v16 = (cfr_temp_6 = StingerWarper.\u13e8 - (9266L ^ 5438986821190415407L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                if (v16 == (3292 ^ -3293)) break;
                v16 = 12281 ^ -656402570;
            }
            secondsSinceNpcKilled = TimeUnit.MILLISECONDS.toSeconds(v15);
            tollerance = 11519L ^ 11517L;
            v17 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl111
            block42: while (true) {
                v17 = v18 / (13041L ^ -1629626226098881677L);
lbl111:
                // 2 sources

                switch ((int)v17) {
                    case -3147964: {
                        break block42;
                    }
                    case 487303282: {
                        v18 = 1787L ^ -2958368637141910274L;
                        continue block42;
                    }
                    case 1753175605: {
                        v18 = 9397L ^ 7140289487106485887L;
                        continue block42;
                    }
                }
                break;
            }
            while (true) {
                if ((v19 = (cfr_temp_7 = StingerWarper.\u13e8 - (4776L ^ -2135570583967554613L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                if (v19 == (12835 ^ 12834)) break;
                v19 = -131844272 >>> "\u0000\u0000".length();
            }
            v20 = msTillWithinNPCSpawnPeriod;
            v21 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl130
            block44: while (true) {
                v21 = (6437L ^ -4288196878647050571L) / (9489L ^ 1514432082455519618L);
lbl130:
                // 2 sources

                switch ((int)v21) {
                    case -3147964: {
                        break block44;
                    }
                    case 962131085: {
                        continue block44;
                    }
                }
                break;
            }
            secondsTillWithinNpcSpawnPeriod = TimeUnit.MILLISECONDS.toSeconds(v20);
            if (secondsSinceNpcKilled >= tollerance) {
                while (true) {
                    if ((v22 = (cfr_temp_8 = StingerWarper.\u13e8 - (2339976273075795016L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                    if (v22 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                    v22 = 28315 ^ -240975456;
                }
                while (true) {
                    if ((v23 = (cfr_temp_9 = StingerWarper.\u13e8 - (-2408471058028941356L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
                    if (v23 == (13953 ^ -13954)) break;
                    v23 = 3752 ^ 1768950753;
                }
                v24 = this.config.MAP_CYCLE_LINK_CONFIG;
                while (true) {
                    if ((v25 = (cfr_temp_10 = StingerWarper.\u13e8 - (23835L ^ -8134301965646324084L)) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
                    if (v25 == (25144 ^ 25145)) break;
                    v25 = 17001 ^ 1872599524;
                }
                if (secondsTillWithinNpcSpawnPeriod >= (long)v24.WAIT_AFTER_KILL_PREDICTED_SPAWN_THRESH) {
                    var11_7 = new byte[5794 ^ 5763];
                    var11_7[24889 ^ 24867] = 340 >>> "\u0000\u0000".length();
                    var11_7[10437 ^ 10463] = 388 >>> "\u0000\u0000".length();
                    var11_7["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 476 >>> "\u0000\u0000".length();
                    var11_7["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 128 >>> "\u0000\u0000".length();
                    var11_7[27951 ^ 27962] = 14043 ^ 13995;
                    var11_7["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 20751 ^ 20854;
                    var11_7["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 396 >>> "\u0000\u0000".length();
                    var11_7["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 14155 ^ 14139;
                    var11_7["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 5494 ^ 5380;
                    var11_7[1123 ^ 1133] = 420 >>> "\u0000\u0000".length();
                    var11_7[4340 ^ 4329] = 17147 ^ 17044;
                    var11_7["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 268 >>> "\u0000\u0000".length();
                    var11_7[3009 ^ 3027] = 30976 ^ 31076;
                    var11_7[29242 ^ 29219] = 128 >>> "\u0000\u0000".length();
                    var11_7[6022 ^ 6023] = 20698 ^ 20667;
                    var11_7["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 10437 ^ 10469;
                    var11_7["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 23901 ^ 23864;
                    var11_7[28644 ^ 28661] = 404 >>> "\u0000\u0000".length();
                    var11_7[6927 ^ 6931] = 432 >>> "\u0000\u0000".length();
                    var11_7[32217 ^ 32199] = 26114 ^ 26229;
                    var11_7["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 27534 ^ 27627;
                    var11_7["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 20354 ^ 20386;
                    var11_7[4124 ^ 4124] = 308 >>> "\u0000\u0000".length();
                    var11_7["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 17621 ^ 17585;
                    var11_7[8508 ^ 8499] = 396 >>> "\u0000\u0000".length();
                    var11_7["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 388 >>> "\u0000\u0000".length();
                    var11_7[28145 ^ 28155] = 19575 ^ 19463;
                    var11_7[24495 ^ 24463] = 400 >>> "\u0000\u0000".length();
                    var11_7[29266 ^ 29258] = 440 >>> "\u0000\u0000".length();
                    var11_7[32560 ^ 32555] = 6738 ^ 6718;
                    var11_7[3102 ^ 3086] = 464 >>> "\u0000\u0000".length();
                    var11_7[24517 ^ 24538] = 404 >>> "\u0000\u0000".length();
                    var11_7["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 432 >>> "\u0000\u0000".length();
                    var11_7["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 2373 ^ 2358;
                    v26 = new String(var11_7);
                    while (true) {
                        if ((v27 = (cfr_temp_11 = StingerWarper.\u13e8 - (-6291991547243116420L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
                        if (v27 == (10797 ^ -10798)) break;
                        v27 = 32120 ^ 1812587282;
                    }
                    this.log(v26);
                    while (true) {
                        if ((v28 = (cfr_temp_12 = StingerWarper.\u13e8 - (21282L ^ -9220240625616579317L)) == 0L ? 0 : (cfr_temp_12 < 0L ? -1 : 1)) == false) continue;
                        if (v28 == (18222 ^ 18223)) break;
                        v28 = -1424761872 >>> "\u0000\u0000".length();
                    }
                    return secondsTillWithinNpcSpawnPeriod;
                }
            }
        }
        return null;
    }

    private boolean mapCycleCanDecideUsingWaitAfterKillTime(MapCycleModule mapCycleModule) {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (5964463121728503132L >>> "\u0000\u0000".length())) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l2 = 0x715B ^ 0x49374926;
        }
        return this.mapCycleHasNextMapIdSet(mapCycleModule);
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private boolean mapCycleIsTravelling() {
        int n;
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x5F83L ^ 0x813F9E5FFAB22CD0L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x7C7A ^ 0x7C7B)) break;
            l2 = 0x3C6F ^ 0xA13D2C83;
        }
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = \u13e8 - (0x5B35L ^ 0xCA11F575B1A15CABL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l3 == (0x7F52 ^ 0x7F53)) break;
            l3 = 0x11A0 ^ 0xF7FA0E5E;
        }
        Map map = this.hero.map;
        long l = \u13e8;
        block19: while (true) {
            switch ((int)l) {
                case -1646249926: {
                    l = (0x52AAL ^ 0x79DF55E55753F0BEL) / (-9175503032453228576L >>> "\u0000\u0000".length());
                    continue block19;
                }
                case -3147964: {
                    break block19;
                }
            }
            break;
        }
        int n2 = map.id;
        long l4 = \u13e8;
        block20: while (true) {
            switch ((int)l4) {
                case -694509341: {
                    l4 = (0x72D5L ^ 0x4DAC0108FAB4F791L) / (0x5876L ^ 0x7CEDBDA53002BB5CL);
                    continue block20;
                }
                case -3147964: {
                    break block20;
                }
            }
            break;
        }
        long l5 = \u13e8;
        boolean bl = true;
        block21: while (true) {
            long l6;
            if (!bl || (bl = false) || !true) {
                l5 = l6 / (0x7196L ^ 0xAE36B3D6AEA7D344L);
            }
            switch ((int)l5) {
                case -1627190753: {
                    l6 = -7137939066064229700L >>> "\u0000\u0000".length();
                    continue block21;
                }
                case -503067128: {
                    l6 = 0x167EL ^ 0x336715BF49883404L;
                    continue block21;
                }
                case -3147964: {
                    break block21;
                }
            }
            break;
        }
        Config config = this.main.config;
        while (true) {
            long l7;
            long l8;
            if ((l8 = (l7 = \u13e8 - (0x351AL ^ 0x2228D579A0BDCA30L)) == 0L ? 0 : (l7 < 0L ? -1 : 1)) == false) continue;
            if (l8 == (0x14F4 ^ 0xFFFFEB0B)) break;
            l8 = 0x35E7 ^ 0x8D7D768C;
        }
        Config.General general = config.GENERAL;
        long l9 = \u13e8;
        block23: while (true) {
            switch ((int)l9) {
                case -1904079169: {
                    l9 = (0x31A3L ^ 0xDC400329792ED58EL) / (0x6073L ^ 0xE74C5A65E9F459FDL);
                    continue block23;
                }
                case -3147964: {
                    break block23;
                }
            }
            break;
        }
        if (n2 != general.WORKING_MAP) {
            n = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
            return n != 0;
        }
        n = 0x122A ^ 0x122A;
        return n != 0;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private boolean mapCycleHasNextMapIdSet(MapCycleModule mapCycleModule) {
        boolean bl;
        long l = \u13e8;
        boolean bl2 = true;
        block5: while (true) {
            long l2;
            if (!bl2 || (bl2 = false) || !true) {
                l = l2 / (0x107AL ^ 0xEA1FD671F523EDD7L);
            }
            switch ((int)l) {
                case -856027417: {
                    l2 = 0x792CL ^ 0xA753D897600F9AC4L;
                    continue block5;
                }
                case -3147964: {
                    break block5;
                }
                case 1256157990: {
                    l2 = 0x49E3L ^ 0x9AA438883206E75DL;
                    continue block5;
                }
            }
            break;
        }
        if (mapCycleModule.getNextMapIdAfterWaitKillPeriod() != null) {
            bl = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
            return bl;
        }
        bl = "".length() >>> "\u0000\u0000".length();
        return bl;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private boolean mapCycleCanDecideUsingPredictedSpawnTime(MapCycleModule mapCycleModule) {
        boolean bl;
        block29: {
            block28: {
                long l = \u13e8;
                block17: while (true) {
                    switch ((int)l) {
                        case -3147964: {
                            break block17;
                        }
                        case 248123984: {
                            l = (0x17A1L ^ 0xFBC658B1AD46FEFEL) / (0x725CL ^ 0x8273A9509F837A06L);
                            continue block17;
                        }
                    }
                    break;
                }
                if (!this.mapCycleHasNextMapIdSet(mapCycleModule)) break block28;
                long l2 = \u13e8;
                block18: while (true) {
                    switch ((int)l2) {
                        case -3147964: {
                            break block18;
                        }
                        case 1986352164: {
                            l2 = (0x3EDDL ^ 0x657DCC7C100D3E19L) / (0x3C10L ^ 0x53907DD9AF8CBCF7L);
                            continue block18;
                        }
                    }
                    break;
                }
                Integer n = mapCycleModule.getNextMapIdAfterWaitKillPeriod();
                while (true) {
                    long l3;
                    long l4;
                    if ((l4 = (l3 = \u13e8 - (0x276CL ^ 0x54AA163BA49C3E2BL)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) continue;
                    if (l4 == (0x55FF ^ 0xFFFFAA00)) break;
                    l4 = 0x33C3 ^ 0xCE0B93D3;
                }
                int n2 = n;
                while (true) {
                    long l5;
                    long l6;
                    if ((l6 = (l5 = \u13e8 - (0x6B70L ^ 0x2E950AE3E9AB0528L)) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) continue;
                    if (l6 == (0x859 ^ 0xFFFFF7A6)) break;
                    l6 = 0x4388 ^ 0x3C84FCFE;
                }
                while (true) {
                    long l7;
                    long l8;
                    if ((l8 = (l7 = \u13e8 - (0x791BL ^ 0x8343B35AD7332A51L)) == 0L ? 0 : (l7 < 0L ? -1 : 1)) == false) continue;
                    if (l8 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                    l8 = 0x6D46 ^ 0xEDDE0CC3;
                }
                Map map = this.hero.map;
                long l9 = \u13e8;
                block22: while (true) {
                    switch ((int)l9) {
                        case -3147964: {
                            break block22;
                        }
                        case 1213520727: {
                            l9 = (0x17AEL ^ 0xA6C9DA85D6A53BA4L) / (0x6231L ^ 0x8275CAD55BE9B36FL);
                            continue block22;
                        }
                    }
                    break;
                }
                if (n2 != map.id) break block29;
            }
            long l = \u13e8;
            boolean bl2 = true;
            block23: while (true) {
                long l10;
                if (!bl2 || (bl2 = false) || !true) {
                    l = l10 / (0x26ABL ^ 0x5C5830823EB3B918L);
                }
                switch ((int)l) {
                    case -2002389887: {
                        l10 = 0x6121L ^ 0xF9FF01B568112744L;
                        continue block23;
                    }
                    case -3147964: {
                        break block23;
                    }
                    case 885049463: {
                        l10 = 0x981L ^ 0xBF7CB183D2F4A5DEL;
                        continue block23;
                    }
                }
                break;
            }
            if (!this.mapCycleIsTravelling()) {
                bl = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
                return bl;
            }
        }
        bl = "".length() >>> "\u0000\u0000".length();
        return bl;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private boolean mapCycleIsCurrentModule() {
        boolean bl;
        long l = \u13e8;
        boolean bl2 = true;
        block6: while (true) {
            long l2;
            if (!bl2 || (bl2 = false) || !true) {
                l = l2 / (0x5E12L ^ 0x890BB2E59926AA6CL);
            }
            switch ((int)l) {
                case -2113762664: {
                    l2 = 0x3223L ^ 0x6FD9510AE0C8EE16L;
                    continue block6;
                }
                case -913798802: {
                    l2 = 0x623L ^ 0x477E59FBAB06B91FL;
                    continue block6;
                }
                case -3147964: {
                    break block6;
                }
                case 1194651870: {
                    l2 = 0x1218L ^ 0x7BE682397C069E56L;
                    continue block6;
                }
            }
            break;
        }
        if (this.getMapCycleModule() != null) {
            bl = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
            return bl;
        }
        bl = "".length() >>> "\u0000\u0000".length();
        return bl;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private MapCycleModule getMapCycleModule() {
        long l = \u13e8;
        boolean bl = true;
        block5: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x662L ^ 0x59CAA980187149A0L);
            }
            switch ((int)l) {
                case -874921813: {
                    l2 = 0x13B2L ^ 0x78BBB41C055A39AFL;
                    continue block5;
                }
                case -3147964: {
                    break block5;
                }
                case 202470371: {
                    l2 = 0xC4FL ^ 0xC41F4136FF81FD06L;
                    continue block5;
                }
            }
            break;
        }
        while (true) {
            long l3;
            long l4;
            if ((l4 = (l3 = \u13e8 - (0x176DL ^ 0xD3D4E408DCC3F163L)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) continue;
            if (l4 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l4 = 0x40CB ^ 0xA2A54DE6;
        }
        if (!(this.main.getModule() instanceof MapCycleModule)) return null;
        while (true) {
            long l5;
            long l6;
            if ((l6 = (l5 = \u13e8 - (0x15BCL ^ 0xEDE76B2838D56C34L)) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) continue;
            if (l6 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l6 = 0x5166 ^ 0x5DEE6D01;
        }
        while (true) {
            long l7;
            long l8;
            if ((l8 = (l7 = \u13e8 - (0x5203L ^ 0x5A99FD23A9941B01L)) == 0L ? 0 : (l7 < 0L ? -1 : 1)) == false) continue;
            if (l8 == (0x5921 ^ 0xFFFFA6DE)) {
                return (MapCycleModule)this.main.getModule();
            }
            l8 = 0x4051 ^ 0xEAE10818;
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private int getHourNow() {
        long l = \u13e8;
        boolean bl = true;
        block5: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (7934611170031887824L >>> "\u0000\u0000".length());
            }
            switch ((int)l) {
                case -1705044492: {
                    l2 = 0x6716L ^ 0x76C4B255B1F6B25EL;
                    continue block5;
                }
                case -701803207: {
                    l2 = 0x64E3L ^ 0xD99823475042F881L;
                    continue block5;
                }
                case -3147964: {
                    return TimeUtils.Get24HourNow();
                }
            }
            break;
        }
        return TimeUtils.Get24HourNow();
    }

    /*
     * Unable to fully structure code
     */
    private boolean dontCheckNextStingerCheck() {
        v0 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl5
        block41: while (true) {
            v0 = (6941L ^ -6347348385277903820L) / (8613L ^ -7513588686927149000L);
lbl5:
            // 2 sources

            switch ((int)v0) {
                case -372002283: {
                    continue block41;
                }
                case -3147964: {
                    break block41;
                }
            }
            break;
        }
        if (!this.validDontCheckConfig()) {
            return (boolean)(31033 ^ 31033);
        }
        v1 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl16
        block42: while (true) {
            v1 = v2 / (14698L ^ 6147333903817001758L);
lbl16:
            // 2 sources

            switch ((int)v1) {
                case -3147964: {
                    break block42;
                }
                case 212197440: {
                    v2 = 6584972302238502012L >>> "\u0000\u0000".length();
                    continue block42;
                }
                case 1666881762: {
                    v2 = 8742L ^ -1831517401634769402L;
                    continue block42;
                }
            }
            break;
        }
        v3 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl29
        block43: while (true) {
            v3 = v4 / (18197L ^ 8096183357671161816L);
lbl29:
            // 2 sources

            switch ((int)v3) {
                case -2110397047: {
                    v4 = 25447L ^ 8372629337974604244L;
                    continue block43;
                }
                case -3147964: {
                    break block43;
                }
                case 1949693292: {
                    v4 = 2201L ^ -993193088897152676L;
                    continue block43;
                }
            }
            break;
        }
        v5 = this.config._AFTER_STINGER_CONFIG;
        v6 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl43
        block44: while (true) {
            v6 = v7 / (30752L ^ 5420544531027695015L);
lbl43:
            // 2 sources

            switch ((int)v6) {
                case -741792396: {
                    v7 = 11969L ^ 5744968684361213357L;
                    continue block44;
                }
                case -3147964: {
                    break block44;
                }
                case 568580386: {
                    v7 = 28576L ^ -7324828916307889479L;
                    continue block44;
                }
                case 1529281428: {
                    v7 = 12974L ^ 6226150935216134094L;
                    continue block44;
                }
            }
            break;
        }
        v8 = v5.DONT_CHECK;
        while (true) {
            if ((v9 = (cfr_temp_0 = StingerWarper.\u13e8 - (26092L ^ -4186725360890350755L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v9 == (6686 ^ 6687)) break;
            v9 = 8729 ^ -94676221;
        }
        startHour = v8.START_HOUR;
        v10 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl66
        block46: while (true) {
            v10 = (19882L ^ 2027427819629458884L) / (19417L ^ -2644614955474615164L);
lbl66:
            // 2 sources

            switch ((int)v10) {
                case -3147964: {
                    break block46;
                }
                case 2020152389: {
                    continue block46;
                }
            }
            break;
        }
        while (true) {
            if ((v11 = (cfr_temp_1 = StingerWarper.\u13e8 - (25396L ^ -4490843146177590673L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v11 == (15788 ^ 15789)) break;
            v11 = 13708 ^ -851117062;
        }
        v12 = this.config._AFTER_STINGER_CONFIG;
        v13 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl81
        block48: while (true) {
            v13 = v14 / (24630L ^ 7005907883696340741L);
lbl81:
            // 2 sources

            switch ((int)v13) {
                case -1687054031: {
                    v14 = 16408L ^ 4071886550434498330L;
                    continue block48;
                }
                case -3147964: {
                    break block48;
                }
                case 2079202437: {
                    v14 = 29736L ^ -3347447700643426807L;
                    continue block48;
                }
            }
            break;
        }
        v15 = v12.DONT_CHECK;
        v16 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl95
        block49: while (true) {
            v16 = v17 / (5836980107158047180L >>> "\u0000\u0000".length());
lbl95:
            // 2 sources

            switch ((int)v16) {
                case -501388970: {
                    v17 = 15772L ^ 4766840554886468566L;
                    continue block49;
                }
                case -3147964: {
                    break block49;
                }
                case 228888024: {
                    v17 = 10038L ^ 482467017152369297L;
                    continue block49;
                }
                case 1971261401: {
                    v17 = 24372L ^ -7355300568919826901L;
                    continue block49;
                }
            }
            break;
        }
        endHour = v15.END_HOUR;
        v18 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl112
        block50: while (true) {
            v18 = v19 / (9478L ^ -1738009526898735316L);
lbl112:
            // 2 sources

            switch ((int)v18) {
                case -935993484: {
                    v19 = 17108L ^ 7823476378238672319L;
                    continue block50;
                }
                case -3147964: {
                    break block50;
                }
                case 196010988: {
                    v19 = 25984L ^ -8923760624298310506L;
                    continue block50;
                }
                case 585234102: {
                    v19 = 17842L ^ -3736812865958014918L;
                    continue block50;
                }
            }
            break;
        }
        return TimeUtils.IsHourNowBetween(startHour, endHour);
    }

    /*
     * Unable to fully structure code
     */
    private long getTimeTillNextSingerCheckMs() {
        block60: {
            block59: {
                v0 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl5
                block43: while (true) {
                    v0 = v1 / (22943L ^ -7842488704932131257L);
lbl5:
                    // 2 sources

                    switch ((int)v0) {
                        case -1976397096: {
                            v1 = 19890L ^ 6482883723421835922L;
                            continue block43;
                        }
                        case -1591694023: {
                            v1 = 10207L ^ 1810471110478445844L;
                            continue block43;
                        }
                        case -3147964: {
                            break block43;
                        }
                    }
                    break;
                }
                if (this.dontCheckNextStingerCheck()) {
                    return 400000L >>> "\u0000\u0000".length();
                }
                v2 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl20
                block44: while (true) {
                    v2 = v3 / (31085L ^ 6201763921989696861L);
lbl20:
                    // 2 sources

                    switch ((int)v2) {
                        case -374125169: {
                            v3 = 2324282929875917616L >>> "\u0000\u0000".length();
                            continue block44;
                        }
                        case -175902454: {
                            v3 = 21578L ^ -2100402627802476304L;
                            continue block44;
                        }
                        case -3147964: {
                            break block44;
                        }
                        case 1719290773: {
                            v3 = 6802L ^ -868899080908352357L;
                            continue block44;
                        }
                    }
                    break;
                }
                v4 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl36
                block45: while (true) {
                    v4 = (7827L ^ -6003189786100179L) / (6267L ^ -3012738260502523275L);
lbl36:
                    // 2 sources

                    switch ((int)v4) {
                        case -3147964: {
                            break block45;
                        }
                        case 176105824: {
                            continue block45;
                        }
                    }
                    break;
                }
                if (!this.useNpcSpawnTimer) break block59;
                while (true) {
                    if ((v5 = (cfr_temp_0 = StingerWarper.\u13e8 - (30594L ^ -9130417299535767392L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                    if (v5 == (11499 ^ 11498)) break;
                    v5 = 20863 ^ -1051259767;
                }
                while (true) {
                    if ((v6 = (cfr_temp_1 = StingerWarper.\u13e8 - (19250L ^ -1955893794999886218L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                    if (v6 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                    v6 = 20948 ^ -384010055;
                }
                v7 = this.config._AFTER_STINGER_CONFIG;
                v8 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl57
                block48: while (true) {
                    v8 = v9 / (5148L ^ 751929088133429977L);
lbl57:
                    // 2 sources

                    switch ((int)v8) {
                        case -3147964: {
                            break block48;
                        }
                        case 1274036440: {
                            v9 = 8364159125657925744L >>> "\u0000\u0000".length();
                            continue block48;
                        }
                        case 1765347230: {
                            v9 = -7619423801636415884L >>> "\u0000\u0000".length();
                            continue block48;
                        }
                    }
                    break;
                }
                if (v7.STINGER_RESPAWN_TIME < 0) break block59;
                v10 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl71
                block49: while (true) {
                    v10 = v11 / (20215L ^ -1854172677842211587L);
lbl71:
                    // 2 sources

                    switch ((int)v10) {
                        case -3147964: {
                            break block49;
                        }
                        case 31633201: {
                            v11 = 19166L ^ 6971051920852316832L;
                            continue block49;
                        }
                        case 1053837759: {
                            v11 = 14918L ^ -9133326792680668112L;
                            continue block49;
                        }
                    }
                    break;
                }
                while (true) {
                    if ((v12 = (cfr_temp_2 = StingerWarper.\u13e8 - (4670L ^ -5367208629324079168L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                    if (v12 == (6364 ^ 6365)) break;
                    v12 = 21961 ^ -787352228;
                }
                v13 = this.config._AFTER_STINGER_CONFIG;
                v14 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl90
                block51: while (true) {
                    v14 = v15 / (9659L ^ 2500730075458042251L);
lbl90:
                    // 2 sources

                    switch ((int)v14) {
                        case -3147964: {
                            break block51;
                        }
                        case 587719953: {
                            v15 = 23L ^ -3816808711445928614L;
                            continue block51;
                        }
                        case 1821642244: {
                            v15 = 29854L ^ 8798039489139798276L;
                            continue block51;
                        }
                    }
                    break;
                }
                v16 = v13.STINGER_RESPAWN_TIME;
                break block60;
            }
            v17 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl106
            block52: while (true) {
                v17 = v18 / (28726L ^ 1590683214411236792L);
lbl106:
                // 2 sources

                switch ((int)v17) {
                    case -222084553: {
                        v18 = 26920L ^ 7787546808316809741L;
                        continue block52;
                    }
                    case -3147964: {
                        break block52;
                    }
                    case 1513335315: {
                        v18 = 25260L ^ 4426241204915918616L;
                        continue block52;
                    }
                }
                break;
            }
            while (true) {
                if ((v19 = (cfr_temp_3 = StingerWarper.\u13e8 - (4192L ^ 6459975423362674991L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v19 == (14401 ^ -14402)) break;
                v19 = 16536 ^ 1424566137;
            }
            v20 = this.config._AFTER_STINGER_CONFIG;
            while (true) {
                if ((v21 = (cfr_temp_4 = StingerWarper.\u13e8 - (31336L ^ -7026319332637106899L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v21 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v21 = "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() ^ -1835028214;
            }
            v16 = v20.CHECK_TIME;
        }
        v22 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl132
        block55: while (true) {
            v22 = (5060L ^ -2424651606480982429L) / (25838L ^ 8886291944223347248L);
lbl132:
            // 2 sources

            switch ((int)v22) {
                case -1770099648: {
                    continue block55;
                }
                case -3147964: {
                    break block55;
                }
            }
            break;
        }
        pool = TimeUnit.MINUTES.toMillis(v16);
        v23 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl142
        block56: while (true) {
            v23 = (19949L ^ -4075680850563869481L) / (8840820847377798060L >>> "\u0000\u0000".length());
lbl142:
            // 2 sources

            switch ((int)v23) {
                case -3147964: {
                    break block56;
                }
                case 1361134802: {
                    continue block56;
                }
            }
            break;
        }
        v24 = System.currentTimeMillis();
        while (true) {
            if ((v25 = (cfr_temp_5 = StingerWarper.\u13e8 - (2219L ^ 848731933604266734L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
            if (v25 == (24619 ^ 24618)) break;
            v25 = 11798 ^ 1076087773;
        }
        return pool - (v24 - StingerWarper.LAST_STINGER_CHECK_MS);
    }

    /*
     * Unable to fully structure code
     */
    private boolean maxTimeShootingStingerEllapsed() {
        block50: {
            v0 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl5
            block33: while (true) {
                v0 = v1 / (8588L ^ 5518156653679581142L);
lbl5:
                // 2 sources

                switch ((int)v0) {
                    case -3147964: {
                        break block33;
                    }
                    case 472633753: {
                        v1 = 20167L ^ -5928030008019859437L;
                        continue block33;
                    }
                    case 1201682096: {
                        v1 = 4773L ^ -261168368180149674L;
                        continue block33;
                    }
                    case 1331207830: {
                        v1 = 9894L ^ 5952217599426634321L;
                        continue block33;
                    }
                }
                break;
            }
            while (true) {
                if ((v2 = (cfr_temp_0 = StingerWarper.\u13e8 - (4613L ^ -8385192550014811327L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v2 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v2 = 23246 ^ -1308288781;
            }
            v3 = this.config._STINGER_CONFIG;
            while (true) {
                if ((v4 = (cfr_temp_1 = StingerWarper.\u13e8 - (6078L ^ -7896107676453060462L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v4 == (27313 ^ 27312)) break;
                v4 = 16359 ^ -1329576861;
            }
            if (v3.MAX_TIME_SHOOTING_STINGER <= 0) {
                return (boolean)(28783 ^ 28783);
            }
            while (true) {
                if ((v5 = (cfr_temp_2 = StingerWarper.\u13e8 - (11660L ^ 6635049339000476878L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v5 == (19327 ^ -19328)) break;
                v5 = -281918728 >>> "\u0000\u0000".length();
            }
            if (!this.isShootingStinger()) break block50;
            while (true) {
                if ((v6 = (cfr_temp_3 = StingerWarper.\u13e8 - (11067L ^ 614411892972958492L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v6 == (8560 ^ 8561)) break;
                v6 = 29578 ^ -426583901;
            }
            if (this.startShootingStingerTimeMs != null) break block50;
            while (true) {
                if ((v7 = (cfr_temp_4 = StingerWarper.\u13e8 - (20717L ^ -8735237668350207692L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v7 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v7 = -877966884 >>> "\u0000\u0000".length();
            }
            v8 = System.currentTimeMillis();
            while (true) {
                if ((v9 = (cfr_temp_5 = StingerWarper.\u13e8 - (23145L ^ -8752608419805198492L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                if (v9 == (24127 ^ 24126)) break;
                v9 = 28333 ^ 2044571711;
            }
            v10 = v8;
            v11 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl58
            block40: while (true) {
                v11 = v12 / (5708745285807973324L >>> "\u0000\u0000".length());
lbl58:
                // 2 sources

                switch ((int)v11) {
                    case -1964691780: {
                        v12 = 1940L ^ -868913046568609048L;
                        continue block40;
                    }
                    case -126627747: {
                        v12 = 20752L ^ -2143262874539316705L;
                        continue block40;
                    }
                    case -3147964: {
                        break block40;
                    }
                }
                break;
            }
            this.startShootingStingerTimeMs = v10;
        }
        v13 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl73
        block41: while (true) {
            v13 = v14 / (8075L ^ 1415260740363577642L);
lbl73:
            // 2 sources

            switch ((int)v13) {
                case -1627491169: {
                    v14 = 13905L ^ 8357222690172405320L;
                    continue block41;
                }
                case -981428969: {
                    v14 = -4299715280096573592L >>> "\u0000\u0000".length();
                    continue block41;
                }
                case -3147964: {
                    break block41;
                }
                case 1415803520: {
                    v14 = 21475L ^ -8355344933606774263L;
                    continue block41;
                }
            }
            break;
        }
        timeshootStingerMs = this.getTimeShootingStingerMs();
        if (timeshootStingerMs == null) {
            return (boolean)(10347 ^ 10347);
        }
        while (true) {
            if ((v15 = (cfr_temp_6 = StingerWarper.\u13e8 - (-5445552325182329804L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
            if (v15 == (21935 ^ -21936)) break;
            v15 = 5130 ^ -1108977008;
        }
        v16 = timeshootStingerMs;
        while (true) {
            if ((v17 = (cfr_temp_7 = StingerWarper.\u13e8 - (10526L ^ -1339409432063623513L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
            if (v17 == (27096 ^ 27097)) break;
            v17 = 29787 ^ 1587078985;
        }
        v18 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl103
        block44: while (true) {
            v18 = v19 / (18559L ^ 9046651706674013683L);
lbl103:
            // 2 sources

            switch ((int)v18) {
                case -718931154: {
                    v19 = 19434L ^ -1610496503008926918L;
                    continue block44;
                }
                case -3147964: {
                    break block44;
                }
                case 160160978: {
                    v19 = 28419L ^ 6197887545295951789L;
                    continue block44;
                }
            }
            break;
        }
        while (true) {
            if ((v20 = (cfr_temp_8 = StingerWarper.\u13e8 - (29160L ^ 4695847841387063702L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
            if (v20 == (259 ^ -260)) break;
            v20 = 13937 ^ -2060997057;
        }
        v21 = this.config._STINGER_CONFIG;
        v22 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl122
        block46: while (true) {
            v22 = v23 / (2555996530416536376L >>> "\u0000\u0000".length());
lbl122:
            // 2 sources

            switch ((int)v22) {
                case -1797267761: {
                    v23 = 22541L ^ 5019742644320257117L;
                    continue block46;
                }
                case -3147964: {
                    break block46;
                }
                case 594057822: {
                    v23 = 22536L ^ -3995052760220783468L;
                    continue block46;
                }
                case 1884306497: {
                    v23 = 13647L ^ 7599441229553996819L;
                    continue block46;
                }
            }
            break;
        }
        v24 = v21.MAX_TIME_SHOOTING_STINGER;
        v25 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl139
        block47: while (true) {
            v25 = v26 / (31467L ^ -3596706672620073489L);
lbl139:
            // 2 sources

            switch ((int)v25) {
                case -813158872: {
                    v26 = 32211L ^ -1315710817867721372L;
                    continue block47;
                }
                case -646437896: {
                    v26 = 16334L ^ 6576036801894115545L;
                    continue block47;
                }
                case -3147964: {
                    break block47;
                }
            }
            break;
        }
        return (boolean)(v16 >= TimeUnit.SECONDS.toMillis(v24) ? 30101 ^ 30100 : 25109 ^ 25109);
    }

    /*
     * Unable to fully structure code
     */
    private Long getTimeShootingStingerMs() {
        while (true) {
            if ((v0 = (cfr_temp_0 = StingerWarper.\u13e8 - (15637L ^ 8827661487452267034L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v0 == (15655 ^ -15656)) break;
            v0 = 18815 ^ 54820717;
        }
        if (this.startShootingStingerTimeMs == null) {
            return null;
        }
        v1 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl13
        block12: while (true) {
            v1 = v2 / (27069L ^ -4967059360045904801L);
lbl13:
            // 2 sources

            switch ((int)v1) {
                case -460619141: {
                    v2 = 15954L ^ -5779272853418031760L;
                    continue block12;
                }
                case -3147964: {
                    break block12;
                }
                case 36347739: {
                    v2 = 1155L ^ -4581606070608852967L;
                    continue block12;
                }
            }
            break;
        }
        v3 = System.currentTimeMillis();
        while (true) {
            if ((v4 = (cfr_temp_1 = StingerWarper.\u13e8 - (11876L ^ 2731253565767362279L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v4 == (23388 ^ -23389)) break;
            v4 = 25905 ^ 857181777;
        }
        v5 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl33
        block14: while (true) {
            v5 = v6 / (27336L ^ 5084294508838007354L);
lbl33:
            // 2 sources

            switch ((int)v5) {
                case -3147964: {
                    break block14;
                }
                case -2191861: {
                    v6 = 4931995434733130008L >>> "\u0000\u0000".length();
                    continue block14;
                }
                case 1143627603: {
                    v6 = 29303L ^ 3023066976704579952L;
                    continue block14;
                }
                case 1365735340: {
                    v6 = 3690L ^ -4835015431378724142L;
                    continue block14;
                }
            }
            break;
        }
        v7 = v3 - this.startShootingStingerTimeMs;
        while (true) {
            if ((v8 = (cfr_temp_2 = StingerWarper.\u13e8 - (23168L ^ 3023178984980194469L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v8 == (20414 ^ -20415)) break;
            v8 = 28938 ^ -768164420;
        }
        return v7;
    }

    /*
     * Unable to fully structure code
     */
    private boolean maxStingerWaitTimeEllapsed() {
        block49: {
            while (true) {
                if ((v0 = (cfr_temp_0 = StingerWarper.\u13e8 - (23111L ^ -3519349946915580075L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v0 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v0 = 1931183032 >>> "\u0000\u0000".length();
            }
            while (true) {
                if ((v1 = (cfr_temp_1 = StingerWarper.\u13e8 - (12479L ^ -8504261632604191226L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v1 == (24074 ^ 24075)) break;
                v1 = 7207 ^ -255559821;
            }
            v2 = this.config._STINGER_CONFIG;
            v3 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl16
            block35: while (true) {
                v3 = v4 / (22877L ^ -5131093318606573200L);
lbl16:
                // 2 sources

                switch ((int)v3) {
                    case -1259467184: {
                        v4 = 5550L ^ 8100230584918246726L;
                        continue block35;
                    }
                    case -1013575003: {
                        v4 = 25533L ^ 6344153071507724067L;
                        continue block35;
                    }
                    case -3147964: {
                        break block35;
                    }
                    case 2128440465: {
                        v4 = 7773L ^ -2777910765134050679L;
                        continue block35;
                    }
                }
                break;
            }
            if (v2.MAX_TIME_WAITING_FOR_STINGER <= 0) {
                return "".length() >>> "\u0000\u0000".length();
            }
            v5 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl34
            block36: while (true) {
                v5 = v6 / (22914L ^ -6520964503534638707L);
lbl34:
                // 2 sources

                switch ((int)v5) {
                    case -719411458: {
                        v6 = 29194L ^ 8962950857164998580L;
                        continue block36;
                    }
                    case -3147964: {
                        break block36;
                    }
                    case 1607774514: {
                        v6 = 20357L ^ 3891190804047340375L;
                        continue block36;
                    }
                }
                break;
            }
            if (!this.isShootingStinger()) break block49;
            v7 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl48
            block37: while (true) {
                v7 = v8 / (20331L ^ -692359459644880495L);
lbl48:
                // 2 sources

                switch ((int)v7) {
                    case -1292066002: {
                        v8 = 24326L ^ 3227233946340581869L;
                        continue block37;
                    }
                    case -936449653: {
                        v8 = 11038L ^ -7741513017522655420L;
                        continue block37;
                    }
                    case -3147964: {
                        break block37;
                    }
                    case 627844487: {
                        v8 = 16111L ^ 1713025297215206006L;
                        continue block37;
                    }
                }
                break;
            }
            this.startMaxShootingStingerTimerMs = null;
            v9 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl65
            block38: while (true) {
                v9 = v10 / (11487L ^ 1488575498664346282L);
lbl65:
                // 2 sources

                switch ((int)v9) {
                    case -1995301798: {
                        v10 = 14585L ^ -1498281776829392921L;
                        continue block38;
                    }
                    case -3147964: {
                        break block38;
                    }
                    case 2059666055: {
                        v10 = 6823L ^ 7302182503867172322L;
                        continue block38;
                    }
                }
                break;
            }
            this.startMaxStingerTimer();
            return (boolean)(2866 ^ 2866);
        }
        v11 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl81
        block39: while (true) {
            v11 = v12 / (2684L ^ -7891269564768078127L);
lbl81:
            // 2 sources

            switch ((int)v11) {
                case -720938915: {
                    v12 = 22547L ^ -6658914618548147487L;
                    continue block39;
                }
                case -3147964: {
                    break block39;
                }
                case 783785956: {
                    v12 = 16102L ^ -6365546331324379859L;
                    continue block39;
                }
                case 1101190138: {
                    v12 = 28662L ^ -5919489117478726360L;
                    continue block39;
                }
            }
            break;
        }
        timeWaitingForStingerMs = this.getTimeWaitingForStingerMs();
        if (timeWaitingForStingerMs == null) {
            while (true) {
                if ((v13 = (cfr_temp_2 = StingerWarper.\u13e8 - (10032L ^ -1799810727602444018L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v13 == (17703 ^ 17702)) break;
                v13 = 18416 ^ 1458922288;
            }
            this.startMaxStingerTimer();
            return (boolean)(28533 ^ 28533);
        }
        while (true) {
            if ((v14 = (cfr_temp_3 = StingerWarper.\u13e8 - (29407L ^ 7412283260048447852L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v14 == (13453 ^ -13454)) break;
            v14 = 8223 ^ -1714079814;
        }
        v15 = timeWaitingForStingerMs;
        while (true) {
            if ((v16 = (cfr_temp_4 = StingerWarper.\u13e8 - (24094L ^ -8167803298285228973L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v16 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v16 = 25633 ^ -1666852440;
        }
        v17 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl117
        block43: while (true) {
            v17 = v18 / (2998236955154105464L >>> "\u0000\u0000".length());
lbl117:
            // 2 sources

            switch ((int)v17) {
                case -1913066476: {
                    v18 = 2233L ^ -1674585212117824133L;
                    continue block43;
                }
                case -1726566813: {
                    v18 = -7986952474755518040L >>> "\u0000\u0000".length();
                    continue block43;
                }
                case -3147964: {
                    break block43;
                }
            }
            break;
        }
        while (true) {
            if ((v19 = (cfr_temp_5 = StingerWarper.\u13e8 - (17554L ^ 5916013294249125281L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
            if (v19 == (18402 ^ -18403)) break;
            v19 = 8732 ^ -2002618965;
        }
        v20 = this.config._STINGER_CONFIG;
        while (true) {
            if ((v21 = (cfr_temp_6 = StingerWarper.\u13e8 - (11230L ^ -4122810393080738376L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
            if (v21 == (30385 ^ 30384)) break;
            v21 = 7166 ^ -1174100664;
        }
        v22 = v20.MAX_TIME_WAITING_FOR_STINGER;
        while (true) {
            if ((v23 = (cfr_temp_7 = StingerWarper.\u13e8 - (27466L ^ -8661489240907605114L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
            if (v23 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v23 = 12517 ^ 1925816552;
        }
        return (boolean)(v15 >= TimeUnit.SECONDS.toMillis(v22) ? 21729 ^ 21728 : 19449 ^ 19449);
    }

    /*
     * Unable to fully structure code
     */
    private Long getTimeWaitingForStingerMs() {
        v0 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl5
        block21: while (true) {
            v0 = v1 / (11971L ^ -2361384177444918549L);
lbl5:
            // 2 sources

            switch ((int)v0) {
                case -686192481: {
                    v1 = 23588L ^ -76803694670551667L;
                    continue block21;
                }
                case -639003823: {
                    v1 = 8525L ^ -5058430516787904837L;
                    continue block21;
                }
                case -3147964: {
                    break block21;
                }
                case 888200323: {
                    v1 = 4057079654044493152L >>> "\u0000\u0000".length();
                    continue block21;
                }
            }
            break;
        }
        if (this.startMaxShootingStingerTimerMs == null) {
            return null;
        }
        v2 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl23
        block22: while (true) {
            v2 = v3 / (2784L ^ -4492898314943306181L);
lbl23:
            // 2 sources

            switch ((int)v2) {
                case -947876983: {
                    v3 = 192L ^ 7499935775381955704L;
                    continue block22;
                }
                case -716323076: {
                    v3 = -8270151506994758320L >>> "\u0000\u0000".length();
                    continue block22;
                }
                case -3147964: {
                    break block22;
                }
                case 1012002813: {
                    v3 = 7228L ^ 6276602012250219458L;
                    continue block22;
                }
            }
            break;
        }
        v4 = System.currentTimeMillis();
        while (true) {
            if ((v5 = (cfr_temp_0 = StingerWarper.\u13e8 - (5659L ^ 6992911428845654450L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v5 == (26223 ^ -26224)) break;
            v5 = 16552 ^ 212293163;
        }
        v6 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl46
        block24: while (true) {
            v6 = v7 / (27426L ^ 9081857125573187972L);
lbl46:
            // 2 sources

            switch ((int)v6) {
                case -1070033813: {
                    v7 = 18682L ^ -7659483638517008378L;
                    continue block24;
                }
                case -706847874: {
                    v7 = 2204252271192512452L >>> "\u0000\u0000".length();
                    continue block24;
                }
                case -3147964: {
                    break block24;
                }
            }
            break;
        }
        v8 = v4 - this.startMaxShootingStingerTimerMs;
        v9 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl60
        block25: while (true) {
            v9 = (31370L ^ -7575971474573189625L) / (1003L ^ -713513984921458596L);
lbl60:
            // 2 sources

            switch ((int)v9) {
                case -2062297343: {
                    continue block25;
                }
                case -3147964: {
                    break block25;
                }
            }
            break;
        }
        return v8;
    }

    /*
     * Unable to fully structure code
     */
    private boolean tickIsSwitchingHangarToStinger() {
        block31: {
            block32: {
                while (true) {
                    if ((v0 = (cfr_temp_0 = StingerWarper.\u13e8 - (6157L ^ 6524630351976565339L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                    if (v0 == (20866 ^ -20867)) break;
                    v0 = 2468 ^ 2005692334;
                }
                if (!this.isSwitchingHangarsToStinger) break block31;
                v1 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl11
                block24: while (true) {
                    v1 = v2 / (28340L ^ -5662555313627501747L);
lbl11:
                    // 2 sources

                    switch ((int)v1) {
                        case -1751375995: {
                            v2 = 6710937543501492888L >>> "\u0000\u0000".length();
                            continue block24;
                        }
                        case -479905259: {
                            v2 = -9046139695743781716L >>> "\u0000\u0000".length();
                            continue block24;
                        }
                        case -7108002: {
                            v2 = 10130L ^ 5115175402292805861L;
                            continue block24;
                        }
                        case -3147964: {
                            break block24;
                        }
                    }
                    break;
                }
                this.isSwitchingHangarsToStinger = 25225 ^ 25225;
                while (true) {
                    if ((v3 = (cfr_temp_1 = StingerWarper.\u13e8 - (15605L ^ -5001461983071822350L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                    if (v3 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                    v3 = 29214 ^ -474993304;
                }
                if (!this.shouldSwitchToStingerConfig()) break block32;
                while (true) {
                    if ((v4 = (cfr_temp_2 = StingerWarper.\u13e8 - (3884L ^ 8453705497528447590L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                    if (v4 == (30980 ^ -30981)) break;
                    v4 = 1563 ^ 1362468138;
                }
                this.onBeforeSwitchToStingerConfig();
                v5 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl40
                block27: while (true) {
                    v5 = v6 / (32736L ^ 6595042476865956277L);
lbl40:
                    // 2 sources

                    switch ((int)v5) {
                        case -123123247: {
                            v6 = 30654L ^ -7542835199300029585L;
                            continue block27;
                        }
                        case -3147964: {
                            break block27;
                        }
                        case 792389079: {
                            v6 = 29834L ^ -1799123473058322471L;
                            continue block27;
                        }
                        case 1038732471: {
                            v6 = 708L ^ 7578256987757290031L;
                            continue block27;
                        }
                    }
                    break;
                }
                while (true) {
                    if ((v7 = (cfr_temp_3 = StingerWarper.\u13e8 - (3201L ^ -5931243038237144401L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                    if (v7 == (11848 ^ 11849)) break;
                    v7 = 10722 ^ 526401560;
                }
                v8 = this.config._STINGER_CONFIG;
                v9 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl62
                block29: while (true) {
                    v9 = v10 / (6627L ^ 7646289974409064883L);
lbl62:
                    // 2 sources

                    switch ((int)v9) {
                        case -1171750311: {
                            v10 = 15818L ^ 4003929687705900390L;
                            continue block29;
                        }
                        case -357366552: {
                            v10 = 31524L ^ -8253216344857865069L;
                            continue block29;
                        }
                        case -3147964: {
                            break block29;
                        }
                        case 507392469: {
                            v10 = 2489L ^ -1702935827041476279L;
                            continue block29;
                        }
                    }
                    break;
                }
                v11 = v8.PROFILE_NAME;
                v12 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl79
                block30: while (true) {
                    v12 = v13 / (21453L ^ 5150610154932161013L);
lbl79:
                    // 2 sources

                    switch ((int)v12) {
                        case -406905000: {
                            v13 = 31331L ^ -10686579828683684L;
                            continue block30;
                        }
                        case -3147964: {
                            break block30;
                        }
                        case 1531389544: {
                            v13 = 32538L ^ 6356327206888642363L;
                            continue block30;
                        }
                    }
                    break;
                }
                this.setBotConfig(v11);
            }
            return "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        }
        return (boolean)(9826 ^ 9826);
    }

    /*
     * Unable to fully structure code
     */
    private void onBeforeSwitchToStingerConfig() {
        v0 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl5
        block11: while (true) {
            v0 = v1 / (7187L ^ -7752201337659645058L);
lbl5:
            // 2 sources

            switch ((int)v0) {
                case -813094450: {
                    v1 = -3760548829644947348L >>> "\u0000\u0000".length();
                    continue block11;
                }
                case -3147964: {
                    break block11;
                }
                case 1225226442: {
                    v1 = 15185L ^ -1162823805917016421L;
                    continue block11;
                }
                case 1647794576: {
                    v1 = 6853L ^ 8422912236239800419L;
                    continue block11;
                }
            }
            break;
        }
        this.fastForwardMapCycleToNextMap();
        while (true) {
            if ((v2 = (cfr_temp_0 = StingerWarper.\u13e8 - (11947L ^ 1643394700785476118L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v2 == (3432 ^ 3433)) break;
            v2 = 2232 ^ 1254448770;
        }
        v3 = this.getMapCyclePersistentState();
        v4 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl28
        block13: while (true) {
            v4 = v5 / (31230L ^ -9221188753270767536L);
lbl28:
            // 2 sources

            switch ((int)v4) {
                case -2035169219: {
                    v5 = -3241677386728739124L >>> "\u0000\u0000".length();
                    continue block13;
                }
                case -1911464725: {
                    v5 = 25405L ^ -7484878494786359911L;
                    continue block13;
                }
                case -3147964: {
                    break block13;
                }
            }
            break;
        }
        v3.saveAndReset();
    }

    /*
     * Unable to fully structure code
     */
    private void onBeforeSwitchToBackToOriginalConfig() {
        block37: {
            v0 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl5
            block28: while (true) {
                v0 = (25982L ^ -229057800553631465L) / (31750L ^ -481491761468940233L);
lbl5:
                // 2 sources

                switch ((int)v0) {
                    case -1818706902: {
                        continue block28;
                    }
                    case -3147964: {
                        break block28;
                    }
                }
                break;
            }
            v1 = this.getMapCyclePersistentState();
            while (true) {
                if ((v2 = (cfr_temp_0 = StingerWarper.\u13e8 - (-5442280426786273156L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v2 == (15827 ^ -15828)) break;
                v2 = 30860 ^ 1379843507;
            }
            v1.loadFromSaved();
            v3 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl21
            block30: while (true) {
                v3 = v4 / (30858L ^ -2263610499711898589L);
lbl21:
                // 2 sources

                switch ((int)v3) {
                    case -853052543: {
                        v4 = -729560582789153212L >>> "\u0000\u0000".length();
                        continue block30;
                    }
                    case -3147964: {
                        break block30;
                    }
                    case 685597159: {
                        v4 = 18539L ^ -5079983869857293072L;
                        continue block30;
                    }
                    case 1558412998: {
                        v4 = 21387L ^ 7362947321648766775L;
                        continue block30;
                    }
                }
                break;
            }
            v5 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl37
            block31: while (true) {
                v5 = v6 / (15133L ^ -6031635561847797036L);
lbl37:
                // 2 sources

                switch ((int)v5) {
                    case -2039796937: {
                        v6 = 5110L ^ 1460939150306279772L;
                        continue block31;
                    }
                    case -125858750: {
                        v6 = 14661L ^ 1580824773088005352L;
                        continue block31;
                    }
                    case -3147964: {
                        break block31;
                    }
                    case 568081096: {
                        v6 = 19147L ^ -3666827615499330463L;
                        continue block31;
                    }
                }
                break;
            }
            v7 = this.config._AFTER_STINGER_CONFIG;
            while (true) {
                if ((v8 = (cfr_temp_1 = StingerWarper.\u13e8 - (19234L ^ -1149414940708392910L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v8 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v8 = 13748 ^ -1494206463;
            }
            if (!v7.BUY_CLOAK_ON_SWAP_BACK) break block37;
            v9 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl60
            block33: while (true) {
                v9 = v10 / (17895L ^ -1810140852164065563L);
lbl60:
                // 2 sources

                switch ((int)v9) {
                    case -725667795: {
                        v10 = 13975L ^ -839742619385524931L;
                        continue block33;
                    }
                    case -445767724: {
                        v10 = 27065L ^ 6495463479698996142L;
                        continue block33;
                    }
                    case -3147964: {
                        break block33;
                    }
                    case 1013262835: {
                        v10 = 19001L ^ 3498073159708079331L;
                        continue block33;
                    }
                }
                break;
            }
            v11 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl76
            block34: while (true) {
                v11 = v12 / (-6100475003065368064L >>> "\u0000\u0000".length());
lbl76:
                // 2 sources

                switch ((int)v11) {
                    case -2101986550: {
                        v12 = 8863L ^ -4594848150546428067L;
                        continue block34;
                    }
                    case -1754966144: {
                        v12 = 31719L ^ 6378494186802356403L;
                        continue block34;
                    }
                    case -513559955: {
                        v12 = 28200L ^ -7137123554822867177L;
                        continue block34;
                    }
                    case -3147964: {
                        break block34;
                    }
                }
                break;
            }
            v13 = this.main.backpage;
            while (true) {
                if ((v14 = (cfr_temp_2 = StingerWarper.\u13e8 - (24876L ^ -8021161600104926442L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v14 == (20942 ^ 20943)) {
                    DoShop.BuySingleCloakCpu(this, v13);
                    break;
                }
                v14 = 18322 ^ 979148456;
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private void fastForwardMapCycleToNextMap() {
        block14: {
            while (true) {
                if ((v0 = (cfr_temp_0 = StingerWarper.\u13e8 - (18651L ^ -8608959462783505825L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v0 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v0 = 6402 ^ 892473670;
            }
            mapCycleModule = this.getMapCycleModule();
            if (mapCycleModule == null) break block14;
            while (true) {
                if ((v1 = (cfr_temp_1 = StingerWarper.\u13e8 - (21200L ^ 7258479390723583770L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v1 == (26851 ^ -26852)) break;
                v1 = 13992 ^ -669124038;
            }
            nextMapId = mapCycleModule.getNextMapIdAfterWaitKillPeriod();
            if (nextMapId == null) break block14;
            v2 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl19
            block8: while (true) {
                v2 = v3 / (32596L ^ -4867578540125112364L);
lbl19:
                // 2 sources

                switch ((int)v2) {
                    case -1327040129: {
                        v3 = 16821L ^ 6469509731737342876L;
                        continue block8;
                    }
                    case -894307716: {
                        v3 = 23001L ^ 7984515227721702776L;
                        continue block8;
                    }
                    case -3147964: {
                        break block8;
                    }
                    case 732224336: {
                        v3 = 29530L ^ 2769822650189652352L;
                        continue block8;
                    }
                }
                break;
            }
            while (true) {
                if ((v4 = (cfr_temp_2 = StingerWarper.\u13e8 - (19224L ^ -3114537238782155537L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v4 == (29776 ^ 29777)) break;
                v4 = 3612 ^ -555405343;
            }
            v5 = this.main.config;
            while (true) {
                if ((v6 = (cfr_temp_3 = StingerWarper.\u13e8 - (22917L ^ -6452110342275003740L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v6 == (13795 ^ 13794)) break;
                v6 = 5475 ^ -12124867;
            }
            v7 = v5.GENERAL;
            while (true) {
                if ((v8 = (cfr_temp_4 = StingerWarper.\u13e8 - (25102L ^ 5945454727803619801L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v8 == (19404 ^ -19405)) break;
                v8 = 1413653860 >>> "\u0000\u0000".length();
            }
            v9 = nextMapId;
            while (true) {
                if ((v10 = (cfr_temp_5 = StingerWarper.\u13e8 - (5802L ^ 2008989487694425837L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                if (v10 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                    v7.WORKING_MAP = v9;
                    break;
                }
                v10 = 3266 ^ -1990530632;
            }
        }
    }

    private boolean shouldSwitchToStingerConfig() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x69C1L ^ 0x31E3ED1BC4B08EDDL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == (0x759A ^ 0xFFFF8A65)) break;
            l2 = 0x7E01 ^ 0xA14AE307;
        }
        return this.hasSuccessfullyChangedHangars();
    }

    /*
     * Unable to fully structure code
     */
    private boolean tickIsSwitchingHangarBackToOriginal() {
        block33: {
            block34: {
                v0 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl5
                block25: while (true) {
                    v0 = (30213L ^ 2926644442275154497L) / (17241L ^ 5683379199484775371L);
lbl5:
                    // 2 sources

                    switch ((int)v0) {
                        case -3147964: {
                            break block25;
                        }
                        case 598582335: {
                            continue block25;
                        }
                    }
                    break;
                }
                if (!this.isSwitchingHangarsBackToOriginal) break block33;
                v1 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl15
                block26: while (true) {
                    v1 = v2 / (11906L ^ 5784957213518625880L);
lbl15:
                    // 2 sources

                    switch ((int)v1) {
                        case -1661377506: {
                            v2 = 16258L ^ -6503234689928124785L;
                            continue block26;
                        }
                        case -1544392747: {
                            v2 = 27956L ^ -9193910975867181993L;
                            continue block26;
                        }
                        case -3147964: {
                            break block26;
                        }
                    }
                    break;
                }
                this.isSwitchingHangarsBackToOriginal = 153 ^ 153;
                while (true) {
                    if ((v3 = (cfr_temp_0 = StingerWarper.\u13e8 - (16809L ^ -224069363941336573L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                    if (v3 == (12092 ^ 12093)) break;
                    v3 = 17324 ^ 1979056984;
                }
                if (!this.shouldSwitchToAfterStingerConfig()) break block34;
                v4 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl35
                block28: while (true) {
                    v4 = v5 / (31713L ^ -3450100167735149572L);
lbl35:
                    // 2 sources

                    switch ((int)v4) {
                        case -1024918271: {
                            v5 = 30168L ^ 1047515979566209951L;
                            continue block28;
                        }
                        case -3147964: {
                            break block28;
                        }
                        case 243161554: {
                            v5 = 25590L ^ -7013141741801596993L;
                            continue block28;
                        }
                    }
                    break;
                }
                this.onBeforeSwitchToBackToOriginalConfig();
                while (true) {
                    if ((v6 = (cfr_temp_1 = StingerWarper.\u13e8 - (-3255952445950386264L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                    if (v6 == (7318 ^ -7319)) break;
                    v6 = 11281 ^ 1629300609;
                }
                v7 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl54
                block30: while (true) {
                    v7 = v8 / (19192L ^ 8962668904123598537L);
lbl54:
                    // 2 sources

                    switch ((int)v7) {
                        case -1878453793: {
                            v8 = 23338L ^ -7797719286532240778L;
                            continue block30;
                        }
                        case -277850403: {
                            v8 = 3020L ^ 8175719872857205408L;
                            continue block30;
                        }
                        case -3147964: {
                            break block30;
                        }
                    }
                    break;
                }
                v9 = this.config._AFTER_STINGER_CONFIG;
                while (true) {
                    if ((v10 = (cfr_temp_2 = StingerWarper.\u13e8 - (12438L ^ 2928936287897230159L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                    if (v10 == (2083 ^ -2084)) break;
                    v10 = 6761 ^ 280054483;
                }
                v11 = v9.PROFILE_NAME;
                v12 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl74
                block32: while (true) {
                    v12 = v13 / (27937L ^ -7947727629106901543L);
lbl74:
                    // 2 sources

                    switch ((int)v12) {
                        case -2136903782: {
                            v13 = 2992L ^ 2113225647120097261L;
                            continue block32;
                        }
                        case -1371365293: {
                            v13 = 11058L ^ 4707047265715997358L;
                            continue block32;
                        }
                        case -36153297: {
                            v13 = 22572L ^ -3454488244270545003L;
                            continue block32;
                        }
                        case -3147964: {
                            break block32;
                        }
                    }
                    break;
                }
                this.setBotConfig(v11);
            }
            return (boolean)(28669 ^ 28668);
        }
        return "".length() >>> "\u0000\u0000".length();
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private boolean hasSuccessfullyChangedHangars() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (-906304665455902504L >>> "\u0000\u0000".length())) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x142C ^ 0xFFFFEBD3)) break;
            l2 = 815663108 >>> "\u0000\u0000".length();
        }
        long l = \u13e8;
        block16: while (true) {
            switch ((int)l) {
                case -3147964: {
                    break block16;
                }
                case 190203032: {
                    l = (0x79BCL ^ 0x9D5A23C3011C58BCL) / (0xCBFL ^ 0x3605A5896402751EL);
                    continue block16;
                }
            }
            break;
        }
        HangarChangeConfig hangarChangeConfig = this.config.HANGAR_CHANGE_CONFIG;
        long l3 = \u13e8;
        boolean bl = true;
        block17: while (true) {
            long l4;
            if (!bl || (bl = false) || !true) {
                l3 = l4 / (0x3243L ^ 0xFF3985FF2E55D25L);
            }
            switch ((int)l3) {
                case -1194093420: {
                    l4 = 0x22A2L ^ 0xBE380397F00CAD17L;
                    continue block17;
                }
                case -847146838: {
                    l4 = 0x23B6L ^ 0xD53DEE95ABD715FCL;
                    continue block17;
                }
                case -3147964: {
                    break block17;
                }
                case 1972524895: {
                    l4 = 0x7740L ^ 0xCECE19B4BB53353AL;
                    continue block17;
                }
            }
            break;
        }
        if (!hangarChangeConfig.USE_HANGAR_CHANGE) {
            return "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        }
        long l5 = \u13e8;
        boolean bl2 = true;
        block18: while (true) {
            long l6;
            if (!bl2 || (bl2 = false) || !true) {
                l5 = l6 / (0x1134L ^ 0xBB05E416C7A00965L);
            }
            switch ((int)l5) {
                case -1102123242: {
                    l6 = 0x367DL ^ 0x7FA0593635ECF037L;
                    continue block18;
                }
                case -365296347: {
                    l6 = 0x691DL ^ 0x71DC5C1FD6925249L;
                    continue block18;
                }
                case -3147964: {
                    break block18;
                }
            }
            break;
        }
        if (this.hangarSwitcher != null) return "".length() >>> "\u0000\u0000".length();
        byte[] byArray = new byte[0x67A9 ^ 0x67BB];
        byArray[0x27C2 ^ 0x27CD] = 0x12D5 ^ 0xFFFFED0F;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x5914 ^ 0x597C;
        byArray[0x6942 ^ 0x6945] = 388 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x2F73 ^ 0x2F14;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 456 >>> "\u0000\u0000".length();
        byArray[0x99A ^ 0x993] = 128 >>> "\u0000\u0000".length();
        byArray[0x11C8 ^ 0x11CB] = 416 >>> "\u0000\u0000".length();
        byArray[0x3892 ^ 0x3890] = 0x5078 ^ 0x5058;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 476 >>> "\u0000\u0000".length();
        byArray[0xE07 ^ 0xE16] = 0x9B8 ^ 0x9CA;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x22C7 ^ 0x22A4;
        byArray["".length() >>> "\u0000\u0000".length()] = 0x135C ^ 0x1312;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x638A ^ 0x63E3;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x5ABD ^ 0x5AD8;
        byArray[0x46F2 ^ 0x46F7] = 440 >>> "\u0000\u0000".length();
        byArray[0x2D98 ^ 0x2D95] = 0x726C ^ 0x7218;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 460 >>> "\u0000\u0000".length();
        byArray[0x1C9C ^ 0x1C9D] = 444 >>> "\u0000\u0000".length();
        byArray[0xB97 ^ 0xB93] = 388 >>> "\u0000\u0000".length();
        String string = new String(byArray);
        while (true) {
            long l7;
            long l8;
            if ((l8 = (l7 = \u13e8 - (0x578FL ^ 0x97DF0EAFF39C6C1EL)) == 0L ? 0 : (l7 < 0L ? -1 : 1)) == false) continue;
            if (l8 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                this.log(string);
                return (0x41AE ^ 0x41AE) != 0;
            }
            l8 = 0x4E4F ^ 0xF44045DC;
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private boolean hasActiveHangarId(Integer expectedHangarId) {
        Integer actualHangarId;
        if (expectedHangarId == null) {
            return (0x46E4 ^ 0x46E4) != 0;
        }
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x51AEL ^ 0x76D0420D4DC4E418L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == (0x8EC ^ 0xFFFFF713)) {
                actualHangarId = this.getActiveHangarId();
                if (actualHangarId == null) {
                    return (0x6314 ^ 0x6314) != 0;
                }
                break;
            }
            l2 = 0x27B0 ^ 0x933D392F;
        }
        long l = \u13e8;
        boolean bl = true;
        block6: while (true) {
            long l3;
            if (!bl || (bl = false) || !true) {
                l = l3 / (0x71E8L ^ 0x4FCFDF84C3E9EAA1L);
            }
            switch ((int)l) {
                case -2004029886: {
                    l3 = 0x371CL ^ 0x7D57507F653221B3L;
                    continue block6;
                }
                case -3147964: {
                    return expectedHangarId.equals(actualHangarId);
                }
                case 921572467: {
                    l3 = 0x48D5L ^ 0xBFD4241E3271E8F8L;
                    continue block6;
                }
            }
            break;
        }
        return expectedHangarId.equals(actualHangarId);
    }

    /*
     * Exception decompiling
     */
    private Integer getActiveHangarId() {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 26[SWITCH]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private boolean shouldSwitchToAfterStingerConfig() {
        long l = \u13e8;
        boolean bl = true;
        block6: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x138L ^ 0xE893882CFBBC64EAL);
            }
            switch ((int)l) {
                case -2081896929: {
                    l2 = 0x2EE8L ^ 0xFDCC7899A4886DD2L;
                    continue block6;
                }
                case -3147964: {
                    return this.hasSuccessfullyChangedHangars();
                }
                case 806919878: {
                    l2 = 0x7D17L ^ 0x944CD5FCDAD3046FL;
                    continue block6;
                }
                case 1701288851: {
                    l2 = 0x52C6L ^ 0x5B712AC1C07AAD0AL;
                    continue block6;
                }
            }
            break;
        }
        return this.hasSuccessfullyChangedHangars();
    }

    /*
     * Unable to fully structure code
     */
    private void cacheMapCycleModuleWaitSeconds() {
        v0 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl5
        block12: while (true) {
            v0 = v1 / (18483L ^ -483665524737428657L);
lbl5:
            // 2 sources

            switch ((int)v0) {
                case -1421378610: {
                    v1 = 17874L ^ 1246995843110294900L;
                    continue block12;
                }
                case -3147964: {
                    break block12;
                }
                case 238844561: {
                    v1 = 13170L ^ 2218906864326413694L;
                    continue block12;
                }
                case 581888938: {
                    v1 = 85L ^ -6640829567294133184L;
                    continue block12;
                }
            }
            break;
        }
        v2 = this.getPersistentState();
        while (true) {
            if ((v3 = (cfr_temp_0 = StingerWarper.\u13e8 - (4111326191909814428L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v3 == (26470 ^ 26471)) break;
            v3 = 3825 ^ 1471302088;
        }
        v4 = this.getMapCycleModuleWaitSeconds();
        v5 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl28
        block14: while (true) {
            v5 = v6 / (22716L ^ -6333486004711253863L);
lbl28:
            // 2 sources

            switch ((int)v5) {
                case -1994084915: {
                    v6 = 25171L ^ 2020229649889922680L;
                    continue block14;
                }
                case -1870843354: {
                    v6 = 6627044598004685056L >>> "\u0000\u0000".length();
                    continue block14;
                }
                case -3147964: {
                    break block14;
                }
                case 1619646129: {
                    v6 = 4345L ^ -2885287036884513301L;
                    continue block14;
                }
            }
            break;
        }
        v2.setCachedMapCycleWaitSeconds(v4);
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private void resetCachedMapCycleModuleWaitSeconds() {
        long l = \u13e8;
        block10: while (true) {
            switch ((int)l) {
                case -3147964: {
                    break block10;
                }
                case 281236200: {
                    l = (0x3C20L ^ 0x9736DAF51E0E364FL) / (0x78C1L ^ 0xB9149FA221E4EF0AL);
                    continue block10;
                }
            }
            break;
        }
        PersistentState persistentState = this.getPersistentState();
        long l2 = \u13e8;
        boolean bl = true;
        block11: while (true) {
            long l3;
            if (!bl || (bl = false) || !true) {
                l2 = l3 / (0x4E96L ^ 0x575954EB7BF91AE4L);
            }
            switch ((int)l2) {
                case -3147964: {
                    break block11;
                }
                case 398564431: {
                    l3 = 0x68B3L ^ 0xAF44AED14C11821FL;
                    continue block11;
                }
                case 1262621543: {
                    l3 = 0x29A6L ^ 0x99C1592E5BBA84C9L;
                    continue block11;
                }
                case 1382582447: {
                    l3 = 0x4962L ^ 0x576DD3F435754330L;
                    continue block11;
                }
            }
            break;
        }
        persistentState.resetCachedMapCycleWaitSeconds();
    }

    /*
     * Unable to fully structure code
     */
    private void tickWaitStinger() {
        block76: {
            block77: {
                block78: {
                    v0 = StingerWarper.\u13e8;
                    if (true) ** GOTO lbl5
                    block61: while (true) {
                        v0 = v1 / (11059L ^ 4611921580361879521L);
lbl5:
                        // 2 sources

                        switch ((int)v0) {
                            case -26861973: {
                                v1 = 15994L ^ -1932568268337454880L;
                                continue block61;
                            }
                            case -3147964: {
                                break block61;
                            }
                            case 261035304: {
                                v1 = 11147L ^ 2625985490471912338L;
                                continue block61;
                            }
                        }
                        break;
                    }
                    if (!this.shouldChangeToStinger()) break block76;
                    v2 = StingerWarper.\u13e8;
                    if (true) ** GOTO lbl19
                    block62: while (true) {
                        v2 = v3 / (17374L ^ 8772554553835213078L);
lbl19:
                        // 2 sources

                        switch ((int)v2) {
                            case -940321450: {
                                v3 = 8608L ^ -2589591818193190518L;
                                continue block62;
                            }
                            case -3147964: {
                                break block62;
                            }
                            case 1116746393: {
                                v3 = 6648L ^ 3143872337312030066L;
                                continue block62;
                            }
                        }
                        break;
                    }
                    this.cacheMapCycleModuleWaitSeconds();
                    while (true) {
                        if ((v4 = (cfr_temp_0 = StingerWarper.\u13e8 - (13011L ^ -7679726377006304538L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                        if (v4 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                        v4 = 1690759020 >>> "\u0000\u0000".length();
                    }
                    this.isSwitchingHangarsToStinger = 24964 ^ 24965;
                    while (true) {
                        if ((v5 = (cfr_temp_1 = StingerWarper.\u13e8 - (24110L ^ -2892973127265924570L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                        if (v5 == (458 ^ 459)) break;
                        v5 = 3203 ^ -161139549;
                    }
                    v6 = StingerWarper.\u13e8;
                    if (true) ** GOTO lbl44
                    block65: while (true) {
                        v6 = (19998L ^ -3629823296255278190L) / (12585L ^ -1692280502457469424L);
lbl44:
                        // 2 sources

                        switch ((int)v6) {
                            case -1783261532: {
                                continue block65;
                            }
                            case -3147964: {
                                break block65;
                            }
                        }
                        break;
                    }
                    v7 = this.config.HANGAR_CHANGE_CONFIG;
                    while (true) {
                        if ((v8 = (cfr_temp_2 = StingerWarper.\u13e8 - (13553L ^ -5714169782610491254L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                        if (v8 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                        v8 = 20364 ^ -727128702;
                    }
                    if (!v7.USE_HANGAR_CHANGE) break block77;
                    v9 = StingerWarper.\u13e8;
                    if (true) ** GOTO lbl60
                    block67: while (true) {
                        v9 = v10 / (22104L ^ -5935938279617261364L);
lbl60:
                        // 2 sources

                        switch ((int)v9) {
                            case -100937504: {
                                v10 = 30448L ^ -2639313938932678964L;
                                continue block67;
                            }
                            case -3147964: {
                                break block67;
                            }
                            case 324442203: {
                                v10 = 24802L ^ -4467562252971573552L;
                                continue block67;
                            }
                        }
                        break;
                    }
                    if (this.canLogoutAndSwitchBack()) break block78;
                    v11 = StingerWarper.\u13e8;
                    if (true) ** GOTO lbl74
                    block68: while (true) {
                        v11 = (3505L ^ 4356552616092607100L) / (22489L ^ -6089656350730764119L);
lbl74:
                        // 2 sources

                        switch ((int)v11) {
                            case -3147964: {
                                break block68;
                            }
                            case 1442665286: {
                                continue block68;
                            }
                        }
                        break;
                    }
                    this.isSwitchingHangarsToStinger = 16765 ^ 16765;
                    return;
                }
                v12 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl86
                block69: while (true) {
                    v12 = v13 / (5660125823353811564L >>> "\u0000\u0000".length());
lbl86:
                    // 2 sources

                    switch ((int)v12) {
                        case -1378755294: {
                            v13 = 8015L ^ 8322466225835507692L;
                            continue block69;
                        }
                        case -1100601439: {
                            v13 = 5909L ^ -309463022152064231L;
                            continue block69;
                        }
                        case -3147964: {
                            break block69;
                        }
                        case 2134351552: {
                            v13 = 16454L ^ -1046703343867346981L;
                            continue block69;
                        }
                    }
                    break;
                }
                this.startStingerMapTimer();
                v14 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl103
                block70: while (true) {
                    v14 = v15 / (-3271031618681672260L >>> "\u0000\u0000".length());
lbl103:
                    // 2 sources

                    switch ((int)v14) {
                        case -1015073263: {
                            v15 = 25661L ^ -6138936474891239055L;
                            continue block70;
                        }
                        case -3147964: {
                            break block70;
                        }
                        case 1626863098: {
                            v15 = 442L ^ -495101815175714660L;
                            continue block70;
                        }
                    }
                    break;
                }
                v16 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl116
                block71: while (true) {
                    v16 = (6800L ^ 9154705946677885850L) / (3376L ^ 9105657985849664267L);
lbl116:
                    // 2 sources

                    switch ((int)v16) {
                        case -1988397685: {
                            continue block71;
                        }
                        case -3147964: {
                            break block71;
                        }
                    }
                    break;
                }
                v17 = this.config.HANGAR_CHANGE_CONFIG;
                v18 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl126
                block72: while (true) {
                    v18 = v19 / (12308L ^ 980645885514561432L);
lbl126:
                    // 2 sources

                    switch ((int)v18) {
                        case -810578650: {
                            v19 = 11713L ^ -6924945994228370154L;
                            continue block72;
                        }
                        case -347973105: {
                            v19 = 14252L ^ 2613600311374983668L;
                            continue block72;
                        }
                        case -3147964: {
                            break block72;
                        }
                        case 2089361385: {
                            v19 = 8948212248559935924L >>> "\u0000\u0000".length();
                            continue block72;
                        }
                    }
                    break;
                }
                v20 = v17.STINGER_HANGAR_ID;
                v21 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl143
                block73: while (true) {
                    v21 = v22 / (15013L ^ 8549059520523538574L);
lbl143:
                    // 2 sources

                    switch ((int)v21) {
                        case -1825584249: {
                            v22 = 550L ^ 8280340066381195088L;
                            continue block73;
                        }
                        case -998418264: {
                            v22 = 11584L ^ -5041393946729960447L;
                            continue block73;
                        }
                        case -3147964: {
                            break block73;
                        }
                        case 1336972259: {
                            v22 = 32348L ^ -7493976611333253763L;
                            continue block73;
                        }
                    }
                    break;
                }
                v23 = v20;
                v24 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl160
                block74: while (true) {
                    v24 = v25 / (12141L ^ 294840934152188723L);
lbl160:
                    // 2 sources

                    switch ((int)v24) {
                        case -3147964: {
                            break block74;
                        }
                        case 341447472: {
                            v25 = 31766L ^ -4467432942526470637L;
                            continue block74;
                        }
                        case 1290971729: {
                            v25 = 1155L ^ -2342692241043877136L;
                            continue block74;
                        }
                        case 2119618733: {
                            v25 = 12615L ^ 6231724280240764047L;
                            continue block74;
                        }
                    }
                    break;
                }
                this.logoutAndSwitchHangarTo(v23);
                break block76;
            }
            v26 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl179
            block75: while (true) {
                v26 = v27 / (20962L ^ -646978988441613313L);
lbl179:
                // 2 sources

                switch ((int)v26) {
                    case -2083672694: {
                        v27 = 32712L ^ 419402473260498990L;
                        continue block75;
                    }
                    case -3147964: {
                        break block75;
                    }
                    case 1616394835: {
                        v27 = 12296L ^ -6913106190526601120L;
                        continue block75;
                    }
                }
                break;
            }
            this.startStingerMapTimer();
        }
    }

    /*
     * Unable to fully structure code
     */
    private void tickStinger() {
        block45: {
            block46: {
                while (true) {
                    if ((v0 = (cfr_temp_0 = StingerWarper.\u13e8 - (13964L ^ 7371973082420059086L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                    if (v0 == (8297 ^ -8298)) break;
                    v0 = 22913 ^ 304218922;
                }
                this.updateKnownDeathsOnStingerMap();
                while (true) {
                    if ((v1 = (cfr_temp_1 = StingerWarper.\u13e8 - (28094L ^ -2032032069101180324L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                    if (v1 == (30146 ^ 30147)) break;
                    v1 = 24810 ^ -1725786434;
                }
                this.fixRefreshBug();
                while (true) {
                    if ((v2 = (cfr_temp_2 = StingerWarper.\u13e8 - (27L ^ -6062314710372770478L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                    if (v2 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                    v2 = 5509 ^ -84550923;
                }
                if (!this.isStingerComplete()) break block45;
                v3 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
                while (true) {
                    if ((v4 = (cfr_temp_3 = StingerWarper.\u13e8 - (23769L ^ -4538718556496510658L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                    if (v4 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                    v4 = 28483 ^ 1817930962;
                }
                this.isSwitchingHangarsBackToOriginal = v3;
                while (true) {
                    if ((v5 = (cfr_temp_4 = StingerWarper.\u13e8 - (11473L ^ -2938312683716155423L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                    if (v5 == (19771 ^ 19770)) break;
                    v5 = 20620 ^ -655894732;
                }
                while (true) {
                    if ((v6 = (cfr_temp_5 = StingerWarper.\u13e8 - (11764L ^ 1495341909868472734L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                    if (v6 == (8140 ^ 8141)) break;
                    v6 = 30025 ^ -93802633;
                }
                v7 = this.config.HANGAR_CHANGE_CONFIG;
                while (true) {
                    if ((v8 = (cfr_temp_6 = StingerWarper.\u13e8 - (8949L ^ 476082280935353292L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                    if (v8 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                    v8 = 8737 ^ 1422571473;
                }
                if (!v7.USE_HANGAR_CHANGE) break block45;
                while (true) {
                    if ((v9 = (cfr_temp_7 = StingerWarper.\u13e8 - (-2109805910760165500L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                    if (v9 == (11905 ^ -11906)) break;
                    v9 = 2295 ^ -527550980;
                }
                if (this.canLogoutAndSwitchBack()) break block46;
                while (true) {
                    if ((v10 = (cfr_temp_8 = StingerWarper.\u13e8 - (11335L ^ -7286110357754421269L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                    if (v10 == (8449 ^ 8448)) break;
                    v10 = 28040 ^ 176101765;
                }
                this.isSwitchingHangarsBackToOriginal = 28210 ^ 28210;
                v11 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl59
                block35: while (true) {
                    v11 = v12 / (21510L ^ 4670535460049880003L);
lbl59:
                    // 2 sources

                    switch ((int)v11) {
                        case -1756751911: {
                            v12 = 25502L ^ -3925042132795819985L;
                            continue block35;
                        }
                        case -3147964: {
                            break block35;
                        }
                        case 251979965: {
                            v12 = 7759L ^ -149089658625698261L;
                            continue block35;
                        }
                        case 298748170: {
                            v12 = 6203L ^ -6046746771836883604L;
                            continue block35;
                        }
                    }
                    break;
                }
                v13 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl75
                block36: while (true) {
                    v13 = (28102L ^ -3505405651233032802L) / (12845L ^ 1492886991718107220L);
lbl75:
                    // 2 sources

                    switch ((int)v13) {
                        case -2055206330: {
                            continue block36;
                        }
                        case -3147964: {
                            break block36;
                        }
                    }
                    break;
                }
                var2_1 = new byte[31857 ^ 31850];
                var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 18304 ^ 18365;
                var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 29290 ^ 29214;
                var2_1[12661 ^ 12645] = 16864 ^ 16832;
                var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 29586 ^ 29666;
                var2_1[2254 ^ 2244] = 25696 ^ 25621;
                var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 10663 ^ 10709;
                var2_1[22530 ^ 22537] = 456 >>> "\u0000\u0000".length();
                var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 21133 ^ 21241;
                var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 404 >>> "\u0000\u0000".length();
                var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 464 >>> "\u0000\u0000".length();
                var2_1[22948 ^ 22945] = 464 >>> "\u0000\u0000".length();
                var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 408 >>> "\u0000\u0000".length();
                var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 128 >>> "\u0000\u0000".length();
                var2_1["".length() >>> "\u0000\u0000".length()] = 28372 ^ 28311;
                var2_1[2752 ^ 2764] = 30113 ^ 30159;
                var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 10572 ^ 10604;
                var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 5355 ^ 5252;
                var2_1[22107 ^ 22082] = 25454 ^ 25359;
                var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 292 ^ 260;
                var2_1[4019 ^ 4007] = 9841 ^ 9748;
                var2_1[29897 ^ 29918] = 26602 ^ 26521;
                var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 4899 ^ 4941;
                var2_1[23016 ^ 23024] = 7006 ^ 6953;
                var2_1["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 1531 ^ 1434;
                var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 30184 ^ 30086;
                var2_1[5025 ^ 5029] = 31334 ^ 31241;
                var2_1[9707 ^ 9708] = 456 >>> "\u0000\u0000".length();
                var2_1["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 388 >>> "\u0000\u0000".length();
                v14 = new String(var2_1);
                v15 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl114
                block37: while (true) {
                    v15 = v16 / (28028L ^ 5245507388471651046L);
lbl114:
                    // 2 sources

                    switch ((int)v15) {
                        case -654448991: {
                            v16 = 16086L ^ 5677920959529968717L;
                            continue block37;
                        }
                        case -3147964: {
                            break block37;
                        }
                        case 462555723: {
                            v16 = 8588L ^ 4897214183775330166L;
                            continue block37;
                        }
                        case 2064229863: {
                            v16 = 4880L ^ 8823186913426432482L;
                            continue block37;
                        }
                    }
                    break;
                }
                v17 = new DisconnectModule(null, v14);
                while (true) {
                    if ((v18 = (cfr_temp_9 = StingerWarper.\u13e8 - (10101L ^ 3079303899302005979L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
                    if (v18 == (29638 ^ -29639)) break;
                    v18 = -258568888 >>> "\u0000\u0000".length();
                }
                this.main.setModule((Module)v17);
                return;
            }
            while (true) {
                if ((v19 = (cfr_temp_10 = StingerWarper.\u13e8 - (6404217982444443244L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
                if (v19 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v19 = 9755 ^ 1839240804;
            }
            v20 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl144
            block40: while (true) {
                v20 = (3155L ^ 4116715525568199974L) / (17371L ^ 6927093602982208302L);
lbl144:
                // 2 sources

                switch ((int)v20) {
                    case -1036064903: {
                        continue block40;
                    }
                    case -3147964: {
                        break block40;
                    }
                }
                break;
            }
            v21 = this.config.HANGAR_CHANGE_CONFIG;
            while (true) {
                if ((v22 = (cfr_temp_11 = StingerWarper.\u13e8 - (3407L ^ 6032144816972107704L)) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
                if (v22 == (27496 ^ -27497)) break;
                v22 = 1262 ^ -523489771;
            }
            v23 = v21.AFTER_STINGER_HANGAR_ID;
            v24 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl160
            block42: while (true) {
                v24 = v25 / (16610L ^ -1596991493089029699L);
lbl160:
                // 2 sources

                switch ((int)v24) {
                    case -1225453935: {
                        v25 = 22726L ^ -3227709206770948482L;
                        continue block42;
                    }
                    case -1058673863: {
                        v25 = 23357L ^ -6877529392599315195L;
                        continue block42;
                    }
                    case -3147964: {
                        break block42;
                    }
                    case 1930099171: {
                        v25 = 11168L ^ 8041179099936767806L;
                        continue block42;
                    }
                }
                break;
            }
            v26 = v23;
            while (true) {
                if ((v27 = (cfr_temp_12 = StingerWarper.\u13e8 - (29282L ^ 6428602340728215495L)) == 0L ? 0 : (cfr_temp_12 < 0L ? -1 : 1)) == false) continue;
                if (v27 == (26193 ^ -26194)) {
                    this.logoutAndSwitchHangarTo(v26);
                    break;
                }
                v27 = 12473 ^ -1440921876;
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private void fixRefreshBug() {
        block60: {
            block58: {
                block59: {
                    fixSeconds = 18068 ^ 18058;
                    v0 = StingerWarper.\u13e8;
                    if (true) ** GOTO lbl6
                    block36: while (true) {
                        v0 = v1 / (27338L ^ 4731663586108377432L);
lbl6:
                        // 2 sources

                        switch ((int)v0) {
                            case -525563238: {
                                v1 = 3997L ^ -86036754543015393L;
                                continue block36;
                            }
                            case -3147964: {
                                break block36;
                            }
                            case 156943056: {
                                v1 = 26939L ^ -8346027662228675560L;
                                continue block36;
                            }
                        }
                        break;
                    }
                    v2 = System.currentTimeMillis();
                    while (true) {
                        if ((v3 = (cfr_temp_0 = StingerWarper.\u13e8 - (24418L ^ 6558008245858972468L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                        if (v3 == (23876 ^ -23877)) break;
                        v3 = 19540 ^ 1999281969;
                    }
                    v4 = v2 - this.lastFixRefreshBugTimeStampMs;
                    while (true) {
                        if ((v5 = (cfr_temp_1 = StingerWarper.\u13e8 - (31303L ^ -7238567982521193453L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                        if (v5 == (19394 ^ 19395)) break;
                        v5 = 9404 ^ -1317453479;
                    }
                    v6 = fixSeconds;
                    while (true) {
                        if ((v7 = (cfr_temp_2 = StingerWarper.\u13e8 - (6331L ^ 7675862493404032854L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                        if (v7 == (5892 ^ -5893)) break;
                        v7 = 9917 ^ -1064321246;
                    }
                    if (v4 <= TimeUnit.SECONDS.toMillis(v6)) break block59;
                    v8 = StingerWarper.\u13e8;
                    if (true) ** GOTO lbl38
                    block40: while (true) {
                        v8 = v9 / (29860L ^ 5212967173179622970L);
lbl38:
                        // 2 sources

                        switch ((int)v8) {
                            case -2125531645: {
                                v9 = 2376808909213987840L >>> "\u0000\u0000".length();
                                continue block40;
                            }
                            case -1370312643: {
                                v9 = 11951L ^ -9087652468071423662L;
                                continue block40;
                            }
                            case -3147964: {
                                break block40;
                            }
                            case 1367471094: {
                                v9 = 17723L ^ 6911114393066927545L;
                                continue block40;
                            }
                        }
                        break;
                    }
                    v10 = System.currentTimeMillis();
                    while (true) {
                        if ((v11 = (cfr_temp_3 = StingerWarper.\u13e8 - (22493L ^ -7024704248538790137L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                        if (v11 != "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                            v11 = 9839 ^ 1300043745;
                            continue;
                        }
                        break block58;
                        break;
                    }
                }
                return;
            }
            this.lastFixRefreshBugTimeStampMs = v10;
            v12 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl65
            block42: while (true) {
                v12 = v13 / (-204502049170368288L >>> "\u0000\u0000".length());
lbl65:
                // 2 sources

                switch ((int)v12) {
                    case -457055007: {
                        v13 = 15920L ^ 6701694715516494423L;
                        continue block42;
                    }
                    case -176193563: {
                        v13 = 19014L ^ 5986396362946722165L;
                        continue block42;
                    }
                    case -3147964: {
                        break block42;
                    }
                }
                break;
            }
            v14 = System.currentTimeMillis();
            while (true) {
                if ((v15 = (cfr_temp_4 = StingerWarper.\u13e8 - (18713L ^ 8891424926382995183L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v15 == (5940 ^ -5941)) break;
                v15 = 32117 ^ -1362804054;
            }
            while (true) {
                if ((v16 = (cfr_temp_5 = StingerWarper.\u13e8 - (7633L ^ -5282272486799998399L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                if (v16 == (2427 ^ 2426)) break;
                v16 = 28472 ^ 1261307028;
            }
            timeEllapsedSinceLastRefreshMs = v14 - this.main.lastRefresh;
            v17 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl90
            block45: while (true) {
                v17 = v18 / (23375L ^ -5984712148531944282L);
lbl90:
                // 2 sources

                switch ((int)v17) {
                    case -1288162913: {
                        v18 = 28427L ^ 5022119846077916732L;
                        continue block45;
                    }
                    case -638940429: {
                        v18 = 727L ^ 4863534108878806134L;
                        continue block45;
                    }
                    case -3147964: {
                        break block45;
                    }
                }
                break;
            }
            while (true) {
                if ((v19 = (cfr_temp_6 = StingerWarper.\u13e8 - (27299L ^ -2850662445855002795L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                if (v19 == (11372 ^ 11373)) break;
                v19 = 26805 ^ -1086979118;
            }
            v20 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl108
            block47: while (true) {
                v20 = (27837L ^ -2036407609620367553L) / (9659L ^ -5844058472343464137L);
lbl108:
                // 2 sources

                switch ((int)v20) {
                    case -3147964: {
                        break block47;
                    }
                    case 656224737: {
                        continue block47;
                    }
                }
                break;
            }
            v21 = this.main.config;
            while (true) {
                if ((v22 = (cfr_temp_7 = StingerWarper.\u13e8 - (24614L ^ -2366993062051075844L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                if (v22 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v22 = 20259 ^ 1517674502;
            }
            v23 = v21.MISCELLANEOUS;
            while (true) {
                if ((v24 = (cfr_temp_8 = StingerWarper.\u13e8 - (2155L ^ -271798405642134500L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                if (v24 == (1235 ^ 1234)) break;
                v24 = 12891 ^ -1145307870;
            }
            v25 = v23.REFRESH_TIME;
            while (true) {
                if ((v26 = (cfr_temp_9 = StingerWarper.\u13e8 - (15871L ^ -1507820881302430843L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
                if (v26 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v26 = 22979 ^ 1602667675;
            }
            timeToEllapseTillRefreshMs = TimeUnit.MINUTES.toMillis(v25);
            timeTillRefreshMs = timeToEllapseTillRefreshMs - timeEllapsedSinceLastRefreshMs;
            if (timeTillRefreshMs > (22665L ^ 22665L)) break block60;
            v27 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl138
            block51: while (true) {
                v27 = v28 / (22020L ^ 5340897399504262494L);
lbl138:
                // 2 sources

                switch ((int)v27) {
                    case -1094370627: {
                        v28 = 16652L ^ -8584745427168891590L;
                        continue block51;
                    }
                    case -3147964: {
                        break block51;
                    }
                    case 1088957246: {
                        v28 = 4249L ^ -746871215818270371L;
                        continue block51;
                    }
                }
                break;
            }
            v29 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl151
            block52: while (true) {
                v29 = v30 / (19683L ^ 6799240300561712790L);
lbl151:
                // 2 sources

                switch ((int)v29) {
                    case -1062599210: {
                        v30 = 21392L ^ 1444602911538336204L;
                        continue block52;
                    }
                    case -3147964: {
                        break block52;
                    }
                    case 414763573: {
                        v30 = 25480L ^ 7848036377225114469L;
                        continue block52;
                    }
                    case 1154944047: {
                        v30 = 3521L ^ -5467876407926456499L;
                        continue block52;
                    }
                }
                break;
            }
            v31 = this.hero.drive;
            while (true) {
                if ((v32 = (cfr_temp_10 = StingerWarper.\u13e8 - (11772L ^ 6234016547214396752L)) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
                if (v32 == (28077 ^ -28078)) break;
                v32 = 17604 ^ 2029804109;
            }
            if (!v31.isMoving()) {
                while (true) {
                    if ((v33 = (cfr_temp_11 = StingerWarper.\u13e8 - (14808L ^ -5147957756258966199L)) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
                    if (v33 == (15342 ^ 15343)) {
                        ApiExtensions.refreshBot();
                        break;
                    }
                    v33 = 23187 ^ -129878617;
                }
            }
        }
    }

    private void logoutAndSwitchHangarTo(int hangarId) {
    }

    /*
     * Unable to fully structure code
     */
    public void install(Main main) {
        while (true) {
            if ((v0 = (cfr_temp_0 = StingerWarper.\u13e8 - (3982L ^ 8112519123023931516L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (6748 ^ -6749)) break;
            v0 = -1431399056 >>> "\u0000\u0000".length();
        }
        v1 = main.hero;
        v2 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl11
        block21: while (true) {
            v2 = v3 / (3239038776498384352L >>> "\u0000\u0000".length());
lbl11:
            // 2 sources

            switch ((int)v2) {
                case -926243992: {
                    v3 = 10912L ^ -830140747914299601L;
                    continue block21;
                }
                case -3147964: {
                    break block21;
                }
                case 1919393911: {
                    v3 = 1902L ^ -7306354752625679848L;
                    continue block21;
                }
            }
            break;
        }
        this.hero = v1;
        while (true) {
            if ((v4 = (cfr_temp_1 = StingerWarper.\u13e8 - (9472L ^ 1171903197386496951L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v4 == (1661 ^ 1660)) break;
            v4 = 2340 ^ -943855721;
        }
        v5 = main.backpage;
        while (true) {
            if ((v6 = (cfr_temp_2 = StingerWarper.\u13e8 - (28936L ^ 8045558183094274942L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v6 == (12130 ^ -12131)) break;
            v6 = 32031 ^ 1920816243;
        }
        this.backpage = v5;
        v7 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl37
        block24: while (true) {
            v7 = v8 / (13538L ^ -2233892464355687955L);
lbl37:
            // 2 sources

            switch ((int)v7) {
                case -3147964: {
                    break block24;
                }
                case 814274492: {
                    v8 = 8235L ^ 5301276550827261931L;
                    continue block24;
                }
                case 2049027881: {
                    v8 = 262L ^ 7450580785112340346L;
                    continue block24;
                }
                case 2142050924: {
                    v8 = 32727L ^ 5428134742090433168L;
                    continue block24;
                }
            }
            break;
        }
        v9 = main.backpage;
        v10 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl54
        block25: while (true) {
            v10 = v11 / (31139L ^ 6969881361562501012L);
lbl54:
            // 2 sources

            switch ((int)v10) {
                case -3147964: {
                    break block25;
                }
                case 1391123302: {
                    v11 = 4733L ^ -1015102492311866933L;
                    continue block25;
                }
                case 1710679483: {
                    v11 = 11937L ^ -2665319464258322184L;
                    continue block25;
                }
            }
            break;
        }
        v12 = v9.hangarManager;
        while (true) {
            if ((v13 = (cfr_temp_3 = StingerWarper.\u13e8 - (16963L ^ 4914754607714277897L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v13 == (27074 ^ -27075)) break;
            v13 = 5409 ^ 1189134066;
        }
        this.hangarManager = v12;
        while (true) {
            if ((v14 = (cfr_temp_4 = StingerWarper.\u13e8 - (28474L ^ -5096450817006647807L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v14 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v14 = 5879 ^ 656115343;
        }
        this.main = main;
        while (true) {
            if ((v15 = (cfr_temp_5 = StingerWarper.\u13e8 - (1240L ^ -8791424735522194798L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
            if (v15 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v15 = 3196 ^ 1102805293;
        }
        v16 = main.mapManager;
        v17 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl86
        block29: while (true) {
            v17 = (13228L ^ 7388522169089976807L) / (1173L ^ -7982642956711043915L);
lbl86:
            // 2 sources

            switch ((int)v17) {
                case -1731032976: {
                    continue block29;
                }
                case -3147964: {
                    break block29;
                }
            }
            break;
        }
        this.mapManager = v16;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private void markNpcSubnameKilled() {
        byte[] byArray = new byte[156 >>> "\u0000\u0000".length()];
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x72E6 ^ 0x728A;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x1342 ^ 0x1336;
        byArray[0x64CA ^ 0x64EB] = 0x5A65 ^ 0x5A45;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x73F ^ 0x74C;
        byArray[0x5675 ^ 0x5669] = 0x6922 ^ 0x6951;
        byArray[0x5B6E ^ 0x5B6A] = 404 >>> "\u0000\u0000".length();
        byArray[148 >>> "\u0000\u0000".length()] = 0x162D ^ 0x1648;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x1825 ^ 0x1846;
        byArray[0x405D ^ 0x405F] = 0x13B6 ^ 0x13DA;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x17BE ^ 0x179E;
        byArray[0x95C ^ 0x95F] = 0x59B9 ^ 0x59D5;
        byArray[0x5926 ^ 0x5906] = 440 >>> "\u0000\u0000".length();
        byArray[0x28F7 ^ 0x28FB] = 468 >>> "\u0000\u0000".length();
        byArray[0x78C1 ^ 0x78D2] = 128 >>> "\u0000\u0000".length();
        byArray[0x733A ^ 0x733A] = 0x5807 ^ 0x584C;
        byArray[0x1593 ^ 0x15B1] = 464 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 440 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 440 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 404 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x58D0 ^ 0x58BD;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 448 >>> "\u0000\u0000".length();
        byArray[0x549E ^ 0x5485] = 128 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x2BF4 ^ 0x2B97;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 476 >>> "\u0000\u0000".length();
        byArray[0x238C ^ 0x2389] = 0x5786 ^ 0x57E2;
        byArray[0x24E ^ 0x241] = 388 >>> "\u0000\u0000".length();
        byArray[0x33A0 ^ 0x33AD] = 392 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() ^ "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length();
        byArray[0x7708 ^ 0x7711] = 0x6014 ^ 0x6064;
        byArray[140 >>> "\u0000\u0000".length()] = 420 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x5570 ^ 0x551E;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 448 >>> "\u0000\u0000".length();
        byArray[152 >>> "\u0000\u0000".length()] = 0x5EB3 ^ 0x5EC1;
        byArray[0x1384 ^ 0x1391] = 0x6744 ^ 0x6721;
        byArray[0x42B ^ 0x42A] = 0x41FD ^ 0x4194;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 176 >>> "\u0000\u0000".length();
        byArray[0x4057 ^ 0x4073] = 436 >>> "\u0000\u0000".length();
        byArray[0x32AA ^ 0x32AC] = 128 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 128 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x12C0 ^ 0x12B3;
        String string = new String(byArray);
        long l = \u13e8;
        boolean bl = true;
        block11: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x4870L ^ 0x8E2B9EA83120C216L);
            }
            switch ((int)l) {
                case -871023447: {
                    l2 = 0x641BL ^ 0xDD95A6C3B30B63C4L;
                    continue block11;
                }
                case -3147964: {
                    break block11;
                }
                case 279582874: {
                    l2 = -2292309262550374092L >>> "\u0000\u0000".length();
                    continue block11;
                }
                case 1077243184: {
                    l2 = 0xAF1L ^ 0xED0CDC5501A6692L;
                    continue block11;
                }
            }
            break;
        }
        this.log(string);
        int n = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        long l3 = \u13e8;
        boolean bl2 = true;
        block12: while (true) {
            long l4;
            if (!bl2 || (bl2 = false) || !true) {
                l3 = l4 / (0x1834L ^ 0xAB500DC8D137D056L);
            }
            switch ((int)l3) {
                case -3147964: {
                    break block12;
                }
                case 1425285397: {
                    l4 = 0x4E56L ^ 0xA497D5E82D475D2EL;
                    continue block12;
                }
                case 2038252074: {
                    l4 = 0x2DA5L ^ 0xCA3329E19597AA36L;
                    continue block12;
                }
            }
            break;
        }
        this.useNpcSpawnTimer = n;
    }

    /*
     * Unable to fully structure code
     */
    private boolean hasKilledNpcSubname() {
        block95: {
            block96: {
                block94: {
                    block93: {
                        while (true) {
                            if ((v0 = (cfr_temp_0 = StingerWarper.\u13e8 - (22776L ^ 8818602881683826496L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                            if (v0 == (28670 ^ -28671)) break;
                            v0 = 27804 ^ -2070586154;
                        }
                        while (true) {
                            if ((v1 = (cfr_temp_1 = StingerWarper.\u13e8 - (10801L ^ -3808125645605378509L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                            if (v1 == (19124 ^ 19125)) break;
                            v1 = 20414 ^ 247322912;
                        }
                        v2 = this.config._STINGER_CONFIG;
                        while (true) {
                            if ((v3 = (cfr_temp_2 = StingerWarper.\u13e8 - (26359L ^ -7835337404145904885L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                            if (v3 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                            v3 = 4624 ^ 1614041811;
                        }
                        subname = v2.NPC_SUBNAME;
                        if (subname == null) break block93;
                        v4 = StingerWarper.\u13e8;
                        if (true) ** GOTO lbl23
                        block66: while (true) {
                            v4 = v5 / (14499L ^ 436298393598151195L);
lbl23:
                            // 2 sources

                            switch ((int)v4) {
                                case -1337197567: {
                                    v5 = 18498L ^ 4636737610558395190L;
                                    continue block66;
                                }
                                case -293294045: {
                                    v5 = -1316462202022074420L >>> "\u0000\u0000".length();
                                    continue block66;
                                }
                                case -3147964: {
                                    break block66;
                                }
                                case 798822852: {
                                    v5 = 26130L ^ 2983994738953821149L;
                                    continue block66;
                                }
                            }
                            break;
                        }
                        if (subname.length() != 0) break block94;
                    }
                    return "".length() >>> "\u0000\u0000".length();
                }
                v6 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl43
                block67: while (true) {
                    v6 = (9833L ^ -7071341591196069859L) / (8980075905053829564L >>> "\u0000\u0000".length());
lbl43:
                    // 2 sources

                    switch ((int)v6) {
                        case -3147964: {
                            break block67;
                        }
                        case 1375555213: {
                            continue block67;
                        }
                    }
                    break;
                }
                v7 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl52
                block68: while (true) {
                    v7 = v8 / (14246L ^ -3120535685504031766L);
lbl52:
                    // 2 sources

                    switch ((int)v7) {
                        case -1920955243: {
                            v8 = 12923L ^ 7700022372011099537L;
                            continue block68;
                        }
                        case -920929512: {
                            v8 = 25155L ^ -3384747475043202968L;
                            continue block68;
                        }
                        case -3147964: {
                            break block68;
                        }
                        case 2064451281: {
                            v8 = 6346L ^ -4930496962571452538L;
                            continue block68;
                        }
                    }
                    break;
                }
                target = this.hero.target;
                if (target == null) break block95;
                v9 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl70
                block69: while (true) {
                    v9 = v10 / (22376L ^ -2179855746933719820L);
lbl70:
                    // 2 sources

                    switch ((int)v9) {
                        case -838549830: {
                            v10 = 31017L ^ -3951120055922428494L;
                            continue block69;
                        }
                        case -3147964: {
                            break block69;
                        }
                        case 213075576: {
                            v10 = 16435L ^ 4994578247572340503L;
                            continue block69;
                        }
                    }
                    break;
                }
                if (!target.isValid()) break block95;
                v11 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl84
                block70: while (true) {
                    v11 = v12 / (1112L ^ -2812503549086938870L);
lbl84:
                    // 2 sources

                    switch ((int)v11) {
                        case -3147964: {
                            break block70;
                        }
                        case 130958913: {
                            v12 = 4254L ^ 8078346415709587810L;
                            continue block70;
                        }
                        case 905849544: {
                            v12 = 22233L ^ -8425285526497713411L;
                            continue block70;
                        }
                        case 2045035608: {
                            v12 = 11681L ^ 7312277441211097507L;
                            continue block70;
                        }
                    }
                    break;
                }
                v13 = target.playerInfo;
                while (true) {
                    if ((v14 = (cfr_temp_3 = StingerWarper.\u13e8 - (24918L ^ 4784202114339812194L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                    if (v14 == (17741 ^ -17742)) break;
                    v14 = 1649 ^ -605406043;
                }
                name = v13.getUsername();
                if (name == null) ** GOTO lbl-1000
                while (true) {
                    if ((v15 = (cfr_temp_4 = StingerWarper.\u13e8 - (6068003210450642916L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                    if (v15 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                    v15 = 20629 ^ -1329150098;
                }
                v16 = name.toLowerCase();
                v17 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl114
                block73: while (true) {
                    v17 = (3838597440476059488L >>> "\u0000\u0000".length()) / (-8048555987817865120L >>> "\u0000\u0000".length());
lbl114:
                    // 2 sources

                    switch ((int)v17) {
                        case -1112912875: {
                            continue block73;
                        }
                        case -3147964: {
                            break block73;
                        }
                    }
                    break;
                }
                v18 = subname.toLowerCase();
                while (true) {
                    if ((v19 = (cfr_temp_5 = StingerWarper.\u13e8 - (19831L ^ -1579232295507116648L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                    if (v19 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                    v19 = 14005 ^ 817759779;
                }
                if (v16.contains(v18)) {
                    v20 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
                } else lbl-1000:
                // 2 sources

                {
                    v20 = 12505 ^ 12505;
                }
                isNpcOfInterest = v20;
                while (true) {
                    if ((v21 = (cfr_temp_6 = StingerWarper.\u13e8 - (22629L ^ 3423395114274398137L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                    if (v21 == (26956 ^ -26957)) break;
                    v21 = 16701 ^ -1138005278;
                }
                targetId = target.getId();
                v22 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl140
                block76: while (true) {
                    v22 = v23 / (17192L ^ -2830443013489888965L);
lbl140:
                    // 2 sources

                    switch ((int)v22) {
                        case -3147964: {
                            break block76;
                        }
                        case 189745090: {
                            v23 = 17804L ^ 7620288378269356330L;
                            continue block76;
                        }
                        case 870204067: {
                            v23 = -833855553717314904L >>> "\u0000\u0000".length();
                            continue block76;
                        }
                        case 1413128772: {
                            v23 = 419L ^ -1751727713355394100L;
                            continue block76;
                        }
                    }
                    break;
                }
                if (this.lastNpcId == null) ** GOTO lbl-1000
                while (true) {
                    if ((v24 = (cfr_temp_7 = StingerWarper.\u13e8 - (4252L ^ 5424898796437318408L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                    if (v24 == (32470 ^ -32471)) break;
                    v24 = 27958 ^ 717678264;
                }
                while (true) {
                    if ((v25 = (cfr_temp_8 = StingerWarper.\u13e8 - (22593L ^ -9025814756038803854L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                    if (v25 == (32699 ^ 32698)) break;
                    v25 = 15845 ^ -1142708486;
                }
                if (targetId != this.lastNpcId) lbl-1000:
                // 2 sources

                {
                    v26 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
                } else {
                    v26 = "".length() >>> "\u0000\u0000".length();
                }
                diffTarget = v26;
                while (true) {
                    if ((v27 = (cfr_temp_9 = StingerWarper.\u13e8 - (21000L ^ 7045833043992891641L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
                    if (v27 == (11147 ^ -11148)) break;
                    v27 = 18706 ^ -1715516018;
                }
                this.useNpcSpawnTimer = 4325 ^ 4325;
                if (isNpcOfInterest == 0 || diffTarget == 0) break block96;
                v28 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl179
                block80: while (true) {
                    v28 = v29 / (20947L ^ -5210149993950006241L);
lbl179:
                    // 2 sources

                    switch ((int)v28) {
                        case -3147964: {
                            break block80;
                        }
                        case 699480627: {
                            v29 = 662L ^ -3319865137912063507L;
                            continue block80;
                        }
                        case 1801471896: {
                            v29 = 768949541312596312L >>> "\u0000\u0000".length();
                            continue block80;
                        }
                        case 2093839132: {
                            v29 = 22542L ^ -5236641703563566217L;
                            continue block80;
                        }
                    }
                    break;
                }
                v30 = targetId;
                v31 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl196
                block81: while (true) {
                    v31 = v32 / (6933L ^ 5662010597537683072L);
lbl196:
                    // 2 sources

                    switch ((int)v31) {
                        case -632558595: {
                            v32 = 27626L ^ 3921094543145120486L;
                            continue block81;
                        }
                        case -3147964: {
                            break block81;
                        }
                        case 2033061476: {
                            v32 = 30798L ^ 5388470010395692500L;
                            continue block81;
                        }
                    }
                    break;
                }
                this.lastNpcId = v30;
                v33 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
                v34 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl211
                block82: while (true) {
                    v34 = (19779L ^ -5805715272503127868L) / (1179L ^ -6825209051208109640L);
lbl211:
                    // 2 sources

                    switch ((int)v34) {
                        case -3147964: {
                            break block82;
                        }
                        case 47956118: {
                            continue block82;
                        }
                    }
                    break;
                }
                this.isAttackingNpcOfInterest = v33;
                return "".length() >>> "\u0000\u0000".length();
            }
            if (diffTarget == 0) break block95;
            v35 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl224
            block83: while (true) {
                v35 = v36 / (24095L ^ -5948570976758934458L);
lbl224:
                // 2 sources

                switch ((int)v35) {
                    case -2132715419: {
                        v36 = 13301L ^ -215814044217881323L;
                        continue block83;
                    }
                    case -3147964: {
                        break block83;
                    }
                    case 247745997: {
                        v36 = -2781787776623147744L >>> "\u0000\u0000".length();
                        continue block83;
                    }
                    case 1017532908: {
                        v36 = 13110L ^ -4996286469556940196L;
                        continue block83;
                    }
                }
                break;
            }
            if (!this.isAttackingNpcOfInterest) break block95;
            v37 = "".length() >>> "\u0000\u0000".length();
            v38 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl242
            block84: while (true) {
                v38 = v39 / (21611L ^ 7475329331745378264L);
lbl242:
                // 2 sources

                switch ((int)v38) {
                    case -1016327965: {
                        v39 = 6995L ^ 1935759268722023533L;
                        continue block84;
                    }
                    case -3147964: {
                        break block84;
                    }
                    case 185574879: {
                        v39 = 20319L ^ -1552589960172647678L;
                        continue block84;
                    }
                }
                break;
            }
            this.isAttackingNpcOfInterest = v37;
            while (true) {
                if ((v40 = (cfr_temp_10 = StingerWarper.\u13e8 - (26493L ^ 4193452853361232884L)) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
                if (v40 == (22988 ^ -22989)) break;
                v40 = 22510 ^ 1822291922;
            }
            this.markNpcSubnameKilled();
            return (boolean)(15545 ^ 15544);
        }
        return "".length() >>> "\u0000\u0000".length();
    }

    /*
     * Unable to fully structure code
     */
    private boolean isShootingStinger() {
        block24: {
            while (true) {
                if ((v0 = (cfr_temp_0 = StingerWarper.\u13e8 - (13930L ^ 8039603936317002491L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v0 == (6724 ^ -6725)) break;
                v0 = 31558 ^ 1599488807;
            }
            v1 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl10
            block12: while (true) {
                v1 = v2 / (24037L ^ -4520823675637618751L);
lbl10:
                // 2 sources

                switch ((int)v1) {
                    case -1536894509: {
                        v2 = 9045L ^ -4130435008381658562L;
                        continue block12;
                    }
                    case -3147964: {
                        break block12;
                    }
                    case 17514677: {
                        v2 = 28206L ^ -8162456484370185549L;
                        continue block12;
                    }
                    case 2041008215: {
                        v2 = 4629L ^ -737143512307643186L;
                        continue block12;
                    }
                }
                break;
            }
            target = this.hero.getLocalTarget();
            if (target == null) break block24;
            while (true) {
                if ((v3 = (cfr_temp_1 = StingerWarper.\u13e8 - (31679L ^ -5557202603329183803L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v3 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v3 = 1257739324 >>> "\u0000\u0000".length();
            }
            if (!target.isValid()) break block24;
            while (true) {
                if ((v4 = (cfr_temp_2 = StingerWarper.\u13e8 - (1782L ^ -6529545399619163015L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v4 == (5769 ^ 5768)) break;
                v4 = 14044 ^ 2016019839;
            }
            v5 = target.getEntityInfo();
            while (true) {
                if ((v6 = (cfr_temp_3 = StingerWarper.\u13e8 - (2421L ^ 7226958484650291968L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v6 == (3164 ^ -3165)) break;
                v6 = -345875384 >>> "\u0000\u0000".length();
            }
            name = v5.getUsername();
            if (name == null) ** GOTO lbl-1000
            while (true) {
                if ((v7 = (cfr_temp_4 = StingerWarper.\u13e8 - (1202L ^ 7688303310274601194L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v7 == (27335 ^ -27336)) break;
                v7 = 1198271500 >>> "\u0000\u0000".length();
            }
            v8 = name.toLowerCase();
            while (true) {
                if ((v9 = (cfr_temp_5 = StingerWarper.\u13e8 - (2855L ^ -7351877049588940576L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                if (v9 == (15471 ^ 15470)) break;
                v9 = 22762 ^ -1723397169;
            }
            v10 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl58
            block18: while (true) {
                v10 = v11 / (18303L ^ -109173100953477398L);
lbl58:
                // 2 sources

                switch ((int)v10) {
                    case -1177656041: {
                        v11 = 17748L ^ 7557890369291479875L;
                        continue block18;
                    }
                    case -3147964: {
                        break block18;
                    }
                    case 1759752437: {
                        v11 = 22329L ^ -4799755870041140053L;
                        continue block18;
                    }
                }
                break;
            }
            v12 = this.config._STINGER_CONFIG;
            while (true) {
                if ((v13 = (cfr_temp_6 = StingerWarper.\u13e8 - (9688L ^ 5407387900044780339L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                if (v13 == (20883 ^ -20884)) break;
                v13 = 21204 ^ -690531758;
            }
            v14 = v12.NPC_SUBNAME;
            while (true) {
                if ((v15 = (cfr_temp_7 = StingerWarper.\u13e8 - (3874079775100297572L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                if (v15 == (10673 ^ 10672)) break;
                v15 = 27562 ^ -1526486695;
            }
            v16 = v14.toLowerCase();
            while (true) {
                if ((v17 = (cfr_temp_8 = StingerWarper.\u13e8 - (-3908060571059658924L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                if (v17 == (23944 ^ -23945)) break;
                v17 = 8322 ^ -889796624;
            }
            if (v8.contains(v16)) {
                v18 = 18495 ^ 18494;
            } else lbl-1000:
            // 2 sources

            {
                v18 = "".length() >>> "\u0000\u0000".length();
            }
            return (boolean)v18;
        }
        return "".length() >>> "\u0000\u0000".length();
    }

    /*
     * Unable to fully structure code
     */
    private void setBotConfig(String config) {
        while (true) {
            if ((v0 = (cfr_temp_0 = StingerWarper.\u13e8 - (1295996048873768480L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (v0 == (26992 ^ 26993)) break;
            v0 = 27843 ^ -1547037121;
        }
        v1 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl11
        block6: while (true) {
            v1 = v2 / (20834L ^ -8695442453248143892L);
lbl11:
            // 2 sources

            switch ((int)v1) {
                case -3147964: {
                    break block6;
                }
                case 81045075: {
                    v2 = 2521L ^ -1265613484155114250L;
                    continue block6;
                }
                case 907643234: {
                    v2 = 6306L ^ 8022232640108959925L;
                    continue block6;
                }
            }
            break;
        }
        this.main.setConfig(config);
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private String getActiveConfigName() {
        long l = \u13e8;
        block13: while (true) {
            switch ((int)l) {
                case -3147964: {
                    break block13;
                }
                case 771542519: {
                    l = (0x7577L ^ 0xC9C9531B388F7E1L) / (0x32DAL ^ 0xE86D769864F8BA82L);
                    continue block13;
                }
            }
            break;
        }
        long l2 = \u13e8;
        block14: while (true) {
            switch ((int)l2) {
                case -3147964: {
                    break block14;
                }
                case 2140676799: {
                    l2 = (0x1E8AL ^ 0x4324F077417B68EAL) / (0x3B64L ^ 0x40C629A08D6C75B2L);
                    continue block14;
                }
            }
            break;
        }
        ConfigManager configManager = this.main.configManager;
        long l3 = \u13e8;
        boolean bl = true;
        block15: while (true) {
            long l4;
            if (!bl || (bl = false) || !true) {
                l3 = l4 / (0x4753L ^ 0x8CE10D5CF278FAB4L);
            }
            switch ((int)l3) {
                case -2008198310: {
                    l4 = 0x3651L ^ 0xD32032F373D8A32L;
                    continue block15;
                }
                case -1111527722: {
                    l4 = 0x5060L ^ 0xCA4C3102CBEE6135L;
                    continue block15;
                }
                case -3147964: {
                    return configManager.getConfigName();
                }
            }
            break;
        }
        return configManager.getConfigName();
    }

    /*
     * Unable to fully structure code
     */
    private boolean botIsUsingStingerConfig() {
        v0 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl5
        block15: while (true) {
            v0 = v1 / (-7421925045638875596L >>> "\u0000\u0000".length());
lbl5:
            // 2 sources

            switch ((int)v0) {
                case -1317616133: {
                    v1 = 429L ^ -5921346138092179622L;
                    continue block15;
                }
                case -3147964: {
                    break block15;
                }
                case 405940342: {
                    v1 = 23886L ^ -6591311887947751108L;
                    continue block15;
                }
                case 1858607093: {
                    v1 = 15531L ^ 7289379085703352292L;
                    continue block15;
                }
            }
            break;
        }
        v2 = this.getActiveConfigName();
        v3 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl22
        block16: while (true) {
            v3 = (18079L ^ 815756139762551872L) / (23878L ^ -5822873333572650253L);
lbl22:
            // 2 sources

            switch ((int)v3) {
                case -1838008451: {
                    continue block16;
                }
                case -3147964: {
                    break block16;
                }
            }
            break;
        }
        while (true) {
            if ((v4 = (cfr_temp_0 = StingerWarper.\u13e8 - (11381L ^ -4948865666792873966L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v4 == (31789 ^ 31788)) break;
            v4 = 7209 ^ -1258397087;
        }
        v5 = this.config._STINGER_CONFIG;
        while (true) {
            if ((v6 = (cfr_temp_1 = StingerWarper.\u13e8 - (13025L ^ -518620006301042577L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v6 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v6 = -978556388 >>> "\u0000\u0000".length();
        }
        v7 = v5.PROFILE_NAME;
        v8 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl43
        block19: while (true) {
            v8 = v9 / (30001L ^ -6511633916321716189L);
lbl43:
            // 2 sources

            switch ((int)v8) {
                case -74562284: {
                    v9 = 16524L ^ -7717967552669491376L;
                    continue block19;
                }
                case -3147964: {
                    break block19;
                }
                case 1785174879: {
                    v9 = 32505L ^ -2304535011841428108L;
                    continue block19;
                }
            }
            break;
        }
        return v2.equals(v7);
    }

    /*
     * Exception decompiling
     */
    private void tryUpdateHangarList() {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * java.lang.UnsupportedOperationException
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.considerAsDoLoopStart(LoopIdentifier.java:383)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.LoopIdentifier.identifyLoops1(LoopIdentifier.java:65)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:681)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    private void updateLabels() {
        boolean bl2 = "".length() >>> "\u0000\u0000".length();
        bl2 = "".length() >>> "\u0000\u0000".length();
        long l = \u13e8;
        boolean bl3 = true;
        block5: while (true) {
            long l2;
            if (!bl3 || (bl3 = false) || !true) {
                l = l2 / (0x6895L ^ 0x4309681798BCAE6FL);
            }
            switch ((int)l) {
                case -130618032: {
                    l2 = 0x6815L ^ 0x722466FE7D0B7F93L;
                    continue block5;
                }
                case -3147964: {
                    break block5;
                }
                case 1542170122: {
                    l2 = 0x3645L ^ 0xF04CEDA08AC4B1F9L;
                    continue block5;
                }
            }
            break;
        }
        this.updateLabels(bl, bl2);
    }

    /*
     * Unable to fully structure code
     */
    private void updateLabels(boolean clearStingerLabels, boolean clearNonStingerLabels) {
        while (true) {
            if ((v0 = (cfr_temp_0 = StingerWarper.\u13e8 - (19254L ^ 7902940112398286009L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (7772 ^ -7773)) break;
            v0 = 263 ^ -823984708;
        }
        v1 = System.currentTimeMillis();
        while (true) {
            if ((v2 = (cfr_temp_1 = StingerWarper.\u13e8 - (25316L ^ 5463346629549502518L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v2 == (14907 ^ -14908)) break;
            v2 = 24847 ^ 1113185195;
        }
        if (v1 - this.lastLabelUpdate >= 4000L >>> "\u0000\u0000".length()) {
            while (true) {
                if ((v3 = (cfr_temp_2 = StingerWarper.\u13e8 - (31451L ^ 9005897624339092038L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v3 == (26334 ^ -26335)) break;
                v3 = 11041 ^ -960610795;
            }
            v4 = System.currentTimeMillis();
            while (true) {
                if ((v5 = (cfr_temp_3 = StingerWarper.\u13e8 - (1820L ^ -6199446635397069912L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v5 != (8904 ^ 8905)) {
                    v5 = 9437 ^ -1898111109;
                    continue;
                }
                break;
            }
        } else {
            return;
        }
        this.lastLabelUpdate = v4;
        while (true) {
            if ((v6 = (cfr_temp_4 = StingerWarper.\u13e8 - (9045L ^ -8188830296815927700L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v6 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v6 = 12379 ^ 1848391137;
        }
        this.updateStatusLabel();
        while (true) {
            if ((v7 = (cfr_temp_5 = StingerWarper.\u13e8 - (9385L ^ -7971034222670285579L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
            if (v7 == (25559 ^ 25558)) break;
            v7 = 26005 ^ -890191781;
        }
        this.updateTimeWaitingForStingerLabel(clearStingerLabels);
        v8 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl43
        block18: while (true) {
            v8 = v9 / (4255L ^ 3818257101645802006L);
lbl43:
            // 2 sources

            switch ((int)v8) {
                case -1112604113: {
                    v9 = 28456L ^ 4370490221088780598L;
                    continue block18;
                }
                case -3147964: {
                    break block18;
                }
                case 1421919033: {
                    v9 = 20628L ^ 8910109736868996450L;
                    continue block18;
                }
                case 1899718071: {
                    v9 = 22530L ^ -5578459187493359536L;
                    continue block18;
                }
            }
            break;
        }
        this.updateTimeShootingStinger(clearStingerLabels);
        while (true) {
            if ((v10 = (cfr_temp_6 = StingerWarper.\u13e8 - (21160L ^ 1081371774328894387L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
            if (v10 == (30300 ^ 30301)) break;
            v10 = 15844 ^ -1932181147;
        }
        this.updateStingerDeathCount(clearStingerLabels);
        v11 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl66
        block20: while (true) {
            v11 = v12 / (18954L ^ 8360950544857333537L);
lbl66:
            // 2 sources

            switch ((int)v11) {
                case -1090013477: {
                    v12 = 5968129974773931256L >>> "\u0000\u0000".length();
                    continue block20;
                }
                case -917194325: {
                    v12 = 11935L ^ -3117994770933733903L;
                    continue block20;
                }
                case -3147964: {
                    break block20;
                }
                case 426858503: {
                    v12 = 27059L ^ -5986941528863197201L;
                    continue block20;
                }
            }
            break;
        }
        this.updateStingerMapMaxTime(clearStingerLabels);
        while (true) {
            if ((v13 = (cfr_temp_7 = StingerWarper.\u13e8 - (575L ^ -2830906872284843934L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
            if (v13 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v13 = 291978596 >>> "\u0000\u0000".length();
        }
        this.updateNextCheckLabel(clearNonStingerLabels);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void updateStatusLabel() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0xB9AL ^ 0xA7FFF2B3396CD895L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l2 = -1916390740 >>> "\u0000\u0000".length();
        }
        byte[] byArray = new byte["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
        byArray[0x7AAF ^ 0x7AAC] = 0x321E ^ 0xFFFFCDC3;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 464 >>> "\u0000\u0000".length();
        byArray[0x7529 ^ 0x752D] = 0x5EBD ^ 0x5EC8;
        byArray[0x24BE ^ 0x24B9] = 0x450E ^ 0x452E;
        byArray[0x55B0 ^ 0x55B5] = 0x16B ^ 0x118;
        byArray["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 464 >>> "\u0000\u0000".length();
        byArray[0x440E ^ 0x440C] = 388 >>> "\u0000\u0000".length();
        byArray[0x2AF1 ^ 0x2AF9] = 0x4AE4 ^ 0x4AC1;
        byArray[0x184C ^ 0x184A] = 0x7A89 ^ 0x7AB3;
        byArray["".length() >>> "\u0000\u0000".length()] = 0x7394 ^ 0x73C7;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 460 >>> "\u0000\u0000".length();
        String string = new String(byArray);
        Object[] objectArray = new Object["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
        int n = "".length() >>> "\u0000\u0000".length();
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = \u13e8 - (0x19EAL ^ 0x8F38004B39B91C23L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l3 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l3 = 0x202F ^ 0x507D0EF0;
        }
        objectArray[n] = this.status;
        while (true) {
            long l;
            long l4;
            if ((l4 = (l = \u13e8 - (0x6751L ^ 0x485024CC837161EFL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l4 == (0x2E4A ^ 0xFFFFD1B5)) break;
            l4 = 0x3E4 ^ 0xCD8E6008;
        }
        String string2 = String.format(string, objectArray);
        long l = \u13e8;
        block7: while (true) {
            switch ((int)l) {
                case -1631290133: {
                    l = (0x30A2L ^ 0x6FA6433F149092E4L) / (0xC16L ^ 0xBB4F1989A86E28B2L);
                    continue block7;
                }
                case -3147964: {
                    break block7;
                }
            }
            break;
        }
        this.statusLabel.setText(string2);
    }

    /*
     * Unable to fully structure code
     */
    private void updateNextCheckLabel(boolean clear) {
        block132: {
            block136: {
                block135: {
                    block134: {
                        block133: {
                            if (!clear) break block133;
                            while (true) {
                                if ((v0 = (cfr_temp_0 = StingerWarper.\u13e8 - (5928L ^ -2304851475049634622L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                                if (v0 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                                v0 = 15893 ^ -774189281;
                            }
                            var5_2 = new byte[2184 ^ 2184];
                            v1 = new String(var5_2);
                            v2 = StingerWarper.\u13e8;
                            if (true) ** GOTO lbl13
                            block95: while (true) {
                                v2 = (817L ^ -3074410997096778188L) / (3199L ^ 2435972438044197354L);
lbl13:
                                // 2 sources

                                switch ((int)v2) {
                                    case -1547636208: {
                                        continue block95;
                                    }
                                    case -3147964: {
                                        break block95;
                                    }
                                }
                                break;
                            }
                            this.nextCheckLabel.setText(v1);
                            return;
                        }
                        while (true) {
                            if ((v3 = (cfr_temp_1 = StingerWarper.\u13e8 - (1165L ^ -9165124597025738825L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                            if (v3 == (12081 ^ 12080)) break;
                            v3 = 17846 ^ -1304064703;
                        }
                        if (!this.dontCheckNextStingerCheck()) break block134;
                        v4 = StingerWarper.\u13e8;
                        if (true) ** GOTO lbl31
                        block97: while (true) {
                            v4 = (627L ^ 8736559174982126129L) / (13814L ^ 4508885661017476544L);
lbl31:
                            // 2 sources

                            switch ((int)v4) {
                                case -703967245: {
                                    continue block97;
                                }
                                case -3147964: {
                                    break block97;
                                }
                            }
                            break;
                        }
                        var5_3 = new byte[136 >>> "\u0000\u0000".length()];
                        var5_3[6691 ^ 6708] = 27225 ^ 27248;
                        var5_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 420 >>> "\u0000\u0000".length();
                        var5_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 396 >>> "\u0000\u0000".length();
                        var5_3[22382 ^ 22371] = 12924 ^ 12811;
                        var5_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 456 >>> "\u0000\u0000".length();
                        var5_3[30515 ^ 30519] = 31373 ^ 31461;
                        var5_3[11296 ^ 11312] = 416 >>> "\u0000\u0000".length();
                        var5_3[5119 ^ 5114] = 31078 ^ 30979;
                        var5_3[27195 ^ 27170] = 400 >>> "\u0000\u0000".length();
                        var5_3[6043 ^ 6074] = 400 >>> "\u0000\u0000".length();
                        var5_3[14222 ^ 14208] = 4373 ^ 4476;
                        var5_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 12123 ^ 12155;
                        var5_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 8386 ^ 8418;
                        var5_3[23937 ^ 23943] = 7638 ^ 7605;
                        var5_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 12921 ^ 12884;
                        var5_3[31985 ^ 31972] = 404 >>> "\u0000\u0000".length();
                        var5_3[21988 ^ 21988] = 312 >>> "\u0000\u0000".length();
                        var5_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 16089 ^ 16121;
                        var5_3["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 18142 ^ 18097;
                        var5_3[10778 ^ 10758] = 24639 ^ 24667;
                        var5_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 27402 ^ 27434;
                        var5_3[17522 ^ 17510] = 7796 ^ 7684;
                        var5_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 21387 ^ 21422;
                        var5_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 19202 ^ 19239;
                        var5_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 400 >>> "\u0000\u0000".length();
                        var5_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 128 >>> "\u0000\u0000".length();
                        var5_3[1041 ^ 1024] = 420 >>> "\u0000\u0000".length();
                        var5_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 440 >>> "\u0000\u0000".length();
                        var5_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 23752 ^ 23719;
                        var5_3[28600 ^ 28568] = 148 >>> "\u0000\u0000".length();
                        var5_3[14475 ^ 14476] = 8965 ^ 9070;
                        var5_3[8270 ^ 8262] = 12745 ^ 12773;
                        var5_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 128 >>> "\u0000\u0000".length();
                        var5_3["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 30621 ^ 30697;
                        var5_3[31641 ^ 31632] = 9809 ^ 9841;
                        v5 = new String(var5_3);
                        v6 = new Object["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
                        v7 = "".length() >>> "\u0000\u0000".length();
                        while (true) {
                            if ((v8 = (cfr_temp_2 = StingerWarper.\u13e8 - (15110L ^ -252410594229016268L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                            if (v8 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                            v8 = 1335 ^ -2100493247;
                        }
                        v9 = this.getHourNow();
                        while (true) {
                            if ((v10 = (cfr_temp_3 = StingerWarper.\u13e8 - (19967L ^ -38581985282796745L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                            if (v10 == (25215 ^ 25214)) break;
                            v10 = 31250 ^ -1199360019;
                        }
                        v6[v7] = v9;
                        while (true) {
                            if ((v11 = (cfr_temp_4 = StingerWarper.\u13e8 - (-1990810089098250936L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                            if (v11 == (26762 ^ -26763)) break;
                            v11 = 11874 ^ -1179274887;
                        }
                        v12 = StingerWarper.\u13e8;
                        if (true) ** GOTO lbl96
                        block101: while (true) {
                            v12 = v13 / (18927L ^ -1847969629214653892L);
lbl96:
                            // 2 sources

                            switch ((int)v12) {
                                case -1914790510: {
                                    v13 = 32171L ^ -8392343280756992820L;
                                    continue block101;
                                }
                                case -1536221208: {
                                    v13 = 13847L ^ -8256221874531479050L;
                                    continue block101;
                                }
                                case -3147964: {
                                    break block101;
                                }
                                case 283127246: {
                                    v13 = 11917L ^ -7150894017297586221L;
                                    continue block101;
                                }
                            }
                            break;
                        }
                        v14 = this.config._AFTER_STINGER_CONFIG;
                        v15 = StingerWarper.\u13e8;
                        if (true) ** GOTO lbl113
                        block102: while (true) {
                            v15 = v16 / (28236L ^ -8635548489679396312L);
lbl113:
                            // 2 sources

                            switch ((int)v15) {
                                case -542588557: {
                                    v16 = 28390L ^ 6691863270936219860L;
                                    continue block102;
                                }
                                case -3147964: {
                                    break block102;
                                }
                                case 180597123: {
                                    v16 = 13260L ^ -5403718476250427192L;
                                    continue block102;
                                }
                                case 1613946354: {
                                    v16 = 16036L ^ 4052503370476739474L;
                                    continue block102;
                                }
                            }
                            break;
                        }
                        v17 = v14.DONT_CHECK;
                        v18 = StingerWarper.\u13e8;
                        if (true) ** GOTO lbl130
                        block103: while (true) {
                            v18 = v19 / (8822L ^ -5247384416172720943L);
lbl130:
                            // 2 sources

                            switch ((int)v18) {
                                case -3147964: {
                                    break block103;
                                }
                                case 42861239: {
                                    v19 = 21060L ^ -4024065412571736150L;
                                    continue block103;
                                }
                                case 897515068: {
                                    v19 = 508L ^ 6377608224710655165L;
                                    continue block103;
                                }
                            }
                            break;
                        }
                        v20 = v17.START_HOUR;
                        while (true) {
                            if ((v21 = (cfr_temp_5 = StingerWarper.\u13e8 - (8067L ^ 4410225064004682334L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                            if (v21 == (21079 ^ -21080)) break;
                            v21 = 29503 ^ 826965040;
                        }
                        v6[1445 ^ 1444] = v20;
                        v22 = StingerWarper.\u13e8;
                        if (true) ** GOTO lbl150
                        block105: while (true) {
                            v22 = (8855L ^ -6395754867194544219L) / (29149L ^ -2808861239635157133L);
lbl150:
                            // 2 sources

                            switch ((int)v22) {
                                case -3147964: {
                                    break block105;
                                }
                                case 1272120629: {
                                    continue block105;
                                }
                            }
                            break;
                        }
                        while (true) {
                            if ((v23 = (cfr_temp_6 = StingerWarper.\u13e8 - (26829L ^ 6048175248388259263L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                            if (v23 == (18012 ^ -18013)) break;
                            v23 = 20752 ^ 556863128;
                        }
                        v24 = this.config._AFTER_STINGER_CONFIG;
                        while (true) {
                            if ((v25 = (cfr_temp_7 = StingerWarper.\u13e8 - (23971L ^ -8098037622857443945L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                            if (v25 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                            v25 = 13858 ^ -322033591;
                        }
                        v26 = v24.DONT_CHECK;
                        while (true) {
                            if ((v27 = (cfr_temp_8 = StingerWarper.\u13e8 - (5372L ^ 6376083710238564360L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                            if (v27 == (31881 ^ -31882)) break;
                            v27 = 28294 ^ -224858123;
                        }
                        v28 = v26.END_HOUR;
                        v29 = StingerWarper.\u13e8;
                        if (true) ** GOTO lbl177
                        block109: while (true) {
                            v29 = v30 / (10257L ^ -4582170561670610480L);
lbl177:
                            // 2 sources

                            switch ((int)v29) {
                                case -1314409347: {
                                    v30 = 22538L ^ 5338219231440691282L;
                                    continue block109;
                                }
                                case -109090536: {
                                    v30 = 2221989991594286228L >>> "\u0000\u0000".length();
                                    continue block109;
                                }
                                case -3147964: {
                                    break block109;
                                }
                                case 472386360: {
                                    v30 = 31089L ^ 215578885673066622L;
                                    continue block109;
                                }
                            }
                            break;
                        }
                        v6[23374 ^ 23372] = v28;
                        v31 = StingerWarper.\u13e8;
                        if (true) ** GOTO lbl194
                        block110: while (true) {
                            v31 = v32 / (4803L ^ -6933527002930904092L);
lbl194:
                            // 2 sources

                            switch ((int)v31) {
                                case -493692124: {
                                    v32 = 8782L ^ 7113662150318124014L;
                                    continue block110;
                                }
                                case -3147964: {
                                    break block110;
                                }
                                case 642814473: {
                                    v32 = 6742L ^ -1074521312762509399L;
                                    continue block110;
                                }
                                case 1159565885: {
                                    v32 = 31931L ^ -1610134013536933900L;
                                    continue block110;
                                }
                            }
                            break;
                        }
                        v33 = String.format(v5, v6);
                        while (true) {
                            if ((v34 = (cfr_temp_9 = StingerWarper.\u13e8 - (25355L ^ -1707714742392954492L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
                            if (v34 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                            v34 = 3841 ^ 1884859521;
                        }
                        this.nextCheckLabel.setText(v33);
                        return;
                    }
                    while (true) {
                        if ((v35 = (cfr_temp_10 = StingerWarper.\u13e8 - (15867L ^ 1969408550288115312L)) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
                        if (v35 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                        v35 = 10381 ^ -55493049;
                    }
                    while (true) {
                        if ((v36 = (cfr_temp_11 = StingerWarper.\u13e8 - (-989925475371684416L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
                        if (v36 == (26167 ^ -26168)) break;
                        v36 = 16298 ^ 1514613036;
                    }
                    v37 = this.getTimeTillNextSingerCheckMs();
                    while (true) {
                        if ((v38 = (cfr_temp_12 = StingerWarper.\u13e8 - (26240L ^ -2582589970948335048L)) == 0L ? 0 : (cfr_temp_12 < 0L ? -1 : 1)) == false) continue;
                        if (v38 == (25370 ^ 25371)) break;
                        v38 = 7007 ^ -856409761;
                    }
                    nextCheckMs = TimeUnit.MILLISECONDS.toSeconds(v37);
                    if (nextCheckMs <= 0L >>> "\u0000\u0000".length()) break block135;
                    while (true) {
                        if ((v39 = (cfr_temp_13 = StingerWarper.\u13e8 - (-5507483156209219944L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_13 < 0L ? -1 : 1)) == false) continue;
                        if (v39 == (31797 ^ -31798)) break;
                        v39 = 12566 ^ -1025194801;
                    }
                    var5_4 = new byte["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
                    var5_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 17486 ^ -17432;
                    var5_4[22065 ^ 22069] = 24338 ^ 24370;
                    var5_4["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 404 >>> "\u0000\u0000".length();
                    var5_4[18182 ^ 18192] = 148 >>> "\u0000\u0000".length();
                    var5_4[5141 ^ 5121] = 26168 ^ 26136;
                    var5_4[25773 ^ 25761] = 20566 ^ 20536;
                    var5_4[25661 ^ 25651] = 15285 ^ 15253;
                    var5_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 400 >>> "\u0000\u0000".length();
                    var5_4[2216 ^ 2221] = 4485 ^ 4582;
                    var5_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 3856 ^ 3960;
                    var5_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 30152 ^ 30140;
                    var5_4[155 ^ 155] = 12959 ^ 13009;
                    var5_4[29090 ^ 29096] = 14906 ^ 14874;
                    var5_4[13368 ^ 13354] = 30772 ^ 30791;
                    var5_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 420 >>> "\u0000\u0000".length();
                    var5_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 5188 ^ 5229;
                    var5_4[18814 ^ 18807] = 428 >>> "\u0000\u0000".length();
                    var5_4[13212 ^ 13193] = 160 >>> "\u0000\u0000".length();
                    var5_4[10859 ^ 10860] = 404 >>> "\u0000\u0000".length();
                    var5_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 164 >>> "\u0000\u0000".length();
                    var5_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 400 >>> "\u0000\u0000".length();
                    var5_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 28795 ^ 28675;
                    var5_4[5732 ^ 5739] = 148 >>> "\u0000\u0000".length();
                    var5_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 23263 ^ 23269;
                    var5_4[14923 ^ 14915] = 396 >>> "\u0000\u0000".length();
                    var5_4[206 ^ 223] = 160 >>> "\u0000\u0000".length();
                    v40 = new String(var5_4);
                    v41 = new Object["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
                    v42 = StingerWarper.\u13e8;
                    if (true) ** GOTO lbl271
                    block116: while (true) {
                        v42 = v43 / (1450811423408912600L >>> "\u0000\u0000".length());
lbl271:
                        // 2 sources

                        switch ((int)v42) {
                            case -9636623: {
                                v43 = 19966L ^ -4920921379453676725L;
                                continue block116;
                            }
                            case -3147964: {
                                break block116;
                            }
                            case 468174871: {
                                v43 = 20923L ^ -8839742984318427865L;
                                continue block116;
                            }
                        }
                        break;
                    }
                    v41[3912 ^ 3912] = nextCheckMs;
                    v44 = StingerWarper.\u13e8;
                    if (true) ** GOTO lbl285
                    block117: while (true) {
                        v44 = v45 / (2773920884458997512L >>> "\u0000\u0000".length());
lbl285:
                        // 2 sources

                        switch ((int)v44) {
                            case -3147964: {
                                break block117;
                            }
                            case 98952074: {
                                v45 = 8356L ^ 6763539161774587493L;
                                continue block117;
                            }
                            case 869089775: {
                                v45 = -8995224645176209484L >>> "\u0000\u0000".length();
                                continue block117;
                            }
                            case 2054564715: {
                                v45 = 19967L ^ 5535246833619292230L;
                                continue block117;
                            }
                        }
                        break;
                    }
                    v46 = StingerWarper.\u13e8;
                    if (true) ** GOTO lbl301
                    block118: while (true) {
                        v46 = v47 / (5381731151181686964L >>> "\u0000\u0000".length());
lbl301:
                        // 2 sources

                        switch ((int)v46) {
                            case -1409265044: {
                                v47 = 19691L ^ 5886074961964181582L;
                                continue block118;
                            }
                            case -991372416: {
                                v47 = 2060L ^ -3102785257389888411L;
                                continue block118;
                            }
                            case -3147964: {
                                break block118;
                            }
                        }
                        break;
                    }
                    v41[8297 ^ 8296] = this.manualResetCount;
                    while (true) {
                        if ((v48 = (cfr_temp_14 = StingerWarper.\u13e8 - (10984L ^ -265409410350929208L)) == 0L ? 0 : (cfr_temp_14 < 0L ? -1 : 1)) == false) continue;
                        if (v48 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                        v48 = 22754 ^ -520585066;
                    }
                    v49 = String.format(v40, v41);
                    while (true) {
                        if ((v50 = (cfr_temp_15 = StingerWarper.\u13e8 - (27760L ^ 8233031852897093681L)) == 0L ? 0 : (cfr_temp_15 < 0L ? -1 : 1)) == false) continue;
                        if (v50 == (29536 ^ -29537)) {
                            this.nextCheckLabel.setText(v49);
                            break block132;
                        }
                        v50 = -911726396 >>> "\u0000\u0000".length();
                    }
                }
                while (true) {
                    if ((v51 = (cfr_temp_16 = StingerWarper.\u13e8 - (27162L ^ 6670641651318357554L)) == 0L ? 0 : (cfr_temp_16 < 0L ? -1 : 1)) == false) continue;
                    if (v51 == (23112 ^ -23113)) break;
                    v51 = 27136 ^ 1259206045;
                }
                v52 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl334
                block122: while (true) {
                    v52 = v53 / (19940L ^ -7378197923672955484L);
lbl334:
                    // 2 sources

                    switch ((int)v52) {
                        case -524435535: {
                            v53 = 13687L ^ 8186997024276472850L;
                            continue block122;
                        }
                        case -321897367: {
                            v53 = -764393945041365020L >>> "\u0000\u0000".length();
                            continue block122;
                        }
                        case -3147964: {
                            break block122;
                        }
                        case 1734933771: {
                            v53 = 22486L ^ -9055473812547496816L;
                            continue block122;
                        }
                    }
                    break;
                }
                v54 = this.config.MAP_CYCLE_LINK_CONFIG;
                v55 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl351
                block123: while (true) {
                    v55 = v56 / (-6775205056579066380L >>> "\u0000\u0000".length());
lbl351:
                    // 2 sources

                    switch ((int)v55) {
                        case -709514800: {
                            v56 = 13980L ^ 4128689911641074552L;
                            continue block123;
                        }
                        case -3147964: {
                            break block123;
                        }
                        case 1261415190: {
                            v56 = -4996363122828986576L >>> "\u0000\u0000".length();
                            continue block123;
                        }
                    }
                    break;
                }
                if (!v54.LINK_TO_MAP_CYCLE) break block136;
                v57 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl365
                block124: while (true) {
                    v57 = v58 / (20889L ^ 8940457707123570656L);
lbl365:
                    // 2 sources

                    switch ((int)v57) {
                        case -3147964: {
                            break block124;
                        }
                        case 1251430690: {
                            v58 = 4195L ^ 7546311765927833160L;
                            continue block124;
                        }
                        case 1666285605: {
                            v58 = 27821L ^ -5752667784144099161L;
                            continue block124;
                        }
                    }
                    break;
                }
                if (!this.mapCycleIsCurrentModule()) break block136;
                while (true) {
                    if ((v59 = (cfr_temp_17 = StingerWarper.\u13e8 - (1634L ^ 3311564951114978542L)) == 0L ? 0 : (cfr_temp_17 < 0L ? -1 : 1)) == false) continue;
                    if (v59 == (31523 ^ -31524)) break;
                    v59 = 23132 ^ 1117189960;
                }
                var5_5 = new byte[4117 ^ 4109];
                var5_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 360 >>> "\u0000\u0000".length();
                var5_5[13817 ^ 13809] = 15917 ^ 15950;
                var5_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 3342 ^ 3366;
                var5_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 2225 ^ 2288;
                var5_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 480 >>> "\u0000\u0000".length();
                var5_5[11549 ^ 11537] = 328 >>> "\u0000\u0000".length();
                var5_5[6740 ^ 6750] = 232 >>> "\u0000\u0000".length();
                var5_5[11365 ^ 11363] = 416 >>> "\u0000\u0000".length();
                var5_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 2913 ^ 2881;
                var5_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 3766 ^ 3731;
                var5_5[11924 ^ 11933] = 428 >>> "\u0000\u0000".length();
                var5_5["".length() >>> "\u0000\u0000".length()] = 9207 ^ 9145;
                var5_5[22845 ^ 22844] = 404 >>> "\u0000\u0000".length();
                var5_5[24409 ^ 24402] = 128 >>> "\u0000\u0000".length();
                var5_5[23586 ^ 23597] = 15769 ^ 15837;
                var5_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 4727 ^ 4695;
                var5_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 11698 ^ 11718;
                var5_5[25848 ^ 25839] = 21262 ^ 21287;
                var5_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 460 >>> "\u0000\u0000".length();
                var5_5[6982 ^ 6996] = 180 >>> "\u0000\u0000".length();
                var5_5[1670 ^ 1685] = 128 >>> "\u0000\u0000".length();
                var5_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 1655 ^ 1556;
                var5_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 404 >>> "\u0000\u0000".length();
                var5_5["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 26952 ^ 26893;
                var5_5[3735 ^ 3719] = 356 >>> "\u0000\u0000".length();
                v60 = new String(var5_5);
                v61 = new Object[21449 ^ 21448];
                v62 = "".length() >>> "\u0000\u0000".length();
                v63 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl413
                block126: while (true) {
                    v63 = v64 / (-4309434304533092124L >>> "\u0000\u0000".length());
lbl413:
                    // 2 sources

                    switch ((int)v63) {
                        case -2114985972: {
                            v64 = 28080L ^ -5055131272952038945L;
                            continue block126;
                        }
                        case -3147964: {
                            break block126;
                        }
                        case 100915511: {
                            v64 = 10477L ^ 6486490097161329984L;
                            continue block126;
                        }
                        case 416621179: {
                            v64 = 11560L ^ -8901576312115498944L;
                            continue block126;
                        }
                    }
                    break;
                }
                v61[v62] = this.getMapCycleWaitStatus();
                while (true) {
                    if ((v65 = (cfr_temp_18 = StingerWarper.\u13e8 - (221L ^ 4585173405918895666L)) == 0L ? 0 : (cfr_temp_18 < 0L ? -1 : 1)) == false) continue;
                    if (v65 == (29896 ^ -29897)) break;
                    v65 = -335517568 >>> "\u0000\u0000".length();
                }
                v66 = String.format(v60, v61);
                v67 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl436
                block128: while (true) {
                    v67 = v68 / (1417071334910915260L >>> "\u0000\u0000".length());
lbl436:
                    // 2 sources

                    switch ((int)v67) {
                        case -3147964: {
                            break block128;
                        }
                        case 1132838492: {
                            v68 = 5388L ^ -6254538892842234226L;
                            continue block128;
                        }
                        case 1897033345: {
                            v68 = 12958L ^ -3921671954835924529L;
                            continue block128;
                        }
                    }
                    break;
                }
                this.nextCheckLabel.setText(v66);
                break block132;
            }
            v69 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl452
            block129: while (true) {
                v69 = (-2682476417537780916L >>> "\u0000\u0000".length()) / (25372L ^ 5153788676197058556L);
lbl452:
                // 2 sources

                switch ((int)v69) {
                    case -3147964: {
                        break block129;
                    }
                    case 579320755: {
                        continue block129;
                    }
                }
                break;
            }
            var5_6 = new byte["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
            var5_6["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
            var5_6["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 416 >>> "\u0000\u0000".length();
            var5_6["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 464 >>> "\u0000\u0000".length();
            var5_6[26411 ^ 26407] = 30413 ^ 30367;
            var5_6["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 3042 ^ 3003;
            var5_6[15884 ^ 15877] = 625 ^ 538;
            var5_6["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 6732 ^ 6708;
            var5_6["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 4190 ^ 4127;
            var5_6[23883 ^ 23876] = 272 >>> "\u0000\u0000".length();
            var5_6[27054 ^ 27046] = 396 >>> "\u0000\u0000".length();
            var5_6[20584 ^ 20588] = 20450 ^ 20418;
            var5_6["".length() >>> "\u0000\u0000".length()] = 14653 ^ 14707;
            var5_6["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 12519 ^ 12418;
            var5_6["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 14652 ^ 14681;
            var5_6["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 20261 ^ 20294;
            var5_6[30808 ^ 30805] = 276 >>> "\u0000\u0000".length();
            var5_6[23328 ^ 23338] = 13779 ^ 13801;
            var5_6[15059 ^ 15064] = 128 >>> "\u0000\u0000".length();
            v70 = new String(var5_6);
            v71 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl481
            block130: while (true) {
                v71 = v72 / (24466L ^ 2231550249173954280L);
lbl481:
                // 2 sources

                switch ((int)v71) {
                    case -1272601325: {
                        v72 = 15457L ^ 1329686055141744474L;
                        continue block130;
                    }
                    case -428692834: {
                        v72 = 1822L ^ 7217106800708491644L;
                        continue block130;
                    }
                    case -3147964: {
                        break block130;
                    }
                    case 862696129: {
                        v72 = 22697L ^ 2938834306901399524L;
                        continue block130;
                    }
                }
                break;
            }
            this.nextCheckLabel.setText(v70);
        }
    }

    /*
     * Unable to fully structure code
     */
    private String getMapCycleWaitStatus() {
        v0 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl5
        block16: while (true) {
            v0 = (1301L ^ -3945329088814557893L) / (942L ^ -2368438729439612140L);
lbl5:
            // 2 sources

            switch ((int)v0) {
                case -3147964: {
                    break block16;
                }
                case 351330164: {
                    continue block16;
                }
            }
            break;
        }
        waitSeconds = this.getMapCycleModuleWaitSeconds();
        var3_2 = new byte["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
        var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 18184 ^ -18248;
        var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 4070 ^ 4038;
        var3_2["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 460 >>> "\u0000\u0000".length();
        var3_2[12611 ^ 12612] = 1213 ^ 1176;
        var3_2[32219 ^ 32219] = 308 >>> "\u0000\u0000".length();
        var3_2[32687 ^ 32679] = 400 >>> "\u0000\u0000".length();
        var3_2[4973 ^ 4972] = 3861 ^ 3926;
        var3_2[1134 ^ 1130] = 15862 ^ 15827;
        var3_2[27373 ^ 27375] = 232 >>> "\u0000\u0000".length();
        var3_2[16702 ^ 16696] = 20698 ^ 20725;
        v1 = new String(var3_2);
        v2 = new Object[21871 ^ 21869];
        v3 = "".length() >>> "\u0000\u0000".length();
        if (waitSeconds == null) {
            var3_2 = new byte["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
            var3_2[32246 ^ 32247] = 32429 ^ 32488;
            var3_2[19945 ^ 19944] = 16562 ^ 16595;
            var3_2[27997 ^ 27997] = 312 >>> "\u0000\u0000".length();
            var3_2[31278 ^ 31276] = 3453 ^ 3379;
            v4 = new String(var3_2);
        } else {
            v4 = waitSeconds;
        }
        v2[v3] = v4;
        v5 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        v6 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl40
        block17: while (true) {
            v6 = v7 / (1798L ^ -7726014007362175890L);
lbl40:
            // 2 sources

            switch ((int)v6) {
                case -2127374750: {
                    v7 = 24388L ^ 2472503923172726539L;
                    continue block17;
                }
                case -18883041: {
                    v7 = 32159L ^ 5663816660395902021L;
                    continue block17;
                }
                case -3147964: {
                    break block17;
                }
                case 1369850156: {
                    v7 = 26539L ^ 2659713156937457019L;
                    continue block17;
                }
            }
            break;
        }
        while (true) {
            if ((v8 = (cfr_temp_0 = StingerWarper.\u13e8 - (5167L ^ 1734811950675266038L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v8 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v8 = 13915 ^ -1717313213;
        }
        v9 = this.config.MAP_CYCLE_LINK_CONFIG;
        while (true) {
            if ((v10 = (cfr_temp_1 = StingerWarper.\u13e8 - (20393L ^ 8629060347692161680L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v10 == (19979 ^ -19980)) break;
            v10 = 1925131108 >>> "\u0000\u0000".length();
        }
        v11 = v9.WAIT_AFTER_KILL_PREDICTED_SPAWN_THRESH;
        while (true) {
            if ((v12 = (cfr_temp_2 = StingerWarper.\u13e8 - (29195L ^ 5796460208933056811L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v12 == (22265 ^ -22266)) break;
            v12 = 190965796 >>> "\u0000\u0000".length();
        }
        v2[v5] = v11;
        v13 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl74
        block21: while (true) {
            v13 = v14 / (14508L ^ -8246846737705976033L);
lbl74:
            // 2 sources

            switch ((int)v13) {
                case -2129572593: {
                    v14 = 13802L ^ -6373841186213239373L;
                    continue block21;
                }
                case -1647981050: {
                    v14 = 31047L ^ 3797187518518311744L;
                    continue block21;
                }
                case -1645196523: {
                    v14 = 25004L ^ 8051115107065911031L;
                    continue block21;
                }
                case -3147964: {
                    break block21;
                }
            }
            break;
        }
        return String.format(v1, v2);
    }

    /*
     * Unable to fully structure code
     */
    private void updateTimeWaitingForStingerLabel(boolean clear) {
        block64: {
            block63: {
                if (clear) {
                    while (true) {
                        if ((v0 = (cfr_temp_0 = StingerWarper.\u13e8 - (7918L ^ 3012281423030591782L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                        if (v0 == (29260 ^ -29261)) break;
                        v0 = 4404 ^ -58072991;
                    }
                    var4_2 = new byte["".length() >>> "\u0000\u0000".length()];
                    v1 = new String(var4_2);
                    while (true) {
                        if ((v2 = (cfr_temp_1 = StingerWarper.\u13e8 - (8523L ^ -1336222606490527980L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                        if (v2 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                        v2 = 20312 ^ -1749198721;
                    }
                    this.timeWaitingForStingerLabel.setText(v1);
                    return;
                }
                while (true) {
                    if ((v3 = (cfr_temp_2 = StingerWarper.\u13e8 - (28603L ^ -8088868762017447168L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                    if (v3 == (25169 ^ 25168)) break;
                    v3 = 31090 ^ 3611501;
                }
                timeWaitingMs = this.getTimeWaitingForStingerMs();
                if (timeWaitingMs != null) break block63;
                v4 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl27
                block49: while (true) {
                    v4 = v5 / (11748L ^ 8766809512996306133L);
lbl27:
                    // 2 sources

                    switch ((int)v4) {
                        case -3147964: {
                            break block49;
                        }
                        case 766622059: {
                            v5 = 25444L ^ 6304333999607252093L;
                            continue block49;
                        }
                        case 2064660293: {
                            v5 = 23800L ^ 3939068130402018144L;
                            continue block49;
                        }
                    }
                    break;
                }
                var4_3 = new byte[23091 ^ 23091];
                v6 = new String(var4_3);
                v7 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl42
                block50: while (true) {
                    v7 = v8 / (3461L ^ 2237988256059392583L);
lbl42:
                    // 2 sources

                    switch ((int)v7) {
                        case -763236040: {
                            v8 = 25366L ^ -1162761733839933509L;
                            continue block50;
                        }
                        case -3147964: {
                            break block50;
                        }
                        case 1827629996: {
                            v8 = -4289001578844680056L >>> "\u0000\u0000".length();
                            continue block50;
                        }
                    }
                    break;
                }
                this.timeWaitingForStingerLabel.setText(v6);
                break block64;
            }
            while (true) {
                if ((v9 = (cfr_temp_3 = StingerWarper.\u13e8 - (19472L ^ 5459518095443816656L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v9 == (4039 ^ -4040)) break;
                v9 = 32070 ^ 1118444541;
            }
            var4_4 = new byte["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
            var4_4[32597 ^ 32598] = 632 ^ -590;
            var4_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 3678 ^ 3626;
            var4_4[25187 ^ 25201] = 32270 ^ 32362;
            var4_4[172 ^ 169] = 440 >>> "\u0000\u0000".length();
            var4_4[19767 ^ 19769] = 11971 ^ 11936;
            var4_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 188 >>> "\u0000\u0000".length();
            var4_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 16428 ^ 16459;
            var4_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 148 >>> "\u0000\u0000".length();
            var4_4[15044 ^ 15059] = 460 >>> "\u0000\u0000".length();
            var4_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 32758 ^ 32658;
            var4_4[3997 ^ 3993] = 11408 ^ 11513;
            var4_4["".length() >>> "\u0000\u0000".length()] = 348 >>> "\u0000\u0000".length();
            var4_4["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 388 >>> "\u0000\u0000".length();
            var4_4[19969 ^ 19976] = 25401 ^ 25430;
            var4_4[31741 ^ 31733] = 408 >>> "\u0000\u0000".length();
            var4_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 448 >>> "\u0000\u0000".length();
            var4_4[26456 ^ 26432] = 3948 ^ 3909;
            var4_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 232 >>> "\u0000\u0000".length();
            var4_4[16655 ^ 16665] = 160 >>> "\u0000\u0000".length();
            var4_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 30765 ^ 30733;
            var4_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 30542 ^ 30574;
            var4_4[26123 ^ 26121] = 5704 ^ 5665;
            var4_4[20794 ^ 20782] = 7012 ^ 6977;
            var4_4[6196 ^ 6206] = 25984 ^ 26098;
            var4_4[1708 ^ 1696] = 440 >>> "\u0000\u0000".length();
            var4_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 9245 ^ 9277;
            v10 = new String(var4_4);
            v11 = new Object["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
            v12 = "".length() >>> "\u0000\u0000".length();
            v13 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl93
            block52: while (true) {
                v13 = v14 / (-8759026448899673660L >>> "\u0000\u0000".length());
lbl93:
                // 2 sources

                switch ((int)v13) {
                    case -3147964: {
                        break block52;
                    }
                    case 209373360: {
                        v14 = 7200417994110336032L >>> "\u0000\u0000".length();
                        continue block52;
                    }
                    case 461306972: {
                        v14 = 26923L ^ 5939217075455105712L;
                        continue block52;
                    }
                }
                break;
            }
            v15 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl106
            block53: while (true) {
                v15 = v16 / (28656L ^ 2450210970974649866L);
lbl106:
                // 2 sources

                switch ((int)v15) {
                    case -1442684790: {
                        v16 = 10869L ^ -5699827402410073531L;
                        continue block53;
                    }
                    case -1192834272: {
                        v16 = 20192L ^ -3928766100674525016L;
                        continue block53;
                    }
                    case -165188372: {
                        v16 = 32630L ^ -4490606502996340061L;
                        continue block53;
                    }
                    case -3147964: {
                        break block53;
                    }
                }
                break;
            }
            v17 = timeWaitingMs;
            v18 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl123
            block54: while (true) {
                v18 = (663L ^ 6708435145656764142L) / (23844L ^ -4929287626710649779L);
lbl123:
                // 2 sources

                switch ((int)v18) {
                    case -3147964: {
                        break block54;
                    }
                    case 1388567549: {
                        continue block54;
                    }
                }
                break;
            }
            v19 = TimeUnit.MILLISECONDS.toSeconds(v17);
            while (true) {
                if ((v20 = (cfr_temp_4 = StingerWarper.\u13e8 - (31945L ^ 4865932126741363949L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v20 == (29938 ^ -29939)) break;
                v20 = 7052 ^ 1215347074;
            }
            v11[v12] = v19;
            while (true) {
                if ((v21 = (cfr_temp_5 = StingerWarper.\u13e8 - (5328L ^ -2503923229216693672L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                if (v21 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v21 = 16397 ^ -436803716;
            }
            v22 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl144
            block57: while (true) {
                v22 = v23 / (29955L ^ 7131683879222977770L);
lbl144:
                // 2 sources

                switch ((int)v22) {
                    case -1114940141: {
                        v23 = 5426L ^ -5086253379681130456L;
                        continue block57;
                    }
                    case -3147964: {
                        break block57;
                    }
                    case 1293409370: {
                        v23 = -6801006472671018112L >>> "\u0000\u0000".length();
                        continue block57;
                    }
                }
                break;
            }
            v24 = this.config._STINGER_CONFIG;
            v25 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl158
            block58: while (true) {
                v25 = v26 / (2220L ^ -4716415590640767777L);
lbl158:
                // 2 sources

                switch ((int)v25) {
                    case -973580131: {
                        v26 = 1261L ^ -1621679161002550804L;
                        continue block58;
                    }
                    case -830422441: {
                        v26 = 25305L ^ -2216477806565009304L;
                        continue block58;
                    }
                    case -3147964: {
                        break block58;
                    }
                }
                break;
            }
            v27 = v24.MAX_TIME_WAITING_FOR_STINGER;
            while (true) {
                if ((v28 = (cfr_temp_6 = StingerWarper.\u13e8 - (-1929744593327287184L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                if (v28 == (31327 ^ -31328)) break;
                v28 = 8259 ^ -1989882189;
            }
            v11[29221 ^ 29220] = v27;
            v29 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl178
            block60: while (true) {
                v29 = v30 / (13156L ^ 8629538205946095874L);
lbl178:
                // 2 sources

                switch ((int)v29) {
                    case -670520193: {
                        v30 = 24230L ^ 7927555578648223291L;
                        continue block60;
                    }
                    case -436746086: {
                        v30 = 25899L ^ -2970259195327565150L;
                        continue block60;
                    }
                    case -3147964: {
                        break block60;
                    }
                    case 2080855875: {
                        v30 = 29024L ^ -3401766247935954264L;
                        continue block60;
                    }
                }
                break;
            }
            v31 = String.format(v10, v11);
            v32 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl195
            block61: while (true) {
                v32 = v33 / (18367L ^ -3419689513757385936L);
lbl195:
                // 2 sources

                switch ((int)v32) {
                    case -779968364: {
                        v33 = 9961L ^ 1972539297904945066L;
                        continue block61;
                    }
                    case -3147964: {
                        break block61;
                    }
                    case 1051958592: {
                        v33 = 7530708246090005828L >>> "\u0000\u0000".length();
                        continue block61;
                    }
                }
                break;
            }
            this.timeWaitingForStingerLabel.setText(v31);
        }
    }

    /*
     * Unable to fully structure code
     */
    private void updateTimeShootingStinger(boolean clear) {
        block83: {
            block82: {
                block81: {
                    if (!clear) break block81;
                    v0 = StingerWarper.\u13e8;
                    if (true) ** GOTO lbl6
                    block61: while (true) {
                        v0 = v1 / (1331L ^ 3756058595347883867L);
lbl6:
                        // 2 sources

                        switch ((int)v0) {
                            case -1927440479: {
                                v1 = 28336L ^ 8806514696029816269L;
                                continue block61;
                            }
                            case -3147964: {
                                break block61;
                            }
                            case 144503278: {
                                v1 = 19371L ^ -7830779393387308191L;
                                continue block61;
                            }
                            case 979188553: {
                                v1 = -6530468609452561932L >>> "\u0000\u0000".length();
                                continue block61;
                            }
                        }
                        break;
                    }
                    var4_2 = new byte["".length() >>> "\u0000\u0000".length()];
                    v2 = new String(var4_2);
                    while (true) {
                        if ((v3 = (cfr_temp_0 = StingerWarper.\u13e8 - (1511L ^ 4424537745300679959L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                        if (v3 == (32580 ^ -32581)) break;
                        v3 = 14264 ^ -206953911;
                    }
                    this.timeShootingStingerLabel.setText(v2);
                    return;
                }
                v4 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl32
                block63: while (true) {
                    v4 = v5 / (22245L ^ -8588038530800208274L);
lbl32:
                    // 2 sources

                    switch ((int)v4) {
                        case -1785254808: {
                            v5 = 16915L ^ -2107980844551432169L;
                            continue block63;
                        }
                        case -908553730: {
                            v5 = 13493L ^ -81687849622824610L;
                            continue block63;
                        }
                        case -3147964: {
                            break block63;
                        }
                        case 1920028863: {
                            v5 = 31789L ^ 6492051146928472265L;
                            continue block63;
                        }
                    }
                    break;
                }
                timeShootingStingerMs = this.getTimeShootingStingerMs();
                if (timeShootingStingerMs != null) break block82;
                while (true) {
                    if ((v6 = (cfr_temp_1 = StingerWarper.\u13e8 - (1348L ^ 9182958724668138017L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                    if (v6 == (7199 ^ -7200)) break;
                    v6 = 8166 ^ -2110522171;
                }
                var4_3 = new byte["".length() >>> "\u0000\u0000".length()];
                v7 = new String(var4_3);
                v8 = StingerWarper.\u13e8;
                if (true) ** GOTO lbl57
                block65: while (true) {
                    v8 = v9 / (16103L ^ -2688000866771868847L);
lbl57:
                    // 2 sources

                    switch ((int)v8) {
                        case -1806578373: {
                            v9 = 2788891848162870572L >>> "\u0000\u0000".length();
                            continue block65;
                        }
                        case -3147964: {
                            break block65;
                        }
                        case 707228442: {
                            v9 = 31488L ^ -661194238733453251L;
                            continue block65;
                        }
                    }
                    break;
                }
                this.timeShootingStingerLabel.setText(v7);
                break block83;
            }
            v10 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl73
            block66: while (true) {
                v10 = v11 / (25245L ^ -5054048639151605764L);
lbl73:
                // 2 sources

                switch ((int)v10) {
                    case -3147964: {
                        break block66;
                    }
                    case 1088099816: {
                        v11 = 2899L ^ -3410172102674923268L;
                        continue block66;
                    }
                    case 1196551989: {
                        v11 = 29145L ^ -6053136904741309892L;
                        continue block66;
                    }
                }
                break;
            }
            var4_4 = new byte[19865 ^ 19852];
            var4_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 25805 ^ -25733;
            var4_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 18106 ^ 18069;
            var4_4[19024 ^ 19031] = 412 >>> "\u0000\u0000".length();
            var4_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 440 >>> "\u0000\u0000".length();
            var4_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 148 >>> "\u0000\u0000".length();
            var4_4[12514 ^ 12520] = 460 >>> "\u0000\u0000".length();
            var4_4[3297 ^ 3296] = 22845 ^ 22869;
            var4_4[19444 ^ 19446] = 444 >>> "\u0000\u0000".length();
            var4_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 11904 ^ 11936;
            var4_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 4433 ^ 4405;
            var4_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 160 >>> "\u0000\u0000".length();
            var4_4[6597 ^ 6606] = 232 >>> "\u0000\u0000".length();
            var4_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 32192 ^ 32175;
            var4_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 420 >>> "\u0000\u0000".length();
            var4_4["".length() >>> "\u0000\u0000".length()] = 10772 ^ 10823;
            var4_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 148 >>> "\u0000\u0000".length();
            var4_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 20527 ^ 20486;
            var4_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 400 >>> "\u0000\u0000".length();
            var4_4[14331 ^ 14322] = 17943 ^ 17970;
            var4_4[27975 ^ 27988] = 31165 ^ 31182;
            var4_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 464 >>> "\u0000\u0000".length();
            var4_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 253 ^ 221;
            v12 = new String(var4_4);
            v13 = new Object[12740 ^ 12743];
            v14 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl111
            block67: while (true) {
                v14 = v15 / (12939L ^ -3097657523097454420L);
lbl111:
                // 2 sources

                switch ((int)v14) {
                    case -3147964: {
                        break block67;
                    }
                    case 1379943616: {
                        v15 = 29521L ^ -7506791877847911248L;
                        continue block67;
                    }
                    case 1701915972: {
                        v15 = 1979L ^ 5861821863050772513L;
                        continue block67;
                    }
                    case 2122719605: {
                        v15 = -420921846758922664L >>> "\u0000\u0000".length();
                        continue block67;
                    }
                }
                break;
            }
            while (true) {
                if ((v16 = (cfr_temp_2 = StingerWarper.\u13e8 - (7209L ^ 4192441991275862599L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v16 == (17844 ^ -17845)) break;
                v16 = 1077969808 >>> "\u0000\u0000".length();
            }
            v17 = this.config._STINGER_CONFIG;
            while (true) {
                if ((v18 = (cfr_temp_3 = StingerWarper.\u13e8 - (8181771748685459148L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v18 == (21411 ^ 21410)) break;
                v18 = 4630 ^ 1131702074;
            }
            v13[253 ^ 253] = v17.NPC_SUBNAME;
            while (true) {
                if ((v19 = (cfr_temp_4 = StingerWarper.\u13e8 - (30330L ^ -2428058924005182575L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v19 == (26507 ^ 26506)) break;
                v19 = 14457 ^ -428237212;
            }
            v20 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl144
            block71: while (true) {
                v20 = v21 / (31311L ^ 6305876268972524430L);
lbl144:
                // 2 sources

                switch ((int)v20) {
                    case -1427312188: {
                        v21 = 18101L ^ -153394083286688311L;
                        continue block71;
                    }
                    case -3147964: {
                        break block71;
                    }
                    case 1116417346: {
                        v21 = 29779L ^ 4344277166129372134L;
                        continue block71;
                    }
                }
                break;
            }
            v22 = timeShootingStingerMs;
            v23 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl158
            block72: while (true) {
                v23 = v24 / (8533L ^ -2237448652299671870L);
lbl158:
                // 2 sources

                switch ((int)v23) {
                    case -1444644283: {
                        v24 = 12904L ^ -1112451938342673599L;
                        continue block72;
                    }
                    case -1149165761: {
                        v24 = 5198506236663941808L >>> "\u0000\u0000".length();
                        continue block72;
                    }
                    case -3147964: {
                        break block72;
                    }
                    case 1719459400: {
                        v24 = 17568L ^ -6349165531008463549L;
                        continue block72;
                    }
                }
                break;
            }
            v25 = TimeUnit.MILLISECONDS.toSeconds(v22);
            while (true) {
                if ((v26 = (cfr_temp_5 = StingerWarper.\u13e8 - (4328L ^ 2524545150955466894L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                if (v26 == (12926 ^ -12927)) break;
                v26 = 7469 ^ 1389539861;
            }
            v13[20767 ^ 20766] = v25;
            v27 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl181
            block74: while (true) {
                v27 = v28 / (3167L ^ 5675071278009648033L);
lbl181:
                // 2 sources

                switch ((int)v27) {
                    case -921267242: {
                        v28 = 22082L ^ 1315305202958405323L;
                        continue block74;
                    }
                    case -847020671: {
                        v28 = 18802L ^ 5954285989848468095L;
                        continue block74;
                    }
                    case -3147964: {
                        break block74;
                    }
                    case 1863068322: {
                        v28 = 14121L ^ 8860825401078362340L;
                        continue block74;
                    }
                }
                break;
            }
            while (true) {
                if ((v29 = (cfr_temp_6 = StingerWarper.\u13e8 - (20259L ^ 5520688907464443552L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                if (v29 == (13214 ^ -13215)) break;
                v29 = 14284 ^ -232840346;
            }
            v30 = this.config._STINGER_CONFIG;
            v31 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl203
            block76: while (true) {
                v31 = v32 / (29277L ^ -1913158568379305130L);
lbl203:
                // 2 sources

                switch ((int)v31) {
                    case -1243307256: {
                        v32 = 8671L ^ 7324188434922277747L;
                        continue block76;
                    }
                    case -71756011: {
                        v32 = 4371L ^ -348852281016249152L;
                        continue block76;
                    }
                    case -3147964: {
                        break block76;
                    }
                    case 1354707677: {
                        v32 = 10720L ^ 605997765595946755L;
                        continue block76;
                    }
                }
                break;
            }
            v33 = v30.MAX_TIME_SHOOTING_STINGER;
            v34 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl220
            block77: while (true) {
                v34 = v35 / (30727L ^ -4304629428032031226L);
lbl220:
                // 2 sources

                switch ((int)v34) {
                    case -1892622879: {
                        v35 = 12316L ^ -3896650844665094193L;
                        continue block77;
                    }
                    case -3147964: {
                        break block77;
                    }
                    case 366374574: {
                        v35 = 18085L ^ -1404381952845503520L;
                        continue block77;
                    }
                }
                break;
            }
            v13[5475 ^ 5473] = v33;
            v36 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl234
            block78: while (true) {
                v36 = v37 / (2122L ^ -2734584179920294475L);
lbl234:
                // 2 sources

                switch ((int)v36) {
                    case -1717752658: {
                        v37 = 27524L ^ 8579614215554888585L;
                        continue block78;
                    }
                    case -532963921: {
                        v37 = 17641L ^ 192261056576453444L;
                        continue block78;
                    }
                    case -3147964: {
                        break block78;
                    }
                }
                break;
            }
            v38 = String.format(v12, v13);
            while (true) {
                if ((v39 = (cfr_temp_7 = StingerWarper.\u13e8 - (32535L ^ 5186172046357683630L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                if (v39 == (11896 ^ -11897)) {
                    this.timeShootingStingerLabel.setText(v38);
                    break;
                }
                v39 = 26502 ^ -367186014;
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private void updateStingerDeathCount(boolean clear) {
        block36: {
            if (!clear) break block36;
            while (true) {
                if ((v0 = (cfr_temp_0 = StingerWarper.\u13e8 - (26746L ^ -6294501079945139762L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                if (v0 == (22323 ^ 22322)) break;
                v0 = 17359 ^ -1709219828;
            }
            var3_2 = new byte[31636 ^ 31636];
            v1 = new String(var3_2);
            v2 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl13
            block22: while (true) {
                v2 = v3 / (16330L ^ -9011281330079406302L);
lbl13:
                // 2 sources

                switch ((int)v2) {
                    case -1437278301: {
                        v3 = -3435317102158214252L >>> "\u0000\u0000".length();
                        continue block22;
                    }
                    case -227583811: {
                        v3 = 29899L ^ 8298935203282914912L;
                        continue block22;
                    }
                    case -3147964: {
                        break block22;
                    }
                    case 941307514: {
                        v3 = 8169L ^ -6714868000602032280L;
                        continue block22;
                    }
                }
                break;
            }
            this.stingerDeathCountLabel.setText(v1);
            return;
        }
        while (true) {
            if ((v4 = (cfr_temp_1 = StingerWarper.\u13e8 - (11727L ^ 7591852427076083994L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v4 == (13744 ^ -13745)) break;
            v4 = 6306 ^ -299727155;
        }
        if (this.seenDeaths <= 0) {
            while (true) {
                if ((v5 = (cfr_temp_2 = StingerWarper.\u13e8 - (8345L ^ -3870135448101028954L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v5 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v5 = 22582 ^ -1873322551;
            }
            var3_3 = new byte["".length() >>> "\u0000\u0000".length()];
            v6 = new String(var3_3);
            while (true) {
                if ((v7 = (cfr_temp_3 = StingerWarper.\u13e8 - (644949229822398908L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v7 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v7 = 17318 ^ -1659134291;
            }
            this.stingerDeathCountLabel.setText(v6);
            return;
        }
        v8 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl52
        block26: while (true) {
            v8 = v9 / (29439L ^ 4872275482156993597L);
lbl52:
            // 2 sources

            switch ((int)v8) {
                case -2018442926: {
                    v9 = 11224L ^ -1869536617925472880L;
                    continue block26;
                }
                case -1563548066: {
                    v9 = 21873L ^ -3593132274872168683L;
                    continue block26;
                }
                case -3147964: {
                    break block26;
                }
                case 1891195059: {
                    v9 = 17588L ^ -1787521827784600096L;
                    continue block26;
                }
            }
            break;
        }
        var3_4 = new byte[17555 ^ 17541];
        var3_4[11872 ^ 11872] = 10060 ^ 9998;
        var3_4[5101 ^ 5101] = 332 >>> "\u0000\u0000".length();
        var3_4[15831 ^ 15824] = 24334 ^ 24446;
        var3_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 26776 ^ 26873;
        var3_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 3193 ^ 3161;
        var3_4[252 ^ 242] = 460 >>> "\u0000\u0000".length();
        var3_4[26732 ^ 26725] = 18042 ^ 17950;
        var3_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 21426 ^ 21442;
        var3_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 27666 ^ 27688;
        var3_4[7580 ^ 7575] = 388 >>> "\u0000\u0000".length();
        var3_4[28044 ^ 28038] = 404 >>> "\u0000\u0000".length();
        var3_4[24909 ^ 24908] = 28373 ^ 28322;
        var3_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 128 >>> "\u0000\u0000".length();
        var3_4[32652 ^ 32664] = 2976 ^ 2949;
        var3_4[26096 ^ 26100] = 20749 ^ 20781;
        var3_4[21377 ^ 21380] = 27790 ^ 27875;
        var3_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 20424 ^ 20396;
        var3_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 400 >>> "\u0000\u0000".length();
        var3_4[6978 ^ 6993] = 188 >>> "\u0000\u0000".length();
        var3_4[23923 ^ 23935] = 464 >>> "\u0000\u0000".length();
        var3_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 148 >>> "\u0000\u0000".length();
        var3_4[2313 ^ 2308] = 416 >>> "\u0000\u0000".length();
        var3_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 7361 ^ 7328;
        v10 = new String(var3_4);
        v11 = new Object["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
        v12 = "".length() >>> "\u0000\u0000".length();
        while (true) {
            if ((v13 = (cfr_temp_4 = StingerWarper.\u13e8 - (11005L ^ 4628541203007376120L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v13 == (1275 ^ -1276)) break;
            v13 = 1408 ^ 958527137;
        }
        while (true) {
            if ((v14 = (cfr_temp_5 = StingerWarper.\u13e8 - (5316L ^ -2878111203156706458L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
            if (v14 == (10869 ^ 10868)) break;
            v14 = 23545 ^ -232206243;
        }
        v11[v12] = this.seenDeaths;
        while (true) {
            if ((v15 = (cfr_temp_6 = StingerWarper.\u13e8 - (27539L ^ -412791249572677526L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
            if (v15 == (24673 ^ 24672)) break;
            v15 = 9731 ^ -1525865034;
        }
        while (true) {
            if ((v16 = (cfr_temp_7 = StingerWarper.\u13e8 - (3016L ^ -6057677188990678807L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
            if (v16 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v16 = 8235 ^ 1013790222;
        }
        v17 = this.config._STINGER_CONFIG;
        while (true) {
            if ((v18 = (cfr_temp_8 = StingerWarper.\u13e8 - (9858L ^ -956424280064000548L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
            if (v18 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v18 = 11724 ^ 1540447530;
        }
        v19 = v17.MAX_STINGER_MAP_DEATHS;
        while (true) {
            if ((v20 = (cfr_temp_9 = StingerWarper.\u13e8 - (21365L ^ 7015848969591527306L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
            if (v20 == (2996 ^ -2997)) break;
            v20 = 21120 ^ 1199597266;
        }
        v11[6340 ^ 6341] = v19;
        v21 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl129
        block33: while (true) {
            v21 = v22 / (30146L ^ -4963897734104664161L);
lbl129:
            // 2 sources

            switch ((int)v21) {
                case -1348069406: {
                    v22 = 32566L ^ 5716418603562061666L;
                    continue block33;
                }
                case -778821081: {
                    v22 = 6079L ^ 7796417062902787093L;
                    continue block33;
                }
                case -3147964: {
                    break block33;
                }
            }
            break;
        }
        v23 = String.format(v10, v11);
        v24 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl143
        block34: while (true) {
            v24 = (3599L ^ -7093613878083938325L) / (26539L ^ -112084101930592361L);
lbl143:
            // 2 sources

            switch ((int)v24) {
                case -1179372723: {
                    continue block34;
                }
                case -3147964: {
                    break block34;
                }
            }
            break;
        }
        this.stingerDeathCountLabel.setText(v23);
    }

    /*
     * Unable to fully structure code
     */
    private void updateStingerMapMaxTime(boolean clear) {
        block59: {
            if (clear) {
                while (true) {
                    if ((v0 = (cfr_temp_0 = StingerWarper.\u13e8 - (8075L ^ 3292379000962371028L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
                    if (v0 == (16230 ^ -16231)) break;
                    v0 = 25248 ^ 1517893363;
                }
                var4_2 = new byte["".length() >>> "\u0000\u0000".length()];
                v1 = new String(var4_2);
                while (true) {
                    if ((v2 = (cfr_temp_1 = StingerWarper.\u13e8 - (28872L ^ 3466352919578987966L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                    if (v2 == (11536 ^ -11537)) break;
                    v2 = 24223 ^ 1970505162;
                }
                this.stingerMapMaxTimeLabel.setText(v1);
                return;
            }
            while (true) {
                if ((v3 = (cfr_temp_2 = StingerWarper.\u13e8 - (16334L ^ -7603101636186044189L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
                if (v3 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v3 = 29472 ^ 1081443481;
            }
            msSpentOnSwapConfig = this.getMsSpentOnStingerConfig();
            if (msSpentOnSwapConfig != null) break block59;
            v4 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl27
            block47: while (true) {
                v4 = v5 / (1987L ^ -379434548217904627L);
lbl27:
                // 2 sources

                switch ((int)v4) {
                    case -3147964: {
                        break block47;
                    }
                    case 700397078: {
                        v5 = 1578717395310944116L >>> "\u0000\u0000".length();
                        continue block47;
                    }
                    case 774581013: {
                        v5 = 7507L ^ -2809054282838285979L;
                        continue block47;
                    }
                }
                break;
            }
            var4_3 = new byte[20087 ^ 20087];
            v6 = new String(var4_3);
            v7 = StingerWarper.\u13e8;
            if (true) ** GOTO lbl42
            block48: while (true) {
                v7 = (26057L ^ -5866376345425030184L) / (15512L ^ -823002040614806575L);
lbl42:
                // 2 sources

                switch ((int)v7) {
                    case -3147964: {
                        break block48;
                    }
                    case 2074507288: {
                        continue block48;
                    }
                }
                break;
            }
            this.stingerMapMaxTimeLabel.setText(v6);
            return;
        }
        while (true) {
            if ((v8 = (cfr_temp_3 = StingerWarper.\u13e8 - (26146L ^ -4095571733305421305L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v8 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v8 = 11703 ^ -902702921;
        }
        var4_4 = new byte[20309 ^ 20342];
        var4_4[26444 ^ 26441] = 10804 ^ -10807;
        var4_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 460 >>> "\u0000\u0000".length();
        var4_4[6158 ^ 6144] = 7687 ^ 7796;
        var4_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 30369 ^ 30417;
        var4_4[21824 ^ 21858] = 164 >>> "\u0000\u0000".length();
        var4_4[8846 ^ 8838] = 440 >>> "\u0000\u0000".length();
        var4_4[30639 ^ 30643] = 11313 ^ 11349;
        var4_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 128 >>> "\u0000\u0000".length();
        var4_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 396 >>> "\u0000\u0000".length();
        var4_4[15711 ^ 15694] = 16635 ^ 16523;
        var4_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 440 >>> "\u0000\u0000".length();
        var4_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 18601 ^ 18569;
        var4_4[32287 ^ 32264] = 420 >>> "\u0000\u0000".length();
        var4_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 3601 ^ 3710;
        var4_4[27370 ^ 27378] = 412 >>> "\u0000\u0000".length();
        var4_4[20529 ^ 20531] = 436 >>> "\u0000\u0000".length();
        var4_4[28097 ^ 28127] = 148 >>> "\u0000\u0000".length();
        var4_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 232 >>> "\u0000\u0000".length();
        var4_4[19110 ^ 19110] = 22982 ^ 22930;
        var4_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 19967 ^ 19866;
        var4_4[20849 ^ 20856] = 15306 ^ 15294;
        var4_4[20193 ^ 20212] = 27823 ^ 27841;
        var4_4[17303 ^ 17334] = 21388 ^ 21503;
        var4_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 404 >>> "\u0000\u0000".length();
        var4_4[8537 ^ 8534] = 4196 ^ 4115;
        var4_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 444 >>> "\u0000\u0000".length();
        var4_4[24264 ^ 24265] = 23539 ^ 23450;
        var4_4[128 >>> "\u0000\u0000".length()] = 160 >>> "\u0000\u0000".length();
        var4_4[29830 ^ 29844] = 128 >>> "\u0000\u0000".length();
        var4_4[10049 ^ 10053] = 128 >>> "\u0000\u0000".length();
        var4_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 408 >>> "\u0000\u0000".length();
        var4_4[23047 ^ 23068] = 148 >>> "\u0000\u0000".length();
        var4_4[11280 ^ 11279] = 21976 ^ 21948;
        var4_4[18623 ^ 18613] = 128 >>> "\u0000\u0000".length();
        var4_4[12776 ^ 12792] = 16668 ^ 16765;
        var4_4["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 188 >>> "\u0000\u0000".length();
        v9 = new String(var4_4);
        v10 = new Object["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
        v11 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl98
        block50: while (true) {
            v11 = v12 / (3295564683684533780L >>> "\u0000\u0000".length());
lbl98:
            // 2 sources

            switch ((int)v11) {
                case -1180500913: {
                    v12 = 25503L ^ -8250404906768896785L;
                    continue block50;
                }
                case -3147964: {
                    break block50;
                }
                case 419506802: {
                    v12 = 32388L ^ -5896932170753237352L;
                    continue block50;
                }
            }
            break;
        }
        v13 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl111
        block51: while (true) {
            v13 = v14 / (8850L ^ -7430287283705718245L);
lbl111:
            // 2 sources

            switch ((int)v13) {
                case -1340972931: {
                    v14 = 21793L ^ 8763534697715525843L;
                    continue block51;
                }
                case -731987423: {
                    v14 = 8536L ^ 7358810274936522940L;
                    continue block51;
                }
                case -3147964: {
                    break block51;
                }
            }
            break;
        }
        v15 = msSpentOnSwapConfig;
        v16 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl125
        block52: while (true) {
            v16 = v17 / (129L ^ 9110703944622961904L);
lbl125:
            // 2 sources

            switch ((int)v16) {
                case -1210045287: {
                    v17 = 20807L ^ -4345563245102130173L;
                    continue block52;
                }
                case -3147964: {
                    break block52;
                }
                case 1663672230: {
                    v17 = 13730L ^ 7288721754392188267L;
                    continue block52;
                }
                case 1803852971: {
                    v17 = 21860L ^ -811643380312636465L;
                    continue block52;
                }
            }
            break;
        }
        v18 = TimeUnit.MILLISECONDS.toSeconds(v15);
        v19 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl142
        block53: while (true) {
            v19 = v20 / (3787L ^ 7642097694149790681L);
lbl142:
            // 2 sources

            switch ((int)v19) {
                case -3147964: {
                    break block53;
                }
                case 573039607: {
                    v20 = 5601L ^ -3451642561067655399L;
                    continue block53;
                }
                case 1317975253: {
                    v20 = 3235L ^ 2783606735428960592L;
                    continue block53;
                }
                case 1696683669: {
                    v20 = 20347L ^ -4504012832465591124L;
                    continue block53;
                }
            }
            break;
        }
        v10[31997 ^ 31997] = v18;
        v21 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl159
        block54: while (true) {
            v21 = (1871L ^ -808423333168427233L) / (17197L ^ -1936563885306965834L);
lbl159:
            // 2 sources

            switch ((int)v21) {
                case -71004328: {
                    continue block54;
                }
                case -3147964: {
                    break block54;
                }
            }
            break;
        }
        v22 = this.getMaximumTimeAllowedOnStingerConfig();
        while (true) {
            if ((v23 = (cfr_temp_4 = StingerWarper.\u13e8 - (17753L ^ 4766817108874780158L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v23 == (19029 ^ -19030)) break;
            v23 = 30644 ^ -874163422;
        }
        v10[13568 ^ 13569] = v22;
        v24 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl175
        block56: while (true) {
            v24 = (183L ^ -8808441629285050524L) / (-4228486755680600940L >>> "\u0000\u0000".length());
lbl175:
            // 2 sources

            switch ((int)v24) {
                case -47420893: {
                    continue block56;
                }
                case -3147964: {
                    break block56;
                }
            }
            break;
        }
        v25 = String.format(v9, v10);
        v26 = StingerWarper.\u13e8;
        if (true) ** GOTO lbl185
        block57: while (true) {
            v26 = v27 / (25757L ^ 6240303265464550384L);
lbl185:
            // 2 sources

            switch ((int)v26) {
                case -1920206789: {
                    v27 = 1448L ^ 7100320702886056205L;
                    continue block57;
                }
                case -3147964: {
                    break block57;
                }
                case 1323312431: {
                    v27 = 5800916846873308484L >>> "\u0000\u0000".length();
                    continue block57;
                }
            }
            break;
        }
        this.stingerDeathCountLabel.setText(v25);
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public Collection<JComponent> getExtraMenuItems(PluginAPI api) {
        byte[] byArray = new byte[0x4900 ^ 0x4916];
        byArray[0x662F ^ 0x6628] = 0x155 ^ 0xFFFFFECA;
        byArray[0x5984 ^ 0x5983] = 320 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x6573 ^ 0x651A;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x78C3 ^ 0x78A6;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 388 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 412 >>> "\u0000\u0000".length();
        byArray[0x5B11 ^ 0x5B18] = 0x3A74 ^ 0x3A1B;
        byArray[0x6667 ^ 0x6662] = 456 >>> "\u0000\u0000".length();
        byArray[0x40AA ^ 0x40BB] = 388 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x4C3D ^ 0x4C53;
        byArray[0x5B3F ^ 0x5B30] = 268 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 404 >>> "\u0000\u0000".length();
        byArray[0x2583 ^ 0x2591] = 0x2801 ^ 0x286F;
        byArray["".length() >>> "\u0000\u0000".length()] = 288 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 408 >>> "\u0000\u0000".length();
        byArray[0x4913 ^ 0x491B] = 456 >>> "\u0000\u0000".length();
        byArray[0xC21 ^ 0xC31] = 416 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 388 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x620A ^ 0x626D;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x7D58 ^ 0x7D78;
        byArray[0xB71 ^ 0xB64] = 456 >>> "\u0000\u0000".length();
        byArray[0x1D4F ^ 0x1D43] = 0xB54 ^ 0xB38;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 128 >>> "\u0000\u0000".length();
        String string = new String(byArray);
        JLabel[] jLabelArray = new JLabel[0x32AE ^ 0x32AB];
        int n = "".length() >>> "\u0000\u0000".length();
        long l = \u13e8;
        block13: while (true) {
            switch ((int)l) {
                case -3147964: {
                    break block13;
                }
                case 1026588496: {
                    l = (0x4D2BL ^ 0xA74DE8BF53C67AAEL) / (0x6641L ^ 0xB901042B27F4929DL);
                    continue block13;
                }
            }
            break;
        }
        jLabelArray[n] = this.statusLabel;
        int n2 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        long l2 = \u13e8;
        boolean bl = true;
        block14: while (true) {
            long l3;
            if (!bl || (bl = false) || !true) {
                l2 = l3 / (0x4EFDL ^ 0x88BFA245A576C0F7L);
            }
            switch ((int)l2) {
                case -1335121433: {
                    l3 = 0x302EL ^ 0xDCFBA4A8DF537528L;
                    continue block14;
                }
                case -1035346969: {
                    l3 = 0x4719L ^ 0x738DA5B2C0645BF0L;
                    continue block14;
                }
                case -3147964: {
                    break block14;
                }
            }
            break;
        }
        jLabelArray[n2] = this.nextCheckLabel;
        while (true) {
            long l4;
            long l5;
            if ((l5 = (l4 = \u13e8 - (0x542L ^ 0xCAB8906F1A655F2EL)) == 0L ? 0 : (l4 < 0L ? -1 : 1)) == false) continue;
            if (l5 == (0x21DE ^ 0x21DF)) break;
            l5 = 0x412B ^ 0x1B901C8B;
        }
        jLabelArray[0x6A9F ^ 0x6A9D] = this.timeWaitingForStingerLabel;
        int n3 = "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        while (true) {
            long l6;
            long l7;
            if ((l7 = (l6 = \u13e8 - (7171294761782304172L >>> "\u0000\u0000".length())) == 0L ? 0 : (l6 < 0L ? -1 : 1)) == false) continue;
            if (l7 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l7 = -1727999856 >>> "\u0000\u0000".length();
        }
        jLabelArray[n3] = this.timeShootingStingerLabel;
        int n4 = "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        long l8 = \u13e8;
        block17: while (true) {
            switch ((int)l8) {
                case -3147964: {
                    break block17;
                }
                case 336269817: {
                    l8 = (3836261383200431176L >>> "\u0000\u0000".length()) / (0x7487L ^ 0xDF0BEE6C5CEA0A1DL);
                    continue block17;
                }
            }
            break;
        }
        jLabelArray[n4] = this.stingerDeathCountLabel;
        while (true) {
            long l9;
            long l10;
            if ((l10 = (l9 = \u13e8 - (0x1041L ^ 0x504E8E9FB988B0E8L)) == 0L ? 0 : (l9 < 0L ? -1 : 1)) == false) continue;
            if (l10 == (0x3CE1 ^ 0xFFFFC31E)) {
                return ExtraMenuExtensions.MapCycleExtraMenu(this, string, jLabelArray);
            }
            l10 = 0x3759 ^ 0x3A180F10;
        }
    }

    static {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (7824766787823557508L >>> "\u0000\u0000".length())) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l2 = 0x668F ^ 0xBF962738;
        }
        long l = System.currentTimeMillis();
        while (true) {
            long l3;
            long l4;
            if ((l4 = (l3 = \u13e8 - (0x7F79L ^ 0xF1FC8C407F6F4E48L)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) continue;
            if (l4 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l4 = 0x16CB ^ 0x4CF0D806;
        }
        LAST_STINGER_CHECK_MS = l;
    }
}

