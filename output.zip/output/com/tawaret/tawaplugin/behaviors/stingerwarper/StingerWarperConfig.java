/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.config.types.Option
 */
package com.tawaret.tawaplugin.behaviors.stingerwarper;

import com.github.manolo8.darkbot.config.types.Option;
import com.tawaret.tawaplugin.behaviors.stingerwarper.AfterStingerConfig;
import com.tawaret.tawaplugin.behaviors.stingerwarper.HangarChangeConfig;
import com.tawaret.tawaplugin.behaviors.stingerwarper.MapCycleModuleConfig;
import com.tawaret.tawaplugin.behaviors.stingerwarper.StingerConfig;

public class StingerWarperConfig {
    @Option(value="Original")
    public AfterStingerConfig _AFTER_STINGER_CONFIG;
    @Option(value="Swap")
    public StingerConfig _STINGER_CONFIG;
    @Option(value="Hangar Change")
    public HangarChangeConfig HANGAR_CHANGE_CONFIG;
    @Option(value="Map Cycle Link")
    public MapCycleModuleConfig MAP_CYCLE_LINK_CONFIG;
    @Option(value="Force restart", description="Restarts the check timer forcefully")
    public boolean FORCE_RESTART_CHECK_TIME;
    public static long \u13e8 = -1186893787887801960L;

    /*
     * Unable to fully structure code
     */
    public StingerWarperConfig() {
        while (true) {
            if ((v0 = (cfr_temp_0 = StingerWarperConfig.\u13e8 - (17872L ^ -1920422443829515716L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v0 = 19297 ^ -739839820;
        }
        super();
        v1 = StingerWarperConfig.\u13e8;
        if (true) ** GOTO lbl11
        block42: while (true) {
            v1 = v2 / (18352L ^ -2483777015874586461L);
lbl11:
            // 2 sources

            switch ((int)v1) {
                case 841298216: {
                    v2 = 7293L ^ -4404126043122992351L;
                    continue block42;
                }
                case 1378677825: {
                    v2 = 26578L ^ 4457607093977611834L;
                    continue block42;
                }
                case 1792305560: {
                    break block42;
                }
                case 2108907667: {
                    v2 = 19522L ^ 6708850089458146506L;
                    continue block42;
                }
            }
            break;
        }
        while (true) {
            if ((v3 = (cfr_temp_1 = StingerWarperConfig.\u13e8 - (14230L ^ -2263691185009183601L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v3 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v3 = 31592 ^ -1707460369;
        }
        v4 = new AfterStingerConfig();
        while (true) {
            if ((v5 = (cfr_temp_2 = StingerWarperConfig.\u13e8 - (-7155553015014456556L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v5 == (2601 ^ -2602)) break;
            v5 = 13688 ^ -638884420;
        }
        this._AFTER_STINGER_CONFIG = v4;
        v6 = StingerWarperConfig.\u13e8;
        if (true) ** GOTO lbl39
        block45: while (true) {
            v6 = v7 / (6499L ^ -6757568800264537151L);
lbl39:
            // 2 sources

            switch ((int)v6) {
                case -1678949144: {
                    v7 = 23219L ^ -763721759681798637L;
                    continue block45;
                }
                case -638020501: {
                    v7 = 2697L ^ 3056877111062289747L;
                    continue block45;
                }
                case 1792305560: {
                    break block45;
                }
            }
            break;
        }
        v8 = StingerWarperConfig.\u13e8;
        if (true) ** GOTO lbl52
        block46: while (true) {
            v8 = v9 / (12848L ^ 2999918246888686723L);
lbl52:
            // 2 sources

            switch ((int)v8) {
                case -289830118: {
                    v9 = 11184L ^ -6962185582260489593L;
                    continue block46;
                }
                case 1792305560: {
                    break block46;
                }
                case 1904807783: {
                    v9 = 27418L ^ 8157930884798753838L;
                    continue block46;
                }
            }
            break;
        }
        v10 = new StingerConfig();
        while (true) {
            if ((v11 = (cfr_temp_3 = StingerWarperConfig.\u13e8 - (28714L ^ -6413588521732806560L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v11 == (31664 ^ 31665)) break;
            v11 = 5715 ^ 1629819333;
        }
        this._STINGER_CONFIG = v10;
        while (true) {
            if ((v12 = (cfr_temp_4 = StingerWarperConfig.\u13e8 - (13890L ^ 8444927833846474926L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
            if (v12 == ("\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() ^ -55)) break;
            v12 = -1882695972 >>> "\u0000\u0000".length();
        }
        while (true) {
            if ((v13 = (cfr_temp_5 = StingerWarperConfig.\u13e8 - (13286L ^ -7812717004432296070L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
            if (v13 == (18947 ^ 18946)) break;
            v13 = 21270 ^ -173131261;
        }
        v14 = new HangarChangeConfig();
        v15 = StingerWarperConfig.\u13e8;
        if (true) ** GOTO lbl83
        block50: while (true) {
            v15 = v16 / (20647L ^ -3983360602547790787L);
lbl83:
            // 2 sources

            switch ((int)v15) {
                case -1082499042: {
                    v16 = 20816L ^ 7497301096856279282L;
                    continue block50;
                }
                case 751683707: {
                    v16 = 4545L ^ 8023931014308884211L;
                    continue block50;
                }
                case 1792305560: {
                    break block50;
                }
            }
            break;
        }
        this.HANGAR_CHANGE_CONFIG = v14;
        v17 = StingerWarperConfig.\u13e8;
        if (true) ** GOTO lbl97
        block51: while (true) {
            v17 = v18 / (13986L ^ -4963710907245627269L);
lbl97:
            // 2 sources

            switch ((int)v17) {
                case -2101162625: {
                    v18 = 2589L ^ 7399226514627776075L;
                    continue block51;
                }
                case 1792305560: {
                    break block51;
                }
                case 1793477148: {
                    v18 = 22526L ^ -9005334783486003665L;
                    continue block51;
                }
            }
            break;
        }
        v19 = StingerWarperConfig.\u13e8;
        if (true) ** GOTO lbl110
        block52: while (true) {
            v19 = v20 / (20135L ^ 2421801726858834374L);
lbl110:
            // 2 sources

            switch ((int)v19) {
                case -1192252344: {
                    v20 = -4093935060849943376L >>> "\u0000\u0000".length();
                    continue block52;
                }
                case 1280915434: {
                    v20 = 3403L ^ -141022288751838668L;
                    continue block52;
                }
                case 1792305560: {
                    break block52;
                }
            }
            break;
        }
        v21 = new MapCycleModuleConfig();
        v22 = StingerWarperConfig.\u13e8;
        if (true) ** GOTO lbl124
        block53: while (true) {
            v22 = (10319L ^ -3879380213017867464L) / (3616L ^ 1627224973892994710L);
lbl124:
            // 2 sources

            switch ((int)v22) {
                case 394176745: {
                    continue block53;
                }
                case 1792305560: {
                    break block53;
                }
            }
            break;
        }
        this.MAP_CYCLE_LINK_CONFIG = v21;
        v23 = StingerWarperConfig.\u13e8;
        if (true) ** GOTO lbl134
        block54: while (true) {
            v23 = v24 / (10499L ^ -4673869512230951369L);
lbl134:
            // 2 sources

            switch ((int)v23) {
                case -1886512924: {
                    v24 = 18853L ^ 7648027210325118124L;
                    continue block54;
                }
                case -1660031325: {
                    v24 = 29509L ^ -99147778080828265L;
                    continue block54;
                }
                case 1792305560: {
                    break block54;
                }
                case 2040448945: {
                    v24 = 20014L ^ 5424909242295200479L;
                    continue block54;
                }
            }
            break;
        }
        this.FORCE_RESTART_CHECK_TIME = 25600 ^ 25600;
    }
}

