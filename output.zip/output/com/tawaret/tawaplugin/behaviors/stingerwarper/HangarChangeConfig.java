/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.config.types.Option
 *  com.github.manolo8.darkbot.core.manager.StarManager$MapOptions
 *  eu.darkbot.api.config.annotations.Dropdown
 */
package com.tawaret.tawaplugin.behaviors.stingerwarper;

import com.github.manolo8.darkbot.config.types.Option;
import com.github.manolo8.darkbot.core.manager.StarManager;
import com.tawaret.tawaplugin.utils.types.ShipSupplier;
import eu.darkbot.api.config.annotations.Dropdown;

public class HangarChangeConfig {
    @Option(value="Use hangar change", description="If disabled, bot will just change profiles")
    public boolean USE_HANGAR_CHANGE;
    @Option(value="Original Hangar")
    @Dropdown(options=ShipSupplier.class)
    public Integer AFTER_STINGER_HANGAR_ID;
    @Option(value="Swap Hangar")
    @Dropdown(options=ShipSupplier.class)
    public Integer STINGER_HANGAR_ID;
    @Option(value="Swap Hangar Map", description="Map you expect swap hangar to be on")
    @Dropdown(options=StarManager.MapOptions.class)
    public Integer STINGER_MAP;
    @Option(value="Enforce Swap Hangar Map", description="If the swap hangar is not on this map, bot will switch back")
    public boolean ENFORCE_STINGER_MAP;
    static long \u13e8 = 8563049155500238822L;

    /*
     * Unable to fully structure code
     */
    public HangarChangeConfig() {
        while (true) {
            if ((v0 = (cfr_temp_0 = HangarChangeConfig.\u13e8 - (11534L ^ 3680272757463019258L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v0 == (5700 ^ 5701)) break;
            v0 = 14922 ^ 981913812;
        }
        super();
        v1 = "".length() >>> "\u0000\u0000".length();
        while (true) {
            if ((v2 = (cfr_temp_1 = HangarChangeConfig.\u13e8 - (23289L ^ 5883734991132348764L)) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
            if (v2 == (15016 ^ 15017)) break;
            v2 = 25654 ^ -1462463034;
        }
        this.USE_HANGAR_CHANGE = v1;
        v3 = HangarChangeConfig.\u13e8;
        if (true) ** GOTO lbl18
        block26: while (true) {
            v3 = v4 / (21936L ^ 7659018681163209140L);
lbl18:
            // 2 sources

            switch ((int)v3) {
                case -2083723290: {
                    break block26;
                }
                case -181537878: {
                    v4 = 4536L ^ 5029938114381204653L;
                    continue block26;
                }
                case 566244631: {
                    v4 = 15336L ^ 1615123110887589139L;
                    continue block26;
                }
            }
            break;
        }
        v5 = 213 ^ -214;
        v6 = HangarChangeConfig.\u13e8;
        if (true) ** GOTO lbl32
        block27: while (true) {
            v6 = (4578L ^ -1151016400341625693L) / (12226L ^ 745540579517953141L);
lbl32:
            // 2 sources

            switch ((int)v6) {
                case -2083723290: {
                    break block27;
                }
                case 2014865127: {
                    continue block27;
                }
            }
            break;
        }
        this.AFTER_STINGER_HANGAR_ID = v5;
        v7 = HangarChangeConfig.\u13e8;
        if (true) ** GOTO lbl42
        block28: while (true) {
            v7 = v8 / (14417L ^ -1565143705662942787L);
lbl42:
            // 2 sources

            switch ((int)v7) {
                case -2083723290: {
                    break block28;
                }
                case -769703681: {
                    v8 = 6982L ^ 660956961567857068L;
                    continue block28;
                }
                case 1397898978: {
                    v8 = 5668L ^ 958857757693575365L;
                    continue block28;
                }
            }
            break;
        }
        v9 = 20724 ^ -20725;
        while (true) {
            if ((v10 = (cfr_temp_2 = HangarChangeConfig.\u13e8 - (10977L ^ -8453876200733022283L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v10 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v10 = 18195 ^ -947406585;
        }
        this.STINGER_HANGAR_ID = v9;
        v11 = HangarChangeConfig.\u13e8;
        if (true) ** GOTO lbl62
        block30: while (true) {
            v11 = v12 / (24343L ^ -3961283318869511484L);
lbl62:
            // 2 sources

            switch ((int)v11) {
                case -2083723290: {
                    break block30;
                }
                case -391807411: {
                    v12 = 7836L ^ 3444797273662423014L;
                    continue block30;
                }
                case -208585450: {
                    v12 = 17859L ^ 6223036940150427595L;
                    continue block30;
                }
            }
            break;
        }
        v13 = 7831 ^ -7832;
        while (true) {
            if ((v14 = (cfr_temp_3 = HangarChangeConfig.\u13e8 - (16508L ^ 3262116413599082847L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
            if (v14 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            v14 = -1059520632 >>> "\u0000\u0000".length();
        }
        this.STINGER_MAP = v13;
        v15 = HangarChangeConfig.\u13e8;
        if (true) ** GOTO lbl82
        block32: while (true) {
            v15 = v16 / (17514L ^ 8136797048672074089L);
lbl82:
            // 2 sources

            switch ((int)v15) {
                case -2083723290: {
                    break block32;
                }
                case -224268366: {
                    v16 = 3381L ^ 7129862151118913053L;
                    continue block32;
                }
                case -201661873: {
                    v16 = 145L ^ 2380563953464085460L;
                    continue block32;
                }
            }
            break;
        }
        this.ENFORCE_STINGER_MAP = 11419 ^ 11418;
    }
}

