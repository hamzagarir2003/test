/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.config.types.Num
 *  com.github.manolo8.darkbot.config.types.Option
 */
package com.tawaret.tawaplugin.behaviors.stingerwarper;

import com.github.manolo8.darkbot.config.types.Num;
import com.github.manolo8.darkbot.config.types.Option;

public class DontCheckConfig {
    @Option(value="Start (Hour)", description="-1 to disable")
    @Num(min=-1, max=23, step=1)
    public int START_HOUR;
    @Option(value="End (Hour)", description="-1 to disable")
    @Num(min=-1, max=23, step=1)
    public int END_HOUR;
    private static long \u13e8 = 5313169177990883183L;

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public DontCheckConfig() {
        long l = \u13e8;
        boolean bl = true;
        block9: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x752FL ^ 0x59B04054DB4A496EL);
            }
            switch ((int)l) {
                case -1917622417: {
                    break block9;
                }
                case -1710504100: {
                    l2 = 0x6650L ^ 0x8EB646180748BBC7L;
                    continue block9;
                }
                case 1978205536: {
                    l2 = 0x2B75L ^ 0xC02F09CC9166EB96L;
                    continue block9;
                }
            }
            break;
        }
        long l3 = \u13e8;
        block10: while (true) {
            switch ((int)l3) {
                case -1917622417: {
                    break block10;
                }
                case 1751357285: {
                    l3 = (0x1DEFL ^ 0x13E3E3F97883945BL) / (0x41E5L ^ 0x8609580C40090176L);
                    continue block10;
                }
            }
            break;
        }
        this.START_HOUR = 0x544F ^ 0xFFFFABB0;
        while (true) {
            long l4;
            long l5;
            if ((l5 = (l4 = \u13e8 - (0x242AL ^ 0x79925279ADEB484BL)) == 0L ? 0 : (l4 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l5 == (0x18A2 ^ 0xFFFFE75D)) {
                this.END_HOUR = 0x47DF ^ 0xFFFFB820;
                return;
            }
            l5 = 0x3E2 ^ 0x70CF8766;
        }
    }
}

