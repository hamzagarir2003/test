/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.config.types.Num
 *  com.github.manolo8.darkbot.config.types.Option
 */
package com.tawaret.tawaplugin.behaviors.stingerwarper;

import com.github.manolo8.darkbot.config.types.Num;
import com.github.manolo8.darkbot.config.types.Option;

public class MapCycleModuleConfig {
    @Option(value="Link to Map Cycle", description="If enabled, Map Cycle will decide when swapping profiles")
    public boolean LINK_TO_MAP_CYCLE;
    @Option(value="Swap if wait is greater (Seconds)", description="Before swapping bot will fast forward to next cycle map")
    @Num(min=0, max=20000, step=10)
    public int WAIT_AFTER_KILL_PREDICTED_SPAWN_THRESH;
    @Option(value="Swap back offset (Seconds)", description="Amount of time you think bot will take to return to next cycle map from the swap config")
    @Num(min=0, max=20000, step=10)
    public int OFFSET_WAIT_AFTER_KILL_PREDICTED_SPAWN_THRESH;
    static long \u13e8 = -9038849536957956743L;

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public MapCycleModuleConfig() {
        long l = \u13e8;
        block14: while (true) {
            switch ((int)l) {
                case -580588374: {
                    l = (0x7212L ^ 0x30F4C908087AAA27L) / (0x2AFCL ^ 0x98B04F77E679368DL);
                    continue block14;
                }
                case 1802157433: {
                    break block14;
                }
            }
            break;
        }
        long l2 = \u13e8;
        boolean bl = true;
        block15: while (true) {
            long l3;
            if (!bl || (bl = false) || !true) {
                l2 = l3 / (0x29C4L ^ 0x4B6EA5FFFFCAFC98L);
            }
            switch ((int)l2) {
                case -1949686806: {
                    l3 = 0x1D81L ^ 0xE830AFB537521096L;
                    continue block15;
                }
                case 517498347: {
                    l3 = 0x2355L ^ 0x8AFE4F7B3D7048F4L;
                    continue block15;
                }
                case 857218878: {
                    l3 = 0x618CL ^ 0xDAADF18BF627F458L;
                    continue block15;
                }
                case 1802157433: {
                    break block15;
                }
            }
            break;
        }
        this.LINK_TO_MAP_CYCLE = 0x4018 ^ 0x4018;
        long l4 = \u13e8;
        block16: while (true) {
            switch ((int)l4) {
                case -1675842221: {
                    l4 = (0x7DE6L ^ 0x93234C0BA726C51FL) / (0x1ED5L ^ 0xBAA04B3965E710B5L);
                    continue block16;
                }
                case 1802157433: {
                    break block16;
                }
            }
            break;
        }
        this.WAIT_AFTER_KILL_PREDICTED_SPAWN_THRESH = 0x3970 ^ 0x385C;
        while (true) {
            long l5;
            long l6;
            if ((l6 = (l5 = \u13e8 - (0x2591L ^ 0x92D822E555445982L)) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l6 == (0x3C23 ^ 0xFFFFC3DC)) {
                this.OFFSET_WAIT_AFTER_KILL_PREDICTED_SPAWN_THRESH = 0x6AFD ^ 0x6AA7;
                return;
            }
            l6 = 0x600 ^ 0x162807BE;
        }
    }
}

