/*
 * Decompiled with CFR 0.152.
 */
package com.tawaret.tawaplugin.behaviors.stingerwarper;

public class PersistentState {
    private Long CACHED_MAP_CYCLE_MODULE_WAIT_SECONDS;
    protected static long \u13e8 = -1030754319601856791L;

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public PersistentState() {
        long l = \u13e8;
        boolean bl = true;
        block9: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x42E7L ^ 0x7BD742BDDC56ADECL);
            }
            switch ((int)l) {
                case -2040424921: {
                    l2 = 0x345AL ^ 0xEC5D87E273C14805L;
                    continue block9;
                }
                case -1876055753: {
                    l2 = 0x75D7L ^ 0xBB207FA7838BC334L;
                    continue block9;
                }
                case 1366200041: {
                    break block9;
                }
            }
            break;
        }
        long l3 = \u13e8;
        block10: while (true) {
            switch ((int)l3) {
                case -1325693083: {
                    l3 = (7032734165717097612L >>> "\u0000\u0000".length()) / (-3017028153378681072L >>> "\u0000\u0000".length());
                    continue block10;
                }
                case 1366200041: {
                    break block10;
                }
            }
            break;
        }
        this.CACHED_MAP_CYCLE_MODULE_WAIT_SECONDS = null;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void setCachedMapCycleWaitSeconds(Long value) {
        long l = \u13e8;
        block4: while (true) {
            switch ((int)l) {
                case -1762973999: {
                    l = (0x59L ^ 0xB0E68F769590E7F3L) / (0x527FL ^ 0x6D1F619B6B73E20BL);
                    continue block4;
                }
                case 1366200041: {
                    break block4;
                }
            }
            break;
        }
        this.CACHED_MAP_CYCLE_MODULE_WAIT_SECONDS = value;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public Long getCachedMapCycleWaitSeconds() {
        long l = \u13e8;
        boolean bl = true;
        block6: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x5F17L ^ 0xD34B2658189EF736L);
            }
            switch ((int)l) {
                case 766892678: {
                    l2 = 0x6115L ^ 0xBF50340C12B8886AL;
                    continue block6;
                }
                case 1214076032: {
                    l2 = 0x4900L ^ 0xAF7D7E2D2CB4D2C5L;
                    continue block6;
                }
                case 1366200041: {
                    return this.CACHED_MAP_CYCLE_MODULE_WAIT_SECONDS;
                }
                case 1876139984: {
                    l2 = 0x3358L ^ 0x70C7A9DD90D024DFL;
                    continue block6;
                }
            }
            break;
        }
        return this.CACHED_MAP_CYCLE_MODULE_WAIT_SECONDS;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void resetCachedMapCycleWaitSeconds() {
        long l = \u13e8;
        block4: while (true) {
            switch ((int)l) {
                case -2134949466: {
                    l = (0x77B4L ^ 0x971ECEB346B3CB2L) / (-1487165308004527580L >>> "\u0000\u0000".length());
                    continue block4;
                }
                case 1366200041: {
                    break block4;
                }
            }
            break;
        }
        this.CACHED_MAP_CYCLE_MODULE_WAIT_SECONDS = null;
    }
}

