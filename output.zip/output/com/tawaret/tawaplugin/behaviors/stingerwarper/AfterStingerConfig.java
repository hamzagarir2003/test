/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.config.types.Num
 *  com.github.manolo8.darkbot.config.types.Option
 *  eu.darkbot.api.config.annotations.Dropdown
 */
package com.tawaret.tawaplugin.behaviors.stingerwarper;

import com.github.manolo8.darkbot.config.types.Num;
import com.github.manolo8.darkbot.config.types.Option;
import com.tawaret.tawaplugin.behaviors.stingerwarper.DontCheckConfig;
import com.tawaret.tawaplugin.utils.types.ConfigSupplier;
import eu.darkbot.api.config.annotations.Dropdown;

public class AfterStingerConfig {
    @Option(value="Profile")
    @Dropdown(options=ConfigSupplier.class)
    public String PROFILE_NAME;
    @Option(value="Check every (Minutes)", description="Check to switch to swap profile every this time, doesn't count if bot is in gg")
    @Num(min=1, max=20000, step=10)
    public int CHECK_TIME;
    @Option(value="Don't check", description="Config for not swapping within certain time period")
    public DontCheckConfig DONT_CHECK;
    @Option(value="Npc Respawn Time (Minutes)", description="Overrides the check every (minutes) setting with this value, -1 to disable")
    @Num(min=-1, max=20000, step=10)
    public int STINGER_RESPAWN_TIME;
    @Option(value="Buy cloak on swap back")
    public boolean BUY_CLOAK_ON_SWAP_BACK;
    protected static long \u13e8 = 3083515728796282541L;

    /*
     * Enabled aggressive block sorting
     */
    public AfterStingerConfig() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x572DL ^ 0x71C39B24445F6CA9L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x495A ^ 0xFFFFB6A5)) break;
            l2 = 0x6357 ^ 0xF075FCB2;
        }
        long l = \u13e8;
        block9: while (true) {
            switch ((int)l) {
                case -1597643811: {
                    l = (0x3DB1L ^ 0x911DE3A8AB96F2F5L) / (-133407079870613608L >>> "\u0000\u0000".length());
                    continue block9;
                }
                case -633639251: {
                    break block9;
                }
            }
            break;
        }
        this.PROFILE_NAME = null;
        while (true) {
            long l3;
            long l4;
            if ((l4 = (l3 = \u13e8 - (0x3415L ^ 0x72ADC579E3F9B524L)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) continue;
            if (l4 == (0x5448 ^ 0xFFFFABB7)) break;
            l4 = 0x5E6F ^ 0x5C16AD31;
        }
        this.CHECK_TIME = 0x7CA0 ^ 0x7CA5;
        while (true) {
            long l5;
            long l6;
            if ((l6 = (l5 = \u13e8 - (0xE8FL ^ 0xCABB5B85626B12BEL)) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) continue;
            if (l6 == (0x7C84 ^ 0x7C85)) break;
            l6 = 0x726B ^ 0xF10F0F0C;
        }
        while (true) {
            long l7;
            long l8;
            if ((l8 = (l7 = \u13e8 - (0x1990L ^ 0x4FF61D711F1E231L)) == 0L ? 0 : (l7 < 0L ? -1 : 1)) == false) continue;
            if (l8 == (0x26B3 ^ 0x26B2)) break;
            l8 = 0xC9D ^ 0x50AA70CE;
        }
        DontCheckConfig dontCheckConfig = new DontCheckConfig();
        long l9 = \u13e8;
        block13: while (true) {
            switch ((int)l9) {
                case -1396863674: {
                    l9 = (0xFF7L ^ 0xA7ADC18071838DD0L) / (0x5848L ^ 0xAE4F18F7E97D30E6L);
                    continue block13;
                }
                case -633639251: {
                    break block13;
                }
            }
            break;
        }
        this.DONT_CHECK = dontCheckConfig;
        while (true) {
            long l10;
            long l11;
            if ((l11 = (l10 = \u13e8 - (0x6C53L ^ 0x5C371065C7276485L)) == 0L ? 0 : (l10 < 0L ? -1 : 1)) == false) continue;
            if (l11 == (0x7EFC ^ 0xFFFF8103)) break;
            l11 = -1736843236 >>> "\u0000\u0000".length();
        }
        this.STINGER_RESPAWN_TIME = 0x7DEF ^ 0xFFFF8210;
        int n = "".length() >>> "\u0000\u0000".length();
        while (true) {
            long l12;
            long l13;
            if ((l13 = (l12 = \u13e8 - (0x7A30L ^ 0x974579060CCF10EEL)) == 0L ? 0 : (l12 < 0L ? -1 : 1)) == false) continue;
            if (l13 == (0x6943 ^ 0x6942)) {
                this.BUY_CLOAK_ON_SWAP_BACK = n;
                return;
            }
            l13 = 0x1A10 ^ 0xA61F2B77;
        }
    }
}

