/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.core.manager.StarManager
 *  com.github.manolo8.darkbot.core.utils.Lazy
 *  com.github.manolo8.darkbot.gui.tree.OptionEditor
 *  com.github.manolo8.darkbot.gui.tree.components.InfoTable
 *  com.github.manolo8.darkbot.gui.utils.GenericTableModel
 */
package com.tawaret.tawaplugin.gui.components;

import com.github.manolo8.darkbot.core.manager.StarManager;
import com.github.manolo8.darkbot.core.utils.Lazy;
import com.github.manolo8.darkbot.gui.tree.OptionEditor;
import com.github.manolo8.darkbot.gui.tree.components.InfoTable;
import com.github.manolo8.darkbot.gui.utils.GenericTableModel;
import com.tawaret.tawaplugin.features.mapcyclemodule.MapCycleModuleConfig;
import com.tawaret.tawaplugin.features.mapcyclemodule.models.MapInfo;
import com.tawaret.tawaplugin.features.mapcyclemodule.models.MapInfoFactory;
import com.tawaret.tawaplugin.models.ICoordinate;
import com.tawaret.tawaplugin.models.IMapCoordinate;
import com.tawaret.tawaplugin.models.MapCoordinateFactory;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

public class JMapCycleInfoTable
extends InfoTable<GenericTableModel<MapInfo>, MapInfo>
implements OptionEditor {
    public static long \u13e8 = -4823885765432319619L;

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public JMapCycleInfoTable(MapCycleModuleConfig config) {
        long l = \u13e8;
        boolean bl = true;
        block25: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x27FFL ^ 0xF961AA8023D6BCE8L);
            }
            switch ((int)l) {
                case -1647382872: {
                    l2 = 0x4BFDL ^ 0x72B85F9C1ECE1F45L;
                    continue block25;
                }
                case -918318655: {
                    l2 = 0x4524L ^ 0xB919581B45C9C50EL;
                    continue block25;
                }
                case -122995621: {
                    l2 = 0x721EL ^ 0x97799EF7461EC127L;
                    continue block25;
                }
                case 1381491069: {
                    break block25;
                }
            }
            break;
        }
        StarManager starManager = StarManager.getInstance();
        long l3 = \u13e8;
        boolean bl2 = true;
        block26: while (true) {
            long l4;
            if (!bl2 || (bl2 = false) || !true) {
                l3 = l4 / (0x3365L ^ 0x970C81B02F0F8A0L);
            }
            switch ((int)l3) {
                case -1493129933: {
                    l4 = 0x502AL ^ 0x4AFD175AA032B33FL;
                    continue block26;
                }
                case -983984206: {
                    l4 = 0x514CL ^ 0x43FE36BB143249F6L;
                    continue block26;
                }
                case 1381491069: {
                    break block26;
                }
            }
            break;
        }
        Map<String, MapInfo> map = JMapCycleInfoTable.tryInitMapCycleTable(config, starManager);
        long l5 = \u13e8;
        boolean bl3 = true;
        block27: while (true) {
            long l6;
            if (!bl3 || (bl3 = false) || !true) {
                l5 = l6 / (8065952819324516632L >>> "\u0000\u0000".length());
            }
            switch ((int)l5) {
                case -602548215: {
                    l6 = 0x3DACL ^ 0xCD2F8ED2503CF608L;
                    continue block27;
                }
                case 1018217358: {
                    l6 = 0x32FDL ^ 0xA75BAA63D000BC4AL;
                    continue block27;
                }
                case 1381491069: {
                    break block27;
                }
            }
            break;
        }
        Lazy<String> lazy = config.MODIFIED_CYCLE_MAP;
        long l7 = \u13e8;
        block28: while (true) {
            switch ((int)l7) {
                case -1149497934: {
                    l7 = (0x1CD2L ^ 0xDF96AA3F22F8EA06L) / (0x49B6L ^ 0xD164E5DA0D11616EL);
                    continue block28;
                }
                case 1381491069: {
                    break block28;
                }
            }
            break;
        }
        Supplier<MapInfo> supplier = MapInfoFactory::Default;
        long l8 = \u13e8;
        boolean bl4 = true;
        block29: while (true) {
            long l9;
            if (!bl4 || (bl4 = false) || !true) {
                l8 = l9 / (0x3E61L ^ 0x636059BD5B730D43L);
            }
            switch ((int)l8) {
                case -1160110227: {
                    l9 = 0x6EB1L ^ 0x3ADD3455B5CBD8C9L;
                    continue block29;
                }
                case 1381491069: {
                    break block29;
                }
                case 1939893048: {
                    l9 = -5831170425344491908L >>> "\u0000\u0000".length();
                    continue block29;
                }
            }
            break;
        }
        super(MapInfo.class, map, lazy, supplier);
    }

    /*
     * Unable to fully structure code
     */
    private static Map<String, MapInfo> tryInitMapCycleTable(MapCycleModuleConfig config, StarManager starManager) {
        v0 = JMapCycleInfoTable.\u13e8;
        if (true) ** GOTO lbl5
        block136: while (true) {
            v0 = (14754L ^ -5739801884987875682L) / (25871L ^ 4208707483907991230L);
lbl5:
            // 2 sources

            switch ((int)v0) {
                case -1599845176: {
                    continue block136;
                }
                case 1381491069: {
                    break block136;
                }
            }
            break;
        }
        ret = config.CYCLE_MAP_INFOS;
        v1 = JMapCycleInfoTable.\u13e8;
        if (true) ** GOTO lbl15
        block137: while (true) {
            v1 = v2 / (9798L ^ 7975683361373194896L);
lbl15:
            // 2 sources

            switch ((int)v1) {
                case -170878807: {
                    v2 = 3146L ^ -2658450872443382787L;
                    continue block137;
                }
                case 464820370: {
                    v2 = 11283L ^ -4296625324679361843L;
                    continue block137;
                }
                case 1381491069: {
                    break block137;
                }
                case 1891239820: {
                    v2 = 8473L ^ -5469874052390283754L;
                    continue block137;
                }
            }
            break;
        }
        v3 = JMapCycleInfoTable.\u13e8;
        if (true) ** GOTO lbl31
        block138: while (true) {
            v3 = (16288L ^ 10875966121085947L) / (25906L ^ 7948438355314748400L);
lbl31:
            // 2 sources

            switch ((int)v3) {
                case 1166774345: {
                    continue block138;
                }
                case 1381491069: {
                    break block138;
                }
            }
            break;
        }
        BL_MAP_ANCHORS = new HashMap<String, IMapCoordinate>();
        v4 = JMapCycleInfoTable.\u13e8;
        if (true) ** GOTO lbl41
        block139: while (true) {
            v4 = v5 / (14822L ^ 7585667234873422437L);
lbl41:
            // 2 sources

            switch ((int)v4) {
                case -1770525146: {
                    v5 = 27930L ^ 8088745344200058506L;
                    continue block139;
                }
                case -1044792466: {
                    v5 = 7391L ^ -6481101238470271782L;
                    continue block139;
                }
                case -233005354: {
                    v5 = 25189L ^ -3972741339014218024L;
                    continue block139;
                }
                case 1381491069: {
                    break block139;
                }
            }
            break;
        }
        v6 = JMapCycleInfoTable.\u13e8;
        if (true) ** GOTO lbl57
        block140: while (true) {
            v6 = (29622L ^ -1202279876281473095L) / (28791L ^ 2397197202303491119L);
lbl57:
            // 2 sources

            switch ((int)v6) {
                case -1918647361: {
                    continue block140;
                }
                case 1381491069: {
                    break block140;
                }
            }
            break;
        }
        BL_MAP_NAMES = new ArrayList<String>();
        v7 = new IMapCoordinate["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
        while (true) {
            if ((v8 = (cfr_temp_0 = JMapCycleInfoTable.\u13e8 - (4429L ^ -3693033374011188966L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) continue;
            if (v8 == (23072 ^ -23073)) break;
            v8 = 29789 ^ 1214024903;
        }
        v7[26064 ^ 26064] = MapCoordinateFactory.BehemothSpawn.BL_3();
        v9 = "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
        v10 = JMapCycleInfoTable.\u13e8;
        if (true) ** GOTO lbl75
        block142: while (true) {
            v10 = v11 / (-9068807848407174328L >>> "\u0000\u0000".length());
lbl75:
            // 2 sources

            switch ((int)v10) {
                case -1563149256: {
                    v11 = 6810L ^ 8989910030416638624L;
                    continue block142;
                }
                case -1215133148: {
                    v11 = 6548L ^ -5378826071482881436L;
                    continue block142;
                }
                case -938069604: {
                    v11 = 22987L ^ 532393646186544254L;
                    continue block142;
                }
                case 1381491069: {
                    break block142;
                }
            }
            break;
        }
        v7[v9] = MapCoordinateFactory.BehemothSpawn.BL_2();
        v12 = JMapCycleInfoTable.\u13e8;
        if (true) ** GOTO lbl92
        block143: while (true) {
            v12 = v13 / (31721L ^ 409235544672179667L);
lbl92:
            // 2 sources

            switch ((int)v12) {
                case -1175449391: {
                    v13 = 30089L ^ 4401047349581483736L;
                    continue block143;
                }
                case -315737279: {
                    v13 = 9184L ^ -6709825547514179565L;
                    continue block143;
                }
                case 1381491069: {
                    break block143;
                }
            }
            break;
        }
        v7[23288 ^ 23290] = MapCoordinateFactory.BehemothSpawn.BL_1();
        var5_5 = v7;
        var6_7 = var5_5.length;
        for (var7_9 = "".length() >>> "\u0000\u0000".length(); var7_9 < var6_7; ++var7_9) {
            mapCoordinate = var5_5[var7_9];
            v14 = JMapCycleInfoTable.\u13e8;
            if (true) ** GOTO lbl110
            block145: while (true) {
                v14 = v15 / (24881L ^ 8092317571502115279L);
lbl110:
                // 2 sources

                switch ((int)v14) {
                    case -1213923926: {
                        v15 = 17746L ^ -5694350199066044255L;
                        continue block145;
                    }
                    case 1245255952: {
                        v15 = 5716512887119237852L >>> "\u0000\u0000".length();
                        continue block145;
                    }
                    case 1359698479: {
                        v15 = 7592951826191722092L >>> "\u0000\u0000".length();
                        continue block145;
                    }
                    case 1381491069: {
                        break block145;
                    }
                }
                break;
            }
            v16 = mapCoordinate.getMapName();
            v17 = JMapCycleInfoTable.\u13e8;
            if (true) ** GOTO lbl127
            block146: while (true) {
                v17 = v18 / (23509L ^ 8252056320610316400L);
lbl127:
                // 2 sources

                switch ((int)v17) {
                    case -1402303691: {
                        v18 = 16237L ^ -5651202612438758031L;
                        continue block146;
                    }
                    case 644178185: {
                        v18 = 9039265220504443768L >>> "\u0000\u0000".length();
                        continue block146;
                    }
                    case 1381491069: {
                        break block146;
                    }
                    case 1957271607: {
                        v18 = 11615L ^ -8451712045742093120L;
                        continue block146;
                    }
                }
                break;
            }
            BL_MAP_ANCHORS.put(v16, mapCoordinate);
            while (true) {
                if ((v19 = (cfr_temp_1 = JMapCycleInfoTable.\u13e8 - (-4853767234289566940L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) continue;
                if (v19 == (18609 ^ -18610)) break;
                v19 = 32033 ^ -1440700878;
            }
            v20 = mapCoordinate.getMapName();
            v21 = JMapCycleInfoTable.\u13e8;
            if (true) ** GOTO lbl151
            block148: while (true) {
                v21 = v22 / (2007043897949827896L >>> "\u0000\u0000".length());
lbl151:
                // 2 sources

                switch ((int)v21) {
                    case -1922159820: {
                        v22 = 32287L ^ 4696763329308232630L;
                        continue block148;
                    }
                    case -1161471740: {
                        v22 = 20794L ^ -7705651173842698208L;
                        continue block148;
                    }
                    case 629461427: {
                        v22 = 31650L ^ 1995706942285452194L;
                        continue block148;
                    }
                    case 1381491069: {
                        break block148;
                    }
                }
                break;
            }
            BL_MAP_NAMES.add(v20);
        }
        while (true) {
            if ((v23 = (cfr_temp_2 = JMapCycleInfoTable.\u13e8 - (29725L ^ 2583386178825322129L)) == 0L ? 0 : (cfr_temp_2 < 0L ? -1 : 1)) == false) continue;
            if (v23 == (3831 ^ -3832)) break;
            v23 = 5124 ^ -1537466041;
        }
        DEFAULT_CYCLE_MAPS_CNT = BL_MAP_NAMES.size();
        for (i = 29435 ^ 29435; i < DEFAULT_CYCLE_MAPS_CNT; ++i) {
            while (true) {
                if ((v24 = (cfr_temp_3 = JMapCycleInfoTable.\u13e8 - (11046L ^ -9025883398152003067L)) == 0L ? 0 : (cfr_temp_3 < 0L ? -1 : 1)) == false) continue;
                if (v24 == (1450 ^ 1451)) break;
                v24 = 11781 ^ 1775066890;
            }
            mapName = (String)BL_MAP_NAMES.get(i);
            isRefreshable = i == DEFAULT_CYCLE_MAPS_CNT - (12803 ^ 12802) ? "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length() : 19193 ^ 19193;
            v25 = JMapCycleInfoTable.\u13e8;
            if (true) ** GOTO lbl184
            block152: while (true) {
                v25 = (8952327091946686700L >>> "\u0000\u0000".length()) / (7034L ^ 5308723333084307380L);
lbl184:
                // 2 sources

                switch ((int)v25) {
                    case -2031932943: {
                        continue block152;
                    }
                    case 1381491069: {
                        break block152;
                    }
                }
                break;
            }
            anchor = (ICoordinate)BL_MAP_ANCHORS.get(mapName);
            v26 = i + ("\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length());
            v27 = JMapCycleInfoTable.\u13e8;
            if (true) ** GOTO lbl195
            block153: while (true) {
                v27 = v28 / (28172L ^ 6026496063822940228L);
lbl195:
                // 2 sources

                switch ((int)v27) {
                    case -465245751: {
                        v28 = 15161L ^ -8113718080974755766L;
                        continue block153;
                    }
                    case -444751101: {
                        v28 = 24648L ^ 4480252502325073877L;
                        continue block153;
                    }
                    case 1381491069: {
                        break block153;
                    }
                    case 1778526932: {
                        v28 = 27669L ^ -5431678313817960041L;
                        continue block153;
                    }
                }
                break;
            }
            v29 = starManager.byName(mapName);
            while (true) {
                if ((v30 = (cfr_temp_4 = JMapCycleInfoTable.\u13e8 - (4443L ^ -889589883562929658L)) == 0L ? 0 : (cfr_temp_4 < 0L ? -1 : 1)) == false) continue;
                if (v30 == (24380 ^ -24381)) break;
                v30 = 7243 ^ 2112744257;
            }
            v31 = v29.id;
            v32 = JMapCycleInfoTable.\u13e8;
            if (true) ** GOTO lbl218
            block155: while (true) {
                v32 = v33 / (14392L ^ -2868357980686743413L);
lbl218:
                // 2 sources

                switch ((int)v32) {
                    case -1755303155: {
                        v33 = 31931L ^ 3012751401282040730L;
                        continue block155;
                    }
                    case 750648379: {
                        v33 = -4394616479066887424L >>> "\u0000\u0000".length();
                        continue block155;
                    }
                    case 1381491069: {
                        break block155;
                    }
                }
                break;
            }
            v34 = anchor.getX();
            v35 = JMapCycleInfoTable.\u13e8;
            if (true) ** GOTO lbl232
            block156: while (true) {
                v35 = v36 / (18101L ^ -4083718061100502076L);
lbl232:
                // 2 sources

                switch ((int)v35) {
                    case -1942555808: {
                        v36 = 25741L ^ -8468397539995783620L;
                        continue block156;
                    }
                    case 1381491069: {
                        break block156;
                    }
                    case 1677396836: {
                        v36 = 3764L ^ -2997062277169167920L;
                        continue block156;
                    }
                }
                break;
            }
            v37 = anchor.getY();
            v38 = JMapCycleInfoTable.\u13e8;
            if (true) ** GOTO lbl246
            block157: while (true) {
                v38 = v39 / (1753175024370293856L >>> "\u0000\u0000".length());
lbl246:
                // 2 sources

                switch ((int)v38) {
                    case -677435130: {
                        v39 = -7982271704976791100L >>> "\u0000\u0000".length();
                        continue block157;
                    }
                    case -399052499: {
                        v39 = 9885L ^ 6056169491001823634L;
                        continue block157;
                    }
                    case 1381491069: {
                        break block157;
                    }
                    case 1557575521: {
                        v39 = -2646523400076042880L >>> "\u0000\u0000".length();
                        continue block157;
                    }
                }
                break;
            }
            v40 = MapInfoFactory.DefaultPartOfCycle(v26, (boolean)isRefreshable, v31, v34, v37);
            while (true) {
                if ((v41 = (cfr_temp_5 = JMapCycleInfoTable.\u13e8 - (7012L ^ 1343157576758472389L)) == 0L ? 0 : (cfr_temp_5 < 0L ? -1 : 1)) == false) continue;
                if (v41 == (2419 ^ -2420)) break;
                v41 = 4043 ^ 255004112;
            }
            ret.putIfAbsent(mapName, v40);
            while (true) {
                if ((v42 = (cfr_temp_6 = JMapCycleInfoTable.\u13e8 - (2480L ^ -7714587172764461201L)) == 0L ? 0 : (cfr_temp_6 < 0L ? -1 : 1)) == false) continue;
                if (v42 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
                v42 = -1581323760 >>> "\u0000\u0000".length();
            }
            mapInfo = ret.get(mapName);
            v43 = JMapCycleInfoTable.\u13e8;
            if (true) ** GOTO lbl275
            block160: while (true) {
                v43 = (6356L ^ -6237470069642767760L) / (31475L ^ -8867528311747527989L);
lbl275:
                // 2 sources

                switch ((int)v43) {
                    case 748599865: {
                        continue block160;
                    }
                    case 1381491069: {
                        break block160;
                    }
                }
                break;
            }
            if (mapInfo.anchor_x >= 0) continue;
            v44 = JMapCycleInfoTable.\u13e8;
            if (true) ** GOTO lbl285
            block161: while (true) {
                v44 = v45 / (11061L ^ -8073548923603847689L);
lbl285:
                // 2 sources

                switch ((int)v44) {
                    case -949229619: {
                        v45 = 14191L ^ -5392007997677081075L;
                        continue block161;
                    }
                    case -692273641: {
                        v45 = 32581L ^ -3075846679703466128L;
                        continue block161;
                    }
                    case 1381491069: {
                        break block161;
                    }
                }
                break;
            }
            if (mapInfo.anchor_y >= 0) continue;
            while (true) {
                if ((v46 = (cfr_temp_7 = JMapCycleInfoTable.\u13e8 - (32072L ^ -1328557482437459965L)) == 0L ? 0 : (cfr_temp_7 < 0L ? -1 : 1)) == false) continue;
                if (v46 == (2587 ^ -2588)) break;
                v46 = 22187 ^ -318713145;
            }
            v47 = anchor.getX();
            while (true) {
                if ((v48 = (cfr_temp_8 = JMapCycleInfoTable.\u13e8 - (15296L ^ -3460089571308824361L)) == 0L ? 0 : (cfr_temp_8 < 0L ? -1 : 1)) == false) continue;
                if (v48 == (32697 ^ -32698)) break;
                v48 = 27844 ^ -1665017702;
            }
            mapInfo.anchor_x = v47;
            while (true) {
                if ((v49 = (cfr_temp_9 = JMapCycleInfoTable.\u13e8 - (14051L ^ -2196590769564869352L)) == 0L ? 0 : (cfr_temp_9 < 0L ? -1 : 1)) == false) continue;
                if (v49 == (23684 ^ -23685)) break;
                v49 = 30569 ^ -1156922917;
            }
            v50 = anchor.getY();
            v51 = JMapCycleInfoTable.\u13e8;
            if (true) ** GOTO lbl317
            block165: while (true) {
                v51 = (10538L ^ -1993512982870427009L) / (12086L ^ 7159579610417617964L);
lbl317:
                // 2 sources

                switch ((int)v51) {
                    case -1447250594: {
                        continue block165;
                    }
                    case 1381491069: {
                        break block165;
                    }
                }
                break;
            }
            mapInfo.anchor_y = v50;
        }
        v52 = JMapCycleInfoTable.\u13e8;
        if (true) ** GOTO lbl328
        block166: while (true) {
            v52 = v53 / (5670L ^ 8619220222494936086L);
lbl328:
            // 2 sources

            switch ((int)v52) {
                case -1115979801: {
                    v53 = 26007L ^ -249160756204222293L;
                    continue block166;
                }
                case 17629952: {
                    v53 = 25975L ^ -5710369870348664657L;
                    continue block166;
                }
                case 1381491069: {
                    break block166;
                }
            }
            break;
        }
        var6_8 = StarManager.OUTPOST_HOME_MAPS;
        mapName = ((String[])var6_8).length;
        for (var8_14 = 14076 ^ 14076; var8_14 < mapName; ++var8_14) {
            refreshMap = var6_8[var8_14];
            while (true) {
                if ((v54 = (cfr_temp_10 = JMapCycleInfoTable.\u13e8 - (22853L ^ 4833995078599519069L)) == 0L ? 0 : (cfr_temp_10 < 0L ? -1 : 1)) == false) continue;
                if (v54 == (14473 ^ -14474)) break;
                v54 = 27731 ^ -1100530798;
            }
            v55 = starManager.byName(refreshMap);
            v56 = JMapCycleInfoTable.\u13e8;
            if (true) ** GOTO lbl351
            block169: while (true) {
                v56 = (13971L ^ -6662143142812961933L) / (23744L ^ -3203485555988620321L);
lbl351:
                // 2 sources

                switch ((int)v56) {
                    case 855548761: {
                        continue block169;
                    }
                    case 1381491069: {
                        break block169;
                    }
                }
                break;
            }
            v57 = v55.id;
            v58 = JMapCycleInfoTable.\u13e8;
            if (true) ** GOTO lbl361
            block170: while (true) {
                v58 = (30470L ^ -6637227443583826099L) / (11619L ^ 4667992641359646750L);
lbl361:
                // 2 sources

                switch ((int)v58) {
                    case 1381491069: {
                        break block170;
                    }
                    case 1557871188: {
                        continue block170;
                    }
                }
                break;
            }
            v59 = MapInfoFactory.Refreshable(v57);
            v60 = JMapCycleInfoTable.\u13e8;
            if (true) ** GOTO lbl371
            block171: while (true) {
                v60 = v61 / (23939L ^ -8177814897703801472L);
lbl371:
                // 2 sources

                switch ((int)v60) {
                    case -1028813071: {
                        v61 = 27442L ^ 3953481856618074156L;
                        continue block171;
                    }
                    case -706740103: {
                        v61 = 32106L ^ 6616692052353150614L;
                        continue block171;
                    }
                    case 1381491069: {
                        break block171;
                    }
                }
                break;
            }
            ret.putIfAbsent(refreshMap, v59);
        }
        while (true) {
            if ((v62 = (cfr_temp_11 = JMapCycleInfoTable.\u13e8 - (29946L ^ 1173288756002025838L)) == 0L ? 0 : (cfr_temp_11 < 0L ? -1 : 1)) == false) continue;
            if (v62 == (30957 ^ -30958)) break;
            v62 = 28290 ^ 688007457;
        }
        v63 = starManager.getAccessibleMaps();
        while (true) {
            if ((v64 = (cfr_temp_12 = JMapCycleInfoTable.\u13e8 - (26140L ^ 7682017464807767962L)) == 0L ? 0 : (cfr_temp_12 < 0L ? -1 : 1)) == false) continue;
            if (v64 == (24718 ^ -24719)) break;
            v64 = 9141 ^ -205663472;
        }
        var6_8 = v63.iterator();
        while (true) {
            v65 = JMapCycleInfoTable.\u13e8;
            if (true) ** GOTO lbl400
            block175: while (true) {
                v65 = v66 / (9137L ^ -1431917794851815476L);
lbl400:
                // 2 sources

                switch ((int)v65) {
                    case -1722858493: {
                        v66 = 10051L ^ 355904519512691462L;
                        continue block175;
                    }
                    case 471095853: {
                        v66 = 9404L ^ 5098085676548666760L;
                        continue block175;
                    }
                    case 1381491069: {
                        break block175;
                    }
                }
                break;
            }
            if (!var6_8.hasNext()) break;
            v67 = JMapCycleInfoTable.\u13e8;
            if (true) ** GOTO lbl414
            block176: while (true) {
                v67 = (684L ^ -3055851649188870493L) / (25122L ^ 8985488698100268205L);
lbl414:
                // 2 sources

                switch ((int)v67) {
                    case -279799782: {
                        continue block176;
                    }
                    case 1381491069: {
                        break block176;
                    }
                }
                break;
            }
            otherMap = (String)var6_8.next();
            v68 = JMapCycleInfoTable.\u13e8;
            if (true) ** GOTO lbl424
            block177: while (true) {
                v68 = v69 / (17658L ^ -6514702131728821344L);
lbl424:
                // 2 sources

                switch ((int)v68) {
                    case -443667365: {
                        v69 = 19694L ^ 8010283643040585445L;
                        continue block177;
                    }
                    case 582491342: {
                        v69 = 2923L ^ 3653268581397431644L;
                        continue block177;
                    }
                    case 1031581870: {
                        v69 = 9560L ^ -2080997069536376626L;
                        continue block177;
                    }
                    case 1381491069: {
                        break block177;
                    }
                }
                break;
            }
            v70 = starManager.byName(otherMap);
            while (true) {
                if ((v71 = (cfr_temp_13 = JMapCycleInfoTable.\u13e8 - (14141L ^ 5259424761654424296L)) == 0L ? 0 : (cfr_temp_13 < 0L ? -1 : 1)) == false) continue;
                if (v71 == (8054 ^ -8055)) break;
                v71 = 632670052 >>> "\u0000\u0000".length();
            }
            v72 = v70.id;
            v73 = JMapCycleInfoTable.\u13e8;
            if (true) ** GOTO lbl447
            block179: while (true) {
                v73 = v74 / (26602L ^ 5256945386558374202L);
lbl447:
                // 2 sources

                switch ((int)v73) {
                    case -588080143: {
                        v74 = 0L ^ -2059648146271658218L;
                        continue block179;
                    }
                    case -574841327: {
                        v74 = 4226L ^ -7306411813348712760L;
                        continue block179;
                    }
                    case 629966764: {
                        v74 = 24877L ^ 9140482245123708404L;
                        continue block179;
                    }
                    case 1381491069: {
                        break block179;
                    }
                }
                break;
            }
            v75 = MapInfoFactory.NotRefreshable(v72);
            v76 = JMapCycleInfoTable.\u13e8;
            if (true) ** GOTO lbl464
            block180: while (true) {
                v76 = v77 / (22264L ^ -8853704018440184932L);
lbl464:
                // 2 sources

                switch ((int)v76) {
                    case -766140256: {
                        v77 = 5636L ^ -5463231383377835256L;
                        continue block180;
                    }
                    case -213416636: {
                        v77 = 18958L ^ 3565484354167149389L;
                        continue block180;
                    }
                    case 1381491069: {
                        break block180;
                    }
                }
                break;
            }
            ret.putIfAbsent(otherMap, v75);
        }
        return ret;
    }
}

