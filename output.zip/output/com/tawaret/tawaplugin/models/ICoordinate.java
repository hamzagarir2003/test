/*
 * Decompiled with CFR 0.152.
 */
package com.tawaret.tawaplugin.models;

public interface ICoordinate {
    public int getX();

    public int getY();
}

