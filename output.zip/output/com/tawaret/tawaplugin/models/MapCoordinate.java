/*
 * Decompiled with CFR 0.152.
 */
package com.tawaret.tawaplugin.models;

import com.tawaret.tawaplugin.models.IMapCoordinate;

public class MapCoordinate
implements IMapCoordinate {
    private final int x;
    private final int y;
    public final String mapName;
    protected static long \u13e8 = -2942538890201499547L;

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public MapCoordinate(String mapName, int x, int y) {
        long l = \u13e8;
        boolean bl = true;
        block21: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x705EL ^ 0xFD3C8F7691EE703DL);
            }
            switch ((int)l) {
                case -1643205082: {
                    l2 = 0x5E4CL ^ 0xAEF5B49B205B3A5L;
                    continue block21;
                }
                case 820449117: {
                    l2 = 0x1BC4L ^ 0x9E3B95A3CFD051FFL;
                    continue block21;
                }
                case 935622757: {
                    break block21;
                }
                case 1740319934: {
                    l2 = 0x418EL ^ 0x1613ECDAF7F77C73L;
                    continue block21;
                }
            }
            break;
        }
        long l3 = \u13e8;
        boolean bl2 = true;
        block22: while (true) {
            long l4;
            if (!bl2 || (bl2 = false) || !true) {
                l3 = l4 / (0x5D45L ^ 0x6B3C0C5FE22285B0L);
            }
            switch ((int)l3) {
                case -1624339091: {
                    l4 = 0x190DL ^ 0x6721B2CBA0CBD91AL;
                    continue block22;
                }
                case -1196716895: {
                    l4 = 0x7036L ^ 0xF3735E072659D5EFL;
                    continue block22;
                }
                case -972305964: {
                    l4 = 0x2A4AL ^ 0xE60F39355C240382L;
                    continue block22;
                }
                case 935622757: {
                    break block22;
                }
            }
            break;
        }
        this.x = x;
        long l5 = \u13e8;
        boolean bl3 = true;
        block23: while (true) {
            long l6;
            if (!bl3 || (bl3 = false) || !true) {
                l5 = l6 / (0x4A7L ^ 0xA33D874D343588A3L);
            }
            switch ((int)l5) {
                case -1515585282: {
                    l6 = 0x28CFL ^ 0x259EA7C778B511DCL;
                    continue block23;
                }
                case 810382470: {
                    l6 = 0x3894L ^ 0x82EFD29D3F6841EAL;
                    continue block23;
                }
                case 935622757: {
                    break block23;
                }
            }
            break;
        }
        this.y = y;
        long l7 = \u13e8;
        block24: while (true) {
            switch ((int)l7) {
                case -1922165848: {
                    l7 = (0x5E52L ^ 0xF913D7940CA9D85L) / (0x151L ^ 0x83510F0F2BFF592EL);
                    continue block24;
                }
                case 935622757: {
                    break block24;
                }
            }
            break;
        }
        this.mapName = mapName;
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    @Override
    public int getX() {
        long l = \u13e8;
        boolean bl = true;
        block6: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x72BL ^ 0x989312409B566A8AL);
            }
            switch ((int)l) {
                case -267005334: {
                    l2 = 0x4C5L ^ 0x8DAE1885441988ACL;
                    continue block6;
                }
                case 795433904: {
                    l2 = 0x6AC3L ^ 0xAA651443B41184ABL;
                    continue block6;
                }
                case 935622757: {
                    return this.x;
                }
                case 1224813626: {
                    l2 = 0x44E7L ^ 0xF323BEBE08486424L;
                    continue block6;
                }
            }
            break;
        }
        return this.x;
    }

    @Override
    public int getY() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x2925L ^ 0xD26ACB97450F4FFFL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == (0x1C3A ^ 0x1C3B)) break;
            l2 = 0x303A ^ 0x182B4B14;
        }
        return this.y;
    }

    @Override
    public String getMapName() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x5ACAL ^ 0xEA6E3D83F3377D97L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                continue;
            }
            if (l2 == (0x2749 ^ 0xFFFFD8B6)) break;
            l2 = 0x3EB1 ^ 0x1004F890;
        }
        return this.mapName;
    }
}

