/*
 * Decompiled with CFR 0.152.
 */
package com.tawaret.tawaplugin.models;

import com.tawaret.tawaplugin.models.ICoordinate;

public interface IMapCoordinate
extends ICoordinate {
    public String getMapName();
}

