/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.github.manolo8.darkbot.core.manager.StarManager
 */
package com.tawaret.tawaplugin.models;

import com.github.manolo8.darkbot.core.manager.StarManager;
import com.tawaret.tawaplugin.models.IMapCoordinate;
import com.tawaret.tawaplugin.models.MapCoordinate;

public class MapCoordinateFactory {
    protected static long \u13e8 = 7378814091649875473L;

    /*
     * Enabled aggressive block sorting
     */
    public MapCoordinateFactory() {
        long l = \u13e8;
        block4: while (true) {
            switch ((int)l) {
                case 1550843409: {
                    break block4;
                }
                case 1697027159: {
                    l = (0x6F05L ^ 0x49C713F3E1A1ED11L) / (0x39BCL ^ 0x7CE6ABFBBD4301A0L);
                    continue block4;
                }
            }
            break;
        }
    }

    public static class StrokelightSpawn {
        public static long \u13e8 = -3809781978335856103L;

        public StrokelightSpawn() {
            while (true) {
                long l;
                long l2;
                if ((l2 = (l = \u13e8 - (0x1565L ^ 0x77EEA3CEC950D657L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
                if (l2 == (0x4948 ^ 0xFFFFB6B7)) break;
                l2 = 0x2CF8 ^ 0xFE04A259;
            }
        }

        /*
         * Unable to fully structure code
         */
        public static IMapCoordinate BL_1() {
            while (true) {
                if ((v0 = (cfr_temp_0 = StrokelightSpawn.\u13e8 - (7877506845330795968L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (v0 == (15688 ^ -15689)) break;
                v0 = -1666376684 >>> "\u0000\u0000".length();
            }
            while (true) {
                if ((v1 = (cfr_temp_1 = StrokelightSpawn.\u13e8 - (-5948911204650992928L >>> "\u0000\u0000".length())) == 0L ? 0 : (cfr_temp_1 < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (v1 == (31310 ^ -31311)) break;
                v1 = 11282 ^ 1670266782;
            }
            v2 = StarManager.BL_MAPS["".length() >>> "\u0000\u0000".length()];
            v3 = "\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length();
            v4 = StrokelightSpawn.\u13e8;
            if (true) ** GOTO lbl19
            block7: while (true) {
                v4 = v5 / (8531L ^ 6709482300728963880L);
lbl19:
                // 2 sources

                switch ((int)v4) {
                    case -1832735620: {
                        v5 = 23210L ^ 6911809043512938784L;
                        continue block7;
                    }
                    case -845465063: {
                        break block7;
                    }
                    case -444912219: {
                        v5 = 24030L ^ 6648046582859064724L;
                        continue block7;
                    }
                }
                break;
            }
            return new MapCoordinate(v2, v3, 9910 ^ 9894);
        }

        /*
         * Enabled aggressive block sorting
         */
        public static IMapCoordinate BL_2() {
            while (true) {
                long l;
                long l2;
                if ((l2 = (l = \u13e8 - (0x32ADL ^ 0xE60D28AA85DC46F0L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
                if (l2 == (0x6033 ^ 0xFFFF9FCC)) break;
                l2 = 0x3124 ^ 0xC1BFA7EE;
            }
            long l = \u13e8;
            block5: while (true) {
                switch ((int)l) {
                    case -1700560374: {
                        l = (0x3D6DL ^ 0x17C7DA3E3D4977F5L) / (0x4848L ^ 0xEED10BFF51125D6L);
                        continue block5;
                    }
                    case -845465063: {
                        break block5;
                    }
                }
                break;
            }
            String string = StarManager.BL_MAPS["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
            int n = 728 >>> "\u0000\u0000".length();
            int n2 = 208 >>> "\u0000\u0000".length();
            while (true) {
                long l3;
                long l4;
                if ((l4 = (l3 = \u13e8 - (0x3ABBL ^ 0xC70C46F52E4C2B3FL)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) continue;
                if (l4 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) {
                    return new MapCoordinate(string, n, n2);
                }
                l4 = 635863212 >>> "\u0000\u0000".length();
            }
        }

        /*
         * Handled impossible loop by adding 'first' condition
         * Enabled aggressive block sorting
         */
        public static IMapCoordinate BL_3() {
            long l = \u13e8;
            boolean bl = true;
            block5: while (true) {
                long l2;
                if (!bl || (bl = false) || !true) {
                    l = l2 / (0x48F6L ^ 0x441A884D722CD4E3L);
                }
                switch ((int)l) {
                    case -845465063: {
                        break block5;
                    }
                    case 902390873: {
                        l2 = 0x33C7L ^ 0x5A6C6C3A0FB17E90L;
                        continue block5;
                    }
                    case 1576511276: {
                        l2 = 0x2AC9L ^ 0x22A5177F0616B21L;
                        continue block5;
                    }
                }
                break;
            }
            while (true) {
                long l3;
                long l4;
                if ((l4 = (l3 = \u13e8 - (0x88AL ^ 0xE7BF0FCDB6EA5554L)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) continue;
                if (l4 == (0x7964 ^ 0xFFFF869B)) break;
                l4 = 0x3DCF ^ 0x128154F3;
            }
            String string = StarManager.BL_MAPS[0x74F2 ^ 0x74F0];
            int n = 712 >>> "\u0000\u0000".length();
            int n2 = 220 >>> "\u0000\u0000".length();
            while (true) {
                long l5;
                long l6;
                if ((l6 = (l5 = \u13e8 - (0x590CL ^ 0x4D7106DC12D93BF7L)) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) continue;
                if (l6 == (0x528C ^ 0xFFFFAD73)) {
                    return new MapCoordinate(string, n, n2);
                }
                l6 = -958244836 >>> "\u0000\u0000".length();
            }
        }
    }

    public static class BehemothSpawn {
        protected static long \u13e8 = -2406166522648459635L;

        public BehemothSpawn() {
            while (true) {
                long l;
                long l2;
                if ((l2 = (l = \u13e8 - (0x43DFL ^ 0x77829CD121172BD3L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
                if (l2 == (0x6B7B ^ 0xFFFF9484)) break;
                l2 = 0x5F2C ^ 0x3559FCA0;
            }
        }

        /*
         * Enabled aggressive block sorting
         */
        public static IMapCoordinate BL_1() {
            while (true) {
                long l;
                long l2;
                if ((l2 = (l = \u13e8 - (0x42D3L ^ 0x7C7004FE9B2CA2EBL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
                if (l2 == (0x622C ^ 0xFFFF9DD3)) break;
                l2 = 966159144 >>> "\u0000\u0000".length();
            }
            while (true) {
                long l;
                long l3;
                if ((l3 = (l = \u13e8 - (4404791658419672436L >>> "\u0000\u0000".length())) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
                if (l3 == (0x4FE7 ^ 0xFFFFB018)) break;
                l3 = 0x3E34 ^ 0x57AC51D6;
            }
            String string = StarManager.BL_MAPS[0x1E71 ^ 0x1E71];
            int n = 232 >>> "\u0000\u0000".length();
            long l = \u13e8;
            block6: while (true) {
                switch ((int)l) {
                    case -887486835: {
                        return new MapCoordinate(string, 0x312E ^ 0x31EC, n);
                    }
                    case 213098078: {
                        l = (3856664786148098352L >>> "\u0000\u0000".length()) / (0x1C11L ^ 0x821FDFE840C90684L);
                        continue block6;
                    }
                }
                break;
            }
            return new MapCoordinate(string, 0x312E ^ 0x31EC, n);
        }

        public static IMapCoordinate BL_2() {
            while (true) {
                long l;
                long l2;
                if ((l2 = (l = \u13e8 - (0x7917L ^ 0x334A9FCE4609ED20L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (l2 == (0x58E9 ^ 0xFFFFA716)) break;
                l2 = 0x10FA ^ 0x8427ABF3;
            }
            while (true) {
                long l;
                long l3;
                if ((l3 = (l = \u13e8 - (4915998181214529056L >>> "\u0000\u0000".length())) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (l3 == (0x9F8 ^ 0xFFFFF607)) break;
                l3 = 0x7E68 ^ 0xB8B352C1;
            }
            String string = StarManager.BL_MAPS["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
            while (true) {
                long l;
                long l4;
                if ((l4 = (l = \u13e8 - (0x6DA3L ^ 0x8F80CE13CB59BAD2L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (l4 == (0x2943 ^ 0x2942)) break;
                l4 = 1210265200 >>> "\u0000\u0000".length();
            }
            return new MapCoordinate(string, 0x22EB ^ 0x22AE, 0x4019 ^ 0x402B);
        }

        /*
         * Unable to fully structure code
         */
        public static IMapCoordinate BL_3() {
            while (true) {
                if ((v0 = (cfr_temp_0 = BehemothSpawn.\u13e8 - (1249L ^ -7599106635911207333L)) == 0L ? 0 : (cfr_temp_0 < 0L ? -1 : 1)) == false) {
                    continue;
                }
                if (v0 == (26509 ^ 26508)) break;
                v0 = 6667 ^ 554871905;
            }
            v1 = BehemothSpawn.\u13e8;
            if (true) ** GOTO lbl11
            block12: while (true) {
                v1 = v2 / (26680L ^ -645336545283981447L);
lbl11:
                // 2 sources

                switch ((int)v1) {
                    case -887486835: {
                        break block12;
                    }
                    case 219572897: {
                        v2 = 29041L ^ 1144327967829021147L;
                        continue block12;
                    }
                    case 921731190: {
                        v2 = 28728L ^ 9193930714458524373L;
                        continue block12;
                    }
                    case 2088894676: {
                        v2 = 30605L ^ -7817706356834026457L;
                        continue block12;
                    }
                }
                break;
            }
            v3 = StarManager.BL_MAPS[17311 ^ 17309];
            v4 = 188 >>> "\u0000\u0000".length();
            v5 = BehemothSpawn.\u13e8;
            if (true) ** GOTO lbl29
            block13: while (true) {
                v5 = v6 / (19466L ^ 7962608583928316307L);
lbl29:
                // 2 sources

                switch ((int)v5) {
                    case -1670872524: {
                        v6 = 5936L ^ 645772101965511316L;
                        continue block13;
                    }
                    case -887486835: {
                        break block13;
                    }
                    case -325346287: {
                        v6 = 14650L ^ 8775528661361293004L;
                        continue block13;
                    }
                }
                break;
            }
            return new MapCoordinate(v3, v4, 19985 ^ 20022);
        }
    }
}

