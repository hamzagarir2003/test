/*
 * Decompiled with CFR 0.152.
 */
package com.tawaret.tawaplugin.debugging;

import com.tawaret.tawaplugin.debugging.DebugLogger;

public interface IDebuggable {
    default public String name() {
        return this.getClass().getSimpleName();
    }

    default public void debugLog(String msg) {
        DebugLogger.Log(msg, this.name());
    }
}

