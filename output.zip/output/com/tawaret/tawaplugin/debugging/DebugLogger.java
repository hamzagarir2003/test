/*
 * Decompiled with CFR 0.152.
 */
package com.tawaret.tawaplugin.debugging;

import com.tawaret.tawaplugin.utils.Compilation.CompilationFlags;
import com.tawaret.tawaplugin.utils.Compilation.ExecutionMode;

public class DebugLogger {
    private static long \u13e8 = 745768859705007787L;

    public DebugLogger() {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x7820L ^ 0x7D24A424668EB7A0L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0xAA1 ^ 0xFFFFF55E)) break;
            l2 = 0x4A9D ^ 0x9BCE2;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void Log(String log, String name) {
        while (true) {
            long l;
            long l2;
            if ((l2 = (l = \u13e8 - (0x74D8L ^ 0xBF783672DD2ACBF0L)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l2 == (0x75AE ^ 0x75AF)) break;
            l2 = 0x3EFC ^ 0xC9B0A7D4;
        }
        while (true) {
            long l;
            long l3;
            if ((l3 = (l = \u13e8 - (0x1860L ^ 0xDB1AB8B23225832DL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l3 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l3 = 0x1D15 ^ 0x141A536F;
        }
        if (CompilationFlags.EXECUTION_MODE == ExecutionMode.PROD) return;
        while (true) {
            long l;
            long l4;
            if ((l4 = (l = \u13e8 - (0x4AE5L ^ 0x982C5B97B3E7F19FL)) == 0L ? 0 : (l < 0L ? -1 : 1)) == false) continue;
            if (l4 == "\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()) break;
            l4 = 0x1E06 ^ 0xBA64E3CB;
        }
        byte[] byArray = new byte[0x7ABA ^ 0x7AA8];
        byArray[0x34C7 ^ 0x34C4] = 0x2BA9 ^ 0x2BCD;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 496 >>> "\u0000\u0000".length();
        byArray[0x5F61 ^ 0x5F6A] = 264 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x7A43 ^ 0x7A1E;
        byArray[0x194D ^ 0x1945] = 0x5997 ^ 0x59CC;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 276 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x7666 ^ 0x763B;
        byArray[0x3DB5 ^ 0x3DBA] = 0x6882 ^ 0x68A2;
        byArray["".length() >>> "\u0000\u0000".length()] = 364 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 148 >>> "\u0000\u0000".length();
        byArray[0x6D4E ^ 0x6D4A] = 0x7D94 ^ 0x7DC0;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x4292 ^ 0x42B2;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x44A6 ^ 0x44F3;
        byArray[0xC1 ^ 0xD0] = 460 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 272 >>> "\u0000\u0000".length();
        byArray[0x44E8 ^ 0x44ED] = 0x123B ^ 0x126C;
        byArray[0x77D4 ^ 0x77D6] = 460 >>> "\u0000\u0000".length();
        byArray[0x39D ^ 0x390] = 284 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x1BC4 ^ 0x1BE1;
        String string = new String(byArray);
        Object[] objectArray = new Object["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()];
        objectArray["".length() >>> "\u0000\u0000".length()] = name;
        objectArray[0x158F ^ 0x158E] = log;
        long l = \u13e8;
        block7: while (true) {
            switch ((int)l) {
                case -1622942037: {
                    break block7;
                }
                case -251122458: {
                    l = (0xD4AL ^ 0x9B30C3B0702C319BL) / (0x5AADL ^ 0xBDB409ACCCB3A108L);
                    continue block7;
                }
            }
            break;
        }
        String string2 = String.format(string, objectArray);
        while (true) {
            long l5;
            long l6;
            if ((l6 = (l5 = \u13e8 - (1822237682905776332L >>> "\u0000\u0000".length())) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) continue;
            if (l6 == (0x7739 ^ 0x7738)) {
                System.out.println(string2);
                return;
            }
            l6 = 0x6168 ^ 0xC5B428F1;
        }
    }
}

