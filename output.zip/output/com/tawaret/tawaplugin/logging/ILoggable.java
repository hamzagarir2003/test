/*
 * Decompiled with CFR 0.152.
 */
package com.tawaret.tawaplugin.logging;

import com.tawaret.tawaplugin.logging.Logger;

public interface ILoggable {
    default public String name() {
        return this.getClass().getSimpleName();
    }

    default public void log(String msg) {
        Logger.Log(msg, this.name());
    }
}

