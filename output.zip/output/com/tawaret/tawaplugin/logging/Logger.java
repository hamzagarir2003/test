/*
 * Decompiled with CFR 0.152.
 */
package com.tawaret.tawaplugin.logging;

public class Logger {
    public static long \u13e8 = -6496759184203523213L;

    /*
     * Enabled aggressive block sorting
     */
    public Logger() {
        long l = \u13e8;
        block4: while (true) {
            switch ((int)l) {
                case 1541086558: {
                    l = (0x1A28L ^ 0x1A02025B427BAB4FL) / (0x4F86L ^ 0x751404CF1062FE84L);
                    continue block4;
                }
                case 2051726195: {
                    break block4;
                }
            }
            break;
        }
    }

    /*
     * Handled impossible loop by adding 'first' condition
     * Enabled aggressive block sorting
     */
    public static void Log(String log, String name) {
        long l = \u13e8;
        boolean bl = true;
        block5: while (true) {
            long l2;
            if (!bl || (bl = false) || !true) {
                l = l2 / (0x5688L ^ 0x7DC7428F417D81E1L);
            }
            switch ((int)l) {
                case -1880106497: {
                    l2 = 0x39C4L ^ 0x7720AB90F32B1CBEL;
                    continue block5;
                }
                case 496744562: {
                    l2 = 1354543380537566464L >>> "\u0000\u0000".length();
                    continue block5;
                }
                case 2051726195: {
                    break block5;
                }
            }
            break;
        }
        byte[] byArray = new byte[0x880 ^ 0x88A];
        byArray[0x234C ^ 0x2349] = 0x2F08 ^ 0xFFFFD0DB;
        byArray[0x6D48 ^ 0x6D4D] = 348 >>> "\u0000\u0000".length();
        byArray["".length() >>> "\u0000\u0000".length()] = 0x5C3 ^ 0x598;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 460 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 336 >>> "\u0000\u0000".length();
        byArray[0x63B7 ^ 0x63B0] = 0x296B ^ 0x294B;
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 460 >>> "\u0000\u0000".length();
        byArray["\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000".length() >>> "\u0000\u0000".length()] = 0x6764 ^ 0x6741;
        byArray[0x5AB ^ 0x5AA] = 148 >>> "\u0000\u0000".length();
        byArray[0x3F2 ^ 0x3F1] = 0x404F ^ 0x4033;
        byArray[0x7C12 ^ 0x7C14] = 0x5949 ^ 0x5914;
        String string = new String(byArray);
        Object[] objectArray = new Object[0x5F20 ^ 0x5F22];
        objectArray[0x1F96 ^ 0x1F96] = name;
        objectArray[0x6329 ^ 0x6328] = log;
        while (true) {
            long l3;
            long l4;
            if ((l4 = (l3 = \u13e8 - (0x446BL ^ 0xDAE37A1A8AB94441L)) == 0L ? 0 : (l3 < 0L ? -1 : 1)) == false) continue;
            if (l4 == (0x23F4 ^ 0xFFFFDC0B)) break;
            l4 = 0x6C2A ^ 0x469BA2CE;
        }
        String string2 = String.format(string, objectArray);
        while (true) {
            long l5;
            long l6;
            if ((l6 = (l5 = \u13e8 - (0x60B0L ^ 0x5EFE2CFC85DA4FF2L)) == 0L ? 0 : (l5 < 0L ? -1 : 1)) == false) continue;
            if (l6 == (0x793D ^ 0xFFFF86C2)) {
                System.out.println(string2);
                return;
            }
            l6 = 1940510484 >>> "\u0000\u0000".length();
        }
    }
}

